# mock-server

Mock server z dynamicznym panelem admina, generowany z pliku OpenAPI (Swagger).

## Szybki start

### 1. Zainstaluj zależności mock-servera

```bash
npm install express cors http-proxy-middleware js-yaml concurrently nodemon --save-dev
```

### 2. Uruchom aplikację z mockami

```bash
npm run start:mock
```

Skrypt odpala jednocześnie:
- `mock-server` na porcie **:4000**
- `ng serve` z proxy i konfiguracją mock

### 3. Otwórz panel admina

```
http://localhost:4000/admin
```

---

## Struktura plików

```
mock/
├── server.js              ← Express server + proxy + admin REST API
├── openapi-parser.js      ← Parser OpenAPI → routing table
├── openapi.yaml           ← Specyfikacja API (edytuj pod swój projekt)
├── responses/
│   ├── users.json         ← Dane mockowe dla tagu "Users"
│   ├── auth.json          ← Dane mockowe dla tagu "Auth"
│   ├── products.json      ← Dane mockowe dla tagu "Products"
│   └── orders.json        ← Dane mockowe dla tagu "Orders"
└── admin-ui/
    └── index.html         ← Panel admina (standalone HTML)

src/
├── environments/
│   ├── environment.ts           ← { apiUrl: '/backend-api' }
│   └── environment.mock.ts      ← { apiUrl: '/backend-api' }
├── proxy.mock.conf.js           ← /backend-api → http://localhost:4000
└── app/core/services/
    └── api.service.ts           ← Przykładowy serwis Angular
```

---

## Konfiguracja

### Własna specyfikacja OpenAPI

Zastąp `mock/openapi.yaml` swoim plikiem. Serwer automatycznie:
- wczyta wszystkie ścieżki i metody HTTP
- wygeneruje routing table na podstawie `operationId` lub `method+path`
- dopasuje dane z `responses/` po nazwie tagu

### Dodawanie odpowiedzi mockowych

W pliku `mock/responses/<tag>.json` dodaj klucz pasujący do `operationId`:

```json
{
  "users-list": {
    "200": { "body": [{ "id": 1, "name": "Jan" }] },
    "500": { "body": { "error": "DB error" } }
  }
}
```

### Zmiana adresu real API

```bash
REAL_API_URL=https://api.twojadomena.com node mock/server.js
```

lub ustaw w `mock/server.js`:
```js
const REAL_API_URL = process.env.REAL_API_URL ?? 'https://api.twojadomena.com';
```

---

## Admin REST API

| Metoda | Ścieżka | Opis |
|--------|---------|------|
| `GET`  | `/api/admin/routes` | Lista wszystkich endpointów |
| `PATCH`| `/api/admin/routes/:id` | Zmień tryb (`useMock`) lub aktywną odpowiedź (`activeResponseIndex`) |
| `POST` | `/api/admin/routes/bulk` | Masowe przełączenie `{ useMock: true/false }` |
| `POST` | `/api/admin/reload` | Przeładuj konfigurację z pliku |
| `GET`  | `/api/admin/status` | Status serwera |

### Przykłady curl

```bash
# przełącz endpoint na real
curl -X PATCH http://localhost:4000/api/admin/routes/users-list \
  -H 'Content-Type: application/json' \
  -d '{"useMock": false}'

# wybierz zwrotkę 409 (index 1)
curl -X PATCH http://localhost:4000/api/admin/routes/users-create \
  -H 'Content-Type: application/json' \
  -d '{"activeResponseIndex": 1}'

# wszystkie na mock
curl -X POST http://localhost:4000/api/admin/routes/bulk \
  -H 'Content-Type: application/json' \
  -d '{"useMock": true}'
```

---

## Konfiguracja Angular

### angular.json — dodaj konfigurację `mock`

```json
"serve": {
  "configurations": {
    "mock": {
      "proxyConfig": "src/proxy.mock.conf.js",
      "fileReplacements": [{
        "replace": "src/environments/environment.ts",
        "with": "src/environments/environment.mock.ts"
      }]
    }
  }
}
```

### package.json — skrypt startowy

```json
"start:mock": "concurrently \"node mock/server.js\" \"ng serve --configuration=mock\""
```

---

## Jak działa proxy

```
Angular HttpClient
  → /backend-api/users
  → proxy.mock.conf.js (tylko w trybie mock)
  → http://localhost:4000/users
  → mock-server sprawdza routingTable
  → zwraca mock JSON  OR  proxy → real API
```

Angular **zawsze** używa aliasu `/backend-api`. Podmiana następuje wyłącznie przez `proxy.mock.conf.js` i `ng serve --configuration=mock`. Kod produkcyjny nie jest zmieniany.
