module.exports = {
  '/backend-api': {
    target: 'http://localhost:4000',
    pathRewrite: { '^/backend-api': '' },
    changeOrigin: true,
    logLevel: 'warn',
    secure: false
  }
};
