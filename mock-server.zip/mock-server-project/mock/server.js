'use strict';

const express = require('express');
const cors = require('cors');
const path = require('path');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { buildRoutingTable } = require('./openapi-parser');

const app = express();
const PORT = process.env.MOCK_PORT ?? 4000;
const REAL_API_URL = process.env.REAL_API_URL ?? 'http://localhost:8080';
const OPENAPI_PATH = path.resolve(__dirname, 'openapi.yaml');
const RESPONSES_DIR = path.resolve(__dirname, 'responses');

app.use(cors());
app.use(express.json());

// serwuj panel admina jako statyczny HTML
app.use('/admin', express.static(path.join(__dirname, 'admin-ui')));

// ── stan serwera ─────────────────────────────────────────
let routingTable = buildRoutingTable(OPENAPI_PATH, RESPONSES_DIR);

// ── Admin API ─────────────────────────────────────────────

// GET /api/admin/routes — lista wszystkich endpointów
app.get('/api/admin/routes', (req, res) => {
  res.json(Object.values(routingTable));
});

// PATCH /api/admin/routes/:id — zmień tryb lub aktywną odpowiedź
app.patch('/api/admin/routes/:id', (req, res) => {
  const route = routingTable[req.params.id];
  if (!route) return res.status(404).json({ error: 'Route not found' });

  if (req.body.useMock !== undefined) {
    route.useMock = Boolean(req.body.useMock);
  }
  if (req.body.activeResponseIndex !== undefined) {
    const idx = parseInt(req.body.activeResponseIndex);
    if (idx >= 0 && idx < route.responses.length) {
      route.activeResponseIndex = idx;
    }
  }
  res.json(route);
});

// POST /api/admin/routes/bulk — masowe przełączenie mock/real
app.post('/api/admin/routes/bulk', (req, res) => {
  const { useMock } = req.body;
  if (typeof useMock !== 'boolean') {
    return res.status(400).json({ error: 'useMock must be boolean' });
  }
  Object.values(routingTable).forEach(r => (r.useMock = useMock));
  res.json({ ok: true, updated: Object.keys(routingTable).length });
});

// POST /api/admin/reload — przeładuj konfigurację z pliku
app.post('/api/admin/reload', (req, res) => {
  try {
    routingTable = buildRoutingTable(OPENAPI_PATH, RESPONSES_DIR);
    res.json({ ok: true, count: Object.keys(routingTable).length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/admin/status — info o serwerze
app.get('/api/admin/status', (req, res) => {
  const routes = Object.values(routingTable);
  res.json({
    port: PORT,
    realApiUrl: REAL_API_URL,
    totalRoutes: routes.length,
    mockRoutes: routes.filter(r => r.useMock).length,
    realRoutes: routes.filter(r => !r.useMock).length
  });
});

// ── Proxy / mock middleware ───────────────────────────────
app.use((req, res, next) => {
  // pomiń ścieżki admina
  if (req.path.startsWith('/api/admin') || req.path.startsWith('/admin')) {
    return next();
  }

  const route = findRoute(req.method, req.path);
  if (!route) {
    return res.status(404).json({ error: `No route for ${req.method} ${req.path}` });
  }

  if (route.useMock) {
    const response = route.responses[route.activeResponseIndex];
    console.log(`[mock] ${req.method} ${req.path} → ${response.status}`);
    if (response.body === null) {
      return res.status(response.status).end();
    }
    return res.status(response.status).json(response.body);
  }

  console.log(`[proxy] ${req.method} ${req.path} → ${REAL_API_URL}`);
  createProxyMiddleware({
    target: REAL_API_URL,
    changeOrigin: true,
    logLevel: 'warn'
  })(req, res, next);
});

function findRoute(method, reqPath) {
  return Object.values(routingTable).find(r => {
    if (r.method !== method.toUpperCase()) return false;
    const pattern = '^' + r.path.replace(/:[^/]+/g, '[^/]+') + '$';
    return new RegExp(pattern).test(reqPath);
  }) ?? null;
}

app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════╗');
  console.log('║        mock-server uruchomiony        ║');
  console.log('╠══════════════════════════════════════╣');
  console.log(`║  API:    http://localhost:${PORT}         ║`);
  console.log(`║  Admin:  http://localhost:${PORT}/admin   ║`);
  console.log(`║  Real:   ${REAL_API_URL.padEnd(26)} ║`);
  console.log('╚══════════════════════════════════════╝');
  console.log('');
});
