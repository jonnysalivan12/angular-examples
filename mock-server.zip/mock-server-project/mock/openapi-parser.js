'use strict';

const fs = require('fs');
const yaml = require('js-yaml');
const path = require('path');

const HTTP_METHODS = ['get', 'post', 'put', 'patch', 'delete', 'head', 'options'];

function toExpressPath(openapiPath) {
  return openapiPath.replace(/\{(\w+)\}/g, ':$1');
}

function inferDefaultBody(status) {
  const s = parseInt(status);
  if (s === 204) return null;
  if (s >= 500) return { error: 'Internal server error' };
  if (s === 404) return { error: 'Not found' };
  if (s === 401) return { error: 'Unauthorized' };
  if (s === 403) return { error: 'Forbidden' };
  if (s === 409) return { error: 'Conflict' };
  if (s === 422) return { error: 'Unprocessable entity' };
  if (s === 400) return { error: 'Bad request' };
  if (s === 402) return { error: 'Payment required' };
  if (s >= 400) return { error: `HTTP ${s}` };
  return {};
}

function buildRoutingTable(openapiPath, responsesDir) {
  const raw = fs.readFileSync(openapiPath, 'utf-8');
  const spec = openapiPath.endsWith('.json')
    ? JSON.parse(raw)
    : yaml.load(raw);

  const table = {};

  for (const [openapiPathStr, pathItem] of Object.entries(spec.paths || {})) {
    for (const method of HTTP_METHODS) {
      const operation = pathItem[method];
      if (!operation) continue;

      const tag = (operation.tags?.[0] ?? 'default').toLowerCase();
      const id =
        operation.operationId ??
        `${method}-${openapiPathStr.replace(/[^a-zA-Z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '')}`;

      // załaduj responses z pliku per-tag
      let savedResponses = {};
      const responsesFile = path.join(responsesDir, `${tag}.json`);
      if (fs.existsSync(responsesFile)) {
        try {
          savedResponses = JSON.parse(fs.readFileSync(responsesFile, 'utf-8'));
        } catch (e) {
          console.warn(`[parser] Nie mogę wczytać ${responsesFile}:`, e.message);
        }
      }

      const savedForId = savedResponses[id] ?? {};

      const responses = Object.entries(operation.responses ?? {}).map(([statusStr, respSpec]) => {
        const status = parseInt(statusStr);
        const saved = savedForId[statusStr];
        return {
          status,
          label: respSpec.description ?? `HTTP ${status}`,
          body: saved?.body !== undefined ? saved.body : inferDefaultBody(statusStr)
        };
      });

      if (responses.length === 0) {
        responses.push({ status: 200, label: 'OK', body: {} });
      }

      table[id] = {
        id,
        method: method.toUpperCase(),
        path: toExpressPath(openapiPathStr),
        openapiPath: openapiPathStr,
        tag: operation.tags?.[0] ?? 'default',
        summary: operation.summary ?? '',
        useMock: true,
        activeResponseIndex: 0,
        responses
      };
    }
  }

  console.log(`[parser] Załadowano ${Object.keys(table).length} endpointów z ${openapiPath}`);
  return table;
}

module.exports = { buildRoutingTable };
