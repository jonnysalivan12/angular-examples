# Zmiany w pluginie figma-design-ir

Najnowsza wersja jest na górze. Nagłówek wersji ma datę wydania. Zainstalowaną wersję pokazuje `copilot plugin list`.

## 0.1.0

Pierwsza wersja.

- Serwer MCP `figma-design-ir` daje każdemu agentowi Copilota cztery narzędzia: `frame_to_ir`, `compare_frames`, `get_frame_image` i `audit_frame`.
- Z tego serwera korzystają pluginy figma-designer, figma-analyst i task-flow w trybie `frontend`.
- Repozytorium projektu musi mieć plik `.github/plugin/figma-design-ir/settings.json` z folderem wyników w polu `outputDir`.
- Plik zmiennych, mapa komponentów i mapa zmiennych CSS pochodzą z repozytorium projektu (`variables.json`, `component-map.json`, `css-variable-map.json` w tym samym folderze) albo z plików domyślnych pluginu. Gdy narzędzie potrzebuje pliku, którego nie ma w żadnym z tych miejsc, kończy pracę błędem ze ścieżką pliku do dodania.
- Komponenty utworzone w pliku z makietami, spoza DS, mają osobną mapę. Wskazuje ją opcjonalne pole `localComponentMap` w `settings.json`. Bez niej takie komponenty nie mają odpowiedników. `component-map.json` opisuje tylko komponenty z biblioteki DS.
- Serwer kończy pracę, gdy Copilot zamknie jego wejście, także w trakcie zapytania do Figmy. Każde zapytanie do Figmy ma limit czasu 60 s, więc zawieszone połączenie nie trzyma procesu.
- Plugin nie ma jeszcze plików domyślnych.
