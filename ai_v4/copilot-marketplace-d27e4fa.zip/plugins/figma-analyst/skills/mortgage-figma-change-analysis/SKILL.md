---
name: mortgage-figma-change-analysis
description: Opisuje zmiany między dwiema wersjami tej samej ramy w Figmie językiem analityka (treść, pola, akcje, kolejność i wygląd) ze wskazaniem, czego dotyczą w wymaganiach. Użyj, gdy analityk pyta, co zmieniło się w makiecie, albo chce sprawdzić, czy zmiana makiety wymaga zmiany wymagań.
---

# Analiza zmian w makiecie

Ten skill porównuje dwie wersje tej samej ramy narzędziem `compare_frames`
serwera MCP `figma-design-ir` z pluginu figma-design-ir i opisuje zmiany tak,
żeby analityk mógł ocenić ich wpływ na wymagania. Gdy narzędzia nie ma, nie
używaj innych narzędzi Figmy. Odpowiedz tylko tym błędem i zakończ:

```text
Błąd: brak serwera MCP figma-design-ir. Zainstaluj plugin poleceniem
copilot plugin install figma-design-ir@mortgage-copilot-tools i rozpocznij nową sesję Copilota.
```

Opis zawiera tylko zmiany z wyniku porównania. Skutków dla wymagań nie
rozstrzygaj. Wskaż tylko, czego dotyczy zmiana.

## Pliki

W argumencie `project_dir` każdego narzędzia podawaj ścieżkę bezwzględną
folderu roboczego: folderu otwartego w edytorze albo folderu, w którym
uruchomiono Copilota. Folder wyników serwer wybiera sam według ustawień
projektu.

## Źródła

Porównanie działa dla dwóch wersji tej samej ramy. Dwie różne ramy, także
kopia ramy, mają w Figmie inne identyfikatory warstw, więc narzędzie zwróci
błąd.

1. Stan późniejszy to zwykle link do ramy. Link bez `version-id` wskazuje
   bieżącą wersję pliku.
2. Stan wcześniejszy to jedno z dwóch:
   - Link do ramy z parametrem `version-id`. Link do wersji kopiuje się
     w historii wersji pliku („Copy link” przy wybranej wersji). Gdy ten link
     nie ma `node-id`, dopisz jego parametr `version-id` do linku ramy. Gdy
     nie ma parametru `version-id`, napisz, że nie da się z niego odczytać
     wersji, i poproś o inne źródło.
   - Plik IR zapisany wcześniej narzędziem `frame_to_ir`, na przykład przy
     opisie ekranu.

## Kroki

1. Ustal oba źródła.
2. Wywołaj `compare_frames`: stan wcześniejszy w `before`, stan późniejszy
   w `after`, a w `html_file` nazwę pliku `<klucz>__<node-id>.diff.html`.
   Serwer zapisze go w folderze wyników.
3. Gdy narzędzie zwraca błąd, przekaż analitykowi jego treść i zakończ.
4. Przypisz każdy wpis z `design_ir_diff` do jednej grupy:
   - Treść: wpis z `changed`, którego pole to `text` albo zaczyna się od
     `inputs.` (etykieta, wartość, tekst zastępczy, tekst pomocniczy, stan).
   - Pola i akcje: wpisy z `added` i `removed`, wpis z `changed` z polem `ref`
     (inny komponent, np. pole tekstowe zamienione na listę wyboru).
   - Kolejność: wpisy z `moved`.
   - Komponenty do zbudowania: wpisy ze ścieżką zaczynającą się od
     `components_to_build`.
   - Wygląd: pozostałe wpisy z `changed`, na przykład pola `styles.`,
     `visual.`, `layout.`, `typography.` i `container.`.
5. Napisz opis według wzoru poniżej. Element wskazuj ścieżką nazw warstw
   z `path`, bez pierwszego członu `layout`.

## Wzór opisu

```markdown
# Zmiany w <nazwa ramy>

Przed: <źródło>, wersja <file_version>. Po: <źródło>, wersja <file_version>.
Strona z obrysami zmian: <html_file>.

## Treść
- <element>: <co> „<przed>” → „<po>”

## Pola i akcje
- Dodane: <element i jego etykieta albo „brak”>
- Usunięte: <element i jego etykieta albo „brak”>
- Zmieniony rodzaj: <element: komponent przed → po albo „brak”>

## Kolejność
- <element>: <rodzic i pozycja przed> → <rodzic i pozycja po>

## Komponenty do zbudowania
- <komponent: co się zmieniło albo „brak”>

## Wygląd
<liczba zmian wyglądu w jednym zdaniu; listę podaj na prośbę>

## Do sprawdzenia w wymaganiach
- <zmiana z grup Treść, Pola i akcje albo Kolejność> → <czego dotyczy:
  etykieta, lista pól, akcja, kolejność kroków>
```

Gdy wszystkie liczby w `summary` wynoszą 0, napisz tylko, że wersje się nie
różnią.
