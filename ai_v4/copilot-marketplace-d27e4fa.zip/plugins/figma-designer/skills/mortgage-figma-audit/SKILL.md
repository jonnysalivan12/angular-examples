---
name: mortgage-figma-audit
description: Sprawdza, czy rama w Figmie jest przygotowana do przekazania programistom, i od razu podaje prompt naprawy dla agenta Figmy, bez pytań do projektanta. Użyj, gdy projektant podaje link do ramy i prosi o audyt, sprawdzenie albo przygotowanie makiety.
---

# Audyt makiety w Figmie

Ten skill sprawdza ramę i od razu podaje prompt naprawy dla agenta Figmy. Nie
zadaje projektantowi pytań i nie czeka na potwierdzenie. Makiety nie zmienia.
Poprawki wprowadza agent Figmy w pliku projektu, gdy projektant wklei mu
prompt.

Audyt wykonuje narzędzie `audit_frame` serwera MCP `figma-design-ir` z pluginu
figma-design-ir. Gdy tego narzędzia nie ma, nie używaj innych narzędzi Figmy.
Odpowiedz tylko tym błędem i zakończ:

```text
Błąd: brak serwera MCP figma-design-ir. Zainstaluj plugin poleceniem
copilot plugin install figma-design-ir@mortgage-copilot-tools i rozpocznij nową sesję Copilota.
```

## Jak pisać

- Rozmówca jest projektantem. Pisz prostym językiem, bez ścieżek plików,
  JSON-a i komunikatów narzędzi.
- Warstwy wskazuj nazwami z Figmy, tak jak podaje je wynik audytu.
- Nie zadawaj pytań. Zmienne i style do przypięcia wybiera prompt (część
  „Zmienne w prompcie”).

## Pliki

W argumencie `project_dir` każdego narzędzia podawaj ścieżkę bezwzględną
folderu roboczego: folderu otwartego w edytorze albo folderu, w którym
uruchomiono Copilota. Folder wyników serwer wybiera sam według ustawień
projektu.

## Kroki

1. Gdy projektant nie podał linku do ramy, napisz, że potrzebny jest link
   z `node-id`, i jak go skopiować: w Figmie zaznacz ramę i wybierz
   „Copy link to selection”. Zakończ.
2. Wywołaj `audit_frame` raz, z linkiem w `figma_url` i folderem roboczym
   w `project_dir`. Nie podawaj `decisions`.
3. Gdy narzędzie zwraca błąd, przekaż projektantowi jego treść prostymi słowami
   razem z zaleceniem i zakończ.
4. Gdy `summary.total` wynosi 0, napisz, że rama jest gotowa, i zakończ.
5. Napisz odpowiedź według części „Odpowiedź”.

Gdy projektant poprosi o ponowny audyt po naprawie, wywołaj `audit_frame`
z `refresh: true` i wróć do kroku 3.

## Odpowiedź

1. Uchybienia: jedna linia na regułę, która ma uchybienia, z ich liczbą
   i z warstwami z `examples`. Nazwy reguł:

   | Reguła w wyniku | Nazwa dla projektanta |
   |---|---|
   | `no-auto-layout` | kontener bez auto layoutu |
   | `raw-value` | wartość wpisana ręcznie zamiast zmiennej |
   | `shadow-without-style` | cień bez stylu efektu |
   | `text-without-style` | tekst bez stylu tekstu i bez zmiennych czcionki |
   | `default-layer-name` | warstwa z domyślną nazwą |
   | `component-definition-in-frame` | definicja komponentu w ramie zamiast instancji |
   | `hidden-layer` | ukryta warstwa |
   | `empty-container` | pusty kontener |
   | `repeated-structure` | powtórzona budowa: kandydat na komponent |

   Uchybienie z polem `component` dotyczy komponentu głównego. Powiedz to przy
   tej warstwie.
2. Reguły `hidden-layer`, `empty-container` i `repeated-structure` pokaż
   osobno, jako sprawy do decyzji projektanta. Prompt naprawy ich nie obejmuje.
   Przy `repeated-structure` wymień wszystkie wystąpienia z `layer_paths`.
3. Prompt naprawy: treść `fix_prompt` w bloku kodu. Nie zmieniaj w niej ani
   słowa. Gdy `fix_prompt` jest pusty, napisz, że prompt nie ma czego naprawić,
   i pomiń punkt 4.
4. Instrukcja:
   1. W Figmie zaznacz audytowaną ramę.
   2. Otwórz agenta: przycisk „Agents” albo Ctrl+Enter (Cmd+Enter na Macu).
   3. Wklej prompt i wyślij.
   4. Sprawdź, czy rama wygląda tak samo jak przed poprawkami. Zmianę cofa
      Ctrl+Z.

## Zmienne w prompcie

Narzędzie samo wpisuje do promptu zmienne i style do przypięcia:

- Gdy rama używa już jednej zmiennej albo jednego stylu przy tej samej
  wartości, prompt wskazuje tę zmienną albo ten styl.
- W innym przypadku prompt każe agentowi Figmy znaleźć zmienną albo styl
  o tej samej wartości w podłączonej bibliotece.
