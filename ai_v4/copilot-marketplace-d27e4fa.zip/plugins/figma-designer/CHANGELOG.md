# Zmiany w pluginie figma-designer

Najnowsza wersja jest na górze. Nagłówek wersji ma datę wydania. Zainstalowaną wersję pokazuje `copilot plugin list`.

## 0.1.0

Pierwsza wersja.

- Skill `mortgage-figma-audit` sprawdza ramę z Figmy i od razu podaje prompt dla agenta Figmy, bez pytań. Zmienne do przypięcia prompt wskazuje sam albo każe agentowi Figmy znaleźć je w podłączonej bibliotece.
- Prompt naprawia kontenery bez auto layoutu, wartości bez zmiennej i stylu, cienie bez stylu efektu, teksty bez stylu tekstu i zmiennych czcionki, domyślne nazwy warstw i definicje komponentów w ramie.
- Ukryte warstwy, puste kontenery i powtórzoną budowę kontenerów skill pokazuje do Twojej decyzji. Prompt ich nie naprawia.
- Pliki wyników trafiają do folderu z pola `outputDir` w pliku `.github/plugin/figma-design-ir/settings.json` repozytorium projektu.
- Plugin wymaga pluginu figma-design-ir z serwerem MCP Figmy. Bez niego skill kończy pracę błędem i podaje polecenie instalacji.
