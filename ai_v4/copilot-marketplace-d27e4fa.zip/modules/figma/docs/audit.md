# Audyt makiety

`audit-design.js` sprawdza ramę i pisze prompt naprawy dla agenta Figmy. Narzędzie `audit_frame` serwera MCP robi to samo, ale prompt naprawy podaje tylko w odpowiedzi, bez zapisu w pliku.

## Uruchomienie

```bash
node audit-design.js "<link do ramy>"
```

Skrypt zapisuje w `ir/` dwa pliki:

1. `<klucz>__<node-id>.audit.json`: wynik audytu.
2. `<klucz>__<node-id>.fix-prompt.md`: prompt naprawy. Plik nie powstaje, gdy prompt nie ma czego naprawić.

## Reguły z poprawką w prompcie

| Reguła | Uchybienie | Skutek w IR |
|---|---|---|
| `no-auto-layout` | Kontener z tekstem albo komponentem w środku nie ma auto layoutu. | IR nie ma kierunku, odstępów ani położenia dzieci. |
| `raw-value` | Kolor, odstęp, zaokrąglenie albo obrys nie ma zmiennej ani stylu. | IR ma surową wartość zamiast tokenu. |
| `shadow-without-style` | Cień nie ma stylu efektu. | IR ma surowy cień zamiast tokenu. |
| `text-without-style` | Tekst nie ma stylu tekstu ani żadnej zmiennej czcionki (rodzina, rozmiar, grubość, krój, interlinia, odstęp liter). | IR ma surowe wartości czcionki zamiast tokenu. |
| `default-layer-name` | Kontener ma domyślną nazwę Figmy, np. „Frame 12”. | Nazwa warstwy w IR nie mówi, czym warstwa jest. |
| `component-definition-in-frame` | Definicja komponentu stoi w ramie zamiast instancji. | IR opisuje ją jak zwykłą warstwę, a nie jak komponent. |

## Reguły do decyzji projektanta

Te uchybienia są w wyniku audytu, ale nie w prompcie naprawy. Poprawkę wybiera projektant, bo agent Figmy nie wie, czy warstwa jest potrzebna.

| Reguła | Uchybienie | Skutek w IR |
|---|---|---|
| `hidden-layer` | Warstwa jest ukryta. Dotyczy warstw poza instancjami komponentów, których widoczności nie steruje właściwość komponentu. | IR pomija ukryte warstwy, więc stan pokazany taką warstwą nie trafi do programistów. |
| `empty-container` | Ramka albo grupa nie ma widocznych dzieci, wypełnienia, obrysu ani efektu. | IR ma warstwę bez treści i bez wyglądu. |
| `repeated-structure` | Ramka spoza instancji ma tę samą budowę co inne ramki w makiecie: te same typy warstw, kierunek układu i komponenty. Ma co najmniej dwoje dzieci, w tym tekst albo komponent. | Każde wystąpienie jest w IR osobno, a nie jako jeden komponent. |

Szczegóły `repeated-structure`:

- Jeden wpis obejmuje wszystkie wystąpienia: `occurrences`, `node_ids` i `layer_paths`.
- Nazwy warstw i treść tekstów nie wpływają na porównanie budowy.
- Ramka wewnątrz innej powtórzonej struktury nie dostaje osobnego wpisu, bo obejmie ją komponent z tej struktury.

## Zakres audytu

- Audyt nie wchodzi do wnętrza instancji komponentów z biblioteki DS.
- Reguły `no-auto-layout` i `default-layer-name` pomijają kontenery z samą grafiką, np. ikony i ilustracje.
- Uchybienie wewnątrz instancji komponentu lokalnego dotyczy komponentu głównego. Każda warstwa komponentu głównego ma więc jeden wpis z liczbą instancji (`occurrences`).
- Ukrytych warstw i powtórzonych struktur wewnątrz instancji audyt nie zgłasza, bo widoczność i budowę wnętrza ustala komponent.

## Wynik audytu

| Pole | Zawartość |
|---|---|
| `summary` | Liczba uchybień każdej reguły. |
| `findings` | Uchybienia z regułą, identyfikatorem warstwy (`node_id`) i ścieżką nazw warstw z Figmy (`layer_path`). Wpis `repeated-structure` podaje wszystkie wystąpienia. |
| `decisions` | Decyzje, których wymaga naprawa. Każda ma pytanie, podpowiedzi (`suggestions`) i odpowiedź (`answer`). |
| `warnings` | Ostrzeżenia, np. o zmiennych bez nazwy w pliku zmiennych. |
| `prompt_file` | Ścieżka pliku promptu albo `null`. Wynik narzędzia `audit_frame` ma zawsze `null`. |

## Decyzje

Decyzja dotyczy wartości bez zmiennej (`raw-value`), cienia bez stylu (`shadow-without-style`) albo tekstu bez stylu (`text-without-style`). Pyta, którą zmienną albo który styl przypisać.

Decyzja dla tekstu ma wartość w postaci skrótu CSS `font`, np. `typography/400 14px/20px Inter`. Bez odpowiedzi prompt każe przypiąć styl tekstu albo zmienne czcionki o tych samych wartościach.

1. Podpowiedzią jest zmienna albo styl, którego ta sama rama używa już przy tej samej wartości.
2. Gdy decyzja ma jedną podpowiedź, ta podpowiedź jest odpowiedzią.
3. Inną odpowiedź podaje plik z opcji `--decisions`. To obiekt JSON: kluczem jest identyfikator decyzji, a wartością nazwa zmiennej albo stylu.

   ```json
   { "gap/12px": "spacing/md", "background/#ffffff": "surface/0" }
   ```

4. Decyzja bez odpowiedzi daje w prompcie polecenie, żeby agent sam znalazł zmienną o tej samej wartości w podłączonej bibliotece.

## Prompt naprawy

Prompt to tekst po polsku dla agenta Figmy w pliku projektu.

1. Projektant zaznacza audytowaną ramę.
2. Otwiera agenta Figmy przyciskiem „Agents”.
3. Wkleja prompt.

Prompt wymienia warstwy po ścieżce nazw. Każe agentowi zachować wygląd ramy i wypisać warstwy, których nie udało się poprawić.

Figma Make nie nadaje się do tej naprawy. Buduje aplikację z promptu i nie zmienia pliku projektu.

## Audyt w rozmowie z agentem

Audyt dla projektanta prowadzi skill `mortgage-figma-audit` z pluginu `figma-designer`. Skill nie zadaje pytań. W jednej odpowiedzi:

1. uruchamia audyt narzędziem `audit_frame` bez odpowiedzi na decyzje;
2. pokazuje uchybienia i osobno sprawy do decyzji projektanta;
3. podaje prompt.

Decyzje rozstrzyga prompt według punktów 2 i 4 z części „Decyzje”.
