# Serwer MCP

`mcp-server.js` jest serwerem MCP przez stdio. Agent, np. Copilot, wywołuje przez niego te same operacje, które wykonują skrypty.

## Uruchomienie

Serwer uruchamia klient MCP z wpisu w swojej konfiguracji:

```json
{
  "figma-design-ir": {
    "type": "stdio",
    "command": "node",
    "args": ["modules/figma/mcp-server.js"]
  }
}
```

- Copilot CLI czyta wpis z `.mcp.json` repozytorium, a VS Code z `.vscode/mcp.json`.
- Serwer ma nazwę `figma-design-ir`, bo pod tą nazwą wywołują go agenci pluginów Copilota, np. orchestrator z narzędziami `figma-design-ir/*`. Nazwa jest charakterystyczna, żeby serwer pluginu nie zasłonił cudzego serwera o ogólnej nazwie, np. `figma`.
- Plugin `figma-design-ir` ma kopię serwera pod tą samą nazwą. Gdy jest zainstalowany, Copilot CLI uruchamia serwer pluginu zamiast wpisu o tej nazwie z `.mcp.json` repozytorium.

Token:

- Serwer czyta token ze zmiennej `FIGMA_API_KEY` przy każdym wywołaniu narzędzia.
- Zmienna musi być w środowisku klienta MCP.
- Porównanie dwóch plików IR bez `html_file` nie wymaga tokenu.

## Narzędzia

### frame_to_ir

Argumenty: `figma_url`, `project_dir`, opcjonalnie `output_dir` i `refresh`.

Zapisuje plik IR. Zwraca:

- ścieżkę pliku (`ir_file`);
- opis ramy (`frame`);
- liczbę komponentów do zbudowania i otwartych pytań.

Narzędzie zwraca ścieżkę, a nie treść IR. IR jednej ramy ma dziesiątki kilobajtów, więc agent czyta go z pliku. Nazwa pliku jest taka sama jak w `extract-design-ir.js`.

### compare_frames

Argumenty: `before`, `after`, `project_dir`, opcjonalnie `html_file` i `refresh`.

- Źródłem jest ścieżka pliku IR albo link, w dowolnej parze: plik i plik, plik i link, link i link.
- Zwraca `design_ir_diff` w tym samym kształcie co `compare-design-ir.js`.
- Z `html_file` zapisuje też stronę HTML z różnicami na obrazach.

### get_frame_image

Argumenty: `figma_url`, `project_dir`, opcjonalnie `scale` i `output_dir`.

- Zapisuje obraz PNG ramy w pliku `<klucz>__<node-id>.png`. Dla linku z `version-id` plik ma nazwę `<klucz>__<node-id>@<wersja>.png`.
- Zwraca ścieżkę pliku (`image_file`), wersję pliku Figmy, rozmiar w pikselach i sam obraz.
- Skala domyślna to 1, dozwolony zakres to 0.01–4.
- Obraz większy niż 1 MB jest tylko w pliku. Wynik ma wtedy `image_in_response: false`.

### audit_frame

Argumenty: `figma_url`, `project_dir`, opcjonalnie `decisions`, `output_dir` i `refresh`.

- Zapisuje wynik audytu tak jak `audit-design.js`. Prompt naprawy podaje tylko w odpowiedzi (`fix_prompt`), bez zapisu w pliku.
- `decisions` przyjmuje odpowiedzi na decyzje w tym samym kształcie co plik z opcji `--decisions`.
- Zwraca ścieżkę pliku wyniku (`audit_file`), `summary`, `decisions`, do trzech przykładów na regułę (`examples`), `warnings` i treść promptu (`fix_prompt`).

## Zasady dla wszystkich narzędzi

1. Link musi wskazywać dokładnie jedną ramę parametrem `node-id`. Link z `version-id` wskazuje starszą wersję pliku Figmy.
2. `project_dir` to ścieżka bezwzględna folderu roboczego sesji. Folder roboczy serwera zależy od klienta, a Copilot CLI uruchamia serwer pluginu w folderze pluginu. Dlatego folder projektu podaje agent. Schemat każdego narzędzia wymaga tego argumentu.
3. Plik IR w `compare_frames` podaje się ścieżką bezwzględną. Wyniki też podają ścieżki bezwzględne.
4. Błąd narzędzia wraca do agenta jako komunikat z tą samą treścią, którą skrypty wypisują na stderr.

## Ustawienia projektu

Repozytorium projektu musi mieć folder `.github/plugin/figma-design-ir/` z plikiem `settings.json`. Pozostałe pliki w tym folderze zastępują pliki domyślne serwera:

| Plik | Co ustawia | Bez tego pliku |
|---|---|---|
| `settings.json` | Pole `outputDir`: folder wyników. Opcjonalne pole `localComponentMap`: plik mapy komponentów lokalnych; bez pola albo bez pliku komponenty spoza DS nie mają odpowiedników. Ścieżki względne serwer liczy od folderu, w którym leży `.github`. | Błąd każdego narzędzia. |
| `variables.json` | Plik zmiennych. | Plik z `config/` albo z opcji `--variables`. |
| `component-map.json` | Mapę komponentów DS. | Plik z `config/` albo z opcji `--component-map`. |
| `css-variable-map.json` | Mapę zmiennych CSS. | Plik z `config/` albo z opcji `--css-variable-map`. |

- Serwer szuka folderu od `project_dir` w górę, aż do folderu z `.git`.
- Gdy pliku konfiguracji nie ma ani w projekcie, ani w miejscu domyślnym, narzędzie, które go potrzebuje, kończy się błędem ze ścieżką pliku do dodania w projekcie.
- `frame_to_ir` potrzebuje trzech plików konfiguracji, `audit_frame` pliku zmiennych i mapy komponentów, a `compare_frames` trzech plików tylko wtedy, gdy jednym ze źródeł jest link. `get_frame_image` nie potrzebuje żadnego.
- Z opcją `--no-variables` serwer nie wymaga pliku zmiennych. Plik zmiennych z projektu nadal działa.
- Pliki czyta przy każdym wywołaniu, więc zmiana działa od razu.
- Błąd składni albo zły kształt pliku kończy narzędzie błędem z nazwą pliku.

Folder wyników narzędzie wybiera w tej kolejności:

1. Ścieżka bezwzględna z `output_dir`.
2. Pole `outputDir` z `settings.json` projektu.

Ścieżkę względną z `output_dir` i `html_file` serwer liczy od folderu z punktu 2.

Kod: `lib/project-settings/project-settings.js`.

## Opcje serwera

- Serwer przyjmuje opcje `--cache`, `--variables`, `--no-variables`, `--component-map` i `--css-variable-map`. Mają to samo znaczenie co w skryptach. Pliki z tych opcji są plikami domyślnymi, które zastępuje plik z projektu.
- Opcje podaje się w `args` wpisu konfiguracji. Obowiązują przez cały czas działania serwera.
- Opis opcji pokazuje `node mcp-server.js --help`.

Stdout serwera przenosi tylko wiadomości protokołu. Komunikaty `[info]`, `[uwaga]` i `[błąd]` trafiają na stderr, czyli do dziennika serwera w kliencie MCP.

## Koniec pracy

Klient MCP kończy sesję, gdy zamyka wejście serwera (stdin). Serwer wtedy:

1. przerywa zapytania do Figmy w toku, więc wywołanie narzędzia w toku kończy się błędem;
2. kończy proces, gdy nic go już nie trzyma;
3. wymusza koniec procesu po sekundzie, gdy proces nadal działa.

Serwer nie kończy procesu od razu przez `process.exit()`. Node w Windows przerywa wtedy proces błędem `Assertion failed: !(handle->flags & UV_HANDLE_CLOSING)`, gdy wyjście przychodzi zaraz po zapytaniu do Figmy.

Zawieszone zapytanie nie trzyma serwera także w trakcie sesji, bo każde zapytanie do Figmy ma limit czasu. Opis: [module.md](module.md), sekcja „Limit czasu zapytań”.

## Pluginy Copilota

Serwer MCP trafia do pluginu `figma-design-ir` w folderze `plugins/`. Pluginy `figma-designer` dla projektantów, `figma-analyst` dla analityków i `task-flow` dla programistów nie mają serwera. Korzystają z serwera pluginu `figma-design-ir`.

| Skill albo agent | Plugin | Co robi |
|---|---|---|
| agent `mortgage-orchestrator` | `task-flow` | Zapisuje IR makiet zadania w folderze zadania narzędziem `frame_to_ir`. |
| skill `mortgage-figma-audit` | `figma-designer` | Audyt i prompt naprawy dla agenta Figmy, bez pytań do projektanta. |
| skill `mortgage-screen-description` | `figma-analyst` | Opis ekranu i każdej sekcji według szablonów SCR i SCRSEC, z obrazami sekcji. |
| skill `mortgage-figma-change-analysis` | `figma-analyst` | Zmiany między wersjami ramy pogrupowane dla analityka. |
| skill `mortgage-figma-version-compare` | `figma-analyst` | Porównanie dwóch wersji ramy ze stroną HTML. |

Wymagania opisuje `README.md` każdego pluginu, a instalację [README pluginów](../../../README.md).

### Gdy serwera nie ma

Copilot CLI nie ma pola na zależność jednego pluginu od drugiego. Każdy skill i agent z tabeli ma więc regułę: gdy nie ma narzędzia serwera `figma-design-ir`, nie używa innych narzędzi Figmy, odpowiada tylko błędem z poleceniem instalacji pluginu i kończy. Orchestrator stosuje ją tylko wtedy, gdy zadanie ma linki do Figmy.

Błąd zgłasza agent według tej reguły. Sam Copilot CLI nie blokuje pluginu, któremu brakuje serwera.

### Po zmianie serwera

Po każdej zmianie serwera, sub-modułów z `lib/` albo plików z `config/` uruchom w głównym folderze repozytorium:

```bash
node scripts/build-plugins.js
```

Skrypt usuwa zawartość folderu `server/` w pluginie `figma-design-ir` i kopiuje pliki serwera od nowa, bez testów: `mcp-server.js`, `settings.js`, `package.json`, `lib/` i `config/`. Gdy `config/` nie ma pliku domyślnego, skrypt wypisuje ostrzeżenie.

Potem:

1. Podnieś `version` w `plugin.json` pluginu i w jego wpisie w `marketplace.json`.
2. Dopisz na górze `CHANGELOG.md` pluginu sekcję `## <wersja> (RRRR-MM-DD)` z datą wydania.
3. Zatwierdź zmiany razem z folderem `server/` i wypchnij je do zdalnego repozytorium.
4. Użytkownicy uruchamiają `copilot plugin update --all`.

### Marketplace

Plik `marketplace.json` w głównym folderze repozytorium opisuje marketplace `mortgage-copilot-tools` z trzema pluginami Figmy i pluginem `task-flow`. Każdy wpis ma `name`, `description`, `version` i `source`, czyli ścieżkę pluginu od korzenia repozytorium.

Jak działa instalacja z marketplace w Copilot CLI:

- `copilot plugin marketplace add <adres git>` pobiera repozytorium poleceniem `git clone --depth 1`. Adres może mieć postać SSH: `git@<serwer>:<ścieżka>.git` albo `ssh://git@<serwer>/<ścieżka>.git`. Wpis marketplace trafia do `extraKnownMarketplaces` w `~/.copilot/settings.json`.
- `copilot plugin install <plugin>@mortgage-copilot-tools` kopiuje folder pluginu do `~/.copilot/installed-plugins/mortgage-copilot-tools/<plugin>/`. Plugin `figma-design-ir` trafia tam razem z folderem `server/`.
- `copilot plugin update` pobiera zmiany także wtedy, gdy `version` się nie zmieniła. `copilot plugin list` pokazuje wersję z `plugin.json`.
- Instalacja z folderu, z repozytorium albo z adresu bez marketplace jest przestarzała. Copilot CLI ostrzega przy niej, że w przyszłości zostanie tylko instalacja `plugin@marketplace`.

Źródła: [dokumentacja marketplace Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/plugins-marketplace) i komunikaty Copilot CLI 1.0.89.

### Dlaczego serwer jest w osobnym pluginie

- Copilot CLI kopiuje przy instalacji tylko folder pluginu, więc plugin nie użyje plików spoza swojego folderu. Serwer musi mieć kopię w folderze pluginu.
- Serwer o tej samej nazwie w kilku pluginach działa tylko raz i nie wiadomo, z której kopii. Jeden plugin z serwerem daje jedną kopię i jedną wersję.
- Kopia zawiera też folder `config/` z plikami domyślnymi, gdy moduł je ma. Gdy pliku domyślnego nie ma, repozytorium projektu musi podać własny.
- Pluginy Figmy nie mają własnego kodu poza skillami, agentami i plikiem `plugin.json`. Plugin `figma-design-ir` ma `plugin.json`, `.mcp.json` i folder `server/`. Plugin task-flow ma też hook.
- Copilot CLI uruchamia serwer pluginu w folderze pluginu i przekazuje mu swoje środowisko, także `FIGMA_API_KEY`.
