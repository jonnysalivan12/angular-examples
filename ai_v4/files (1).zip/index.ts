import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const FIGMA_TOKEN = process.env.FIGMA_TOKEN;
if (!FIGMA_TOKEN) throw new Error("FIGMA_TOKEN env variable is required");
const TOKEN: string = FIGMA_TOKEN;

const BASE_URL = "https://api.figma.com/v1";

async function figmaFetch(path: string) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "X-Figma-Token": TOKEN },
  });
  if (!res.ok) throw new Error(`Figma API error: ${res.status} ${res.statusText}`);
  return res.json();
}

// Recursively collect all INSTANCE nodes from a node tree
function collectInstances(node: any, results: any[] = []): any[] {
  if (node.type === "INSTANCE") {
    results.push({
      id: node.id,
      name: node.name,
      componentId: node.componentId,
      x: node.absoluteBoundingBox?.x,
      y: node.absoluteBoundingBox?.y,
      width: node.absoluteBoundingBox?.width,
      height: node.absoluteBoundingBox?.height,
    });
  }
  if (node.children) {
    for (const child of node.children) {
      collectInstances(child, results);
    }
  }
  return results;
}

// Recursively find a node by id
function findNode(node: any, targetId: string): any | null {
  if (node.id === targetId) return node;
  if (node.children) {
    for (const child of node.children) {
      const found = findNode(child, targetId);
      if (found) return found;
    }
  }
  return null;
}

const server = new McpServer({
  name: "figma-mcp",
  version: "1.0.0",
});

// Tool 1: Get all component instances used in a file or specific frame
server.tool(
  "get_component_instances",
  "Get all component instances (INSTANCE nodes) used in a Figma file or specific frame. Returns component names, IDs and positions.",
  {
    file_id: z.string().describe("Figma file ID (from file URL: figma.com/file/{FILE_ID}/...)"),
    node_id: z.string().optional().describe("Optional: specific frame/page node ID to scope the search"),
  },
  async ({ file_id, node_id }) => {
    const depth = 10;
    const query = node_id
      ? `/files/${file_id}/nodes?ids=${encodeURIComponent(node_id)}&depth=${depth}`
      : `/files/${file_id}?depth=${depth}`;

    const data = await figmaFetch(query);

    let rootNode: any;
    if (node_id) {
      rootNode = data.nodes[node_id]?.document;
    } else {
      rootNode = data.document;
    }

    if (!rootNode) throw new Error("Node not found");

    const instances = collectInstances(rootNode);

    // Fetch component metadata for all unique componentIds
    const componentIds = [...new Set(instances.map((i) => i.componentId).filter(Boolean))];
    let componentMeta: Record<string, any> = {};

    if (componentIds.length > 0) {
      const componentsData = await figmaFetch(`/files/${file_id}/components`);
      for (const comp of componentsData.meta?.components ?? []) {
        componentMeta[comp.node_id] = {
          key: comp.key,
          name: comp.name,
          description: comp.description,
          remote: comp.remote ?? false,
          file_key: comp.file_key,
        };
      }
    }

    const enriched = instances.map((inst) => ({
      ...inst,
      component: componentMeta[inst.componentId] ?? null,
    }));

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({ total: enriched.length, instances: enriched }, null, 2),
        },
      ],
    };
  }
);

// Tool 2: Get file pages and top-level frames (for overview/navigation)
server.tool(
  "get_file_structure",
  "Get the top-level structure of a Figma file: pages and their direct children (frames/screens). Useful for navigation before drilling into a specific frame.",
  {
    file_id: z.string().describe("Figma file ID"),
  },
  async ({ file_id }) => {
    const data = await figmaFetch(`/files/${file_id}?depth=2`);

    const pages = (data.document?.children ?? []).map((page: any) => ({
      id: page.id,
      name: page.name,
      type: page.type,
      frames: (page.children ?? []).map((frame: any) => ({
        id: frame.id,
        name: frame.name,
        type: frame.type,
        width: frame.absoluteBoundingBox?.width,
        height: frame.absoluteBoundingBox?.height,
      })),
    }));

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({ file_name: data.name, pages }, null, 2),
        },
      ],
    };
  }
);

// Tool 3: Get node tree (for layout analysis)
server.tool(
  "get_node_tree",
  "Get the full node tree of a specific frame/node. Returns hierarchy with types, names and layout info. Use for analyzing layout and component composition of a screen.",
  {
    file_id: z.string().describe("Figma file ID"),
    node_id: z.string().describe("Node ID (frame/page). Get from get_file_structure."),
    depth: z.number().min(1).max(10).default(5).describe("Tree depth (default: 5)"),
  },
  async ({ file_id, node_id, depth }) => {
    const data = await figmaFetch(
      `/files/${file_id}/nodes?ids=${encodeURIComponent(node_id)}&depth=${depth}`
    );

    const node = data.nodes[node_id]?.document;
    if (!node) throw new Error("Node not found");

    // Simplify the tree for LLM consumption
    function simplify(n: any, currentDepth: number): any {
      const base: any = {
        id: n.id,
        name: n.name,
        type: n.type,
      };
      if (n.type === "INSTANCE") base.componentId = n.componentId;
      if (n.absoluteBoundingBox) {
        base.size = {
          w: Math.round(n.absoluteBoundingBox.width),
          h: Math.round(n.absoluteBoundingBox.height),
        };
      }
      if (n.layoutMode) base.layout = n.layoutMode; // HORIZONTAL / VERTICAL (auto-layout)
      if (n.children && currentDepth > 0) {
        base.children = n.children.map((c: any) => simplify(c, currentDepth - 1));
      }
      return base;
    }

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(simplify(node, depth), null, 2),
        },
      ],
    };
  }
);

// Tool 4: Get component metadata by key (resolve library source)
server.tool(
  "get_component_by_key",
  "Get detailed metadata about a component by its key (from component instances). Returns source file, name, description. Useful for identifying which design system library a component comes from.",
  {
    component_key: z.string().describe("Component key (from get_component_instances result)"),
  },
  async ({ component_key }) => {
    const data = await figmaFetch(`/components/${component_key}`);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(data.meta, null, 2),
        },
      ],
    };
  }
);

// Tool 5: List all components defined in a file (design system inventory)
server.tool(
  "get_file_components",
  "List all components defined in a Figma file. Useful for mapping the design system component library.",
  {
    file_id: z.string().describe("Figma file ID"),
  },
  async ({ file_id }) => {
    const data = await figmaFetch(`/files/${file_id}/components`);
    const components = (data.meta?.components ?? []).map((c: any) => ({
      key: c.key,
      node_id: c.node_id,
      name: c.name,
      description: c.description,
      remote: c.remote ?? false,
    }));
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({ total: components.length, components }, null, 2),
        },
      ],
    };
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
