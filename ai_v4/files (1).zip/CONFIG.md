# Konfiguracja klienta MCP

## Claude Code / Cursor / Windsurf
# Dodaj do .claude/mcp.json (lub analogicznego pliku konfiguracyjnego klienta):

{
  "mcpServers": {
    "figma": {
      "command": "node",
      "args": ["/SCIEZKA/DO/figma-mcp/dist/index.js"],
      "env": {
        "FIGMA_TOKEN": "TU_WSTAW_TOKEN"
      }
    }
  }
}

## Alternatywnie przez tsx (dev, bez buildu):
{
  "mcpServers": {
    "figma": {
      "command": "npx",
      "args": ["tsx", "/SCIEZKA/DO/figma-mcp/src/index.ts"],
      "env": {
        "FIGMA_TOKEN": "TU_WSTAW_TOKEN"
      }
    }
  }
}

## Dostępne narzędzia MCP:

1. get_file_structure(file_id)
   → Strony i ramki pliku (nawigacja, punkt startowy)

2. get_node_tree(file_id, node_id, depth?)
   → Drzewo węzłów konkretnego ekranu (layout, hierarchia)

3. get_component_instances(file_id, node_id?)
   → Wszystkie INSTANCE nodes = użyte komponenty na ekranie
      + metadane: skąd pochodzi komponent (remote/local)

4. get_file_components(file_id)
   → Inwentarz komponentów zdefiniowanych w pliku (design system)

5. get_component_by_key(component_key)
   → Szczegóły komponentu (źródłowa biblioteka, opis)

## Jak wyciągnąć file_id z URL Figmy:
   https://www.figma.com/file/ABC123xyz/Nazwa-projektu
                              ^^^^^^^^^
                              to jest file_id

## Jak wyciągnąć node_id z URL Figmy:
   Po kliknięciu na frame w Figmie URL zmienia się na:
   https://www.figma.com/file/ABC123xyz/...?node-id=10%3A5
   node-id w URL = "10:5" (zdekodowane)
