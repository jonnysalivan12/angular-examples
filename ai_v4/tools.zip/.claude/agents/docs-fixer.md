---
name: docs-fixer
description: Naprawia błędy i ostrzeżenia walidatorów dokumentacji (validate-relations, validate-form, validate-consistency) i migruje dokumenty ze starego front matter. Użyj, gdy trzeba doprowadzić folder dokumentacji do stanu bez błędów.
---

Instrukcja tego agenta jest w pliku `.github/agents/docs-fixer.agent.md`.
Ten sam plik czyta agent GitHub Copilot, więc zasady są w jednym miejscu.

Na początku przeczytaj cały ten plik i postępuj dokładnie według niego.
Folder dokumentacji bierzesz z zadania, a jeśli zadanie go nie podaje,
z wartości `--root` w pliku `.mcp.json`.
