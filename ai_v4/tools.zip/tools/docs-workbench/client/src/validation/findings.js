// Problemy walidacji: klucz do adresu strony i prompt dla agenta, który ma
// problem naprawić.

// Klucz problemu w adresie: walidator, kod, dokument, linia i numer wśród
// identycznych krotek, więc nie zależy od kolejności całej listy.
export const findingKey = (finding, ordinal) => `${finding.validator}|${finding.code}|${finding.docId || ''}|${finding.line || 0}|${ordinal}`;

export function keyedFindings(validation) {
  const seen = new Map();
  return (validation?.findings || []).map(finding => {
    const base = findingKey(finding, 0);
    const ordinal = (seen.get(base) || 0) + 1;
    seen.set(base, ordinal);
    return { ...finding, key: findingKey(finding, ordinal) };
  });
}

export const severityLabel = severity => (severity === 'error' ? 'błąd' : 'ostrzeżenie');

// Fragment pliku wokół linii z numerami; linia z problemem ma znacznik „>”.
export function excerpt(content, line, radius = 4) {
  const lines = (content || '').split(/\r?\n/);
  if (!line || line > lines.length) return null;
  const from = Math.max(1, line - radius);
  const to = Math.min(lines.length, line + radius);
  const width = String(to).length;
  return {
    from, to,
    text: lines.slice(from - 1, to).map((text, index) => {
      const number = from + index;
      return `${number === line ? '>' : ' '}${String(number).padStart(width)} | ${text}`;
    }).join('\n'),
  };
}

// Prompt dla agenta: co jest nie tak, gdzie, jak sprawdzić naprawę.
export function agentPrompt({ finding, validation, meta, content, docType }) {
  const validator = validation?.validators.find(item => item.id === finding.validator);
  const script = validator?.script ? `scripts/${validator.script}` : 'walidator dokumentacji';
  const root = meta?.root || '<folder dokumentacji>';
  const part = excerpt(content, finding.line);
  const lines = [
    'Napraw jeden problem walidacji dokumentacji w tym repozytorium.',
    '',
    `Plik: ${finding.file}${finding.line ? `:${finding.line}` : ''}`,
    finding.docId ? `Dokument: ${finding.docId}${docType ? ` (typ ${docType})` : ''}` : null,
    `Walidator: ${script}${validator?.name ? ` (${validator.name})` : ''}`,
    `Problem: ${finding.code} ${finding.check}, poziom: ${severityLabel(finding.severity)}`,
    `Komunikat walidatora: ${finding.message}`,
    finding.fix ? `Podpowiedź walidatora: ${finding.fix}` : 'Podpowiedź walidatora: brak. Ustal zmianę na podstawie komunikatu i standardu.',
  ].filter(line => line !== null);
  if (part) lines.push('', `Fragment pliku (linie ${part.from}–${part.to}, „>” oznacza linię z problemem):`, '```', part.text, '```');
  lines.push(
    '',
    'Zasady:',
    '1. Zmień tylko to, czego dotyczy ten problem. Nie przepisuj pozostałych części dokumentu.',
    `2. Trzymaj się szablonu i guide.md typu${docType ? ` ${docType}` : ''} w standards/templates (folder typu podaje standards/templates/_00-meta.md) oraz komentarzy w standards/config/relation-matrix.yaml.`,
    `3. Jeśli zmiana dodaje albo usuwa wzmianki o ID innych dokumentów, uzgodnij pole relations: node scripts/sync-relations.js ${finding.file} --fix`,
    `4. Po zmianie uruchom: node ${script} ${root}`,
    `   Potwierdź, że ${finding.code} dla ${finding.docId || 'tego pliku'} już nie występuje i że nie pojawiły się nowe problemy.`,
    '5. Na końcu napisz w jednym, dwóch zdaniach, co zmieniłeś i dlaczego.',
  );
  return lines.join('\n');
}
