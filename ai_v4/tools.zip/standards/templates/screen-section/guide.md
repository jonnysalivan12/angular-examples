# Sekcja ekranu (SCRSEC)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Jeden wydzielony fragment ekranu: pola, źródła danych, walidacje, reguły
biznesowe, zachowania. Podrzędna wobec ekranu.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz szczegółowo pola w sekcji ekranu.

**Nie używaj gdy:**

- opisujesz układ całego ekranu → [screen](../screen/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

- Sekcję wskazuje ekran: `SCR-001 contains SCRSEC-001`.
- Atrybuty „Źródło danych” i „Miejsce utrwalenia” wskazują encję: `SCRSEC-001 consumes ENT-Client`.
- Wskazujesz encję, która w sekcji jest osobnym bytem. Część zagnieżdżona w całości dochodzi przez `ENT contains ENT`. Sekcja „Pozycje” z listą pozycji wskazuje `ENT-DispositionItem`: `SCRSEC-002 consumes ENT-DispositionItem`.
- Atrybut „Zachowanie” wskazuje API albo INT wywołania, które nie jest krokiem scenariusza: podpowiadanie, walidacja w locie, słownik wartości. Wywołanie, które jest krokiem, wpisujesz w kolumnie „Wywołanie” w UC albo TUC.
- Test: jeśli podpowiadanie da się wymienić na listę rozwijaną bez zmiany scenariusza, wywołanie należy do sekcji.

## 4. Warianty

Brak wariantów.
