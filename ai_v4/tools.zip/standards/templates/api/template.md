---
doc-id: API-{nnn}
title: "{METODA} /{zasób}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
owner: "{Imię Nazwisko}"
relations:
  - type: realizes
    target: CAP-{nnn}                          # zdolność
  - type: consumes
    target: ENT-{Nazwa}                        # Encje
  - type: consumes
    target: INT-{nnn}                          # Zależności
  - type: constrained_by
    target: NFR-{nnn}.NFRT-{KATEGORIA}-{nn}    # Ograniczenia NFR
---

# {METODA} /{zasób}

| Pole | Wartość |
|---|---|
| Zdolność | CAP-{nnn} |

## Cel

{Po co istnieje punkt końcowy}

## Parametry wejściowe

| Parametr | Typ | Wymagany | Źródło |
|---|---|---|---|
| {nazwa} | {typ} | tak / nie | query / header / path / body |

## Walidacja pól wejściowych

| Reguła | Kod błędu HTTP | Komunikat zwracany przez system |
|---|---|---|
| {Reguła} | {Kod błędu HTTP} | {Komunikat zwracany przez system} |

## Złożone parametry wejściowe

<!-- Opcjonalnie, np. zaszyfrowany token zawierający kilka informacji. -->

{Budowa złożonego parametru}

## Autentykacja

{Sposób autentykacji: JWT Bearer / publiczny / wymagana rola}

## Zachowanie

### Przebieg podstawowy

{Co robi punkt końcowy w typowym wywołaniu}

### Przypadek brzegowy

{Zachowanie w przypadku brzegowym}

## Model odpowiedzi

<!-- Opcjonalnie: classDiagram i tabela pól, bez kopiowania OpenAPI. -->

```mermaid
classDiagram
```

| Pole | Typ | Opis |
|---|---|---|
| {Pole} | {Typ} | {Opis} |

## Struktura odpowiedzi błędnej

{Format odpowiedzi przy błędzie}

## Encje

- ENT-{Nazwa}: {jak występuje w żądaniu lub odpowiedzi}

## Zależności

- INT-{nnn}: {po co punkt końcowy go woła}

## Ograniczenia NFR

- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}
