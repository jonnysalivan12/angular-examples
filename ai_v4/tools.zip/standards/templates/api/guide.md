# API Endpoint (API)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Opis jednego punktu końcowego: cel, parametry, zachowanie, model odpowiedzi.
Jeden punkt końcowy to jeden plik. Opisuje to, co nie wynika z OpenAPI
(Swagger).

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz jeden punkt końcowy API.

**Nie używaj gdy:**

- opisujesz połączenie z systemem zewnętrznym → [integration](../integration/guide.md),
- opisujesz kontrakt zdarzenia w brokerze → [event](../event/guide.md),
- opisujesz sekwencję wywołań → [flow](../flow/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

- Nie kopiujesz kontraktu OpenAPI.
- Zdolność podajesz w polu „Zdolność” i wskazujesz wpisem `realizes`: `API-001 realizes CAP-001`.
- Sekcja „Encje” wymienia encje, które w żądaniu lub odpowiedzi są osobnym bytem: `API-001 consumes ENT-Disposition`, `ENT-StatusDict`. Część zagnieżdżona w całości dochodzi przez `ENT contains ENT`: `POST /dispositions` z pozycjami w środku wskazuje tylko `ENT-Disposition`, a odpowiedź `{ disposition, dispositionItems }` wskazuje obie encje.
- „Zależności” wskazują integracje: `API consumes INT`. Punkt końcowy nie woła innego punktu końcowego; sekwencję wywołań opisuje FLOW.
- „Ograniczenia NFR” wskazują wiersze NFR: `API-001 constrained_by NFR-001.NFRT-PERF-01`. Wiersza NFR swojej zdolności nie powtarzasz: `API-020` podlega `NFR-002.NFRT-SEC-02` przez `CAP-020`.

## 4. Warianty

Brak wariantów.
