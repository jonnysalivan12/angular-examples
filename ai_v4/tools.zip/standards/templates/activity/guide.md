# Krok przepływu, Activity (ACT)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Jedna aktywność z diagramu przepływu: logika biznesowa, wejście i wyjście,
reguły, scenariusze błędów. Jeden plik to jedna aktywność.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** wydzielasz krok przepływu ze złożonym algorytmem.

**Nie używaj gdy:**

- krok jest prosty; opisujesz go w przepływie → [flow](../flow/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

- Aktywność nie zapisuje relacji. Wskazuje ją przepływ: `FLOW-001 contains ACT-002`. Wywołania API, INT i QUE wpisuje przepływ w kolumnie „Wywołanie”.
- Matryca nie ma trójek ACT z API, INT ani QUE, więc ID tych dokumentów w treści aktywności są błędem walidatora. Aktywność nie wymienia też przepływu, który ją zawiera ([methodology.md](../../methodology.md), sekcja 7).

## 4. Warianty

Brak wariantów, jednolita struktura.
