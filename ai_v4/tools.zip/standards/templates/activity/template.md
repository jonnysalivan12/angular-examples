---
doc-id: ACT-{nnn}
title: "{Nazwa aktywności}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
owner: "{Imię Nazwisko}"
relations: []
---

# {Nazwa aktywności}

## Cel

{Co aktywność ma osiągnąć w przepływie}

## Opis akcji

{Co aktywność robi, krok po kroku}

## Wejście i wyjście

| Kierunek | Dane | Opis |
|---|---|---|
| Wejście | {Dane} | {Opis} |
| Wyjście | {Dane} | {Opis} |

## Warunki i reguły

{Warunki wykonania i reguły algorytmu}

## Scenariusze błędów

{Sytuacje błędne i reakcja aktywności}

## Zależności

<!-- Bez ID API, INT i QUE: wywołania wskazuje przepływ w kolumnie „Wywołanie”. -->

{Zależności aktywności, podane nazwą}
