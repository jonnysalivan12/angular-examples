# START — przeczytaj to najpierw

Archiwum projektu: system dokumentacji projektowej oparty na grafie relacji.
Stan na 7 września 2026.

---

## O co chodzi w projekcie

Firma ma standard dokumentacji: 22 szablony dokumentów (BFS, UC, API, ENT…), każdy z front matter i relacjami do innych dokumentów. Problem: relacje są zapisane tak, że nie da się z nich zbudować grafu — jedno pole miesza trzy kierunki i nie ma typu relacji.

Cel: przerobić to na graf, który odpowiada na pytania w rodzaju „co poprawić, gdy zmienię to wymaganie", „co jest potrzebne do implementacji tego scenariusza", „co przetestować".

Pięć produktów: metodyka, zasada relacjonowania, baza wiedzy z repozytorium, linter, serwer MCP.

---

## Gdzie jesteśmy

| Produkt | Stan |
|---|---|
| P1 metodyka | 80% — trzy pliki do scalenia |
| P2 zasada relacjonowania | **ZAMKNIĘTE** — matryca wypełniona |
| P3 baza wiedzy | 20% — brak parsera i indeksu |
| P4 linter | 60% — działa, ale na starym słowniku typów |
| P5 serwer MCP | 0% |

**Następny krok z planu:** scalenie metodyki w jeden dokument (P1), potem parser.

---

## Kolejność czytania

1. **`00-PLAN.md`** — pełny obraz: pięć produktów, inwentarz, rozpoznanie alternatyw, kolejność prac
2. **`02-matryca/matryca-relacji.yaml`** — serce systemu, 63 wiersze, konfiguracja walidatora i zapytań
3. **`01-metodyka/sciaga-zasady.md`** — jedna strona: zasady, podział pracy, korzyści
4. Reszta według potrzeby

---

## Zawartość

### `01-metodyka/`

| Plik | Co to |
|---|---|
| `standard-relacji-ustalenia.md` | 18 ustaleń U-001…U-022 z uzasadnieniami — dlaczego tak, a nie inaczej |
| `relacje-przewodnik.md` | ta sama treść po ludzku, na jednym przykładzie |
| `sciaga-zasady.md` | jedna strona na wejście dla zespołu |
| `standard-szablonow.md` | wyciąg z oryginalnej dokumentacji firmy: 22 szablony, drzewo katalogu |

⚠️ Pierwsze trzy opisują **11 typów relacji**. Matryca ma **9**. Przy scalaniu trzeba zaktualizować — `defines` weszło w `contains`, `uses-data` w `consumes`, `used-in` zniknęło, doszło `references`.

### `02-matryca/`

| Plik | Co to |
|---|---|
| `matryca-relacji.yaml` | **63 wiersze, wypełnione** — trójka (źródło, relacja, cel) + kierunek propagacji + liczebność |
| `matryca-uzasadnienia.md` | wersja robocza z komentarzami, które wiersze były sporne i dlaczego |
| `pary-dozwolone-i-luki.md` | które pary dozwolone, pary jawnie zabronione, 7 luk (część już zamknięta) |

### `03-korpus/`

| Plik | Co to |
|---|---|
| `korpus-dokumentacji.yaml` | **215 dokumentów, 13 procesów** — dane testowe dla parsera, lintera i serwera |
| `korpus-dokumentacji.js` | źródło: pierwsze 54 dokumenty (proces dyspozycji) |
| `korpus-rozszerzenie.js` | źródło: 10 dalszych procesów bankowych |

### `04-narzedzia/`

| Plik | Co to |
|---|---|
| `lint-relations.js` | walidator w Node, 6 reguł plus spójność grafu |
| `lint_relations.py` | to samo w Pythonie |

⚠️ Oba na **starym słowniku 11 typów**. Do przepisania: czytać matrycę jako konfigurację zamiast mieć reguły w kodzie.

### `05-wizualizacja/`

`graf-dokumentacji-3d.html` — jeden plik bez zależności, otwierany z dysku. Każdy proces jako wieża, wspólne pośrodku, cztery warstwy, trzy zapytania na węźle. Dodatek, nie ścieżka krytyczna.

### `99-archiwum/`

`przyklad-relacji.md` — **nieaktualny**. Opisuje symetrię wymuszoną linterem, odrzuconą w U-011. Zostaje jako ślad rozważanego wariantu.

---

## Ustalenia, które trzeba znać

**Jedno pole `relations`** zamiast `source-spec-ids` i `related-doc-ids`.

**Dokument mówi, z czego wynika i co zawiera** — nigdy, kto z niego korzysta. Relacja odwrotna wylicza się z grafu.

**Identyfikator w treści wymaga wpisu w metadanych.** Bez wyjątku dla wzmianek.

**Identyfikatory lokalne** (`REQ-01`, `RB-01`, `DOM-*`) są węzłami grafu, zgłaszanymi przez `contains`, wskazywanymi z prefiksem: `BFS-003.REQ-01`.

**Nic nie wisi w próżni** — każdy węzeł osiągalny z reszty grafu.

**Jeden BFS = jeden proces** — jeden start, jeden koniec. Nie dzielić po iteracjach ani ścieżkach błędnych.

**Kierunek propagacji jest własnością trójki**, nie typu relacji. To samo `contains` ma `→` dla `BFS → REQ` i `↔` dla `SCR → SCRSEC`.

---

## Do rozstrzygnięcia

| # | Pytanie | Blokuje |
|---|---|---|
| 1 | Czy linter ostrzega, gdy ten sam punkt końcowy wołany przez sekcję i przez scenariusz ją zawierający | P4 |
| 2 | Czy indeks przyrostowy czy przebudowywany w całości | P3 |
| 3 | Lista narzędzi serwera MCP | P5 |
| 4 | Czy dokumentacja publikowana, czy tylko w repozytorium | generatory |
| 5 | Czy zmienić szablon sekcji ekranu — „Źródło danych" ma dziś przykład z punktem końcowym, powinna być encja | P1 |

---

## Otwarte wątki z rozmowy

**Rozjazd wersji.** Metodyka i lintery opisują 11 typów, matryca 9. To skutek tego, że matrycę ustalaliśmy później. Scalenie metodyki musi to naprawić.

**Maszyny stanów i procesy BPMN** nie miały kotwicy do procesu — w korpusie wylądowały we wspólnych. Matryca to naprawia (`STM realizes CAP`, `BPMN realizes CAP`), ale korpus nie został zaktualizowany.

**Generowana treść w plikach.** Ustalenie: sekcje wyliczane z grafu wstawiane między znacznikami, nadpisywane przy każdej zmianie. Niezaimplementowane.
