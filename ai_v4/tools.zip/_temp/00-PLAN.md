# Plan: uporządkowanie systemu dokumentacji

Pięć produktów, jeden inwentarz, rozpoznanie alternatyw. Stan na wrzesień 2026.

---

## 1. Pięć produktów i ich stan

| # | Produkt | Stan | Co zostało |
|---|---|---|---|
| P1 | Metodyka tworzenia dokumentacji | 80% | scalić trzy pliki, zaktualizować do ośmiu typów relacji |
| P2 | Zasada relacjonowania bytów | 70% | wypełnić matrycę: 47 trójek × kierunek + liczebność (skutki niżej) |
| P3 | Baza wiedzy z repozytorium | 20% | parser, indeks, schemat |
| P4 | Linter | 60% | przepisać na osiem typów, dodać matrycę jako konfigurację |
| P5 | Serwer MCP | 0% | projekt narzędzi, implementacja |

Blokada: **P2 blokuje P3, P4 i P5.** Bez wypełnionej matrycy walidator nie ma czego egzekwować, a zapytania o zasięg zmiany nie mają kierunków.

### Skutki wpisu w kolumnie kierunku

Każdy wiersz matrycy to decyzja o tym, co znajdzie się w zakresie zgłoszenia. Wpis działa w obie strony: włącza pliki i wyklucza pliki.

| Wpis | Co się dzieje przy zmianie | Ryzyko przy błędzie |
|---|---|---|
| `←` | zmiana celu wciąga źródło do zakresu; zmiana źródła nie rusza celu | jeśli powinno być `↔`, zmiana źródła pominie cel — zostanie niespójność |
| `→` | odwrotnie: zmiana źródła wciąga cel | jeśli powinno być `↔`, pominięte zostanie źródło |
| `↔` | obie strony wchodzą do zakresu | przy węźle o wielu połączeniach zakres puchnie lawinowo |
| `–` | krawędź niewidoczna dla zapytania o zasięg, służy tylko nawigacji | plik, który trzeba było poprawić, nie pojawi się na liście |

Dwa błędy mają różną cenę. Za wąski kierunek daje ciszę — dokumentacja rozjeżdża się bez ostrzeżenia. Za szeroki daje szum — zakres zgłoszenia zawiera pliki, których zmiana nie dotyczy, i po kilku razach zespół przestaje go czytać.

Reguła kciuka przy wypełnianiu: **przy wątpliwości wybierz szerzej, ale policz stopień węzła.** `↔` na relacji prowadzącej do encji słownikowej albo do wymagania jakościowego rozdmucha każdy zakres, bo te węzły mają dziesiątki połączeń. Tam lepiej `←` i osobna reguła wyjątku.

---

## 2. Inwentarz — co mamy i co z tym zrobić

### Zostaje jako źródło

| Plik | Rola docelowa |
|---|---|
| `standard-szablonow.md` | wyciąg z oryginału — archiwum, punkt odniesienia |
| `korpus-dokumentacji.yaml` | 215 dokumentów, 13 procesów — dane testowe dla P3, P4, P5 |
| `matryca-do-wypelnienia.md` | **P2 — do wypełnienia** |

### Do scalenia w jeden dokument metodyki (P1)

| Plik | Co z niego bierzemy |
|---|---|
| `standard-relacji-ustalenia.md` | ustalenia U-001…U-022 jako uzasadnienia |
| `relacje-przewodnik.md` | narracja i przykłady |
| `sciaga-zasady.md` | jedna strona na wejście |
| `macierz-relacji.md` | które pary dozwolone + siedem luk |

### Do przepisania

| Plik | Problem |
|---|---|
| `lint-relations.js`, `lint_relations.py` | jedenaście typów zamiast ośmiu, brak matrycy jako konfiguracji |

### Nieaktualne

| Plik | Dlaczego |
|---|---|
| `przyklad-relacji.md` | opisuje symetrię wymuszoną linterem, odrzuconą w U-011 |

### Dodatek

`graf-dokumentacji-3d.html`, `korpus-dokumentacji.js`, `korpus-rozszerzenie.js` — wizualizacja i jej dane. Nie na ścieżce krytycznej.

---

## 3. Docelowy układ repozytorium

```
docs-standards/
├── AGENTS.md                  ← instrukcja dla agentów, pod 150 linii
├── llms.txt                   ← mapa dokumentacji dla modeli
├── metodyka/
│   ├── 00-start.md            ← ściąga, jedna strona
│   ├── 10-zasady.md           ← pięć zasad + uzasadnienia
│   ├── 20-typy-dokumentow.md  ← 22 szablony, kiedy który
│   ├── 30-relacje.md          ← słownik ośmiu typów
│   ├── 40-matryca.yaml        ← 47 trójek: kierunek + liczebność
│   └── 50-proces-pracy.md     ← rytm zmian, migracja, role
├── szablony/                  ← 22 pliki, bez zmian względem oryginału
├── narzedzia/
│   ├── parser/                ← Markdown + front matter → graf
│   ├── linter/                ← walidacja wobec matrycy
│   ├── indeks/                ← SQLite, budowany z parsera
│   └── mcp/                   ← serwer zapytań
└── przyklady/
    └── korpus.yaml            ← 215 dokumentów, dane testowe
```

Matryca jako `yaml`, nie tabela w Markdown — jest konfiguracją trzech narzędzi naraz.

---

## 4. Rozpoznanie: alternatywne formaty

### Co warto wziąć

**`llms.txt`** — propozycja standardu: plik w korzeniu, który daje agentom prowadzoną ścieżkę do treści strony. Dwa warianty: `llms.txt` jako indeks tytułów, adresów i krótkich opisów, oraz `llms-full.txt` jako cała dokumentacja w jednym pliku Markdown. W maju 2026 Google dodał `llms.txt` do audytu „Agentic Browsing" w Lighthouse.

Dla nas: `llms.txt` generowany z grafu, nie pisany ręcznie. Sekcje po typach dokumentów, opis każdego wpisu z pola `title`. Koszt: kilkadziesiąt linii w generatorze.

**`AGENTS.md`** — plik w korzeniu repozytorium mówiący agentom, jak budować, testować i zmieniać projekt; czytany przez ponad trzydzieści narzędzi, format prowadzony przez Agentic AI Foundation przy Linux Foundation.

Dla nas: tu trafiają reguły pracy z dokumentacją — jak dodać dokument, kiedy odpalić linter, czego nie ruszać. Uwaga: badanie na 2500 repozytoriów wykazało, że pliki `AGENTS.md` wygenerowane przez model obniżają skuteczność zadań w pięciu z ośmiu testowanych ustawień i dodają od 2,45 do 3,92 kroku na zadanie. Pisać ręcznie, krótko, dodawać sekcję dopiero gdy agent regularnie się myli.

**`SKILL.md`** — `AGENTS.md` mówi agentowi, czym jest projekt; Agent Skills mówią, jak coś zrobić, i wędrują z agentem między projektami. Skill to folder z plikiem `SKILL.md`, dwoma wymaganymi polami w nagłówku i instrukcją w treści.

Dla nas: umiejętność „napisz BFS", „rozbij wymaganie na scenariusze", „popraw błędy lintera". To jest miejsce na agenta naprawczego z naszej ściągi.

**Front matter plus odnośniki w treści** — dwustronna strategia: nagłówek daje modelowi wiarygodne typowane relacje do nawigacji, odnośniki w treści dają kontekst rozumienia.

Dla nas: potwierdza nasz U-006, ale z odwrotnym akcentem. My zabroniliśmy identyfikatorów w treści bez wpisu w metadanych. To jest ostrzejsze i lepsze dla grafu — ale warto wiedzieć, że rozpowszechniona praktyka dopuszcza oba kanały.

### Co warto znać, ale nie brać

**Diátaxis** — dzieli dokumentację na cztery typy: samouczki, poradniki, materiał referencyjny i wyjaśnienia.

Inna oś niż nasza. Diátaxis dzieli po potrzebie czytelnika, my po roli w systemie. Warto zastosować do samej metodyki (P1) — bo to dokumentacja dla ludzi — ale nie do dokumentacji projektowej.

**DITA i AsciiDoc** — DITA organizuje treść w wielokrotnie używane tematy: pojęcia, zadania i materiał referencyjny, spięte mapą definiującą hierarchię i relacje. To najbliższy nam dojrzały standard — typowane dokumenty plus mapa relacji. Rekomendacja branżowa: DITA rezerwować dla sytuacji, w których wymagają go normy regulacyjne albo objętość treści; dla mniejszych zespołów AsciiDoc daje podobne możliwości strukturyzacji przy znacznie niższym koszcie wdrożenia.

Dla nas: nie migrujemy. Ale warto sprawdzić, czy nasz słownik ośmiu relacji nie powiela czegoś z DITA `reltable` — jeśli tak, warto zapożyczyć nazewnictwo zamiast wymyślać własne.

### Rozstrzygnięcia techniczne dla P3

**SQLite z rekurencyjnymi zapytaniami** — rekurencyjne wyrażenia CTE dają wszystko, czego trzeba do przechodzenia wielu skoków; przy właściwym indeksowaniu wystarcza dla grafów rzędu dziesiątek tysięcy węzłów, co pokrywa większość zastosowań jednego zespołu lub projektu.

Nasz korpus ma 215 dokumentów i 560 krawędzi. Z zapasem mieści się w tym przedziale. **To jest właściwy wybór.**

**Kuzu** — osadzona baza grafowa działająca w procesie aplikacji jak SQLite, z językiem Cypher, ale w październiku 2025 projekt został zarchiwizowany po przejęciu firmy przez Apple, a utrzymanie przeszło na odgałęzienia społecznościowe.

Nie brać. Ryzyko utrzymania większe niż zysk z Ciphera przy naszej skali.

**GraphRAG** — warto znać ostrzeżenie: nieograniczona ekstrakcja encji tworzy szum, zduplikowane węzły i fałszywe relacje, a hierarchiczne podsumowania mogą ten szum wzmacniać.

Nas to nie dotyczy, bo nie wydobywamy grafu z tekstu — analityk deklaruje relacje ręcznie, a walidator je sprawdza. To jest przewaga naszego podejścia i warto ją zapisać w metodyce.

### Źródła

| Temat | Adres |
|---|---|
| specyfikacja `llms.txt` (wersja 2) | llmstxt.org |
| `llms.txt` w audycie Lighthouse | developer.chrome.com/docs/lighthouse/agentic-browsing/llms-txt |
| `AGENTS.md` — zakres i przyjęcie | morphllm.com/agents-md-guide |
| badanie skuteczności `AGENTS.md` | betterclaw.io/blog/agents-md-best-practices |
| `SKILL.md` i standardy agentowe | blog.agentailor.com/posts/top-ai-agent-standards-2026 |
| graf wiedzy w Markdown | jamescroft.co.uk/building-out-your-knowledge-graph-in-markdown |
| Diátaxis | idratherbewriting.com/blog/what-is-diataxis-documentation-framework |
| DITA kontra AsciiDoc | adoc-studio.app/blog/choosing-a-documentation-tool |
| SQLite jako baza grafowa | dev.to/rohansx/sqlite-as-a-graph-database-recursive-ctes-semantic-search-and-why-we-ditched-neo4j |
| Kuzu — stan projektu | puppygraph.com/blog/what-is-kuzudb |
| szum w GraphRAG | github.com/davidamitchell/Research/wiki |

---

## 5. Usprawnienia dokumentacji

Uszeregowane po stosunku zysku do kosztu.

### Tanie i natychmiastowe

**U1. Wersja `.md` każdego dokumentu pod adresem z sufiksem.** Praktyka spotykana w dokumentacji dla agentów: każda strona dostępna też jako czysty Markdown. U nas pliki już są w Markdown, więc to zero pracy, jeśli publikujemy statycznie.

**U2. `llms.txt` generowany przy każdej zmianie.** Indeks z grafu, nie z katalogu — dzięki temu zawiera typ, proces i krótki opis każdego dokumentu.

**U3. Blok „skrót dla modelu" w każdym dokumencie.** Trzy zdania na początku: co to jest, z czego wynika, kto z tego korzysta. Generowane z grafu, wstawiane między znacznikami.

**U4. Nagłówek pliku zawiera skrót zawartości.** Pozwala wykryć, że dokument się zmienił, bez porównywania treści — potrzebne dla przyrostowego budowania indeksu.

### Średnie

**U5. `AGENTS.md` i trzy umiejętności.** Pisanie BFS, rozbicie na scenariusze, naprawa błędów lintera.

**U6. Jeden plik na widok procesu.** Wygenerowany z grafu przegląd całego wycinka: wymagania, scenariusze, punkty końcowe, encje. Model dostaje kontekst procesu w jednym pobraniu zamiast czterdziestu.

**U7. Odnośniki zwrotne w treści między znacznikami.** Rozwiązuje problem z U-011 — czytelnik surowego pliku widzi, kto go używa.

### Drogie, ale warte rozważenia

**U8. Wyszukiwanie znaczeniowe obok grafu.** Graf odpowiada na „co jest połączone", nie na „gdzie opisaliśmy obsługę wyjątków przy płatnościach". Dwa różne pytania. Warstwa wektorowa jako uzupełnienie, nie zamiennik.

**U9. Wykrywanie rozjazdu z kodem.** Porównanie grafu dokumentacji z grafem importów w repozytorium kodu. Produktem jest różnica: punkt końcowy w kodzie bez dokumentu, dokument bez implementacji.

---

## 6. Kolejność prac

```
1. Wypełnić matrycę (P2)                    ← blokuje wszystko
2. Scalić metodykę w jeden dokument (P1)
3. Parser: Markdown → graf                  ← podstawa P3, P4, P5
4. Linter na matrycy (P4)
5. Indeks SQLite (P3)
6. Serwer MCP (P5)
7. Generatory: llms.txt, widoki procesów, odnośniki zwrotne
8. AGENTS.md i umiejętności
```

Kroki 3, 4 i 5 dzielą ten sam parser — warto go napisać raz, jako osobny moduł z testami na korpusie 215 dokumentów.

---

## 7. Do rozstrzygnięcia

| # | Pytanie | Wpływ |
|---|---|---|
| 1 | Czy matryca ma 47 trójek, czy trzeba ją poszerzyć o pary z `macierz-relacji.md` | P2 |
| 2 | Czy `defines` zostaje scalone z `contains` (decyzja z 6 września) | P2, P4 |
| 3 | Czy indeks jest przyrostowy, czy przebudowywany w całości | P3 |
| 4 | Jakie narzędzia wystawia serwer MCP — lista zapytań | P5 |
| 5 | Czy dokumentacja jest publikowana, czy tylko w repozytorium | U1, U2 |
