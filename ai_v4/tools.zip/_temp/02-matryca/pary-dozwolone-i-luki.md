# Macierz relacji — stan i luki

Dla każdej pary typów dokumentów: jaka relacja jest dozwolona i kto ją deklaruje.
Macierz jest źródłem prawdy dla walidatora — para spoza niej to błąd.

Legenda: ✅ ustalone · ❓ do rozstrzygnięcia · — relacja niedozwolona

---

## Część ustalona

| Deklaruje | Cel | Typ | Ustalenie |
|---|---|---|---|
| BFS | NFR | `constrained-by` | U-007 |
| UC, TUC | BFS.REQ, BFS.RB | `realizes` | U-014 |
| UC, TUC | CAP | `realizes` | U-021 |
| UC, TUC | ACTOR.rola | `involves` | U-008 |
| CAP | BFS.REQ | `realizes` | U-018 |
| CAP, FLOW, SPEC-WF | QUE | `consumes` | U-021 |
| API, INT, QUE | CAP | `realizes` | U-019 |
| API, INT, QUE | UC, TUC | `used-in` | U-019 |
| API, SCRSEC | ENT | `uses-data` | U-021 |
| LDM | DDM | `realizes` | U-012 |
| LDM | ENT | `contains` | U-015 |
| ENT | DDM.DOM | `realizes` | U-016 |
| ENT | ENT | `contains` | U-010 |
| STM | DDM.DOM | `realizes` | U-020 |
| SCR | SCRSEC | `contains` | U-013 |
| SCR | UC, TUC | `used-in` | U-021 |
| NAV | SCR | `groups` | U-021 |
| UCMAP | UC, TUC | `groups` | U-021 |
| FLOW | ACT | `contains` | U-021 |
| FLOW | API, INT | `consumes` | U-021 |
| BPMN | SPEC-WF | `contains` | U-021 |
| SPEC-WF | API, INT | `consumes` | U-021 |
| SPEC-WF | SPEC-WF | `precedes` | U-021 |
| ADR | ADR | `supersedes` | U-021 |
| dowolny | NFR | `constrained-by` | U-007 |
| dowolny | ADR | `constrained-by` | U-021 |
| dokument definiujący | własny identyfikator | `defines` | U-005, U-017 |

Korpus 215 dokumentów używa 44 par i wszystkie mieszczą się w tej tabeli.

---

## Luki do uzupełnienia

### L-01 ❓ STM nie ma powiązania z procesem

**Stan:** maszyna stanów wskazuje wyłącznie pojęcie domenowe (`STM → DDM.DOM`).

**Problem:** `DDM` jest wspólny dla wielu procesów, więc `STM` nie da się przypisać do żadnego. W korpusie osiem maszyn stanów wylądowało we wspólnych, choć opisują cykl życia obiektu w konkretnym procesie.

**Do rozstrzygnięcia:** czy `STM` deklaruje dodatkowo `realizes` do `CAP`, czy przynależność ma wynikać z czegoś innego.

### L-02 ❓ BPMN nie ma powiązania z procesem biznesowym

**Stan:** proces silnika deklaruje wyłącznie `contains` do swoich kroków.

**Problem:** ten sam efekt co wyżej — trzy procesy BPMN trafiły do wspólnych.

**Do rozstrzygnięcia:** `BPMN → BFS.REQ` typem `realizes`, czy `BPMN → CAP`.

### L-03 ❓ SPEC-WF a przypadek użycia

**Stan:** krok procesu deklaruje `consumes` do punktów końcowych i `precedes` do sąsiada.

**Problem:** nie wiadomo, który scenariusz krok realizuje. Zapytanie o testy nie połączy `SPEC-WF` ze scenariuszem użytkownika.

**Do rozstrzygnięcia:** czy `SPEC-WF` deklaruje `used-in` do `TUC`, analogicznie do punktu końcowego.

### L-04 ❓ Rola aktora: inicjuje czy uczestniczy

**Stan:** jeden typ `involves`, bez rozróżnienia.

**Problem:** oryginalna macierz aktorów miała trzy wartości: inicjuje, uczestniczy, nie bierze udziału. Wygenerowana z grafu będzie miała dwie.

**Do rozstrzygnięcia:** drugi typ relacji (`initiates`), pole w relacji (`role: initiator`), czy rezygnacja z rozróżnienia.

### L-05 ❓ Kompozycja a zwykłe odwołanie między encjami

**Stan:** jeden typ `contains` na oba przypadki.

**Problem:** „dyspozycja zawiera pozycje" i „dyspozycja odwołuje się do klienta" to różne rzeczy. Pozycja ginie razem z dyspozycją, klient nie. Graf tego nie odróżnia, więc zasięg zmiany traktuje oba tak samo.

**Do rozstrzygnięcia:** czy dołożyć `references`, czy zostawić jeden typ.

### L-06 ❓ ACT i SCRSEC nie deklarują niczego w górę

**Stan:** aktywność i sekcja ekranu są wskazywane przez rodzica (`FLOW → ACT`, `SCR → SCRSEC`), same nie deklarują nic poza `uses-data`.

**Problem:** to zgodne z U-011, ale `ACT` bez żadnej relacji wychodzącej jest liściem, który nie mówi, co realizuje.

**Do rozstrzygnięcia:** czy to jest w porządku, czy `ACT` powinien wskazywać `CAP` albo wymaganie.

### L-07 ❓ Zdarzenie: producent i odbiorca tym samym typem

**Stan:** `QUE → CAP` typem `realizes` oznacza producenta. `CAP → QUE` typem `consumes` oznacza odbiorcę.

**Problem:** kierunek zależy od tego, po której stronie stoisz, i łatwo o pomyłkę. Walidator nie wykryje, że ktoś zadeklarował producenta zamiast odbiorcy.

**Do rozstrzygnięcia:** czy przywrócić typ `publishes` dla jasności, czy zostawić.

---

## Pary jawnie zabronione

Te kombinacje walidator odrzuca — wpisane, żeby nie trzeba było ich rozstrzygać za każdym razem.

| Deklaruje | Cel | Dlaczego |
|---|---|---|
| BFS | UC, TUC, CAP | odwrócony kierunek, U-011 |
| NFR | cokolwiek poza własnymi identyfikatorami | NFR jest tylko celem |
| ACTOR | UC, TUC | odwrócony kierunek, U-008 |
| CAP | UC, TUC, API, INT | odwrócony kierunek, U-018 |
| DDM | LDM, ENT | odwrócony kierunek, U-012 |
| SCRSEC | SCR | odwrócony kierunek, U-013 |
| ENT | LDM | odwrócony kierunek, U-015 |
| dowolny | BFS jako całość | wskazuje się `REQ` albo `RB`, nie dokument |

---

## Do uzupełnienia przy wdrożeniu

Poza lukami merytorycznymi zostają trzy rzeczy techniczne:

- format zapisu macierzy w `metadata-and-linking.md` — tabela, YAML, czy oba
- czy walidator odrzuca parę spoza macierzy, czy tylko ostrzega w pierwszym miesiącu
- kto zatwierdza dopisanie nowej pary
