# Standard dokumentacji — wyciąg ze zdjęć

Źródło: repozytorium `docs-standards`, ścieżka `docs/standard/90-templates/`, gałąź `develop` (GitLab).
Ostatnia widoczna zmiana: „Add mandatory Change History section to documentation templates", Kamil Cieślik, ok. miesiąc przed zrzutem.

---

## 1. Drzewo katalogu szablonów

```
90-templates/
├── architecture/
│   └── decision-records/
│       └── adr.md
├── functional/
│   ├── actors/actors.md
│   ├── business-functional-specs/business-functional-spec.md
│   ├── data-models/ddm.md
│   ├── technical-use-cases/technical-use-case.md
│   └── use-cases/
│       ├── use-case-technical-map.md
│       └── use-case.md
├── gui/
│   └── gui-specs/…
├── system/
│   ├── apis/api-endpoint.md
│   ├── asyncapi/asyncapi-event.md
│   ├── capabilities/capability.md
│   ├── data-models/
│   │   ├── ldm-entity.md
│   │   └── ldm.md
│   ├── flows/
│   │   ├── activity.md
│   │   └── flow.md
│   ├── integrations/integration.md
│   ├── non-functional-requirements/non-functional-requirements.md
│   ├── state-machines/state-machine.md
│   ├── ui-specs/screen-section.md
│   └── workflows/bpmn-process.md
└── _meta-template.md
```

Uwaga: `screen.md` i `navigation-map.md` w tabeli katalogowej należą do obszaru GUI, a `screen-section.md` leży w `system/ui-specs/`. Sam szablon sekcji ekranu jest opisany jako „warstwa systemowa".

---

## 2. Katalog artefaktów (tabela z dokumentu przeglądowego)

Szablony pogrupowane wg docelowego obszaru: `functional`, `system`, `gui`, `architecture`. Mapę `type → folder` opisuje `metadata-and-linking.md`.

### Functional

| Szablon | Plik | doc-id | Kiedy używać |
|---|---|---|---|
| Business Functional Spec | business-functional-spec.md | `BFS-` | Punkt wejścia do analizy systemowej (praca przyrostowa lub projektowa) |
| Use Case | use-case.md | `UC-` | Scenariusz działania użytkownika |
| Technical Use Case | technical-use-case.md | `TUC-` | Scenariusz działania systemu bez udziału użytkownika (cron, harmonogram, zadanie nocne) |
| Use Case + Technical Map | use-case-technical-map.md | `UCMAP-` | Mapa relacji UC i TUC z aktorami oraz relacjami include/extend/exclude |
| Actor | actors.md | `ACTOR-` | Aktorzy w procesie |
| Domain Data Model | ddm.md | `DDM-` | Domenowy model danych (pojęcia biznesowe i relacje) |

### System

| Szablon | Plik | doc-id | Kiedy używać |
|---|---|---|---|
| Capability | capability.md | `CAP-` | Zakres odpowiedzialności komponentu (mapa artefaktów) |
| Non-Functional Requirements | non-functional-requirements.md | `NFR-` | Wymagania jakościowe systemu/komponentu |
| API Endpoint | api-endpoint.md | `API-` | Opis jednego punktu końcowego API |
| Integracja | integration.md | `INT-` | Integracja z systemem zewnętrznym |
| Przepływ (Flow) | flow.md | `FLOW-` | Przepływ biznesowy lub techniczny |
| Krok przepływu (Activity) | activity.md | `ACT-` | Wydzielony krok przepływu ze złożonym algorytmem |
| Maszyna stanów | state-machine.md | `STM-` | Cykl życia obiektu jako maszyna stanów |
| Sekcja ekranu | screen-section.md | `SCRSEC-` | Szczegółowy opis pól w sekcji ekranu |
| Logical Data Model | ldm.md | `LDM-` | Logiczny model danych (encje, atrybuty, relacje) |
| Encja modelu logicznego | ldm-entity.md | `ENT-` | Szczegółowy opis pojedynczej encji |
| AsyncAPI — publikacja zdarzenia | asyncapi-event.md | `QUE-` | Kontrakt zdarzenia publikowanego przez brokera (Kafka/RabbitMQ) |

### Workflow (BPMN/BPMS)

| Szablon | Plik | doc-id | Kiedy używać |
|---|---|---|---|
| Proces BPMN | bpmn-process.md | `BPMN-` | Mapa procesu w silniku Workflow — orkiestracja, nie logika |
| Krok Workflow (SPEC-WF) | workflow-step.md | `SPEC-WF-` | Logika pojedynczego zadania BPMN (reguły, zmienne procesowe, kryteria akceptacji) |

### GUI

| Szablon | Plik | doc-id | Kiedy używać |
|---|---|---|---|
| Ekran | screen.md | `SCR-` | Opis ekranu z odnośnikami do makiet, z podziałem na sekcje |
| Mapa nawigacyjna ekranów | navigation-map.md | `NAV-` | Przejścia i połączenia między ekranami procesu |

### Architecture

| Szablon | Plik | doc-id | Kiedy używać |
|---|---|---|---|
| ADR | adr.md | `ADR-` | Rejestracja decyzji architektonicznej |

### Meta

| Plik | Cel |
|---|---|
| `_meta-template.md` | Szablon do tworzenia nowych szablonów |

Dodanie nowego szablonu: prompt `create-new-template` w Copilot Chat, albo ręczna kopia `_meta-template.md`; następnie zgłoszenie zmiany do repozytorium `docs-standards` (praca w kopii repozytorium).

---

## 3. Wspólna struktura każdego szablonu

Każdy plik szablonu ma identyczny szkielet siedmiu sekcji:

1. Jakiego artefaktu to szablon?
2. Kiedy analityk powinien go użyć? — bloki „Użyj gdy" i „Nie używaj gdy" (z odesłaniem do właściwego szablonu)
3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
4. Front matter (obowiązkowe pola)
5. Struktura sekcji (blok kodu do skopiowania, z komentarzami `<!-- DLACZEGO: … -->`)
6. Warianty
7. Powiązany prompt generujący

Front matter samego szablonu: `doc-id: TPL-*`, `title`, `status: active`, `tags: [standard, template, …]`, `related-doc-ids`, opcjonalnie `examples-ids`.

Front matter dokumentu tworzonego z szablonu: `doc-id`, `title`, `status: draft`, `type`, `component`, opcjonalnie `source-spec-ids` (dokument nadrzędny), `related-doc-ids` (dokumenty powiązane), `owner`.

Lokalizacja docelowa wynika z pola `type` zgodnie z mapą `type → folder`.

Każdy szablon kończy się obowiązkową sekcją „Historia zmian": `Źródło | Autor | Data | Wydanie | Opis` (odnośnik do Jiry, imię i nazwisko, data zapisu, odnośnik do wydania, krótki sens zmiany dla odbiorcy).

### Identyfikatory szablonów (`TPL-*`)

`TPL-BFS`, `TPL-UC`, `TPL-TUC`, `TPL-UCMAP`, `TPL-ACTOR`, `TPL-DDM`, `TPL-LDM`, `TPL-ENT`, `TPL-CAP`, `TPL-NFR`, `TPL-API`, `TPL-INT`, `TPL-FLOW`, `TPL-ACT`, `TPL-STM`, `TPL-QUE`, `TPL-SCR`, `TPL-SCRSEC`, `TPL-NAV`, `TPL-ADR`, `TPL-BPMN`, `TPL-WF`.

### Powoływane inwarianty

- I1 — jedno źródło prawdy dla diagramu; zakaz duplikowania w innej notacji.
- I3 — jeden byt = jeden plik (jeden ADR, jedno API, jedna encja, jedna aktywność, jeden task BPMN, jeden wariant UC/TUC).
- I7 — opis zachowania z perspektywy biznesowej, nie kopia kodu ani kontraktu OpenAPI.

---

## 4. Szablony — wyciąg szczegółowy

### 4.1 BFS — Business Functional Spec (`TPL-BFS`, `BFS-`)

Opisuje wymagania funkcjonalne i reguły biznesowe dla jednego procesu biznesowego. Odpowiada na pytanie „Co proces musi robić i dlaczego?". Dokument nadrzędny wobec przypadków użycia.

- Powiązane szablony: `TPL-UC`, `TPL-NFR`, `TPL-ADR`.
- Użyj gdy: start projektu i katalogowanie wymagań; zebranie reguł biznesowych przed rozbiciem na UC; grupowanie wymagań biznesowych, reguł, wymagań prawnych, UX (WCAG), zgodności oraz wspólnego słownika pojęć.
- Nie używaj gdy: szczegółowy scenariusz użytkownika (→ `use-case`); decyzja architektoniczna (→ `adr`).
- Sekcje: tabela nagłówkowa (Proces, Właściciel biznesowy); Kontekst biznesowy; Cel; Zakres (W zakresie / Poza zakresem); Wymagania funkcjonalne (`REQ-01…` + priorytet MoSCoW + powiązanie z UC); Reguły biznesowe (`RB-01…` + źródło/uzasadnienie); Wymagania niefunkcjonalne jako referencje po `NFR-ID`; Słownik pojęć; Założenia i otwarte pytania (właściciel, termin, status); Historia zmian.
- Warianty: BFS dla nowego procesu (puste `related-doc-ids`, tabela wymagań jako zaległości do rozbicia na UC); BFS dla istniejącego procesu (dokumentacja wsteczna — start od reguł biznesowych wydobytych z kodu).
- Prompt: `.github/prompts/create-business-functional-spec.prompt.md`, wywołanie `/create-business-functional-spec` w Copilot Chat; źródła: epiki i zadania z Jiry, strony Confluence, pliki z GitLaba, opis słowny analityka.

### 4.2 Use Case (`TPL-UC`, `UC-`)

Scenariusz działania użytkownika: co chce osiągnąć, jak to robi krok po kroku i co może pójść nie tak. Odpowiada na „Co użytkownik robi i czego oczekuje?".

- Podrzędny wobec BFS — musi wskazywać realizowane `REQ-*` i `RB-*`. Odwołuje się do Capability i GUI.
- Powiązane: `TPL-BFS`, `TPL-CAP`, `TPL-NFR`, `TPL-FLOW`, `TPL-INT`.
- Sekcje: tabela nagłówkowa (Aktor główny, Kanały, BFS/SPEC, Powiązane REQ, Powiązane RB, Makiety); Powiązanie z BFS (tabela `Typ | ID z BFS | Jak UC to realizuje`); Cel; Aktorzy; Kiedy można to zrobić (warunki wstępne jako lista kontrolna); Kroki; Co może pójść inaczej (`A1`, `A2`…); Co może pójść nie tak (`E1`, `E2`…); Reguły biznesowe (`RB` + źródło w BFS); Ograniczenia NFR (referencje po ID); Kryteria akceptacji w formacie „Kiedy / wtedy"; Diagram Mermaid `flowchart TD` (opcjonalny, maks. 15 kroków); Historia zmian.
- Warianty: uproszczony (jeden przepływ, bez diagramu); po BFS (zalecany); złożony (rozbicie na pliki: jeden UC na aktora lub kanał).

### 4.3 Technical Use Case (`TPL-TUC`, `TUC-`)

Scenariusz uruchamiany automatycznie przez system, bez udziału człowieka. Odpowiada na „Co system wykonuje automatycznie i jakiego efektu oczekujemy?". Również podrzędny wobec BFS.

- Sekcje analogiczne do UC, ale: tabela nagłówkowa zawiera Aktora `[System]` i Trigger (np. `cron 02:00`, zdarzenie, harmonogram); kroki opisują akcje systemu; sytuacje błędne odwołują się do polityki błędu (ponowienie/eskalacja/zatrzymanie).
- Warianty: uproszczony, po BFS (zalecany), złożony (jeden TUC na wariant, łączenie przez `related-doc-ids`).

### 4.4 Use Case + Technical Use Case Map (`TPL-UCMAP`, `UCMAP-`)

Jeden diagram relacji między UC i TUC — powiązania `<<include>>`, `<<extend>>`, `<<exclude>>` oraz aktorzy.

- Sekcje: tabela nagłówkowa (Aktorzy biznesowi, Aktorzy systemowi, Wersja diagramu); Cel; Legenda relacji; Diagram Mermaid `flowchart LR` z klasami dla aktorów, UC i TUC; Opis relacji (`Źródło | Relacja | Cel | Uzasadnienie`); Powiązanie z artefaktami szczegółowymi (odnośniki do plików UC i TUC); Otwarte pytania; Historia zmian.
- Znaczenie relacji: `include` — krok obowiązkowy; `extend` — krok warunkowy; `exclude` — wzajemne wykluczenie wariantów (nie jest to standard UML).
- Warianty: lekki (do 5 przypadków — tylko Cel, Diagram, Opis relacji, Powiązania); rozbudowany (podział diagramu na obszary, jeden plik mapy).

### 4.5 Actors (`TPL-ACTOR`, `ACTOR-`)

Wspólna baza aktorów (użytkowników i ról systemowych) dla UC i TUC — role, odpowiedzialności, uprawnienia, zależności.

- Reguły modelowania: jeden aktor = jedna nazwa kanoniczna i jedno ID; rola opisuje odpowiedzialność biznesową, nie stanowisko; aktor systemowy realizuje kroki bez udziału człowieka; dziedziczenie uprawnień pokazuj jawnie w tabeli i na diagramie relacji.
- Sekcje: Kontekst biznesowy; Cel; Zakres (W zakresie / Poza zakresem); Klasyfikacja aktorów (biznesowy/systemowy + kryterium kwalifikacji); Przykład minimalny; Aktorzy (tabela kanoniczna); Mapa udziału aktorów w procesach (macierz aktor × UC/TUC z wartościami Inicjuje / Uczestniczy / –); Słownik nazw i aliasów; Historia zmian.
- Warianty: aktorzy per proces; aktorzy per system (preferowany dla spójności nazewniczej).

### 4.6 DDM — Domain Data Model (`TPL-DDM`, `DDM-`)

Model domenowy danych dla jednego obszaru: pojęcia biznesowe, znaczenie, reguły i relacje. Odpowiada na „Co te dane znaczą w domenie i jakimi regułami się rządzą?".

- Poziom analityczny, niezależny od implementacji, struktury bazy i kontraktów API. Nadrzędny i niezależny od konsumentów — to oni referują do modelu.
- Front matter zawiera dodatkowo `source-model` (np. „EA CaseRepository / Case v4.0").
- Konwencja pliku: jeden obszar domenowy = jeden plik (`ddm-case.md`, `ddm-loans.md`).
- Sekcje: tabela nagłówkowa (Obszar, Źródło domeny); Cel i zakres; Źródła wymagań w górę (EA/CaseRepository, Jira, polityki i regulacje); Słownik pojęć domenowych (`DOM-{Nazwa}` + definicja, synonimy, właściciel pojęcia); Encje i Value Objects (typ, tożsamość, odpowiedzialność); Relacje i agregaty (opcjonalny `classDiagram`); Reguły i inwarianty domenowe (`RD-001…` + kryterium walidacji); Zakres poza dokumentem; Historia zmian.
- DDM nie opisuje: struktury logicznej (to LDM), konsumentów modelu.
- Sposób pracy: od źródła w górę (model EA, Jira, rozmowy) → pojęcia z ID `DOM-*` → encje i Value Objects, agregaty → reguły `RD-*` → mapowanie do LDM.

### 4.7 LDM — indeks (`TPL-LDM`, `LDM-`)

Model logiczny danych dla obszaru: obiekty logiczne, atrybuty, relacje, typy logiczne. Pomost między domeną (DDM) a interfejsami. Plik indeksu; szczegóły encji w osobnych plikach.

- Front matter: `source-spec-ids: DDM-{numer}`, `source` (np. eksport XML z EA).
- Sekcje: tabela nagłówkowa (ID, Źródło DDM, Wersja, Źródło); Cel i zakres; Źródło (DDM); Mapowanie DDM → LDM (`DOM-{Nazwa}` → `ENT-{Nazwa}` + uzasadnienie); Diagram ER (Mermaid `erDiagram`, bez kluczy PK/FK, z notacją liczebności); Encje (lista z `ENT-*` i odnośnikami); Kluczowe relacje; Słowniki zewnętrzne; Reguły walidacyjne i spójności (`RW-001` z powiązaniem do `RD-*`); Zakres poza dokumentem; Historia zmian.
- Słownik typów logicznych: `String`, `Integer`, `Decimal`, `Date`, `DateTime`, `Boolean`, `UUID`, `Dictionary[NazwaSłownika]`, `Enum`. Zakaz typów fizycznych (`VARCHAR(255)`, `BIGINT`, `TIMESTAMP WITH TIME ZONE`).
- Nie umieszczać: kluczy fizycznych i relacji po kluczach, typów i struktur fizycznych, nazw klas i adnotacji ORM, wartości domyślnych zależnych od środowiska, referencji do konsumentów.
- Sposób pracy: DDM jako źródło → mapowanie `DOM-*` → `ENT-*` → diagram ER → plik na encję → relacje, słowniki i reguły walidacyjne z odesłaniem do `RD-*`.

### 4.8 LDM — encja (`TPL-ENT`, `ENT-`)

Pojedyncza encja modelu logicznego: pełna lista atrybutów, powiązania, reguły. Jeden plik = jedna encja. Podrzędna wobec indeksu LDM, realizuje pojęcia z DDM.

- Konwencja pliku: kebab-case, angielski, bez przedrostka `t_` i sufiksu `_table` (`cases.md`, `case-data.md`, `loan-application.md`).
- Sekcje: nagłówek (`ID`, `Alias biznesowy`, `Realizuje pojęcie (DDM)`); Opis; Atrybuty (Nazwa, Alias, Typ logiczny, Wymagalność, Identyfikator, Opis); Typy wyliczeniowe; Powiązania (relacja, encja docelowa, liczebność, opis — bez kluczy fizycznych); Reguły biznesowe (`RB-001`, reguły domenowe pozostają w DDM); Uwagi (jawne braki, „nie zmodelowano"); Historia zmian.
- Tożsamość: kolumna `Identyfikator` = „Tak" dla atrybutów współtworzących tożsamość; to pojęcie logiczne, nie klucz główny.

### 4.9 Capability (`TPL-CAP`, `CAP-`)

Zakres odpowiedzialności komponentu, modułu lub domeny — analogia kontraktu komponentu. Spina i referuje szczegóły z UC, TUC, NFR, API i integracji, ale ich nie duplikuje.

- Nie używaj gdy: kroki scenariusza (→ UC/TUC), kontrakt punktu końcowego (→ api-endpoint), połączenie z systemem zewnętrznym (→ integration), wymagania jakościowe (→ NFR), reguły biznesowe (→ BFS, który jest ich domem).
- Sekcje: Cel biznesowy; Zakres odpowiedzialności (in-scope); Poza zakresem (out-of-scope); Zdarzenia i kontrakty domenowe (publikowane/odbierane); Miary i kryteria skuteczności (KPI/SLA); Ryzyka i ograniczenia; Historia zmian.
- Warianty: minimalny (Cel, in-scope, out-of-scope; powiązania z front matter renderuje mechanizm automatyczny) i pełny (zalecany).

### 4.10 NFR — Non-Functional Requirements (`TPL-NFR`, `NFR-`)

Wymagania jakościowe: szybkość, bezpieczeństwo, niezawodność, operacyjność. Dokument nadrzędny dla ograniczeń niefunkcjonalnych — BFS, Capability, UC, TUC, API i integracje referują do niego po identyfikatorze.

- Bazowy zestaw powstaje na etapie VISION i jest uszczegóławiany później.
- Identyfikatory wewnętrzne (`NFR-PERF-01`, `NFR-SEC-01`) są lokalnymi ID wierszy macierzy, nie `doc-id`.
- Sekcje: tabela nagłówkowa (Zakres: system/component/process; Właściciel; Krytyczność); Cel i kontekst; Macierz wymagań (ID, atrybut jakości, metryka, próg docelowy, metoda pomiaru); Katalog wg kategorii — Performance, Availability i Reliability, Security i Compliance, Observability i Auditability, Operability i Maintainability, Continuity (RTO/RPO); Traceability do artefaktów (NFR × CAP/UC/TUC/API/INT); Weryfikacja i monitorowanie (przed wydaniem / po wydaniu / próg alertu); Wyjątki i odstępstwa (powód, akceptujący, data wygaśnięcia); Historia zmian.
- Warianty: NFR systemowy (`scope: system`) i komponentowy (`scope: component`).

### 4.11 API Endpoint (`TPL-API`, `API-`)

Opis jednego punktu końcowego: cel, parametry, zachowanie, model odpowiedzi. Jeden punkt końcowy = jeden plik. Opisuje to, czego nie wynika z OpenAPI/Swagger.

- Konwencja pliku: `{metoda}-{zasób}.md` (`get-offers.md`, `post-reset-prelimit.md`).
- Sekcje: Cel; Parametry wejściowe (parametr, typ, wymagany, źródło: query/header/path/body); Walidacja pól wejściowych (reguła, kod błędu HTTP, komunikat zwracany przez system); Złożone parametry wejściowe (opcjonalna — np. zaszyfrowany token zawierający kilka informacji); Autentykacja (JWT Bearer / publiczny / wymagana rola); Zachowanie (scenariusze: przebieg podstawowy, przypadek brzegowy); Model odpowiedzi (opcjonalny — `classDiagram` plus tabela pól, bez kopiowania OpenAPI); Struktura odpowiedzi błędnej; Zależności; Historia zmian.

### 4.12 Integracja (`TPL-INT`, `INT-`)

Integracja z systemem zewnętrznym z perspektywy konsumenta: cel, protokół, operacje, obsługa błędów.

- Konwencja pliku: `{nazwa-systemu}.md`; przy wielu operacjach osobny plik na operację `{system}-{operacja}.md`.
- Sekcje: Cel; Protokół (Typ: REST/SOAP/gRPC/JMS; Właściciel: Area/Tribe/Squad; Endpoint; API Catalog); Operacje konsumowane (Żądanie: pole, źródło, opis; Odpowiedź: tylko pola istotne dla nas — bez kopiowania pełnej specyfikacji dostawcy); Warunek wywołania; Obsługa błędów (404, 5xx, przekroczenie czasu); Diagram sekwencji; Historia zmian.

### 4.13 Przepływ — Flow (`TPL-FLOW`, `FLOW-`)

Sekwencja kroków procesu biznesowego lub technicznego, z wariantami. Bez schodzenia do implementacji.

- Konwencja pliku: `{operacja}-{wariant}.md` (`get-offers-happy-path.md`, `get-offers-error-handling.md`).
- Zasada: diagram maks. 10–15 uczestników lub kroków; większe dzielić na poddiagramy.
- Sekcje: Warunki wstępne; Diagram; Opis przepływu (lista kroków; aktywność wymagająca osobnej specyfikacji dostaje czytelny tytuł i odnośnik do `activity`); Scenariusze błędów; Historia zmian.
- Warianty jako osobne pliki: przebieg podstawowy oraz obsługa błędów.

### 4.14 Activity (`TPL-ACT`, `ACT-`)

Jedna aktywność z diagramu przepływu: logika biznesowa, wejście i wyjście, reguły, scenariusze błędów. Jeden plik = jedna aktywność.

- Konwencja pliku: `{nazwa-aktywności}.md`, kebab-case (`fetch-individual-offers.md`).
- Front matter: `source-spec-ids: FLOW-{numer}`.
- Sekcje: Cel; Opis akcji; Wejście/wyjście; Warunki i reguły; Scenariusze błędów; Zależności; Historia zmian.
- Brak wariantów — jednolita struktura.

### 4.15 Maszyna stanów (`TPL-STM`, `STM-`)

Cykl życia obiektu lub procesu: dozwolone stany, przejścia i warunki ich wyzwalania, stany terminalne (sukces, błąd, rezygnacja).

- Sekcje: Warunki wstępne; Diagram maszyny stanów (Mermaid `stateDiagram-v2`, generowany z tabel); Stany — opis: Słownik statusów (kod, status, opis, czy końcowy) oraz Stany procesowe (ObjectFlow: stan z, stan do, opis przejścia, typ przepływu `MAIN`/`ALTERNATIVE`/`ERROR`); Kluczowe elementy (główna ścieżka sukcesu, przejścia alternatywne, przekroczenie czasu, odrzucenia i rezygnacje); Scenariusze błędów; Historia zmian.
- Warianty: diagram wyeksportowany z EA (katalog `assets/`) albo domyślny diagram Mermaid generowany z tabel.

### 4.16 Ekran (`TPL-SCR`, `SCR-`)

Pojedynczy ekran procesu użytkownika: cel, podział na sekcje, kolejność wyświetlania, nawigacja do sąsiednich kroków. Spina sekcje (`screen-section`) i osadza ekran w mapie nawigacyjnej.

- Front matter zawiera dodatkowo `step: {numer-kroku}`.
- Tytuł: „Ekran {Nazwa produktu}: Krok {X} z {Y} — {Nazwa kroku}".
- Sekcje: Opis ekranu (cele ekranu, odnośnik do Figmy); Mapa sekcji na ekranie (obrazy, kolejność od góry); Struktura ekranu (kolejność, sekcja, opis, warunek wyświetlenia); Kolejne ekrany (krok poprzedni/bieżący/następny ze statusem); Nawigacja (przycisk wstecz, przycisk „Dalej", odnośniki dodatkowe); Historia zmian.

### 4.17 Sekcja ekranu (`TPL-SCRSEC`, `SCRSEC-`)

Jeden wydzielony fragment ekranu: pola, źródła danych, walidacje, reguły biznesowe, zachowania. Podrzędna wobec ekranu.

- Sekcje: Opis sekcji; Pola sekcji — blok powielany dla każdego pola, z atrybutami: Typ pola, Etykieta, Wartość domyślna, Wartość przykładowa, Źródło danych, Miejsce utrwalenia, Edytowalność, Wymagalność, Uprawnienia, Walidacja, Zachowanie, Tooltip, WCAG (atrybut `aria`), Analityka zdarzeń (opcjonalnie), Referencja komponentu UI (opcjonalnie); Reguły biznesowe; Zachowania specjalne (opcjonalnie, pseudokod); Historia zmian.

### 4.18 Mapa nawigacyjna ekranów (`TPL-NAV`, `NAV-`)

Przejścia między ekranami jednego procesu — ścieżka podstawowa i ścieżki błędne. Konwencja: jeden proces = jedna mapa.

- Sekcje: Warunki wstępne (zakres mapy, założenia o kompletności); Diagram nawigacji (Mermaid `flowchart TD`: ekran startowy, pośredni, końcowy, ekran błędu, wyjście poza przepływ); Kluczowe elementy nawigacji; Odniesienia do ekranów (ekran, rola w mapie, dokument); Scenariusze błędów; Historia zmian.
- Każdy ekran z diagramu musi mieć wpis w tabeli odniesień.

### 4.19 AsyncAPI — publikacja zdarzenia (`TPL-QUE`, `QUE-`)

Kontrakt zdarzenia publikowanego asynchronicznie przez brokera. Jeden plik = jeden obszar logiczny komunikacji.

- Front matter zawiera dodatkowo `broker: {kafka|rabbitmq|inne}`.
- Konwencja pliku: kebab-case, angielski (`asyncapi-overdraft-renewal.md`, `asyncapi-loan-origination.md`).
- Sekcje: Informacje podstawowe (nazwa zdarzenia, wersja, system producenta, adres kanału, format JSON/AVRO, producent, konsumenci); Cel i zakres; Kontekst biznesowy z odnośnikiem do dokumentu nadrzędnego (TUC/UC); Przepływ danych (diagram sekwencji: producent → broker → konsument); Nagłówek komunikatu (`correlationId`, `messageId`, `ce_id`, `ce_source`, `ce_time`, `content-type` — zgodnie z wytycznymi dla AsyncAPI 3.0 i CloudEvents); Specyfikacja schematu (atrybut: typ, obligatoryjność, wartości/format, opis biznesowy); Przykład ładunku (JSON); Charakterystyka dostarczenia (gwarancja dostarczenia, idempotencja konsumenta, kolejność, klucz partycji, retencja, kolejka wiadomości niedostarczonych); Powiązanie z przepływem od początku do końca; Powiązane dokumenty; Historia zmian.
- Wariant alternatywny: plik AsyncAPI wygenerowany z Enterprise Architect — wtedy szablon pełni rolę dokumentacji uzupełniającej.

### 4.20 Proces BPMN (`TPL-BPMN`, `BPMN-`)

Mapa procesu systemowego realizowanego przez silnik Workflow (BPMN/BPMS). Orkiestracja: sekwencja, sterowanie, podział na User Task i Service Task. Bez logiki kroków — ta trafia do SPEC-WF.

- Zasady: silnik BPMN jest jedynym źródłem prawdy dla diagramu (zakaz duplikowania w Mermaid lub ASCII — inwariancja I1); maks. 15 zadań na diagramie, większe procesy dzielić na podprocesy (I3); każdy User Task musi mieć powiązaną specyfikację interfejsu, każdy Service Task — SPEC-WF; każda zmiana procesu wymaga aktualizacji `process-version`.
- Front matter: `process-version: "1.0"` wiążące specyfikację z konkretną wersją pliku BPMN XML (znacznik lub skrót zapisu).
- Konwencja pliku: nazwa odpowiada identyfikatorowi procesu w silniku (`bpmn-decyzja-wstepna.md`); podprocesy jako osobne pliki.
- Sekcje: Cel procesu; Kontekst (system, silnik BPMN, inicjator, zakres); Diagram procesu (tabela zasobów: BPMN XML, widok w silniku, eksport PNG/SVG); Zadania procesu (ID zadania, typ, nazwa, odnośnik do SPEC-WF); Bramki i warunki; Zdarzenia graniczne; Podprocesy; Powiązane dokumenty; Historia zmian.
- Warianty: pełny proces, podproces, proces obsługi błędów.
- Miejsce plików BPMN: `docs/project/system/workflows/bpmn/{nazwa}.bpmn` oraz opcjonalny eksport `.svg`.
- Cykl życia: analityk tworzy BPMN XML (Camunda Modeler) → wypełnia specyfikację procesu → tworzy SPEC-WF dla każdego zadania → zapisuje razem specyfikację, BPMN XML i SPEC-WF.
- Model źródeł prawdy: katalog dokumentacji — intencja biznesowa (analityk); repozytorium kodu — implementacja (programista); Camunda — proces wdrożony (silnik). Przy rozbieżności kod jest źródłem prawdy implementacyjnej, dokumentacja — intencji biznesowej.
- Prompt `generate-bpmn-process-spec` nie istnieje (do zdefiniowania).

### 4.21 Krok Workflow — SPEC-WF (`TPL-WF`, `SPEC-WF-`)

Logika pojedynczego zadania procesu BPMN: przyjmowane i oddawane zmienne procesowe, reguły, wywoływane zasoby, obsługa błędów. Jeden task BPMN = jeden plik.

- Granica odpowiedzialności:

  | SPEC-WF opisuje | SPEC-WF nie opisuje |
  |---|---|
  | Jak zadanie używa API w tym procesie | Kontrakt API — w SPEC-API |
  | Jak zadanie wywołuje capability i co robi z wynikiem | Logika capability — w `capability.md` |
  | Zmienne procesowe wchodzące i wychodzące | Schemat danych domenowych — w modelu danych |
  | Reguły specyficzne dla tego kroku | Reguły globalne — w `capability.md` lub specyfikacji funkcjonalnej |

- Front matter: `bpmn-process-id`, `bpmn-task-id`, `task-type: service-task | user-task`.
- Konwencja pliku: `spec-wf-{nnn}.md`.
- Sekcje: Kontekst (proces BPMN, etap procesu, typ zadania, aktor/serwis, Jira); Cel zadania; Warunki wstępne; Wywoływane zasoby (API, Capability, Integracja, interfejs — deklaracja, nie duplikacja kontraktów); Zmienne procesowe — wejście (odczytywane z kontekstu) i wyjście (zapisywane do kontekstu); Reguły i logika (formułowane deterministycznie: „jeśli X, to Y"); Scenariusze błędów; Obsługa zdarzeń granicznych; Efekty uboczne (zmiany stanu obiektów domenowych, powiadomienia); Kryteria akceptacji (`AC-01` w formacie Given/When/Then); Powiązane dokumenty; Historia zmian.
- Warianty: Service Task, User Task, Script Task, wywołanie podprocesu.
- Prompt `generate-workflow-step-spec` nie istnieje (do zdefiniowania).

### 4.22 ADR — Architecture Decision Record (`TPL-ADR`, `ADR-`)

Pojedyncza decyzja architektoniczna: kontekst, rozważane opcje, wybór i konsekwencje. Zachowuje historię decyzji — status `Deprecated` zamiast usuwania. Nie rejestruje dyskusji, ta zostaje w zgłoszeniu scalenia.

- Numeracja trzycyfrowa, sekwencyjna (`ADR-001`, `ADR-002`).
- Status: `Proposed | Accepted | Deprecated`.
- Sekcje: Status; Kontekst; Opcje (A, B… z zaletami i wadami, wybrana oznaczona); Decyzja z uzasadnieniem; Konsekwencje (zmiany, ryzyka, kompromisy, ograniczenia); Historia zmian.
- Brak wariantów; minimum dwie rozważane opcje.

---

## 5. Prompty generujące

- Jedyny dedykowany prompt: `create-business-functional-spec` (dla BFS).
- Pozostałe artefakty powstają promptami ogólnymi: `generate-spec-from-code`, `generate-spec-from-jira`, `generate-spec-from-description`.
- Prompt do tworzenia nowych szablonów: `create-new-template`.
- Braki zadeklarowane wprost: `generate-bpmn-process-spec`, `generate-workflow-step-spec`.

---

## 6. Zasady przekrojowe widoczne we wszystkich szablonach

1. **Traceability w górę, nie w dół.** Dokument referuje swoje źródła; konsumenci referują do niego. Wyraźnie w DDM, LDM i NFR.
2. **Zakaz duplikacji treści.** Każdy szablon ma sekcję „Nie używaj gdy" oraz „Zakres poza dokumentem" lub „Czego nie umieszczać".
3. **Stabilne identyfikatory jako mechanizm łączenia.** `REQ-*`, `RB-*`, `RD-*`, `RW-*`, `DOM-*`, `ENT-*`, `NFR-*-nn`, `AC-*` — referencje po ID zamiast kopiowania treści.
4. **Jawne braki.** Wzorzec `> Założenie: …` oraz tabela otwartych pytań z właścicielem i terminem.
5. **Komentarze „DLACZEGO" w szablonach.** Każda sekcja tłumaczy powód swojego istnienia.
6. **Powiązania przez front matter, nie przez ścieżki.** `source-spec-ids` i `related-doc-ids`; ścieżkę docelową i tytuł wylicza mechanizm automatyczny (hook).
7. **Obowiązkowa historia zmian** w każdym szablonie.
8. **Diagramy Mermaid ze wskazanymi limitami** (maks. 15 kroków), z wyjątkiem BPMN, gdzie źródłem jest silnik.
