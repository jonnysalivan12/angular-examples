# Przykład: symetryczne relacje dla 13 dokumentów

Zakres: 2 UC, 3 API, 5 encji, 2 CAP, 1 ACTOR. Dodatkowo `BFS-003` i `LDM-002` jako rodzice — bez nich reguła „dokładnie jedna relacja `child-of`" nie miałaby czego wskazać.

Pokazane jest wyłącznie pole `relations`; pozostałe pola front matter pominięto.

---

## Warstwa funkcjonalna

### BFS-003 — Obsługa dyspozycji klienta

```yaml
relations:
  - type: has-child
    target: UC-011
  - type: has-child
    target: UC-012
  - type: has-child
    target: CAP-004
  - type: has-child
    target: CAP-005
  - type: has-child
    target: ACTOR-002
```

### UC-011 — Złożenie dyspozycji

```yaml
relations:
  - type: child-of
    target: BFS-003
  - type: realizes
    target: CAP-004
  - type: grouped-by
    target: ACTOR-002
```

### UC-012 — Korekta dyspozycji

```yaml
relations:
  - type: child-of
    target: BFS-003
  - type: realizes
    target: CAP-004
  - type: realizes
    target: CAP-005
  - type: grouped-by
    target: ACTOR-002
```

### ACTOR-002 — Aktorzy procesu dyspozycji

```yaml
relations:
  - type: child-of
    target: BFS-003
  - type: groups
    target: UC-011
  - type: groups
    target: UC-012
```

---

## Warstwa systemowa

### CAP-004 — Przyjmowanie i realizacja dyspozycji

```yaml
relations:
  - type: child-of
    target: BFS-003
  - type: realized-by
    target: UC-011
  - type: realized-by
    target: UC-012
  - type: has-child
    target: API-021
  - type: has-child
    target: API-022
```

### CAP-005 — Walidacja danych klienta

```yaml
relations:
  - type: child-of
    target: BFS-003
  - type: realized-by
    target: UC-012
  - type: has-child
    target: API-023
```

### API-021 — POST /dispositions

```yaml
relations:
  - type: child-of
    target: CAP-004
  - type: uses-data
    target: ENT-Disposition
  - type: uses-data
    target: ENT-DispositionItem
  - type: uses-data
    target: ENT-StatusDict
```

### API-022 — GET /dispositions/{id}

```yaml
relations:
  - type: child-of
    target: CAP-004
  - type: uses-data
    target: ENT-Disposition
  - type: uses-data
    target: ENT-StatusDict
```

### API-023 — POST /clients/validate

```yaml
relations:
  - type: child-of
    target: CAP-005
  - type: uses-data
    target: ENT-Client
  - type: uses-data
    target: ENT-Address
```

---

## Warstwa danych

### LDM-002 — Model logiczny obszaru dyspozycji

```yaml
relations:
  - type: has-child
    target: ENT-Disposition
  - type: has-child
    target: ENT-DispositionItem
  - type: has-child
    target: ENT-Client
  - type: has-child
    target: ENT-Address
  - type: has-child
    target: ENT-StatusDict
```

### ENT-Disposition

```yaml
relations:
  - type: child-of
    target: LDM-002
  - type: used-by
    target: API-021
  - type: used-by
    target: API-022
```

### ENT-DispositionItem

```yaml
relations:
  - type: child-of
    target: LDM-002
  - type: used-by
    target: API-021
```

### ENT-Client

```yaml
relations:
  - type: child-of
    target: LDM-002
  - type: used-by
    target: API-023
```

### ENT-Address

```yaml
relations:
  - type: child-of
    target: LDM-002
  - type: used-by
    target: API-023
```

### ENT-StatusDict

```yaml
relations:
  - type: child-of
    target: LDM-002
  - type: used-by
    target: API-021
  - type: used-by
    target: API-022
```

---

## Weryfikacja symetrii

Każdy wiersz to jedna krawędź zapisana po obu stronach. Linter porównuje kolumnę drugą z czwartą.

| Plik źródłowy | Wpis | Plik docelowy | Wpis zwrotny |
|---|---|---|---|
| UC-011 | `child-of: BFS-003` | BFS-003 | `has-child: UC-011` |
| UC-012 | `child-of: BFS-003` | BFS-003 | `has-child: UC-012` |
| CAP-004 | `child-of: BFS-003` | BFS-003 | `has-child: CAP-004` |
| CAP-005 | `child-of: BFS-003` | BFS-003 | `has-child: CAP-005` |
| ACTOR-002 | `child-of: BFS-003` | BFS-003 | `has-child: ACTOR-002` |
| UC-011 | `realizes: CAP-004` | CAP-004 | `realized-by: UC-011` |
| UC-012 | `realizes: CAP-004` | CAP-004 | `realized-by: UC-012` |
| UC-012 | `realizes: CAP-005` | CAP-005 | `realized-by: UC-012` |
| ACTOR-002 | `groups: UC-011` | UC-011 | `grouped-by: ACTOR-002` |
| ACTOR-002 | `groups: UC-012` | UC-012 | `grouped-by: ACTOR-002` |
| API-021 | `child-of: CAP-004` | CAP-004 | `has-child: API-021` |
| API-022 | `child-of: CAP-004` | CAP-004 | `has-child: API-022` |
| API-023 | `child-of: CAP-005` | CAP-005 | `has-child: API-023` |
| API-021 | `uses-data: ENT-Disposition` | ENT-Disposition | `used-by: API-021` |
| API-021 | `uses-data: ENT-DispositionItem` | ENT-DispositionItem | `used-by: API-021` |
| API-021 | `uses-data: ENT-StatusDict` | ENT-StatusDict | `used-by: API-021` |
| API-022 | `uses-data: ENT-Disposition` | ENT-Disposition | `used-by: API-022` |
| API-022 | `uses-data: ENT-StatusDict` | ENT-StatusDict | `used-by: API-022` |
| API-023 | `uses-data: ENT-Client` | ENT-Client | `used-by: API-023` |
| API-023 | `uses-data: ENT-Address` | ENT-Address | `used-by: API-023` |
| ENT-* (5 plików) | `child-of: LDM-002` | LDM-002 | `has-child: ENT-*` |

Razem 25 krawędzi, 50 wpisów w 13 plikach.

---

## Liczebności widoczne w przykładzie

| Relacja | Liczebność | Dowód |
|---|---|---|
| API → ENT | 1:N | API-021 używa trzech encji |
| ENT → API | 1:N | ENT-StatusDict używana przez dwa API |
| UC → CAP | 1:N | UC-012 realizuje dwa CAP |
| CAP → UC | 1:N | CAP-004 realizowany przez dwa UC |
| child-of | 1:1 w górę | każdy dokument ma dokładnie jednego rodzica |
| has-child | 1:N w dół | BFS-003 ma pięcioro dzieci |

Relacja `uses-data` jest N:N i to ona generuje najwięcej wpisów. Przy trzech API i pięciu encjach daje siedem krawędzi, czyli czternaście wpisów — ponad połowę objętości pola we wszystkich plikach.

---

## Koszt zmiany — pomiar na tym przykładzie

Dodanie jednego punktu końcowego `API-024` używającego czterech encji i podlegającego `CAP-004`:

- pliki edytowane: `API-024` (nowy), `CAP-004`, cztery pliki encji — razem sześć,
- wpisy dodane: pięć w nowym pliku, pięć w istniejących.

Przy symetrii wymuszonej linterem to minimum, którego nie da się zejść bez trybu naprawy w narzędziu.
