# Warsztat dokumentacji gdprrt: runda 2

Kontynuacja projektu z rundy 1. Najpierw zastosuj decyzje i poprawki z sekcji 1–3 do ekranów 1a–1d. Potem zaprojektuj brakujące artboardy z sekcji 4. Zasady, warstwy i dane z wsadu (`uploads/design-brief.md`) nadal obowiązują. Wszystkie dane w tym dokumencie pochodzą z plików dokumentacji. Nie dopisuj tytułów, relacji ani treści, których tu nie ma.

---

## 1. Decyzje po rundzie 1

1. **Węzeł dokumentu: wariant 1g „Kropka i kolorowe ID”** na wszystkich ekranach. W 1c zamień węzły z paskiem (1e) na 1g. Warianty 1e i 1f usuń z biblioteki.
2. **Węzeł startowy zasięgu jest w wyniku.** W 1c usuń notkę „Węzeł startowy nie trafia do listy…”. `BFS-001.REQ-01` ma być pierwszą pozycją listy, z oznaczeniem „start”, i nadal wyróżnioną na płótnie.
3. **Implementacja użyje React Flow**, czyli węzły to karty HTML, a zoom, przesuwanie, minimapa i ramka zaznaczenia są wbudowane. Projektuj węzły i nakładki jako elementy HTML, bez efektów, których nie da się zrobić w CSS.

## 2. Kontrast kolorowego ID w motywie jasnym

Wariant 1g pisze ID kolorem warstwy. Zmierzony kontrast kolorów warstw z rundy 1 jako tekstu 11,5 px:

| Warstwa | Na #ffffff | Na #f1f2f7 |
|---|---|---|
| Wymagania #8A4F7D | 6,01 | 5,37 |
| Odpowiedzialność #6B7628 | 4,94 | **4,42** |
| Scenariusze #1D7770 | 5,35 | 4,79 |
| Ekrany #B04A5A | 5,29 | 4,73 |
| Kontrakty #5652B2 | 6,47 | 5,79 |
| Przepływy #2A7AA2 | 4,77 | **4,27** |
| Pojęcia i dane #3B8646 | **4,48** | **4,01** |
| Mapy #7A6B5C | 5,14 | 4,60 |

Poniżej 4,5 są Odpowiedzialność, Przepływy i Pojęcia i dane. Dodaj w motywie jasnym osobne tokeny koloru tekstu warstwy (na przykład `--l-data-text`) przyciemnione do co najmniej 4,5:1 na obu tłach. Kropka i obwódki zostają w obecnych kolorach. W motywie ciemnym wszystkie kolory mają kontrast powyżej 6,7:1 na #161826, więc nic nie zmieniaj.

## 3. Poprawki błędów w ekranach 1a–1d

### 3.1 Pasek górny (wszystkie ekrany): stan walidacji

„0 problemów” jest nieprawdziwe. Walidatory zwracają dziś dla korpusu **1 błąd i 10 ostrzeżeń**. Pokaż to w pasku jako dwa liczniki: czerwony „1 błąd” i bursztynowy „10 ostrzeżeń”. Kliknięcie otwiera panel walidacji (artboard 2f). W inspektorze grupy BFS-001 (1a) sekcja Walidacja pokazuje: 0 błędów, 3 ostrzeżenia (UC-005 dwa, API-005 jedno).

### 3.2 Mapa 1a: liczby w panelu lewym

Liczby dokumentów przy warstwach: Wymagania **5** (było 4), Odpowiedzialność 7, Scenariusze 12, Ekrany 19, Kontrakty 23, Przepływy 27, Pojęcia i dane 21, Mapy **5** (było 6). Liczby przy relacjach usuń: aplikacja policzy je z danych, a w rundzie 1 były wymyślone.

### 3.3 Katalog 1b: inspektor ENT-Client

Zastąp inspektor tymi danymi:
- ścieżka: `shared/domains/DDM-001/ent-client.md` (bez folderu `entities/`), status active, właściciel **Tomasz Lewandowski** (nie Anna Nowak), opis: „Encja klienta detalicznego z numerem PESEL, imieniem, nazwiskiem, datą urodzenia i adresem.”
- **Relacje wychodzące:** `realizes` DDM-001.DOM-Klient, `contains` ENT-Client.RW-001. Nic więcej.
- Usuń `contained_in LDM-001`: takiej relacji nie ma. To relacja odwrotna i należy do „Wskazywany przez”.
- Usuń `constrained_by NFR-002.NFRT-SEC-02`: matryca nie pozwala encji wskazywać progów.
- **Wskazywany przez (11):** `contains` LDM-001; `consumes` API-003, API-010, API-011, API-012, INT-001, INT-010, INT-012, SCRSEC-001, SCRSEC-010, SCRSEC-013. Pogrupuj według rodzaju relacji.
- **Wiersze:** `ENT-Client.RW-001` bez opisu i bez liczby odwołań.
- **Treść:** usuń wymyślony akapit. Zostaw sekcję „Treść” z informacją „Podgląd pliku: Space”.

Zasada na wszystkie ekrany: „Relacje wychodzące” to tylko wpisy z pola `relations` tego dokumentu. Wszystko, co wskazuje dokument, idzie do „Wskazywany przez”.

### 3.4 Zasięg 1c: prawdziwe tytuły węzłów

| Węzeł | Tytuł |
|---|---|
| BFS-001.REQ-01 | Klient składa dyspozycję przelewu wielopozycyjnego z 1–50 pozycjami. |
| BFS-001 | Obsługa dyspozycji |
| ACTOR-001.ROLE-01 | Klient |
| UC-001 | Złożenie dyspozycji |
| UC-002 | Korekta dyspozycji |
| API-001 | POST /dispositions |
| QUE-001 | DispositionAccepted |
| SCR-001 | Ekran Dyspozycja: Krok 1 z 2 — Dane i pozycje |
| SCR-002 | Ekran Dyspozycja: Krok 2 z 2 — Podsumowanie |
| CAP-001 | Przyjmowanie dyspozycji |
| UCMAP-001 | Mapa scenariuszy dyspozycji i reklamacji |
| NAV-001 | Obsługa dyspozycji: mapa nawigacyjna |
| SCRSEC-001 | Dane klienta |
| SCRSEC-002 | Pozycje dyspozycji |
| SCRSEC-003 | Podsumowanie kwot |
| FLOW-001 | Przyjęcie dyspozycji — przebieg podstawowy |
| FLOW-002 | Przyjęcie dyspozycji — obsługa błędów |

Linie: NAV-001 łączy się z SCR-001 **i** SCR-002 (`NAV-001 groups` oba ekrany).

## 4. Brakujące artboardy

Każdy w motywie ciemnym i jasnym, 1440×900, z wariantem węzła 1g.

### 2a. Katalog: wszystkie API, graf

Dane z wsadu, sekcja 6.2. Grupy to zdolności CAP w kolumnach procesów. Węzeł: ID kolorem warstwy, tytuł (metoda i ścieżka) skrócony z wielokropkiem, liczba użyć po prawej. Zaznaczony API-005 (4 użycia), z inspektorem: `realizes` CAP-001; `consumes` ENT-Disposition, ENT-DispositionItem, ENT-StatusDict; `constrained_by` NFR-001.NFRT-PERF-01; wskazywany przez (`consumes`) SPEC-WF-001, UC-002, UC-005, SCRSEC-005. W podsumowaniu katalogu: 12 dokumentów, 12 draft, najczęściej używane API-005 i API-007 (po 4), bez użyć: brak.

### 2b. Mapa: grupa BFS-001 rozwinięta, zoom 150%, minimapa

Grupa rozwinięta w dokumenty, a pozostałe grupy zostają zwinięte przy krawędziach. Zaznaczony UC-001 z inspektorem z sekcji 2e (w wersji skróconej). Minimapa w prawym dolnym rogu nad paskiem zoomu. Dokumenty BFS-001 (34):

| Warstwa | Dokumenty |
|---|---|
| Wymagania | BFS-001 Obsługa dyspozycji (active) |
| Odpowiedzialność | CAP-001 Przyjmowanie dyspozycji · CAP-003 Rozliczanie dyspozycji |
| Scenariusze | UC-001 Złożenie dyspozycji · UC-002 Korekta dyspozycji · UC-005 Podgląd dyspozycji · TUC-001 Nocne rozliczenie dyspozycji · TUC-002 Ponowienie nieudanych rozliczeń |
| Ekrany | SCR-001 Ekran Dyspozycja: Krok 1 z 2 — Dane i pozycje · SCR-002 Ekran Dyspozycja: Krok 2 z 2 — Podsumowanie · SCR-003 Ekran Korekta dyspozycji: Krok 1 z 2 — Edycja pozycji · SCRSEC-001 Dane klienta · SCRSEC-002 Pozycje dyspozycji · SCRSEC-003 Podsumowanie kwot · SCRSEC-004 Historia statusów |
| Kontrakty | API-001 POST /dispositions · API-002 PATCH /dispositions/{id}/items/{itemId} · API-005 GET /dispositions · API-006 POST /settlement-runs · INT-001 System limitów: sprawdzenie limitu · INT-002 Księga główna: księgowanie dyspozycji · QUE-001 DispositionAccepted |
| Przepływy | FLOW-001 Przyjęcie dyspozycji — przebieg podstawowy · FLOW-002 Przyjęcie dyspozycji — obsługa błędów · ACT-001 Walidacja wejścia dyspozycji · ACT-002 Zapis dyspozycji · ACT-003 Odrzucenie dyspozycji · BPMN-001 Rozliczenie dyspozycji · SPEC-WF-001 Pobranie dyspozycji do rozliczenia · SPEC-WF-002 Księgowanie pozycji · SPEC-WF-003 Zamknięcie dnia rozliczeniowego |
| Pojęcia i dane | STM-003 Cykl życia przebiegu rozliczenia |
| Mapy | NAV-001 Obsługa dyspozycji: mapa nawigacyjna · UCMAP-002 Mapa scenariuszy rozliczenia dyspozycji |

Wszystkie dokumenty poza BFS-001 mają status draft. Linie wychodzące z UC-001: `contains` SCR-001, SCR-002; `realizes` CAP-001; `consumes` API-001, QUE-001. Linie do grup zwiniętych: `realizes` BFS-001.REQ-01 i BFS-001.RB-01 (wewnątrz grupy), `involves` ACTOR-001.ROLE-01 (grupa shared/actors), `constrained_by` NFR-001.NFRT-SEC-01 (grupa shared/nfr).

### 2c. Zasięg: symulacja usunięcia SCR-002

Tryb „Symulacja usunięcia”, koszyk: SCR-002. Płótno pokazuje zasięg przed usunięciem (`change_scope` dla SCR: `<-contains- UC|TUC|SPEC-WF` oraz `<-groups- NAV`): SCR-002, UC-001, UC-002, NAV-001. SCR-002 jest przekreślony albo pokazany jako „do usunięcia”. Inspektor ma dwie sekcje:
- **Do przejrzenia (4):** SCR-002 (start), UC-001, UC-002, NAV-001, ze ścieżkami plików.
- **Po usunięciu zepsuje się (3):** `NAV-001 groups SCR-002`, `UC-001 contains SCR-002`, `UC-002 contains SCR-002`, każdy z etykietą „cel nie istnieje”.

Pod spodem notka: „Pliki się nie zmieniają. Relacje usuwa się na końcu (metodyka, sekcja 6).”

### 2d. Przepływ: bez zmian w danych

Popraw tylko wariant węzła, chipy i kontrast tekstu według sekcji 1–2.

### 2e. Podgląd pliku UC-001 na całą szerokość

Panel lewy zwinięty, graf zmniejszony do minimapy w rogu. Kolumna do czytania około 72 znaków szerokości, a obok niej inspektor. Nagłówek: UC-001 · Złożenie dyspozycji · draft · Anna Nowak · `processes/BFS-001/scenarios/uc-001.md` · przyciski Otwórz w VS Code, Zasięg, Implementacja, Kopiuj ID.

Front matter zwinięty w jednej linii („11 relacji · rozwiń YAML”). Spis sekcji dokumentu jako nawigacja: Powiązanie z BFS · Cel · Aktorzy · Kiedy można to zrobić · Kroki · Co może pójść inaczej (A1. Zapis szkicu) · Co może pójść nie tak (E1. Przekroczony limit) · Reguły biznesowe · Ograniczenia NFR · Kryteria akceptacji · Diagram.

Treść (pokaż początek):

Tabela pól: Aktor główny `ACTOR-001.ROLE-01` · Kanały: Aplikacja mobilna, bankowość internetowa · BFS `BFS-001` · Powiązane REQ `BFS-001.REQ-01` · Powiązane RB `BFS-001.RB-01` · Zdolność `CAP-001` · Makiety: Figma, plik „Dyspozycja”, ramki „Krok 1 — Dane i pozycje” i „Krok 2 — Podsumowanie”.

## Powiązanie z BFS

| Typ | ID z BFS | Jak UC to realizuje |
|---|---|---|
| REQ | BFS-001.REQ-01 | Klient wpisuje od 1 do 50 pozycji, sprawdza podsumowanie i zatwierdza dyspozycję; system zapisuje ją ze statusem ZAAKCEPTOWANA. |
| RB | BFS-001.RB-01 | Przy zatwierdzeniu system porównuje kwotę łączną dyspozycji z dostępnym limitem klienta i odrzuca dyspozycję ponad limit (E1). |

## Cel

Klient chce jedną dyspozycją i jednym uwierzytelnieniem zlecić kilka przelewów z jednego rachunku, zamiast wypełniać osobny formularz dla każdego przelewu.

Każde ID w treści to link kolorem warstwy. Pokaż jeden stan najechania: tooltip nad `CAP-001` z tytułem „Przyjmowanie dyspozycji” i statusem draft.

### 2f. Panel walidacji

Panel zastępuje inspektor, a płótno zostaje. Wynik to rzeczywisty stan korpusu z trzech walidatorów. Każdy problem ma: poziom (błąd albo ostrzeżenie), kod, nazwę, doc-id, plik z numerem linii, komunikat, podpowiedź „Naprawa” (jeśli jest) i przycisk „Pokaż”. Filtry: poziom, walidator (relacje, forma, spójność), dokument. Grupowanie według walidatora.

| Walidator | Poziom | Kod | Nazwa | Dokument | Plik:linia | Komunikat | Naprawa |
|---|---|---|---|---|---|---|---|
| spójność | BŁĄD | CONS-01 | ta sama informacja w dwóch miejscach | SPEC-WF-008 | processes/BFS-002/flows/BPMN-002/steps/spec-wf-008.md:47 | SPEC-WF-008 ma wpis consumes SPEC-WF-009, a kolumna „Źródło” (sekcje: Zmienne procesowe) go nie wymienia. | Wpisz SPEC-WF-009 w kolumnie „Źródło” w wierszu, którego dotyczy. |
| relacje | OSTRZEŻENIE | REL-05 | encja zawarta wskazana osobno | API-005 | processes/BFS-001/contracts/api-005.md:12 | API-005 wskazuje ENT-Disposition i ENT-DispositionItem, a ENT-Disposition zawiera ENT-DispositionItem. | — |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | UC-005 | processes/BFS-001/scenarios/uc-005.md:57 | Brak sekcji „Co może pójść inaczej” z szablonu. | Dodaj sekcję „## Co może pójść inaczej” przed sekcją „Reguły biznesowe”. |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | UC-005 | processes/BFS-001/scenarios/uc-005.md:57 | Brak sekcji „Co może pójść nie tak” z szablonu. | Dodaj sekcję „## Co może pójść nie tak” przed sekcją „Reguły biznesowe”. |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | CAP-002 | processes/BFS-002/capabilities/cap-002.md:30 | Brak sekcji „Zdarzenia i kontrakty domenowe” z szablonu. | Dodaj sekcję na końcu dokumentu. |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | CAP-002 | processes/BFS-002/capabilities/cap-002.md:30 | Brak sekcji „Miary i kryteria skuteczności” z szablonu. | Dodaj sekcję na końcu dokumentu. |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | CAP-002 | processes/BFS-002/capabilities/cap-002.md:30 | Brak sekcji „Ograniczenia NFR” z szablonu. | Dodaj sekcję na końcu dokumentu. |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | CAP-002 | processes/BFS-002/capabilities/cap-002.md:30 | Brak sekcji „Ryzyka i ograniczenia” z szablonu. | Dodaj sekcję na końcu dokumentu. |
| forma | OSTRZEŻENIE | FORM-04 | tabele | UCMAP-001 | shared/maps/ucmap-001.md:17 | Pod nagłówkiem H1 brakuje tabeli „\| Pole \| Wartość \|” z szablonu. | Dodaj pod nagłówkiem H1 tabelę z nagłówkiem „\| Pole \| Wartość \|”. |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | UCMAP-001 | shared/maps/ucmap-001.md:27 | Brak sekcji „Legenda relacji” z szablonu. | Dodaj sekcję „## Legenda relacji” przed sekcją „Diagram”. |
| forma | OSTRZEŻENIE | FORM-03 | sekcje | UCMAP-001 | shared/maps/ucmap-001.md:66 | Brak sekcji „Otwarte pytania” z szablonu. | Dodaj sekcję „## Otwarte pytania” na końcu dokumentu. |

Zaznaczony problem CONS-01. Na płótnie (tryb Mapa, grupa BFS-002 rozwinięta w dokumenty) SPEC-WF-008 ma czerwoną obwódkę i znacznik „!”. Węzły UC-005, CAP-002 i API-005 mają bursztynowy znacznik ostrzeżenia.

### 2g. Wyszukiwanie Ctrl+K

Paleta nad płótnem, wpisane „dysp”. Pierwsze wyniki (pasujących tytułów jest więcej, lista się przewija):
- **Dokumenty:** BFS-001 Obsługa dyspozycji · UC-001 Złożenie dyspozycji · UC-002 Korekta dyspozycji · UC-005 Podgląd dyspozycji · FLOW-001 Przyjęcie dyspozycji — przebieg podstawowy · DDM-001 Domena dyspozycji · ENT-Disposition Dyspozycja
- **Wiersze:** DDM-001.DOM-Dyspozycja
- **Polecenia:** „Katalog typu: …” (podpowiedź składni `typ:API`)

Pokaż też stan „bez wyników” dla „xyz” z podpowiedzią składni.

### 2h. Biblioteka komponentów

Komponenty z sekcji 7 wsadu, w wariancie 1g, w obu motywach, z tokenami tekstu warstw z sekcji 2. Dodaj: licznik błędów i ostrzeżeń w pasku górnym, wiersz problemu walidacji, znacznik błędu i ostrzeżenia na węźle, węzeł „do usunięcia” z symulacji.

## 5. Poza zakresem tej rundy

- nowe kolory akcentu i typografia: zostają z rundy 1 (Nocturne, Inter, JetBrains Mono)
- widok kontraktów w Przepływie, eksport Markdown, zapytanie `implementation`: zaprojektujemy później, jeśli okażą się potrzebne
