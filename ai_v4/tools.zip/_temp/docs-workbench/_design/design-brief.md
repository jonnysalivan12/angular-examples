# Wsad dla Claude Design: Warsztat dokumentacji gdprrt

Zaprojektuj interfejs aplikacji desktopowej (w przeglądarce) dla analityka, który pracuje z dokumentacją projektową zapisaną jako graf. Potrzebuję zestawu ekranów (artboardów) i biblioteki komponentów opisanych niżej. Wszystkie dane w tym wsadzie są prawdziwe, pochodzą z korpusu przykładów dokumentacji. Używaj ich w projektach zamiast wypełniaczy.

Pełna koncepcja z działającą makietą: https://claude.ai/code/artifact/f9e3d1bf-0c51-4052-9ee0-071bfaf6185c

---

## 1. Produkt w jednym akapicie

Dokumentacja projektu to kilkaset plików Markdown. Każdy plik ma w nagłówku YAML identyfikator (`doc-id`, na przykład `UC-001`) i listę relacji do innych dokumentów (`relations`). Razem tworzą graf. Aplikacja czyta te pliki z dysku i pozwala analitykowi:

1. zobaczyć całą dokumentację albo jej wycinek jako graf,
2. zobaczyć wszystkie dokumenty jednego typu, na przykład wszystkie API albo wszystkie encje,
3. sprawdzić zasięg zmiany (blast radius): które pliki przejrzeć, gdy zmienia się jeden element,
4. zobaczyć przepływ danych między komponentami,
5. przeczytać treść pliku bez wychodzenia z aplikacji.

Aplikacja **tylko czyta**. Pliki edytuje się w VS Code, a aplikacja ma przycisk „Otwórz w VS Code”.

## 2. Użytkownik i cel projektu

- **Kto:** analityk systemowy albo biznesowy. Zna standard dokumentacji, pracuje długo i skupiony, często na dwóch monitorach.
- **Cel:** ergonomiczne, jasne i przejrzyste środowisko pracy. Ważniejsze od efektu „wow” jest to, że po godzinie pracy nic nie męczy i niczego nie trzeba szukać.
- **Charakter:** spokojne narzędzie klasy IDE. Dużo informacji na ekranie, ale czytelnej. Bez dekoracji, bez gradientów, bez ilustracji.

## 3. Zasady, które projekt musi zachować

1. **Kolor oznacza zawsze warstwę dokumentu** (tabela w sekcji 4). Stan elementu (zaznaczenie, wynik zasięgu, błąd, brak użyć) pokazuje obwódka, poświata albo tło, a nigdy zmiana koloru warstwy.
2. **Jedno zaznaczenie dla całej aplikacji.** Węzeł zaznaczony w jednym trybie jest zaznaczony we wszystkich trybach i w inspektorze.
3. **Bez okien modalnych.** Wszystko dzieje się w panelach, a płótno z grafem nigdy nie jest zasłonięte. Wyjątek: paleta wyszukiwania Ctrl+K.
4. **Każda liczba jest klikalna** i otwiera listę, z której powstała.
5. **Nazwy ze standardu bez tłumaczenia:** typy (`UC`, `API`, `ENT`…), rodzaje relacji (`contains`, `realizes`, `consumes`, `constrained_by`, `involves`, `groups`), nazwy zapytań (`change_scope`, `implementation`). Identyfikatory zawsze pisane krojem o stałej szerokości.
6. **Interfejs po polsku.** Treść dokumentów też jest po polsku.
7. **Dwa motywy: jasny i ciemny.** Oba są pełnoprawne, a kolory warstw mają wystarczający kontrast w obu.
8. **Desktop.** Projektuj na 1440×900 i sprawdź 1920×1080. Wersja mobilna nie jest potrzebna.

## 4. Warstwy dokumentów (kolory)

Osiem warstw pochodzi z metodyki. Wiersz to element wewnątrz dokumentu, który ma własny identyfikator (na przykład wymaganie `BFS-001.REQ-01`).

| Warstwa | Typy dokumentów | Typy wierszy | Propozycja koloru (jasny / ciemny) |
|---|---|---|---|
| Wymagania | BFS, NFR | REQ, RB, NFRT | #8A4F7D / #C98DBB |
| Odpowiedzialność | ACTOR, CAP | ROLE | #6B7628 / #B2BC6A |
| Scenariusze | UC, TUC | A, E | #1D7770 / #5EBEB5 |
| Ekrany | SCR, SCRSEC | — | #B04A5A / #E48C99 |
| Kontrakty | API, INT, QUE | — | #5652B2 / #A6A2EE |
| Przepływy | FLOW, ACT, BPMN, SPEC-WF | AC | #2A7AA2 / #6CB7DC |
| Pojęcia i dane | DDM, LDM, ENT, STM | DOM, RD, RW | #3B8646 / #80C68A |
| Mapy | UCMAP, NAV | — | #7A6B5C / #BDAA96 |

Kolory warstw możesz dopracować. Muszą jednak zostać rozróżnialne, stonowane i spójne w obu motywach.

Proponowane kolory interfejsu (do dopracowania):

| Rola | Jasny | Ciemny |
|---|---|---|
| Tło | #F5F6F3 | #111614 |
| Powierzchnia paneli | #FFFFFF | #19201D |
| Tekst | #18211F | #E3E9E5 |
| Tekst pomocniczy | #5A6560 | #98A49E |
| Linie | #D6DBD6 | #2F3934 |
| Akcent (zaznaczenie, aktywna kontrolka) | #2D4BA0 | #93AAEC |
| Zasięg zmiany | #B06C08 | #E3A64A |
| Błąd | #B3261E | #F08B81 |

Typografia w makiecie: IBM Plex Sans (tekst), IBM Plex Sans Condensed (nagłówki, etykiety), IBM Plex Mono (identyfikatory, wzorce zapytań). Możesz zaproponować inną parę, ale krój o stałej szerokości dla identyfikatorów jest obowiązkowy, a wszystkie kroje muszą mieć polskie znaki.

## 5. Układ ekranu

```
┌─ Warsztat │ Mapa 1 │ Zasięg 2 │ Przepływ 3 │ develop · stan roboczy │ Szukaj… Ctrl K ─┐
│ PANEL LEWY      │ PŁÓTNO                                         │ INSPEKTOR          │
│ ~210 px         │ graf albo tabela                               │ ~290 px            │
│ zakres, filtry, │ etykieta widoku (lewy górny róg)               │ zaznaczony węzeł,  │
│ wygląd          │ przełącznik widoku (prawy górny róg)           │ relacje, treść     │
│                 │ wskazówki (lewy dolny), zoom (prawy dolny)     │                    │
└─────────────────┴────────────────────────────────────────────────┴────────────────────┘
```

- Panele boczne można zwinąć i zmienić ich szerokość.
- Pasek górny: nazwa, przełącznik trzech trybów ze skrótami 1/2/3, gałąź git i informacja „stan roboczy”, pole wyszukiwania.

## 6. Tryby i widoki do zaprojektowania

### 6.1 Mapa: całość w grupach

Przy 300–2000 dokumentach mapa startuje od grup: procesów `processes/BFS-*`, domen `shared/domains/DDM-*` i pozostałych folderów `shared/`. Grupa zwinięta pokazuje ID, tytuł, liczbę dokumentów i pasek udziału warstw. Linia między grupami ma grubość zależną od liczby relacji i etykietę z tą liczbą. Dwuklik rozwija grupę.

Dane:

| Grupa | Tytuł | Dokumenty | Warstwy (Wym/Odp/Scen/Ekr/Kontr/Przep/Dane/Mapy) |
|---|---|---|---|
| BFS-001 | Obsługa dyspozycji | 34 | 1/2/5/7/7/9/1/2 |
| BFS-002 | Reklamacje dyspozycji | 31 | 1/2/4/5/8/10/0/1 |
| BFS-003 | Otwarcie rachunku | 30 | 1/2/3/7/8/8/0/1 |
| DDM-001 | Domena dyspozycji | 10 | same Dane |
| DDM-002 | Domena rachunków | 10 | same Dane |
| shared/nfr | NFR-001, NFR-002 | 2 | same Wymagania |
| shared/actors | ACTOR-001 | 1 | Odpowiedzialność |
| shared/maps | UCMAP-001 | 1 | Mapy |

Relacje między grupami: BFS-001–DDM-001 16 · BFS-003–DDM-002 15 · BFS-001–nfr 12 · BFS-002–DDM-001 12 · BFS-003–nfr 9 · BFS-003–DDM-001 7 · BFS-001–actors 5 · BFS-002–actors 5 · BFS-003–actors 4 · BFS-001–BFS-002 3 · BFS-002–nfr 3 · BFS-002–BFS-003 2 · BFS-001–maps 2 · BFS-002–maps 2 · BFS-001–BFS-003 1.

Panel lewy (Mapa): Zakres (całość / proces / domena / typ dokumentu / sąsiedztwo węzła 1–3 kroki), Grupuj (proces i domena / warstwa / folder / bez grup), Koloruj (warstwa / status), Warstwy (8 pól wyboru z kolorem), Relacje (6 pól wyboru), Układ (siłowy / warstwowy / kołowy wokół zaznaczenia), Etykiety (ID / ID i tytuł / po najechaniu), Gęstość (suwak).

Inspektor dla zaznaczonej grupy BFS-001: zawartość według warstw (Przepływy 9, Ekrany 7, Kontrakty 7, Scenariusze 5, Odpowiedzialność 2, Mapy 2, Wymagania 1, Pojęcia i dane 1), relacje z innymi grupami (39) i wewnątrz grupy (83), stan walidacji (0 problemów), przyciski „Rozwiń grupę” i „Tylko ten proces”.

### 6.2 Mapa: katalog typu (wszystkie API, wszystkie encje)

Zakres „Typ dokumentu” pokazuje wszystkie dokumenty wybranych typów. Można wybrać kilka typów naraz. Przełącznik **Graf | Tabela** stoi w prawym górnym rogu płótna.

**Graf wszystkich API** jest pogrupowany według zdolności CAP, a zdolności według procesów. Każdy węzeł ma ID, skrócony tytuł i liczbę dokumentów, które go wskazują. Węzeł bez użyć ma przerywaną obwódkę.

| API | Tytuł | Zdolność | Encje | INT | Progi NFRT | Używany przez |
|---|---|---|---|---|---|---|
| API-001 | POST /dispositions | CAP-001 | ENT-Disposition, ENT-StatusDict | INT-001 | NFRT-PERF-01, NFRT-SEC-01 | FLOW-001, FLOW-002, UC-001 |
| API-002 | PATCH /dispositions/{id}/items/{itemId} | CAP-001 | ENT-DispositionItem | — | NFRT-PERF-01 | UC-002 |
| API-005 | GET /dispositions | CAP-001 | ENT-Disposition, ENT-DispositionItem, ENT-StatusDict | — | NFRT-PERF-01 | SPEC-WF-001, UC-002, UC-005, SCRSEC-005 |
| API-006 | POST /settlement-runs | CAP-003 | — | — | — | TUC-001, TUC-002 |
| API-003 | POST /clients/validate | CAP-002 | ENT-Client | INT-010 | — | UC-006 |
| API-004 | POST /complaints | CAP-004 | ENT-Complaint | — | — | UC-003, UC-006 |
| API-007 | GET /complaints/{id} | CAP-004 | ENT-Complaint, ENT-Disposition | — | — | SPEC-WF-004, SPEC-WF-009, TUC-003, UC-004 |
| API-008 | POST /complaints/{id}/decision | CAP-004 | ENT-Complaint | — | — | UC-004 |
| API-010 | POST /account-applications | CAP-010 | ENT-Account, ENT-Client, ENT-Consent, ENT-Deposit | — | — | UC-010 |
| API-011 | POST /identity-verifications | CAP-011 | ENT-Client | INT-010, INT-012 | NFRT-PERF-01 | SPEC-WF-011, FLOW-010 |
| API-012 | GET /identity-verifications/{id} | CAP-011 | ENT-Client | — | — | UC-011 |
| API-013 | POST /accounts | CAP-010 | ENT-Account, ENT-Deposit | — | — | SPEC-WF-013 |

Zdolności: CAP-001 Przyjmowanie dyspozycji i CAP-003 Rozliczanie dyspozycji (BFS-001), CAP-002 Walidacja danych klienta i CAP-004 Obsługa reklamacji (BFS-002), CAP-010 Zakładanie rachunku i CAP-011 Weryfikacja tożsamości (BFS-003).

**Tabela wszystkich encji.** Kolumny wynikają z relacji dozwolonych dla typu. Sortowanie i filtr działają na każdej kolumnie. Kliknięcie wiersza zaznacza encję w inspektorze.

| ENT | Tytuł | Status | Pojęcie DOM | LDM | Zawiera | RW | RD | Używany przez |
|---|---|---|---|---|---|---|---|---|
| ENT-Account | Rachunek | draft | DDM-002.DOM-Rachunek | LDM-002 | — | 1 | 0 | API-010, API-013, INT-011, QUE-010, SCRSEC-011 |
| ENT-AccountSnapshot | Stan dzienny rachunku | draft | DDM-002.DOM-Rachunek | LDM-003 | — | 0 | 0 | **nikt (0)** |
| ENT-Client | Klient | active | DDM-001.DOM-Klient | LDM-001 | — | 1 | 0 | 10 dokumentów: API-003, API-010, API-011, API-012, INT-001, INT-010, INT-012, SCRSEC-001, SCRSEC-010, SCRSEC-013 |
| ENT-Complaint | Reklamacja | active | DDM-001.DOM-Reklamacja | LDM-001 | — | 1 | 0 | API-004, API-007, API-008, INT-004, QUE-003, SCRSEC-005, SCRSEC-006, SCRSEC-007 |
| ENT-Consent | Zgoda | draft | DDM-002.DOM-Zgoda | LDM-002 | — | 1 | 0 | API-010, SCRSEC-012 |
| ENT-Deposit | Lokata terminowa | draft | DDM-002.DOM-Rachunek | LDM-002 | — | 1 | 0 | API-010, API-013, INT-011, QUE-010, SCRSEC-011 |
| ENT-Disposition | Dyspozycja | active | DDM-001.DOM-Dyspozycja | LDM-001 | ENT-DispositionItem | 2 | 2 | API-001, API-005, API-007, INT-002, QUE-001, SCRSEC-003, SCRSEC-004, SCRSEC-005 |
| ENT-DispositionItem | Pozycja dyspozycji | active | DDM-001.DOM-Pozycja | LDM-001 | — | 1 | 1 | API-002, API-005, SCRSEC-002 |
| ENT-Product | Produkt | draft | DDM-002.DOM-Produkt | LDM-002 | — | 0 | 0 | SCRSEC-011 |
| ENT-StatusDict | Słownik statusów | active | — (encja techniczna) | LDM-001 | — | 0 | 0 | API-001, API-005, SCRSEC-004 |

W grafie encje grupuje DDM, a w nim LDM. Między ENT-Disposition i ENT-DispositionItem jest strzałka `contains`.

Inspektor katalogu: podsumowanie typu (liczba, status, najczęściej używany, bez użyć), a pod nim szczegóły zaznaczonego wiersza.

### 6.3 Zasięg zmiany

Analityk dodaje węzły do koszyka (klawisz Z) i uruchamia zapytanie `change_scope` albo `implementation`. Wynik jest podświetlony na płótnie w układzie warstwowym od lewej do prawej. Sąsiedzi spoza wyniku są wyszarzeni. Po prawej jest lista plików pogrupowana według wzorca zapytania, a przy każdym pliku ścieżka, którą zapytanie do niego doszło.

Przykład: start `BFS-001.REQ-01` (wiersz wymagania w BFS-001), wynik 13 plików:

| Wzorzec | Plik | Ścieżka |
|---|---|---|
| `<-realizes- UC\|TUC -consumes-> API\|INT\|QUE` | processes/BFS-001/scenarios/uc-001.md | REQ-01 ‹ UC-001 |
| | processes/BFS-001/contracts/api-001.md | UC-001 › API-001 |
| | processes/BFS-001/contracts/que-001.md | UC-001 › QUE-001 |
| `<-realizes- UC\|TUC -contains-> SCR -contains-> SCRSEC` | processes/BFS-001/screens/SCR-001/scr-001.md | UC-001 › SCR-001 |
| | processes/BFS-001/screens/SCR-002/scr-002.md | UC-001 › SCR-002 |
| | processes/BFS-001/screens/shared/scrsec-001.md | SCR-001 › SCRSEC-001 |
| | processes/BFS-001/screens/shared/scrsec-002.md | SCR-001 › SCRSEC-002 |
| | processes/BFS-001/screens/SCR-002/sections/scrsec-003.md | SCR-002 › SCRSEC-003 |
| `<-realizes- UC\|TUC -contains-> SCR <-groups- NAV` | processes/BFS-001/maps/nav-001.md | SCR-001 ‹ NAV-001 |
| `<-realizes- UC\|TUC -realizes-> CAP <-realizes- FLOW\|BPMN\|STM` | processes/BFS-001/capabilities/cap-001.md | UC-001 › CAP-001 |
| | processes/BFS-001/flows/FLOW-001/flow-001.md | CAP-001 ‹ FLOW-001 |
| | processes/BFS-001/flows/FLOW-002/flow-002.md | CAP-001 ‹ FLOW-002 |
| `<-realizes- UC\|TUC <-groups- UCMAP` | shared/maps/ucmap-001.md (inny folder niż proces) | UC-001 ‹ UCMAP-001 |

Kontekst wyszarzony: BFS-001, ACTOR-001.ROLE-01, UC-002.

Panel lewy (Zasięg): Zapytanie (`change_scope` / `implementation`), Koszyk (chipy z możliwością usunięcia), Tryb (Przegląd / Symulacja usunięcia), Grupuj listę (wzorzec / folder / warstwa), Na płótnie (sąsiedzi spoza wyniku, nazwy relacji na liniach). Przyciski: „Eksportuj listę” (lista kontrolna Markdown), „Kopiuj link”.

**Symulacja usunięcia** to osobny stan tego trybu. Pokazuje zasięg policzony przed usunięciem i to, co zepsuje się po usunięciu. Pliki się nie zmieniają. Przykłady:

| Usuwam | Skutek |
|---|---|
| SCR-002 | 3 relacje wskażą cel, który nie istnieje: NAV-001 groups, UC-001 contains, UC-002 contains |
| FLOW-002 | ACT-003 „Odrzucenie dyspozycji” traci jedyne powiązanie |
| ENT-DispositionItem | 5 relacji bez celu: API-002, API-005, SCRSEC-002, ENT-Disposition, LDM-001 |

### 6.4 Przepływ danych

Poziom zdolności CAP. Każda zdolność to prostokąt z chipami swoich kontraktów (API, INT, QUE). Zdolności są ułożone w kolumnach procesów. Linie są trzech rodzajów:

| Linia | Wygląd | Przykład |
|---|---|---|
| Zdarzenie, pewny kierunek | ciągła ze strzałką | CAP-010 → QUE-010 AccountOpened → CAP-001 |
| Zdarzenie, pewny kierunek | ciągła ze strzałką | CAP-004 → QUE-003 ComplaintResolved → CAP-003 |
| Wywołanie, pewny kierunek | ciągła ze strzałką | CAP-002 → API-003 wywołuje INT-010 → CAP-011 |
| Niejednoznaczna (scenariusz należy do dwóch CAP) | przerywana bez strzałki | CAP-002 – CAP-004 przez UC-006; CAP-010 – CAP-011 przez UC-010 |

Kontrakty zdolności:
- CAP-001: API-001, API-002, API-005, INT-001, QUE-001
- CAP-003: API-006, INT-002
- CAP-002: API-003, INT-003
- CAP-004: API-004, API-007, API-008, INT-004, INT-005, QUE-003
- CAP-010: API-010, API-013, INT-011, QUE-010
- CAP-011: API-011, API-012, INT-010, INT-012

Zaznaczona linia QUE-010 w inspektorze: nadawca CAP-010 (bo QUE-010 realizes CAP-010), odbiorca CAP-001 (bo CAP-001 consumes QUE-010), ładunek ENT-Account i ENT-Deposit. Korzystają też: TUC-010, SPEC-WF-014, a UC-010 należy do kilku CAP. Notka: wpis `consumes QUE` nie mówi, czy scenariusz publikuje, czy odbiera, dlatego te dokumenty nie wyznaczają linii.

Panel lewy (Przepływ): Poziom (zdolności CAP / kontrakty), Procesy (pola wyboru), Linie (zdarzenia / wywołania / niejednoznaczne), Na linii (ID kontraktu / encje), legenda linii.

### 6.5 Inspektor i podgląd pliku

Części inspektora dla dokumentu:
1. nagłówek: chip typu z ID, tytuł, status (draft/active), właściciel, ścieżka pliku,
2. relacje wychodzące pogrupowane według rodzaju relacji,
3. „Wskazywany przez”: lista wyliczona z grafu,
4. wiersze dokumentu z liczbą odwołań,
5. treść: wyrenderowany Markdown z tabelami i diagramami Mermaid. Każde ID w treści to link, a po najechaniu pojawia się tytuł i status.

Akcje: Otwórz w VS Code (O), Zasięg (Z), Implementacja (I), Kopiuj ID.

Podgląd na całą szerokość (Space) to osobny artboard: treść pliku w kolumnie do czytania, graf jako mała mapa w rogu.

Przykładowy dokument UC-001:
- tytuł „Złożenie dyspozycji”, status draft, właściciel Anna Nowak, plik `processes/BFS-001/scenarios/uc-001.md`
- opis: „Klient składa w kanale cyfrowym dyspozycję przelewu wielopozycyjnego i zatwierdza ją silnym uwierzytelnieniem.”
- relacje: contains A1, E1, SCR-001, SCR-002 · realizes BFS-001.REQ-01, BFS-001.RB-01, CAP-001 · consumes API-001, QUE-001 · constrained_by NFR-001.NFRT-SEC-01 · involves ACTOR-001.ROLE-01
- wskazywany przez: UCMAP-001 (groups)
- treść zaczyna się tabelą: Aktor główny ACTOR-001.ROLE-01 · Kanały: aplikacja mobilna, bankowość internetowa · BFS: BFS-001 · Zdolność CAP-001. Dalej są sekcje „Powiązanie z BFS”, „Cel” i „Aktorzy”.

### 6.6 Płótno: zoom i przesuwanie

Dotyczy wszystkich trybów:
- kółko myszy albo gest szczypania przybliża w miejscu kursora,
- przeciąganie tła przesuwa widok,
- Shift z przeciąganiem rysuje ramkę, do której widok się przybliża (pokaż stan w trakcie rysowania ramki),
- przeciąganie węzła przesuwa węzeł,
- przyciski −, wskaźnik procentów, +, „Dopasuj” w prawym dolnym rogu, skróty + − 0 i F,
- zakres od 10% do 400%,
- szczegółowość zależy od zoomu: poniżej 50% bez etykiet, poniżej 25% tylko grupy,
- minimapa w rogu po przybliżeniu powyżej 150%.

### 6.7 Wyszukiwanie Ctrl+K

Paleta nad płótnem. Wyniki pogrupowane: dokumenty (chip ID, tytuł, ścieżka), wiersze, polecenia. Składnia `typ:API` otwiera katalog typu. Przykład: wpisane „dysp” zwraca między innymi: BFS-001 Obsługa dyspozycji, UC-001 Złożenie dyspozycji, FLOW-001 Przyjęcie dyspozycji — przebieg podstawowy, DDM-001 Domena dyspozycji, ENT-Disposition Dyspozycja oraz wiersz DDM-001.DOM-Dyspozycja.

### 6.8 Panel walidacji

Lista problemów z ośmiu sprawdzeń standardu: rodzaj relacji spoza listy, trójka spoza matrycy, cel nie istnieje, wzmianka bez relacji, doc-id nie jest unikalny, węzeł bez powiązania albo wyspa, ponownie użyty numer wiersza, dokument active wskazuje draft. Każdy problem ma ikonę ważności, węzeł, plik z numerem linii i przycisk „Pokaż”. Na płótnie węzeł z błędem ma czerwoną obwódkę.

Zaprojektuj dwa stany:
- **Brak problemów.** Tak jest dziś w korpusie: 119 dokumentów, 410 relacji, 0 problemów.
- **Z problemami.** Użyj skutków symulacji usunięcia SCR-002 i FLOW-002 z punktu 6.3 jako przykładu i oznacz go w projekcie jako przykład.

## 7. Komponenty do biblioteki

| Komponent | Warianty i stany |
|---|---|
| Węzeł dokumentu | zwykły · najechany · zaznaczony · w zasięgu · startowy zasięgu · kontekst (wyszarzony) · z błędem · bez użyć · z rozwiniętymi wierszami |
| Węzeł wiersza | zwykły · zaznaczony · startowy |
| Grupa | zwinięta (z paskiem warstw i liczbą) · rozwinięta · zaznaczona |
| Linia | relacja · agregat z liczbą · zdarzenie · wywołanie · niejednoznaczna · podświetlona ścieżka |
| Chip ID | 8 kolorów warstw · w koszyku (z usunięciem) · w tekście (link) |
| Pasek warstw | proporcje 8 warstw |
| Kontrolki panelu | select · przełącznik segmentowy · pola wyboru z kolorem warstwy · suwak · koszyk |
| Sekcja inspektora | nagłówek · lista relacji · wynik zasięgu ze ścieżką · podsumowanie katalogu |
| Tabela katalogu | nagłówek z sortowaniem · wiersz zaznaczony · komórka „0 użyć” |
| Pasek zoomu i minimapa | — |
| Paleta Ctrl+K | pusta · z wynikami · bez wyników |
| Status dokumentu | draft · active |

## 8. Lista artboardów

1. Mapa: całość w grupach, zaznaczona grupa BFS-001 (motyw jasny)
2. Mapa: grupa BFS-001 rozwinięta w dokumenty, zoom około 150% z minimapą
3. Katalog: wszystkie API, graf
4. Katalog: wszystkie encje, tabela, zaznaczony ENT-Client
5. Zasięg: `change_scope` dla BFS-001.REQ-01, najechana ścieżka SCR-001 › SCRSEC-001
6. Zasięg: symulacja usunięcia SCR-002
7. Przepływ: poziom CAP, zaznaczona linia QUE-010
8. Podgląd pliku UC-001 na całą szerokość
9. Paleta Ctrl+K z wynikami dla „dysp”
10. Panel walidacji: stan z problemami
11. Artboard 5 w motywie ciemnym
12. Biblioteka komponentów z sekcji 7

## 9. Poza zakresem

- edycja dokumentów i relacji,
- logowanie, konta, uprawnienia,
- porównanie gałęzi git,
- wersja mobilna,
- widok kolejności kroków procesu (BPMN, sekwencje). Przepływ pokazuje tylko dane między zdolnościami.

## 10. Otwarte kwestie (projekt może je pokazać wariantowo)

1. Węzeł startowy zasięgu: proponujemy, żeby nie trafiał do listy wyników, a na płótnie był wyróżniony.
2. Linia niejednoznaczna w przepływie: proponujemy linię przerywaną bez strzałki. Warto pokazać też alternatywę, na przykład linię od scenariusza zamiast od zdolności.
