---
name: plain-language-docs
description: Upraszcza opisy w dokumentacji i narzędziach. Przepisuje komentarze w plikach konfiguracyjnych i skryptach, teksty Markdown, instrukcje --help i komunikaty programów na prosty język, zrozumiały dla wszystkich. Pisze pełnymi zdaniami, z pełnym kontekstem i bez skrótów myślowych. Nie zmienia danych ani działania kodu. Użyj, gdy ktoś prosi o uproszczenie, wyjaśnienie albo przepisanie opisów „po ludzku”.
---

# Proste opisy dokumentacji

Ten skill przepisuje opisy tak, żeby zrozumiał je każdy członek zespołu, także
osoba, która pierwszy raz widzi projekt. Zmienia się tylko sposób opisu. Dane,
klucze, identyfikatory i działanie kodu zostają dokładnie takie same.

## Co przepisywać

- Komentarze w plikach konfiguracyjnych, na przykład YAML, JSON z komentarzami, TOML.
- Komentarze w kodzie i skryptach.
- Teksty w plikach Markdown: README, instrukcje, opisy standardów.
- Instrukcje wypisywane przez `--help` i komunikaty, które program pokazuje użytkownikowi.

## Czego nie zmieniać

- Wartości, kluczy ani struktury plików konfiguracyjnych.
- Kodu: warunków, wyrażeń regularnych, nazw zmiennych i funkcji.
- Identyfikatorów, nazw typów, nazw plików i kluczy. Nie tłumacz ich na inny język.
- Etykiet i nazw, do których odwołuje się inny plik. Przykład: nazwa błędu wypisywana przez skrypt występuje też w tabeli w README. Zmiana tylko w jednym miejscu rozspójni oba pliki.
- Plików w folderach, które projekt oznacza jako tylko do odczytu albo jako źródło.

## Zasady pisania

1. **Pełne zdania.** Każda myśl to zdanie z podmiotem i orzeczeniem. Nie zastępuj zdań znakami `;`, `->`, `:` ani samymi hasłami.
   - Źle: `# retry 3x, potem DLQ`
   - Dobrze: `# Jeśli wysłanie się nie uda, program ponawia próbę trzy razy. Po trzeciej nieudanej próbie wiadomość trafia do kolejki wiadomości błędnych (DLQ).`
2. **Pełny kontekst.** Napisz, czego dotyczy opis, skąd bierze się wartość (który plik, która sekcja, która kolumna tabeli) i co z tego wynika. Czytelnik nie musi znać innych plików, żeby zrozumieć opis.
3. **Bez skrótów myślowych.** Rozwiń każdy skrót przy pierwszym użyciu albo dodaj słownik skrótów na początku pliku. Zamiast `patrz §7` napisz `opis jest w pliku X, w sekcji 7`.
4. **Proste słowa.** Wybieraj słowa potoczne zamiast żargonu, na przykład „niezgodność” zamiast „rozjazd”. Termin fachowy, bez którego się nie da, wyjaśnij od razu w tym samym zdaniu.
5. **Ten sam język.** Pisz w języku, w którym są już opisy w pliku. Nie mieszaj języków w jednym opisie, poza nazwami, których się nie tłumaczy.
6. **Przykłady tylko prawdziwe.** Bierz przykłady z plików, które już istnieją w projekcie: z danych, z przykładów, z dokumentacji albo z dotychczasowych komentarzy. Nie wymyślaj nowych identyfikatorów ani przypadków.
7. **Tylko obecny stan.** Opis mówi, jak jest teraz. Nie opisuje historii zmian ani wcześniejszych wersji.
8. **Nie dopisuj nowych reguł.** Opis może wyjaśniać tylko to, co wynika z danych albo kodu. Jeśli dopisujesz zdanie, którego wcześniej nie było, sprawdź je w danych albo w kodzie i zgłoś je użytkownikowi w podsumowaniu.
9. **Czytelny układ.**
   - Długi komentarz na końcu linii przenieś nad tę linię.
   - Nad grupą wpisów dodaj nagłówek, który mówi, czego ta grupa dotyczy.
   - Listy warunków zapisz jako numerowane punkty albo pary pytanie i odpowiedź.
10. **Komunikaty programów.** Komunikat to pełne zdanie zakończone kropką. Mówi, co jest nie tak i jak to poprawić.
    - Źle: `brak klucza: id`
    - Dobrze: `Wpis nie ma klucza id. Dodaj ten klucz albo usuń wpis.`

## Jak pracować

1. **Kopia zapasowa.** Skopiuj pliki, które zmieniasz, do katalogu tymczasowego poza projektem.
2. **Kontekst.** Przeczytaj cały plik i pliki, do których się odwołuje. Znaczenie skrótów i pojęć znajdziesz w dokumentacji projektu: w słowniku, w opisie metodyki albo w README.
3. **Przepisanie.** Zmieniaj tylko opisy według zasad powyżej.
4. **Sprawdzenie danych.** Porównaj plik z kopią po usunięciu komentarzy i pustych linii. Różnica musi być pusta.

   Pliki z komentarzami zaczynającymi się od `#`:

   ```bash
   strip() { sed -E 's/[[:space:]]+#.*$//; /^[[:space:]]*#/d; /^[[:space:]]*$/d' "$1"; }
   diff <(strip kopia/plik.yaml) <(strip plik.yaml) && echo "dane bez zmian"
   ```

   Pliki z komentarzami zaczynającymi się od `//`. Różnica pokaże zmienione teksty komunikatów, więc przejrzyj ją i upewnij się, że zmieniły się tylko teksty:

   ```bash
   strip() { sed -E '/^[[:space:]]*\/\//d; /^[[:space:]]*$/d' "$1"; }
   diff <(strip kopia/skrypt.js) <(strip skrypt.js)
   ```

   Sprawdzenie usuwa też znaki `#` wewnątrz wartości w cudzysłowie. Jeśli plik ma takie wartości, porównaj je osobno.
5. **Sprawdzenie działania programu.** Jeśli zmieniasz komunikaty albo `--help`, uruchom starą i nową wersję na tych samych danych, także na danych z celowo wprowadzonymi błędami. Poza treścią komunikatów wszystko musi być identyczne: rodzaje zgłoszeń, miejsca błędów, kody wyjścia i pliki zapisane przez program. Jeśli program szuka plików względem własnego folderu, skopiuj go razem z tymi plikami i zachowaj układ folderów.
6. **Testy i walidatory projektu.** Uruchom testy, walidatory albo inne narzędzia kontrolne, które projekt już ma. Wynik musi być taki sam jak przed zmianą.

## Pułapki

- **Niewidoczne znaki.** Przy przepisywaniu całego pliku zapis znaku przez sekwencję ucieczki (ukośnik wsteczny, litera `u` i kod znaku) może zamienić się w sam znak. Dotyczy to zwłaszcza znaków niewidocznych, jak BOM (U+FEFF) albo spacja o zerowej szerokości (U+200B). Po zapisie policz takie znaki w pliku i porównaj z kopią zapasową.
- **Zależne pliki.** Gdy zmieniasz tekst w programie, wyszukaj ten sam tekst w całym projekcie. Jeśli występuje gdzie indziej, zmień wszystkie miejsca albo zostaw wszystkie bez zmian.
- **Plik zmieniony w trakcie pracy.** Jeśli zapis się nie udaje, bo plik się zmienił, porównaj go z kopią zapasową, zanim cokolwiek nadpiszesz.

## Podsumowanie dla użytkownika

Na końcu napisz krótko, w punktach:

1. Które pliki się zmieniły i co się w nich zmieniło.
2. Jak sprawdzono, że dane i działanie są bez zmian.
3. Które zdania są nowe, a nie tylko przepisane. Zapytaj, czy je zostawić.
