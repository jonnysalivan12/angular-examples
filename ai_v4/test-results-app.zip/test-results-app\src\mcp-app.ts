// Widok wyników testów. Działa w ramce wewnątrz czatu i rozmawia z hostem przez klasę App.
import {
  App,
  applyDocumentTheme,
  applyHostFonts,
  applyHostStyleVariables,
} from "@modelcontextprotocol/ext-apps";
import type { CallToolResult } from "@modelcontextprotocol/client";
import type { Runner, RunState, TestCase, TestFile, TestReport, TestStatus } from "./types.ts";
import "./mcp-app.css";

const POLL_INTERVAL_MS = 1000;
const ICONS: Record<TestStatus, string> = { passed: "✓", failed: "✗", skipped: "○" };

type RunArgs = { cwd: string; runner: Runner };

const byId = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
const metaEl = byId("meta");
const rerunBtn = byId<HTMLButtonElement>("rerun");
const runningEl = byId("running");
const runningLabelEl = byId("running-label");
const outputEl = byId("output");
const summaryEl = byId("summary");
const onlyFailedEl = byId<HTMLInputElement>("only-failed");
const errorEl = byId("error");
const errorTextEl = byId("error-text");
const errorOutputEl = byId("error-output");
const filesEl = byId("files");

let lastArgs: RunArgs | null = null;
let lastReport: TestReport | null = null;
let tickInterval: number | undefined;
let pollTimeout: number | undefined;

const app = new App({ name: "Wyniki testów", version: "1.0.0" });

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className?: string, text?: string) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function formatDuration(ms: number | null): string {
  if (ms === null) return "";
  return ms < 1000 ? `${Math.round(ms)} ms` : `${(ms / 1000).toFixed(1)} s`;
}

function formatElapsed(ms: number): string {
  return `${Math.floor(ms / 1000)} s`;
}

function stopTimers() {
  window.clearInterval(tickInterval);
  window.clearTimeout(pollTimeout);
  tickInterval = undefined;
  pollTimeout = undefined;
}

function readState(result: CallToolResult): RunState | null {
  const state = result.structuredContent as RunState | undefined;
  return state?.runId ? state : null;
}

function textOf(result: CallToolResult): string {
  return result.content
    .map((item) => (item.type === "text" ? item.text : ""))
    .join("\n")
    .trim();
}

// Stany widoku: trwa, błąd, raport.

function showRunning(label: string, outputTail: string[] = []) {
  runningEl.hidden = false;
  runningLabelEl.textContent = label;
  outputEl.hidden = outputTail.length === 0;
  outputEl.textContent = outputTail.join("\n");
  errorEl.hidden = true;
  rerunBtn.disabled = true;
}

function showError(message: string, outputTail: string[]) {
  stopTimers();
  runningEl.hidden = true;
  errorEl.hidden = false;
  errorTextEl.textContent = message;
  errorOutputEl.hidden = outputTail.length === 0;
  errorOutputEl.textContent = outputTail.join("\n");
  rerunBtn.disabled = lastArgs === null;
}

function renderState(state: RunState) {
  lastArgs = { cwd: state.cwd, runner: state.runner };
  if (state.status === "running") {
    showRunning(`Trwa uruchamianie testów… ${formatElapsed(state.elapsedMs)}`, state.outputTail);
    return;
  }
  if (state.status === "error" || !state.report) {
    showError(state.error ?? "Nieznany błąd.", state.outputTail);
    return;
  }

  stopTimers();
  runningEl.hidden = true;
  errorEl.hidden = true;
  rerunBtn.disabled = false;
  lastReport = state.report;
  const finishedAt = new Date(state.report.finishedAt).toLocaleTimeString("pl-PL");
  metaEl.textContent = `${state.runner} · ${state.cwd} · ${formatDuration(state.elapsedMs)} · ${finishedAt}`;
  renderReport();
}

function renderReport() {
  if (!lastReport) return;
  const { summary, files } = lastReport;
  const total = Math.max(summary.total, 1);

  summaryEl.hidden = false;
  for (const status of ["passed", "failed", "skipped"] as const) {
    byId(`count-${status}`).textContent = String(summary[status]);
    byId(`bar-${status}`).style.width = `${(summary[status] / total) * 100}%`;
  }

  const onlyFailed = onlyFailedEl.checked;
  const visibleFiles = files.filter((file) => !onlyFailed || file.status === "failed");
  if (visibleFiles.length === 0) {
    filesEl.replaceChildren(
      el("p", "empty", onlyFailed ? "Wszystkie testy przeszły." : "Program testowy nie znalazł testów."),
    );
    return;
  }
  filesEl.replaceChildren(...visibleFiles.map((file) => renderFile(file, onlyFailed)));
}

function renderFile(file: TestFile, onlyFailed: boolean): HTMLElement {
  const details = el("details", `file file-${file.status}`);
  details.open = file.status === "failed";

  const passed = file.tests.filter((test) => test.status === "passed").length;
  const header = el("summary", "file-summary");
  header.append(
    el("span", `icon icon-${file.status}`, ICONS[file.status]),
    el("span", "file-path", file.path),
    el("span", "file-count", `${passed}/${file.tests.length}`),
  );
  details.append(header);

  if (file.error) {
    details.append(renderFailure(file.path, "cały plik", file.error));
  }

  const list = el("ul", "tests");
  for (const test of file.tests) {
    if (!onlyFailed || test.status === "failed") list.append(renderTest(file, test));
  }
  details.append(list);
  return details;
}

function renderTest(file: TestFile, test: TestCase): HTMLElement {
  const item = el("li", `test test-${test.status}`);
  const row = el("div", "test-row");
  row.append(
    el("span", `icon icon-${test.status}`, ICONS[test.status]),
    el("span", "test-name", test.name),
    el("span", "test-duration", formatDuration(test.durationMs)),
  );
  item.append(row);
  if (test.failureMessage) {
    item.append(renderFailure(file.path, test.name, test.failureMessage));
  }
  return item;
}

function renderFailure(filePath: string, testName: string, message: string): HTMLElement {
  const box = el("div", "failure");
  const askBtn = el("button", "button button-secondary", "Poproś o naprawę");
  askBtn.type = "button";
  askBtn.addEventListener("click", () => void askForFix(filePath, testName, message, askBtn));
  box.append(el("pre", "failure-message", message), askBtn);
  return box;
}

// Akcje użytkownika.

// Wysyła do czatu wiadomość w imieniu użytkownika, tak jakby wpisał ją sam.
async function askForFix(filePath: string, testName: string, message: string, button: HTMLButtonElement) {
  button.disabled = true;
  const text =
    `Test „${testName}” w pliku ${filePath} nie przechodzi. Komunikat błędu:\n\n` +
    `${message.slice(0, 2000)}\n\nZnajdź przyczynę i popraw kod. Potem uruchom testy ponownie.`;
  try {
    const { isError } = await app.sendMessage(
      { role: "user", content: [{ type: "text", text }] },
      { signal: AbortSignal.timeout(5000) },
    );
    button.textContent = isError ? "Host odrzucił wiadomość" : "Wysłano do czatu";
  } catch {
    button.textContent = "Nie udało się wysłać. Spróbuj ponownie";
    button.disabled = false;
  }
}

async function pollRun(runId: string) {
  try {
    const result = await app.callServerTool({ name: "get-test-run", arguments: { runId } });
    const state = readState(result);
    if (!state) {
      showError(textOf(result) || "Serwer nie zwrócił stanu przebiegu.", []);
      return;
    }
    renderState(state);
    if (state.status === "running") {
      pollTimeout = window.setTimeout(() => void pollRun(runId), POLL_INTERVAL_MS);
    }
  } catch (error) {
    showError(`Nie udało się pobrać stanu testów: ${String(error)}`, []);
  }
}

rerunBtn.addEventListener("click", async () => {
  if (!lastArgs) return;
  stopTimers();
  showRunning("Uruchamiam testy…");
  try {
    const result = await app.callServerTool({ name: "start-test-run", arguments: lastArgs });
    const state = readState(result);
    if (!state) {
      showError(textOf(result) || "Serwer nie uruchomił testów.", []);
      return;
    }
    renderState(state);
    pollTimeout = window.setTimeout(() => void pollRun(state.runId), POLL_INTERVAL_MS);
  } catch (error) {
    showError(`Nie udało się uruchomić testów: ${String(error)}`, []);
  }
});

onlyFailedEl.addEventListener("change", renderReport);

// Zdarzenia od hosta. Rejestrujemy je przed connect(), żeby nie zgubić pierwszego wyniku.

// Model wywołał `run-tests`: znamy argumenty, ale wynik przyjdzie dopiero po zakończeniu testów.
app.addEventListener("toolinput", (params) => {
  const args = params.arguments as Partial<RunArgs> | undefined;
  if (args?.cwd) {
    lastArgs = { cwd: args.cwd, runner: args.runner ?? "vitest" };
    metaEl.textContent = `${lastArgs.runner} · ${lastArgs.cwd}`;
  }
  const startedAt = Date.now();
  showRunning("Trwa uruchamianie testów…");
  tickInterval = window.setInterval(() => {
    runningLabelEl.textContent = `Trwa uruchamianie testów… ${formatElapsed(Date.now() - startedAt)}`;
  }, 1000);
});

app.addEventListener("toolresult", (result) => {
  stopTimers();
  const state = readState(result);
  if (state) {
    renderState(state);
  } else {
    showError(textOf(result) || "Narzędzie nie zwróciło wyników.", []);
  }
});

app.addEventListener("toolcancelled", () => {
  showError("Uruchomienie testów zostało anulowane.", []);
});

function applyHostContext() {
  const ctx = app.getHostContext();
  if (!ctx) return;
  if (ctx.theme) applyDocumentTheme(ctx.theme);
  if (ctx.styles?.variables) applyHostStyleVariables(ctx.styles.variables);
  if (ctx.styles?.css?.fonts) applyHostFonts(ctx.styles.css.fonts);
}

app.addEventListener("hostcontextchanged", applyHostContext);
app.onerror = console.error;

app.connect().then(applyHostContext);
