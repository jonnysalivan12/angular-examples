import { defineConfig } from "vitest/config";

// Własna konfiguracja, żeby Vitest nie wczytał vite.config.ts z katalogu wyżej.
export default defineConfig({});
