// Uruchamia Vitest albo Jest, śledzi przebiegi i zamienia raport JSON na typy z src/types.ts.
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { statSync } from "node:fs";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type { Runner, RunState, TestFile, TestReport, TestStatus } from "./src/types.ts";

const OUTPUT_TAIL_LINES = 12;
const MAX_STORED_RUNS = 20;
const ANSI_ESCAPES = /\x1b\[[0-9;]*[A-Za-z]/g;

type Run = { state: RunState; startedAt: number; done: Promise<RunState> };

const runs = new Map<string, Run>();

// Vitest i Jest zapisują raport w tym samym formacie.
type JestAssertion = {
  title: string;
  ancestorTitles?: string[];
  status: string;
  duration?: number | null;
  failureMessages?: string[];
};

type JestFileResult = {
  name: string;
  status: string;
  message?: string;
  assertionResults: JestAssertion[];
};

type JestReport = { testResults: JestFileResult[] };

function buildCommand(runner: Runner, reportFile: string): string {
  // Domyślny reporter Vitesta wypisuje postęp, a reporter JSON zapisuje raport do pliku.
  // Flaga `--no` blokuje pobieranie programu testowego, którego projekt nie ma w zależnościach.
  // Po `--` npm przekazuje resztę flag do programu testowego i ich nie czyta.
  return runner === "vitest"
    ? `npx --no -- vitest run --reporter=default --reporter=json --outputFile.json="${reportFile}"`
    : `npx --no -- jest --json --outputFile="${reportFile}"`;
}

function clean(text: string): string {
  return text.replace(ANSI_ESCAPES, "").trim();
}

// Usuwa ze śladu stosu linie z bibliotek i z samego Node.js, zostawia linie z kodu projektu.
function cleanFailure(text: string): string {
  return clean(text)
    .split("\n")
    .filter((line) => !/node_modules|node:internal|\(<anonymous>\)/.test(line))
    .join("\n");
}

function toStatus(status: string): TestStatus {
  if (status === "passed") return "passed";
  if (status === "failed") return "failed";
  return "skipped";
}

function toReport(json: JestReport, cwd: string, runner: Runner): TestReport {
  const files: TestFile[] = json.testResults.map((file) => {
    const tests = file.assertionResults.map((assertion) => ({
      name: [...(assertion.ancestorTitles ?? []), assertion.title].join(" › "),
      status: toStatus(assertion.status),
      durationMs: assertion.duration ?? null,
      failureMessage: assertion.failureMessages?.length
        ? cleanFailure(assertion.failureMessages.join("\n"))
        : null,
    }));
    const hasFailedTest = tests.some((test) => test.status === "failed");
    const error =
      file.status === "failed" && !hasFailedTest && file.message ? cleanFailure(file.message) : null;
    return {
      path: path.relative(cwd, file.name).split(path.sep).join("/") || file.name,
      status: hasFailedTest || error ? "failed" : "passed",
      tests,
      error,
    };
  });

  const allTests = files.flatMap((file) => file.tests);
  const count = (status: TestStatus) => allTests.filter((test) => test.status === status).length;

  return {
    cwd,
    runner,
    finishedAt: new Date().toISOString(),
    summary: {
      total: allTests.length,
      passed: count("passed"),
      failed: count("failed"),
      skipped: count("skipped"),
      fileErrors: files.filter((file) => file.error).length,
    },
    files,
  };
}

export function startRun(cwd: string, runner: Runner): Run {
  const runId = randomUUID();
  const reportFile = path.join(os.tmpdir(), `test-results-${runId}.json`);
  const startedAt = Date.now();
  const state: RunState = {
    runId,
    cwd,
    runner,
    status: "running",
    elapsedMs: 0,
    outputTail: [],
    report: null,
    error: null,
  };

  const done = new Promise<RunState>((resolve) => {
    let settled = false;
    const finish = async (startError?: Error) => {
      if (settled) return;
      settled = true;
      state.elapsedMs = Date.now() - startedAt;
      try {
        if (startError) throw startError;
        const raw = await fs.readFile(reportFile, "utf-8");
        state.report = toReport(JSON.parse(raw), cwd, runner);
        state.status = "done";
      } catch {
        state.status = "error";
        state.error = startError
          ? `Nie udało się uruchomić testów: ${startError.message}`
          : "Program testowy nie zapisał raportu. Przyczyna jest zwykle w ostatnich liniach wyniku.";
      } finally {
        await fs.rm(reportFile, { force: true });
        resolve(state);
      }
    };

    if (!statSync(cwd, { throwIfNoEntry: false })?.isDirectory()) {
      void finish(new Error(`katalog ${cwd} nie istnieje.`));
      return;
    }

    // Powłoka jest potrzebna, żeby `npx` działało także w Windowsie.
    const child = spawn(buildCommand(runner, reportFile), {
      cwd,
      shell: true,
      env: { ...process.env, FORCE_COLOR: "0", NO_COLOR: "1" },
    });
    const collect = (chunk: Buffer) => {
      const lines = clean(chunk.toString())
        .split(/\r?\n/)
        .filter((line) => line.trim());
      state.outputTail = [...state.outputTail, ...lines].slice(-OUTPUT_TAIL_LINES);
    };
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);
    child.on("error", (error) => void finish(error));
    child.on("close", () => void finish());
  });

  const run = { state, startedAt, done };
  runs.set(runId, run);
  if (runs.size > MAX_STORED_RUNS) {
    runs.delete(runs.keys().next().value!);
  }
  return run;
}

export function getRun(runId: string): RunState | undefined {
  const run = runs.get(runId);
  if (run?.state.status === "running") {
    run.state.elapsedMs = Date.now() - run.startedAt;
  }
  return run?.state;
}

// Tekst dla modelu: krótkie podsumowanie i lista niezaliczonych testów.
export function describeRun(state: RunState): string {
  if (state.status === "running") {
    return `Testy w ${state.cwd} nadal trwają (${Math.round(state.elapsedMs / 1000)} s).`;
  }
  if (state.status === "error" || !state.report) {
    const tail = state.outputTail.length ? ["Ostatnie linie wyniku:", ...state.outputTail] : [];
    return [state.error ?? "Nieznany błąd.", ...tail].join("\n");
  }

  const { summary, files } = state.report;
  const lines = [
    `Testy (${state.runner}) w ${state.cwd}. Zaliczone: ${summary.passed}, ` +
      `niezaliczone: ${summary.failed}, pominięte: ${summary.skipped}. ` +
      `Czas: ${(state.elapsedMs / 1000).toFixed(1)} s.`,
  ];
  for (const file of files) {
    if (file.error) {
      lines.push(`- ${file.path}: plik się nie uruchomił. ${file.error.split("\n")[0]}`);
    }
    for (const test of file.tests.filter((test) => test.status === "failed")) {
      lines.push(`- ${file.path} › ${test.name}: ${test.failureMessage?.split("\n")[0] ?? ""}`);
    }
  }
  return lines.join("\n");
}
