// Punkt wejścia. `--stdio` uruchamia serwer dla VS Code, bez flagi serwer słucha przez HTTP
// (do testów w hoście basic-host z repozytorium ext-apps).
import { createMcpExpressApp } from "@modelcontextprotocol/express";
import { NodeStreamableHTTPServerTransport } from "@modelcontextprotocol/node";
import { StdioServerTransport } from "@modelcontextprotocol/server/stdio";
import cors from "cors";
import type { Request, Response } from "express";
import { createServer } from "./server.ts";

async function startHttpServer(): Promise<void> {
  const port = parseInt(process.env.PORT ?? "3001", 10);

  // Narzędzie uruchamia polecenia na tym komputerze, więc serwer przyjmuje tylko połączenia
  // z localhost, a CORS wpuszcza tylko strony z localhost.
  const app = createMcpExpressApp();
  app.use(cors({ origin: /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/ }));

  app.all("/mcp", async (req: Request, res: Response) => {
    const server = createServer();
    const transport = new NodeStreamableHTTPServerTransport({ sessionIdGenerator: undefined });

    res.on("close", () => {
      transport.close().catch(() => {});
      server.close().catch(() => {});
    });

    try {
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (error) {
      console.error("Błąd MCP:", error);
      if (!res.headersSent) {
        res.status(500).json({
          jsonrpc: "2.0",
          error: { code: -32603, message: "Internal server error" },
          id: null,
        });
      }
    }
  });

  app.listen(port, "127.0.0.1", (error) => {
    if (error) {
      console.error("Serwer nie wystartował:", error);
      process.exit(1);
    }
    console.log(`Serwer MCP słucha pod adresem http://localhost:${port}/mcp`);
  });
}

async function main() {
  if (process.argv.includes("--stdio")) {
    // W trybie stdio standardowe wyjście należy do protokołu MCP, więc nic tu nie wypisujemy.
    await createServer().connect(new StdioServerTransport());
  } else {
    await startHttpServer();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
