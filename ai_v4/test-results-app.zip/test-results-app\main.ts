// Punkt wejścia. `--stdio` uruchamia serwer dla VS Code, bez flagi serwer słucha przez HTTP
// (do testów w hoście basic-host z repozytorium ext-apps).
import { createMcpExpressApp } from "@modelcontextprotocol/express";
import { NodeStreamableHTTPServerTransport } from "@modelcontextprotocol/node";
import { CLIENT_CAPABILITIES_META_KEY } from "@modelcontextprotocol/server";
import { StdioServerTransport } from "@modelcontextprotocol/server/stdio";
import cors from "cors";
import type { Request, Response } from "express";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createServer } from "./server.ts";

// Dziennik diagnostyczny trybu stdio. Zapisuje, co klient zgłasza w swoich możliwościach,
// żeby sprawdzić, czy obsługuje okienka MCP Apps. Argumentów narzędzi nie zapisuje.
const LOG_FILE = path.join(os.tmpdir(), "test-results-mcp.log");

type LoggedMessage = {
  method?: string;
  params?: Record<string, unknown>;
  result?: Record<string, unknown>;
};

function writeLog(entry: Record<string, unknown>) {
  try {
    fs.appendFileSync(LOG_FILE, JSON.stringify({ time: new Date().toISOString(), ...entry }) + "\n");
  } catch {
    // Dziennik jest pomocniczy, więc błąd zapisu nie może zatrzymać serwera.
  }
}

function logIncoming(message: LoggedMessage) {
  if (!message.method) return;
  const params = message.params ?? {};
  const meta = params._meta as Record<string, unknown> | undefined;
  writeLog({
    direction: "klient->serwer",
    method: message.method,
    protocolVersion: params.protocolVersion,
    clientInfo: params.clientInfo,
    capabilities: params.capabilities,
    metaClientCapabilities: meta?.[CLIENT_CAPABILITIES_META_KEY],
  });
}

function logOutgoing(message: LoggedMessage) {
  if (message.result?.capabilities) {
    writeLog({ direction: "serwer->klient", capabilities: message.result.capabilities });
  }
}

async function startHttpServer(): Promise<void> {
  const port = parseInt(process.env.PORT ?? "3001", 10);

  // Narzędzie uruchamia polecenia na tym komputerze, więc serwer przyjmuje tylko połączenia
  // z localhost, a CORS wpuszcza tylko strony z localhost.
  const app = createMcpExpressApp();
  app.use(cors({ origin: /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/ }));

  app.all("/mcp", async (req: Request, res: Response) => {
    const server = createServer();
    const transport = new NodeStreamableHTTPServerTransport({ sessionIdGenerator: undefined });

    res.on("close", () => {
      transport.close().catch(() => {});
      server.close().catch(() => {});
    });

    try {
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (error) {
      console.error("Błąd MCP:", error);
      if (!res.headersSent) {
        res.status(500).json({
          jsonrpc: "2.0",
          error: { code: -32603, message: "Internal server error" },
          id: null,
        });
      }
    }
  });

  app.listen(port, "127.0.0.1", (error) => {
    if (error) {
      console.error("Serwer nie wystartował:", error);
      process.exit(1);
    }
    console.log(`Serwer MCP słucha pod adresem http://localhost:${port}/mcp`);
  });
}

async function main() {
  if (process.argv.includes("--stdio")) {
    // W trybie stdio standardowe wyjście należy do protokołu MCP, więc nic tu nie wypisujemy.
    const transport = new StdioServerTransport();
    await createServer().connect(transport);

    const handleMessage = transport.onmessage;
    transport.onmessage = (message) => {
      logIncoming(message as LoggedMessage);
      handleMessage?.(message);
    };
    const send = transport.send.bind(transport);
    transport.send = (message) => {
      logOutgoing(message as LoggedMessage);
      return send(message);
    };
  } else {
    await startHttpServer();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
