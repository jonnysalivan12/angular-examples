// Typy wspólne dla serwera i widoku.

export type Runner = "vitest" | "jest";

export type TestStatus = "passed" | "failed" | "skipped";

export type TestCase = {
  name: string;
  status: TestStatus;
  durationMs: number | null;
  failureMessage: string | null;
};

export type TestFile = {
  path: string;
  status: "passed" | "failed";
  tests: TestCase[];
  // Błąd całego pliku, np. błąd składni, przez który żaden test się nie uruchomił.
  error: string | null;
};

export type TestSummary = {
  total: number;
  passed: number;
  failed: number;
  skipped: number;
  fileErrors: number;
};

export type TestReport = {
  cwd: string;
  runner: Runner;
  finishedAt: string;
  summary: TestSummary;
  files: TestFile[];
};

export type RunState = {
  runId: string;
  cwd: string;
  runner: Runner;
  status: "running" | "done" | "error";
  elapsedMs: number;
  outputTail: string[];
  report: TestReport | null;
  error: string | null;
};
