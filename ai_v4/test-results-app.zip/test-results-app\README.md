# Wyniki testów jako aplikacja MCP

Serwer MCP z narzędziem `run-tests`. Narzędzie uruchamia testy projektu (Vitest albo Jest), a wyniki pokazuje w interaktywnym widoku w czacie: pasek z wynikami, listę plików i testów, treść błędów, przycisk ponownego uruchomienia i przycisk, który prosi asystenta o naprawę niezaliczonego testu.

## Pliki

| Plik | Co robi |
|---|---|
| `server.ts` | Rejestruje narzędzia i zasób z widokiem. |
| `runner.ts` | Uruchamia program testowy, śledzi postęp i zamienia raport JSON na wyniki. |
| `main.ts` | Uruchamia serwer przez stdio (dla VS Code i Claude Desktop) albo przez HTTP (dla hosta testowego). |
| `mcp-app.html`, `src/mcp-app.ts`, `src/mcp-app.css` | Widok wyświetlany w czacie. |
| `src/types.ts` | Typy wspólne dla serwera i widoku. |
| `demo/` | Przykładowe testy: cztery przechodzą, jeden nie przechodzi, jeden jest pominięty. |
| `scripts/` | Skrypt, który dopisuje serwer do konfiguracji Claude Desktop. |

Serwer ma trzy narzędzia:

- `run-tests` widzi model. Narzędzie czeka na koniec testów i zwraca podsumowanie oraz listę błędów.
- `start-test-run` i `get-test-run` widzi tylko widok (`visibility: ["app"]`). Widok uruchamia nimi testy ponownie i co sekundę pobiera postęp.

## Budowanie

```bash
npm install
npm run build
```

Budowanie tworzy plik `dist/mcp-app.html`, który serwer wysyła hostowi jako widok.

## Użycie w VS Code

Do pliku `.vscode/mcp.json` w swoim projekcie dodaj serwer. Zamień `C:/sciezka/do/test-results-app` na ścieżkę do tego folderu:

```json
{
  "servers": {
    "test-results": {
      "type": "stdio",
      "command": "node",
      "args": [
        "C:/sciezka/do/test-results-app/node_modules/tsx/dist/cli.mjs",
        "C:/sciezka/do/test-results-app/main.ts",
        "--stdio"
      ]
    }
  }
}
```

Potem napisz w czacie Copilota w trybie agenta, na przykład: „Uruchom testy w C:\Workspace\Projects\moj-projekt”. Copilot wywoła `run-tests`, a widok pojawi się w odpowiedzi. VS Code obsługuje aplikacje MCP od wersji 1.109.

## Użycie w Claude Desktop

Claude Desktop czyta plik `claude_desktop_config.json` tylko przy starcie. W trakcie działania zapisuje ten plik ze swojej pamięci, więc zmiany zrobione przy otwartej aplikacji znikają. Serwer trzeba dopisać, gdy aplikacja jest zamknięta. Robi to skrypt `scripts/dodaj-do-claude-desktop.ps1`.

1. Zamknij Claude Desktop całkowicie, także ikonę obok zegara.
2. Uruchom skrypt w PowerShell (podmień ścieżkę, jeśli projekt leży gdzie indziej):

   ```powershell
   powershell -ExecutionPolicy Bypass -File "C:\Workspace\Projects\mcp-test-results\test-results-app\scripts\dodaj-do-claude-desktop.ps1"
   ```

   Skrypt odmówi działania, jeśli Claude Desktop nadal działa. Przed zmianą zapisuje kopię zapasową pliku obok oryginału.
3. Uruchom Claude Desktop.
4. W polu wiadomości kliknij przycisk dodawania (lewy dolny róg), potem **Connectors** i **Manage connectors**. Na liście powinien być serwer `wyniki-testow` z narzędziem `run-tests`.
5. Napisz w czacie, na przykład: „Uruchom testy w C:\Workspace\Projects\moj-projekt”. Zatwierdź użycie narzędzia, a widok pojawi się w odpowiedzi.

Wersja Claude Desktop ze Sklepu Microsoft trzyma plik konfiguracji w folderze pakietu: `%LOCALAPPDATA%\Packages\Claude_<id>\LocalCache\Roaming\Claude\`. Bieżący dziennik aplikacji `main.log` leży w `%LOCALAPPDATA%\Claude\logs`. Jeśli serwer się nie łączy, szukaj tam pliku `mcp-server-wyniki-testow.log` albo wpisów z nazwą `wyniki-testow` w `main.log`.

## Sprawdzenie bez VS Code

Repozytorium MCP Apps ma host testowy `basic-host`, który wyświetla widoki tak jak klient MCP.

1. Uruchom serwer przez HTTP: `npm run serve`. Serwer słucha pod adresem `http://localhost:3001/mcp`.
2. Pobierz repozytorium `https://github.com/modelcontextprotocol/ext-apps` i przejdź do `examples/basic-host`.
3. Zainstaluj zależności i zbuduj host: `npm install`, potem `npx cross-env INPUT=index.html vite build` i `npx cross-env INPUT=sandbox.html vite build`.
4. Uruchom host: `npx tsx serve.ts`. Skrypt `npm start` z repozytorium wymaga programu Bun.
5. Otwórz `http://localhost:8080`, wybierz narzędzie `run-tests` i podaj dane wejściowe, na przykład `{ "cwd": "C:\\sciezka\\do\\test-results-app\\demo" }`.

## Ograniczenia

- Serwer obsługuje tylko Vitest i Jest, bo czyta ich wspólny format raportu JSON.
- Narzędzie uruchamia testy, czyli kod projektu, na twoim komputerze. Podawaj tylko katalogi projektów, którym ufasz.
- Program testowy musi być w zależnościach projektu. Flaga `npx --no` blokuje pobieranie go z internetu.
- W trybie HTTP serwer przyjmuje tylko połączenia z localhost.
- Testowany projekt nie może leżeć w folderze aplikacji Claude w `AppData\Roaming`. Windows przekierowuje ten folder do innej fizycznej ścieżki i Vite widzi wtedy ten sam plik pod dwiema ścieżkami, więc go nie znajduje.
