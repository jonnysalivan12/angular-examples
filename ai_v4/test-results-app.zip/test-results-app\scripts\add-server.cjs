// Dopisuje serwer "wyniki-testow" do sekcji mcpServers w claude_desktop_config.json.
// Pozostałe ustawienia zostają bez zmian, a poprzednia wersja pliku trafia do kopii zapasowej.
// Użycie: node add-server.cjs <ścieżka do pliku konfiguracji> <folder projektu> <ścieżka do node.exe>
const fs = require("fs");
const path = require("path");

const [configPath, projectDir, nodePath] = process.argv.slice(2);
if (!configPath || !projectDir || !nodePath) {
  console.error("Brak argumentów. Podaj ścieżkę do pliku konfiguracji, folder projektu i ścieżkę do node.exe.");
  process.exit(1);
}

let config = {};
if (fs.existsSync(configPath)) {
  const backupPath = `${configPath}.bak-${Date.now()}`;
  fs.copyFileSync(configPath, backupPath);
  console.log(`Kopia zapasowa: ${backupPath}`);
  config = JSON.parse(fs.readFileSync(configPath, "utf8"));
} else {
  fs.mkdirSync(path.dirname(configPath), { recursive: true });
}

config.mcpServers = {
  ...(config.mcpServers ?? {}),
  "wyniki-testow": {
    command: nodePath,
    args: [
      path.join(projectDir, "node_modules", "tsx", "dist", "cli.mjs"),
      path.join(projectDir, "main.ts"),
      "--stdio",
    ],
  },
};

fs.writeFileSync(configPath, JSON.stringify(config, null, 2) + "\n", "utf8");
console.log(`Dopisano serwer "wyniki-testow" do pliku ${configPath}.`);
