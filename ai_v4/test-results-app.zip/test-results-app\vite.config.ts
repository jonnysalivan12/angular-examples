import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const INPUT = process.env.INPUT;
if (!INPUT) {
  throw new Error("Brak zmiennej środowiskowej INPUT. Uruchom budowanie przez `npm run build`.");
}

const isDevelopment = process.env.NODE_ENV === "development";

// Host wczytuje widok jako jeden plik HTML, więc skrypty i style trafiają do środka.
export default defineConfig({
  plugins: [viteSingleFile()],
  build: {
    sourcemap: isDevelopment ? "inline" : undefined,
    cssMinify: !isDevelopment,
    minify: !isDevelopment,
    rollupOptions: {
      input: INPUT,
    },
    outDir: "dist",
    emptyOutDir: false,
  },
});
