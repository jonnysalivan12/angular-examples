import {
  EXTENSION_ID,
  registerAppResource,
  registerAppTool,
  RESOURCE_MIME_TYPE,
} from "@modelcontextprotocol/ext-apps/server";
import {
  McpServer,
  type CallToolResult,
  type ReadResourceResult,
} from "@modelcontextprotocol/server";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import { describeRun, getRun, startRun } from "./runner.ts";
import type { RunState } from "./src/types.ts";

const DIST_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), "dist");
const RESOURCE_URI = "ui://test-results/mcp-app.html";

const runInput = z.object({
  cwd: z.string().describe("Bezwzględna ścieżka do katalogu projektu z testami."),
  runner: z
    .enum(["vitest", "jest"])
    .default("vitest")
    .describe("Program testowy, którego używa projekt."),
});

function toToolResult(state: RunState): CallToolResult {
  return {
    content: [{ type: "text", text: describeRun(state) }],
    structuredContent: state,
    isError: state.status === "error",
  };
}

export function createServer(): McpServer {
  const server = new McpServer(
    { name: "Wyniki testów", version: "1.1.0" },
    // Serwer zgłasza rozszerzenie MCP Apps. Część klientów pokazuje okienka tylko wtedy,
    // gdy rozszerzenie zgłosi zarówno klient, jak i serwer.
    { capabilities: { extensions: { [EXTENSION_ID]: { mimeTypes: [RESOURCE_MIME_TYPE] } } } },
  );

  // Narzędzie dla modelu. Pole `_meta.ui.resourceUri` mówi hostowi, który widok pokazać w czacie.
  registerAppTool(
    server,
    "run-tests",
    {
      title: "Uruchom testy",
      description:
        "Uruchamia testy projektu (Vitest albo Jest) i pokazuje wyniki w interaktywnym widoku. " +
        "Zwraca podsumowanie i listę niezaliczonych testów z pierwszą linią błędu.",
      inputSchema: runInput,
      _meta: { ui: { resourceUri: RESOURCE_URI } },
    },
    async ({ cwd, runner }): Promise<CallToolResult> => {
      const run = startRun(cwd, runner);
      return toToolResult(await run.done);
    },
  );

  // Dwa narzędzia tylko dla widoku (`visibility: ["app"]`), model ich nie widzi.
  // Widok uruchamia nimi testy ponownie i co sekundę pyta o postęp.
  registerAppTool(
    server,
    "start-test-run",
    {
      title: "Rozpocznij przebieg testów",
      description: "Uruchamia testy w tle i od razu zwraca identyfikator przebiegu.",
      inputSchema: runInput,
      _meta: { ui: { visibility: ["app"] } },
    },
    async ({ cwd, runner }): Promise<CallToolResult> => toToolResult(startRun(cwd, runner).state),
  );

  registerAppTool(
    server,
    "get-test-run",
    {
      title: "Stan przebiegu testów",
      description: "Zwraca stan przebiegu: czas trwania, ostatnie linie wyniku i raport po zakończeniu.",
      inputSchema: z.object({ runId: z.string() }),
      _meta: { ui: { visibility: ["app"] } },
    },
    async ({ runId }): Promise<CallToolResult> => {
      const state = getRun(runId);
      if (!state) {
        return {
          content: [
            {
              type: "text",
              text: `Serwer nie zna przebiegu ${runId}. Mógł zostać uruchomiony ponownie. Uruchom testy jeszcze raz.`,
            },
          ],
          isError: true,
        };
      }
      return toToolResult(state);
    },
  );

  // Zasób z widokiem: zbudowany plik dist/mcp-app.html.
  registerAppResource(
    server,
    RESOURCE_URI,
    RESOURCE_URI,
    { mimeType: RESOURCE_MIME_TYPE, description: "Widok wyników testów" },
    async (): Promise<ReadResourceResult> => {
      const html = await fs.readFile(path.join(DIST_DIR, "mcp-app.html"), "utf-8");
      return { contents: [{ uri: RESOURCE_URI, mimeType: RESOURCE_MIME_TYPE, text: html }] };
    },
  );

  return server;
}
