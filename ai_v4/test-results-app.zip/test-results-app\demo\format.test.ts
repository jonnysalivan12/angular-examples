import { describe, expect, it } from "vitest";
import { formatPrice } from "./cart.ts";

describe("formatowanie ceny", () => {
  it("używa przecinka i dwóch miejsc po przecinku", () => {
    expect(formatPrice(12.5)).toBe("12,50 zł");
  });

  it("formatuje zero", () => {
    expect(formatPrice(0)).toBe("0,00 zł");
  });
});
