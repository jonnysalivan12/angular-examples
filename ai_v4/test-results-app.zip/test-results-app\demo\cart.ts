// Przykładowy kod do testów.

export type CartItem = { name: string; price: number; quantity: number };

export function cartTotal(items: CartItem[]): number {
  return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

export function applyDiscount(total: number, percent: number): number {
  return total - (total * percent) / 100;
}

export function formatPrice(value: number): string {
  return `${value.toFixed(2).replace(".", ",")} zł`;
}
