﻿# Dopisuje serwer "wyniki-testow" do konfiguracji Claude Desktop.
# Uruchom go, gdy Claude Desktop jest całkowicie zamknięty. Działająca aplikacja zapisuje plik
# konfiguracji ze swojej pamięci i usuwa zmiany zrobione w trakcie jej działania.
#
# Uruchomienie z PowerShell:
#   powershell -ExecutionPolicy Bypass -File "<folder projektu>\scripts\dodaj-do-claude-desktop.ps1"

$ErrorActionPreference = "Stop"
$projectDir = Split-Path -Parent $PSScriptRoot

# Sprawdzamy tylko procesy z folderu WindowsApps, żeby nie pomylić Claude Desktop z innym programem claude.exe.
$running = Get-Process -Name "claude" -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -like "*\WindowsApps\Claude_*" }
if ($running) {
  Write-Host "Claude Desktop nadal działa. Zamknij go całkowicie, także ikonę obok zegara, i uruchom skrypt ponownie."
  exit 1
}

# Wersja ze Sklepu Microsoft trzyma plik w folderze pakietu, a nie w %APPDATA%\Claude.
$package = Get-ChildItem (Join-Path $env:LOCALAPPDATA "Packages") -Directory -Filter "Claude_*" -ErrorAction SilentlyContinue |
  Select-Object -First 1
if ($package) {
  $configPath = Join-Path $package.FullName "LocalCache\Roaming\Claude\claude_desktop_config.json"
} else {
  $configPath = Join-Path $env:APPDATA "Claude\claude_desktop_config.json"
}

$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
  Write-Host "Nie znaleziono programu node. Zainstaluj Node.js z https://nodejs.org i uruchom skrypt ponownie."
  exit 1
}

if (-not (Test-Path (Join-Path $projectDir "node_modules\tsx\dist\cli.mjs"))) {
  Write-Host "Brak zależności projektu. Uruchom npm install w folderze $projectDir i uruchom skrypt ponownie."
  exit 1
}

& $node.Source (Join-Path $PSScriptRoot "add-server.cjs") $configPath $projectDir $node.Source
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "Gotowe. Uruchom Claude Desktop."
