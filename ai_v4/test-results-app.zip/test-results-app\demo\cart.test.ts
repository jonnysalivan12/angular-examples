import { describe, expect, it } from "vitest";
import { applyDiscount, cartTotal } from "./cart.ts";

describe("koszyk", () => {
  it("sumuje ceny pomnożone przez ilość", () => {
    expect(cartTotal([{ name: "kubek", price: 20, quantity: 2 }])).toBe(40);
  });

  it("zwraca 0 dla pustego koszyka", () => {
    expect(cartTotal([])).toBe(0);
  });

  it("odejmuje rabat procentowy", () => {
    expect(applyDiscount(200, 10)).toBe(180);
  });

  it.skip("nalicza koszt wysyłki", () => {});
});
