---
name: mortgage-figma-audit
description: Sprawdza, czy rama w Figmie jest przygotowana do przekazania programistom, i przygotowuje prompt naprawy dla agenta Figmy. Użyj, gdy projektant podaje link do ramy i prosi o audyt, sprawdzenie albo przygotowanie makiety.
---

# Audyt makiety w Figmie

Ten skill prowadzi projektanta przez cztery etapy: audyt ramy, pytania, plan
naprawy i prompt naprawy. Makiety nie zmienia. Poprawki wprowadza agent Figmy
w pliku projektu, gdy projektant wklei mu gotowy prompt.

Audyt wykonuje narzędzie `audit_frame` serwera MCP `figma-design-ir` z pluginu
figma-design-ir. Gdy tego narzędzia nie ma, nie używaj innych narzędzi Figmy.
Odpowiedz tylko tym błędem i zakończ:

```text
Błąd: brak serwera MCP figma-design-ir. Zainstaluj plugin poleceniem
copilot plugin install figma-design-ir@mortgage-copilot-tools i rozpocznij nową sesję Copilota.
```

## Jak rozmawiać

- Rozmówca jest projektantem. Pisz prostym językiem, bez ścieżek plików,
  JSON-a i komunikatów narzędzi.
- Zadawaj jedno pytanie naraz i czekaj na odpowiedź.
- Warstwy wskazuj nazwami z Figmy, tak jak podaje je wynik audytu.

## Pliki

W argumencie `project_dir` każdego narzędzia podawaj ścieżkę bezwzględną
folderu roboczego: folderu otwartego w edytorze albo folderu, w którym
uruchomiono Copilota. Folder wyników serwer wybiera sam według ustawień
projektu.

## Etap 1. Audyt

1. Poproś o link do ramy, jeśli projektant go nie podał. Link ma zawierać
   `node-id`. Projektant dostaje go w Figmie: zaznacza ramę i wybiera
   „Copy link to selection”.
2. Wywołaj `audit_frame` z linkiem w `figma_url` i folderem roboczym
   w `project_dir`.
3. Gdy narzędzie zwraca błąd, przekaż projektantowi jego treść prostymi słowami
   razem z zaleceniem i zakończ.

Gdy `summary.total` wynosi 0, napisz, że rama jest gotowa, i zakończ.

W innym razie pokaż wynik: jedna linia na regułę, która ma uchybienia, z ich
liczbą i z warstwami z `examples`. Nazwy reguł:

| Reguła w wyniku | Nazwa dla projektanta |
|---|---|
| `no-auto-layout` | kontener bez auto layoutu |
| `raw-value` | wartość wpisana ręcznie zamiast zmiennej |
| `shadow-without-style` | cień bez stylu efektu |
| `text-without-style` | tekst bez stylu tekstu i bez zmiennych czcionki |
| `default-layer-name` | warstwa z domyślną nazwą |
| `component-definition-in-frame` | definicja komponentu w ramie zamiast instancji |
| `hidden-layer` | ukryta warstwa |
| `empty-container` | pusty kontener |
| `repeated-structure` | powtórzona budowa: kandydat na komponent |

Uchybienie z polem `component` dotyczy komponentu głównego. Powiedz to przy
tej warstwie.

Reguły `hidden-layer`, `empty-container` i `repeated-structure` pokaż osobno,
jako sprawy do decyzji projektanta. Prompt naprawy ich nie obejmuje. Przy
`repeated-structure` wymień wszystkie wystąpienia z `layer_paths`. Gdy
`fix_prompt` jest pusty, pomiń etapy 2–4.

## Etap 2. Pytania

Lista `decisions` w wyniku to decyzje, których wymaga naprawa. Dla każdej:

- Pole `answer` ma wartość: nie pytaj. Narzędzie wybrało zmienną, której ta
  sama rama już używa przy tej wartości. Pokażesz ją w planie.
- Pole `answer` jest puste, a `suggestions` ma kilka nazw: zapytaj, którą
  wybrać. Dodaj możliwości „inna” i „nie wiem”.
- Pole `answer` jest puste i `suggestions` też: zadaj pytanie z pola
  `question`. Odpowiedź to nazwa zmiennej albo stylu. Przyjmij też „nie wiem”.

Po odpowiedzi „nie wiem” nie zapisuj nic dla tej decyzji. Agent Figmy poszuka
wtedy zmiennej o tej samej wartości w podłączonej bibliotece.

## Etap 3. Plan naprawy

1. Gdy projektant udzielił odpowiedzi, wywołaj `audit_frame` ponownie z tym
   samym linkiem i folderem roboczym. W `decisions` podaj obiekt: `id` decyzji → nazwa
   zmiennej albo stylu.
2. Pokaż plan: ponumerowana lista poprawek z `fix_prompt`, każda w jednym
   zdaniu.
3. Zapytaj, czy plan jest w porządku. Gdy projektant chce zmienić zmienną,
   wróć do etapu 2 dla tej decyzji.

## Etap 4. Prompt naprawy

1. Pokaż treść `fix_prompt` w bloku kodu. Nie zmieniaj w niej ani słowa.
2. Podaj instrukcję:
   1. W Figmie zaznacz audytowaną ramę.
   2. Otwórz agenta: przycisk „Agents” albo Ctrl+Enter (Cmd+Enter na Macu).
   3. Wklej prompt i wyślij.
   4. Sprawdź, czy rama wygląda tak samo jak przed poprawkami. Zmianę cofa
      Ctrl+Z.
3. Zaproponuj ponowny audyt po naprawie. Wywołaj wtedy `audit_frame`
   z `refresh: true` i wróć do etapu 1.
