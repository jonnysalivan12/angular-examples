# Plugin figma-designer

Sprawdza, czy rama w Figmie jest gotowa do przekazania programistom, i daje prompt naprawy dla agenta Figmy. Plugin jest dla projektantów.

## Szybki start

1. Przygotuj token Figmy i pliki projektu według [README pluginu figma-design-ir](../figma-design-ir/README.md), sekcje „Co trzeba mieć” i „Konfiguracja projektu”.
2. Zainstaluj oba pluginy:

   ```bash
   copilot plugin install figma-design-ir@mortgage-copilot-tools
   copilot plugin install figma-designer@mortgage-copilot-tools
   ```

   Przy pierwszej instalacji najpierw dodaj marketplace według [README pluginów](../../README.md).
3. W Figmie zaznacz ramę i wybierz „Copy link to selection”.
4. Napisz do Copilota: „Sprawdź ramę <link>”.
5. Odpowiedz na pytania o zmienne. Gotowy prompt wklej w agencie Figmy.

## Co dostajesz

Skill `mortgage-figma-audit` prowadzi cię przez cztery kroki:

1. Pokazuje uchybienia w ramie.
2. Pyta o zmienne, których wymaga naprawa.
3. Pokazuje plan naprawy.
4. Podaje prompt do wklejenia w agencie Figmy.

Pliki wyników trafiają do folderu z pola `outputDir` w pliku `.github/plugin/figma-design-ir/settings.json` repozytorium projektu.

## Co trzeba mieć

1. Plugin figma-design-ir z jego wymaganiami i plikami projektu. Bez niego plugin kończy pracę błędem z poleceniem instalacji.
2. Prawo edycji pliku Figmy i miejsce Full. Tego wymaga agent Figmy przy wklejaniu promptu naprawy.

Aktualizację, VS Code i przejście z instalacji z folderu opisuje [README pluginów](../../README.md).
