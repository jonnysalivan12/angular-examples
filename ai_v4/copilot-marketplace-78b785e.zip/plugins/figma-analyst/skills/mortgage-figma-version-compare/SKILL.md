---
name: mortgage-figma-version-compare
description: Pokazuje zmiany między dwiema wersjami tej samej ramy w Figmie na obrazach i zapisuje stronę HTML z obrazami obu wersji i obrysami zmian. Użyj, gdy analityk chce zobaczyć zmiany w makiecie na ekranie, pokazać je innym albo zapisać stan ramy do późniejszego porównania.
---

# Porównanie wersji ramy

Ten skill porównuje dwie wersje tej samej ramy narzędziem `compare_frames`
serwera MCP `figma-design-ir` z pluginu figma-design-ir. Wynikiem jest krótka
lista zmian i strona HTML, na której każda zmiana ma obrys na obrazie ramy
przed i po. Gdy narzędzia nie ma, nie używaj innych narzędzi Figmy. Odpowiedz
tylko tym błędem i zakończ:

```text
Błąd: brak serwera MCP figma-design-ir. Zainstaluj plugin poleceniem
copilot plugin install figma-design-ir@mortgage-copilot-tools i rozpocznij nową sesję Copilota.
```

Opis zmian pogrupowany pod kątem wymagań daje skill `mortgage-figma-change-analysis`.

## Jak rozmawiać

- Pisz prostym językiem, bez JSON-a i komunikatów narzędzi.
- Warstwy wskazuj nazwami z Figmy.

## Pliki

W argumencie `project_dir` każdego narzędzia podawaj ścieżkę bezwzględną
folderu roboczego: folderu otwartego w edytorze albo folderu, w którym
uruchomiono Copilota. Folder wyników serwer wybiera sam według ustawień
projektu.

## Źródła

Porównanie działa dla dwóch wersji tej samej ramy. Dwie różne ramy, także
kopia ramy, mają w Figmie inne identyfikatory warstw, więc narzędzie zwróci
błąd.

1. Stan późniejszy to zwykle link do ramy. Link bez `version-id` wskazuje
   bieżącą wersję pliku.
2. Stan wcześniejszy to jedno z dwóch:
   - Link do ramy z parametrem `version-id`. Link do wersji kopiuje się
     w historii wersji pliku („Copy link” przy wybranej wersji). Gdy ten link
     nie ma `node-id`, dopisz jego parametr `version-id` do linku ramy. Gdy
     nie ma parametru `version-id`, napisz, że nie da się z niego odczytać
     wersji, i poproś o inne źródło.
   - Plik IR zapisany wcześniej narzędziem `frame_to_ir`.

Gdy analityk chce porównać ramę później, na przykład przed zmianami
w makiecie, zapisz jej bieżący stan narzędziem `frame_to_ir` z folderem
roboczym w `project_dir`. Powiedz analitykowi, że stan jest zapisany, i podaj nazwę
pliku.

## Kroki

1. Ustal oba źródła.
2. Wywołaj `compare_frames`: stan wcześniejszy w `before`, stan późniejszy
   w `after`, a w `html_file` nazwę pliku `<klucz>__<node-id>.diff.html`.
   Serwer zapisze go w folderze wyników.
3. Gdy narzędzie zwraca błąd, przekaż analitykowi jego treść prostymi słowami
   i zakończ.
4. Pokaż wynik:
   - liczbę elementów dodanych, usuniętych, przeniesionych i zmienionych
     (`summary`),
   - do pięciu zmian, które widać na ekranie: nazwa warstwy z końca `path`
     i zmiana prostymi słowami, na przykład zmieniony tekst albo nowy przycisk,
   - ścieżkę strony HTML z informacją, że strona pokazuje obrysy wszystkich
     zmian na obu obrazach.

Gdy wszystkie liczby w `summary` wynoszą 0, napisz, że wersje się nie różnią.
