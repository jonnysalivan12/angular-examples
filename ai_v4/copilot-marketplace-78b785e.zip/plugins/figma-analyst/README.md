# Plugin figma-analyst

Opisuje ekran z ramy w Figmie według szablonów ekranu i sekcji oraz zmiany między wersjami ramy. Plugin jest dla analityków.

## Szybki start

1. Przygotuj token Figmy i pliki projektu według [README pluginu figma-design-ir](../figma-design-ir/README.md), sekcje „Co trzeba mieć” i „Konfiguracja projektu”.
2. Zainstaluj oba pluginy:

   ```bash
   copilot plugin install figma-design-ir@mortgage-copilot-tools
   copilot plugin install figma-analyst@mortgage-copilot-tools
   ```

   Przy pierwszej instalacji najpierw dodaj marketplace według [README pluginów](../../README.md).
3. W Figmie zaznacz ramę i wybierz „Copy link to selection”.
4. Uruchom agenta opisu ekranu i podaj mu link:

   ```bash
   copilot --agent figma-analyst:mortgage-screen-description
   ```

## Co możesz zrobić

| Co robisz | Kto to robi | Co dostajesz |
|---|---|---|
| Uruchamiasz agenta i podajesz link | agent `mortgage-screen-description` | Opis ekranu według szablonu SCR, opis każdej sekcji według szablonu SCRSEC, obrazy sekcji i listę pytań. |
| Piszesz do Copilota: „Co zmieniło się w ramie <link>?” | skill `mortgage-figma-change-analysis` | Zmiany pogrupowane według treści, pól i akcji, kolejności, komponentów do zbudowania i wyglądu, z informacją, czego dotyczą w wymaganiach. |
| Piszesz do Copilota: „Pokaż zmiany w ramie <link> na obrazach” | skill `mortgage-figma-version-compare` | Stronę HTML z obrazami obu wersji i obrysami zmian. Skill zapisuje też bieżący stan ramy, żeby porównać go później. |

Pliki wyników trafiają do folderu z pola `outputDir` w pliku `.github/plugin/figma-design-ir/settings.json` repozytorium projektu.

## Opis ekranu

Agent `mortgage-screen-description`:

1. Pobiera obraz ekranu i IR ramy.
2. Ustala z IR podział ekranu na sekcje.
3. Gdy podział budzi wątpliwości, pokazuje warianty i czeka na Twój wybór.
4. Pobiera obraz każdej sekcji.
5. Zapisuje opisy w podfolderze `<klucz>__<node-id>/` folderu wyników.

Wskazówki:

- Podaj identyfikatory dokumentów razem z linkiem, np. „SCR-020, sekcje od SCRSEC-040”. Bez nich agent zostawi `{nnn}`.
- Pola szablonu, których makieta nie pokazuje, zostają z tekstem zastępczym `{…}`. Pytania o nie trafiają do `questions.md`.
- W sesji Copilota agenta wybierasz też poleceniem `/agent`.

## Co trzeba mieć

Plugin figma-design-ir z jego wymaganiami i plikami projektu. Bez niego agent i skille kończą pracę błędem i podają polecenie instalacji.

Aktualizację, VS Code i przejście z instalacji z folderu opisuje [README pluginów](../../README.md).
