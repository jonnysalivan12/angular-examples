# Zmiany w pluginie figma-analyst

Najnowsza wersja jest na górze. Nagłówek wersji ma datę wydania. Zainstalowaną wersję pokazuje `copilot plugin list`.

## 0.1.0

Pierwsza wersja.

- Agent `mortgage-screen-description` opisuje ekran według szablonu SCR i każdą sekcję według szablonu SCRSEC. Zapisuje też obrazy sekcji i listę pytań.
- Skill `mortgage-figma-change-analysis` grupuje zmiany między dwiema wersjami ramy dla analityka.
- Skill `mortgage-figma-version-compare` zapisuje stronę HTML z obrazami obu wersji ramy i obrysami zmian.
- Pliki wyników trafiają do folderu z pola `outputDir` w pliku `.github/plugin/figma-design-ir/settings.json` repozytorium projektu.
- Plugin wymaga pluginu figma-design-ir z serwerem MCP Figmy. Bez niego agent i skille kończą pracę błędem i podają polecenie instalacji.
