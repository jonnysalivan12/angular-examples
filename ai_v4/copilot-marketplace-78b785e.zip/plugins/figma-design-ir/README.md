# Plugin figma-design-ir

Serwer MCP Figmy dla agentów Copilota. Pluginy figma-designer, figma-analyst i task-flow korzystają z tego serwera i bez niego kończą pracę błędem.

## Szybki start

1. Ustaw token Figmy w zmiennej `FIGMA_API_KEY` (sekcja „Co trzeba mieć”).
2. Zainstaluj plugin:

   ```bash
   copilot plugin install figma-design-ir@mortgage-copilot-tools
   ```

   Przy pierwszej instalacji najpierw dodaj marketplace według [README pluginów](../../README.md).
3. Dodaj pliki projektu (sekcja „Konfiguracja projektu”).
4. W Figmie zaznacz ramę i wybierz „Copy link to selection”.
5. Napisz do Copilota: „Zapisz IR ramy <link>”.

## Co możesz zrobić

| Napisz do Copilota | Narzędzie | Co dostajesz |
|---|---|---|
| „Zapisz IR ramy <link>” | `frame_to_ir` | IR ramy, czyli opis ramy w JSON dla programistów i agentów. |
| „Porównaj ramę <link> z wersją <link z version-id>” | `compare_frames` | Porównanie dwóch wersji ramy. Na prośbę także stronę HTML z obrysami zmian na obrazach. |
| „Pobierz obraz ramy <link>” | `get_frame_image` | Obraz PNG ramy. |
| „Sprawdź ramę <link>” | `audit_frame` | Wynik audytu i prompt naprawy dla agenta Figmy. |

- Pliki wyników trafiają do folderu z pola `outputDir` w `settings.json` projektu.
- Argumenty narzędzi opisuje [modules/figma/docs/mcp-server.md](../../modules/figma/docs/mcp-server.md) w repozytorium z pluginem.

## Konfiguracja projektu

Przed pierwszym użyciem dodaj w repozytorium projektu folder `.github/plugin/figma-design-ir/` z plikiem `settings.json`. Wartości w przykładzie są pokazowe:

```json
{
  "outputDir": "design/figma",
  "localComponentMap": ".github/plugin/figma-design-ir/local-component-map.json"
}
```

- `outputDir` jest wymagane: to folder wyników.
- `localComponentMap` jest opcjonalne: to plik mapy komponentów utworzonych w pliku z makietami, spoza DS. Bez pola albo bez pliku takie komponenty nie mają odpowiedników w kodzie.
- Ścieżki względne serwer liczy od głównego folderu repozytorium.

| Plik w projekcie | Co ustawia | Kiedy jest wymagany |
|---|---|---|
| `settings.json` | Folder wyników i plik mapy komponentów lokalnych. | zawsze |
| `variables.json` | Zmienne z biblioteki Figmy. | gdy plugin nie ma pliku domyślnego |
| `component-map.json` | Mapę komponentów z biblioteki DS na komponenty w kodzie. | gdy plugin nie ma pliku domyślnego |
| `css-variable-map.json` | Mapę tokenów Figmy na zmienne CSS w kodzie. | gdy plugin nie ma pliku domyślnego |

- Pliki domyślne pluginu leżą w `server/config/` w folderze pluginu. Plik z projektu zastępuje plik domyślny.
- Bez wymaganego pliku narzędzie kończy pracę błędem i podaje ścieżkę pliku do dodania.
- Szczegóły i formaty plików: [docs/configuration.md](docs/configuration.md).

## Co trzeba mieć

1. Copilot CLI albo VS Code z GitHub Copilot.
2. W organizacji z Copilot Business albo Enterprise administrator musi włączyć politykę „MCP servers in Copilot”.
3. Node.js.
4. Osobisty token Figmy w zmiennej środowiskowej `FIGMA_API_KEY`:
   - token tworzysz w Figmie: Settings → Security → Personal access tokens,
   - zakresy `file_content:read` i `file_metadata:read`,
   - po ustawieniu zmiennej uruchom ponownie terminal albo VS Code.
5. Dostęp do pliku Figmy z makietą. Wystarczy podgląd.

Aktualizację, VS Code i wydanie nowej wersji opisuje [README pluginów](../../README.md).
