# Hook task-flow

Skrypt `hooks/task-flow.js` działa tylko na gałęziach `feature/task-flow/*`.

## Co blokuje

- `git push`, `git reset --hard` i `git clean`.
- Każde wywołanie narzędzia innego niż odczyt, którego argumenty zawierają ścieżkę `.github/plugin/task-flow/settings.json`. Dotyczy to także zapisu innego pliku, w którego treści pada ta ścieżka. Polecenie powłoki z tą ścieżką hook przepuszcza tylko wtedy, gdy zaczyna się od `cat`, `type`, `Get-Content` albo `gc`.
- Podagenta task-flow wywołanego z polem `mode` innym niż `sync`. Orchestrator i pętla implementacji powtarzają wtedy wywołanie w trybie `sync`.
- Drugiego podagenta task-flow, gdy pierwszy jeszcze pracuje. Blokadę zwalnia zakończenie podagenta, także nieudane. Pętla implementacji nie podlega tej blokadzie, bo sama wywołuje testera, implementera i verifiera.

Co zrobić, gdy blokada zostaje, choć żaden podagent nie pracuje: [README](../README.md), sekcja „Gdy praca stanie”.

## Limit nieudanych sprawdzeń

1. Hook liczy odpowiedzi verifiera, których ostatnia niepusta linia nie jest dokładnie `RESULT: PASS`, osobno dla każdego zadania z planu.
2. Po `maxFailedChecks` zatrzymuje pętlę. Blokuje wtedy testera, implementera i zapis plików poza folderem zadania.
3. Licznik obowiązuje w jednej sesji Copilota. Nowa sesja liczy od zera, dlatego wznowienie po `stopped` zaczynasz w nowej sesji.

## Dziennik

Z `TASK_FLOW_DEBUG=1` hook zapisuje dziennik w `<folder tymczasowy>/task-flow/hooks.log`.

## Zachowanie, o którym warto wiedzieć

- **Tryb `background`.** Hook odrzuca podagenta z polem `mode` innym niż `sync`, a wywołanie bez tego pola przepuszcza, bo schemat Copilot CLI nie podaje wartości domyślnej. Gdyby podagent ruszył w tle, hook policzy odpowiedź verifiera jako nieudaną, a blokada podagentów nie zadziała.
- **Odczyt wyniku.** Hook i pętla implementacji czytają ostatnią niepustą linię odpowiedzi verifiera. Zadanie zalicza tylko dokładne `RESULT: PASS`. Gdyby Copilot dopisywał coś po odpowiedzi podagenta, obaj policzą wynik jako nieudany. Dziennik z `TASK_FLOW_DEBUG=1` zapisuje odczytaną ostatnią linię w polu `lastLine`.
- **Sesja wewnątrz podagenta.** W Copilot CLI 1.0.71 wywołania narzędzi wewnątrz podagenta trafiały do hooka z identyfikatorem sesji równym identyfikatorowi wywołania podagenta. Jeśli tak jest też w obecnej wersji, każde wywołanie pętli przez orchestratora liczy nieudane sprawdzenia od zera. Pokaże to pole `sessionId` w dzienniku z `TASK_FLOW_DEBUG=1`.
