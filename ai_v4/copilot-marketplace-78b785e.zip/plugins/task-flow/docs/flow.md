# Przepływ task-flow

## Kroki

1. **Start.** Orchestrator tworzy gałąź `feature/task-flow/<task>` od najnowszej `baseBranch`. Zgłoszenie z Jiry zapisuje jako `task.md`. W trybie `frontend` zapisuje IR makiet w folderze `design/` narzędziem `frame_to_ir` serwera `figma-design-ir`.
2. **Analiza.** Analyst wybiera z zadania część frontendową albo backendową według `mode`, a resztę wypisuje jako „Poza zakresem”. Wybraną część porównuje z IR makiet i kodem. Pisze `plan.md` z niespójnościami i ponumerowanymi zadaniami.
3. **Akceptacja.** Orchestrator pokazuje plan razem z otwartymi pytaniami z makiet. Człowiek akceptuje plan albo odrzuca go z uwagami i odpowiada na pytania. Uwagi i odpowiedzi trafiają do analysta, który poprawia plan.
4. **Standardy.** Standards-scout wybiera sekcje standardów dla zadań z planu i zapisuje je w `standards.md`.
5. **Pętla implementacji.** Dla każdego zadania z planu orchestrator wywołuje pętlę implementacji i traktuje ją jako całość. Pętla wywołuje testera, implementera i verifiera. Po `RESULT: FAIL` zaczyna obieg od testera.
6. **Raport.** Orchestrator pisze `report.md`. Push i merge request robi człowiek.

Gdy dzieje się coś, czego przepływ nie przewiduje, orchestrator zatrzymuje się i pokazuje człowiekowi, co się stało.

## Wyniki pętli implementacji

| Wynik | Kiedy | Co dalej |
|---|---|---|
| `LOOP: DONE` | Verifier zaliczył zadanie. | Orchestrator robi commit i przechodzi do następnego zadania. |
| `LOOP: STOPPED` | Skończył się limit nieudanych sprawdzeń. | Orchestrator pisze raport i ustawia etap `stopped`. |
| `LOOP: NEEDS-HUMAN` | Potrzebna jest decyzja człowieka. | Orchestrator pyta człowieka i wywołuje pętlę ponownie z jego decyzją. |

Pętla zapisuje decyzję człowieka w `plan.md` pod bieżącym zadaniem, więc znają ją wszyscy podagenci i nowa sesja.

## Folder zadania

| Plik w `specs/<task>/` | Kto pisze | Zawartość |
|---|---|---|
| `state.json` | orchestrator | Etap, ścieżka zadania i numer bieżącego zadania z planu. |
| `task.md` | orchestrator | Kopia zgłoszenia z Jiry. |
| `design/` | orchestrator | IR makiet, jeden plik na ramkę. |
| `plan.md` | analyst, pętla implementacji | Część zadania poza zakresem, niespójności, komponenty z makiet i zadania planu. Pętla dopisuje decyzje człowieka. |
| `standards.md` | standards-scout | Wybrane sekcje standardów dla każdego zadania. |
| `tests.md` | tester | Dla każdego zadania: pliki testów i warunki „Gotowe, gdy”, które sprawdzają. |
| `changes.md` | implementer | Dla każdego zadania: zmienione pliki, wyniki poleceń sprawdzających i linia `COMMIT:` z opisem commita. |
| `checks.md` | verifier | Wyniki kolejnych sprawdzeń. |
| `report.md` | orchestrator | Wynik, commity, standardy i ostatnie uwagi. |

## Etapy w `state.json`

1. `received`
2. `analyzed`
3. `approved`
4. `standards-selected`
5. `implementing`
6. `done`, a po wyczerpaniu limitu `stopped`

Wznowienie zaczyna od etapu po ostatnim ukończonym, a w pętli od zadania zapisanego w `planTask`. Po `stopped` orchestrator najpierw pokazuje ostatnie uwagi verifiera i pyta, co zmienić.

## Warunek startu

Każdy agent przed pracą sprawdza artefakty, których potrzebuje. Gdy czegoś brakuje, nie wykonuje pracy i odpowiada linią `BRAK: <plik albo sekcja>`.

| Agent | Wymaga |
|---|---|
| analyst | pliku zadania, a w trybie `frontend` pliku IR dla każdego linku do ramki Figmy z zadania |
| standards-scout | `plan.md` i pliku wejściowego standardów |
| tester | pliku zadania, zadania N w `plan.md`, sekcji `## Zadanie N` w `standards.md` i plików IR z pola „Makiety” |
| implementer | tego co tester oraz sekcji `## Zadanie N` w `tests.md` |
| verifier | tego co implementer oraz sekcji `## Zadanie N` w `changes.md` |
