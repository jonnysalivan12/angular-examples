# Zmiany we wtyczce task-flow

Najnowsza wersja jest na górze. Nagłówek wersji ma datę wydania. Zainstalowaną wersję pokazuje `copilot plugin list`.

## 0.1.0

Pierwsza wersja.

- Agent `mortgage-orchestrator` prowadzi zadanie od gałęzi `feature/task-flow/<task>` do raportu, z jedną akceptacją planu przez człowieka.
- Agent `mortgage-implementation-loop` wykonuje jedno zadanie z planu: tester pisze testy, implementer pisze kod, a verifier sprawdza wynik, aż do zaliczenia albo limitu. Wywołuje go orchestrator albo człowiek. Po zaliczeniu orchestrator robi commit.
- Każdy krok zapisuje artefakt w `specs/<task>/`, a każdy agent na starcie sprawdza artefakty poprzednich kroków i przy braku zgłasza `BRAK:`.
- W trybie `frontend` orchestrator pobiera IR makiet z serwera MCP `figma-design-ir` z pluginu figma-design-ir. Bez tego pluginu zatrzymuje się z błędem i poleceniem instalacji.
- Hook blokuje `git push`, `git reset --hard`, `git clean` i zmiany pliku `settings.json`. Pilnuje, żeby podagenci działali po jednym i w trybie `sync`. Zatrzymuje pętlę po `maxFailedChecks` nieudanych sprawdzeniach.
