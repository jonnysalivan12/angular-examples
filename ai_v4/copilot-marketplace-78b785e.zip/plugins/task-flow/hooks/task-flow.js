#!/usr/bin/env node
'use strict';

// Hook wtyczki task-flow dla Copilot CLI.
//
// Copilot uruchamia skrypt przed każdym użyciem narzędzia (preToolUse), po
// udanym użyciu (postToolUse) i po nieudanym (postToolUseFailure). Nazwę
// zdarzenia skrypt dostaje jako pierwszy argument, a dane wywołania jako JSON na
// standardowym wejściu. Skrypt działa tylko na gałęziach feature/task-flow/<task>.
// Na innych gałęziach niczego nie blokuje.
//
// Przed użyciem narzędzia skrypt sprawdza cztery rzeczy:
//   1. Blokady ochronne: git push, git reset --hard, git clean i zapis do
//      .github/plugin/task-flow/settings.json.
//   2. Limit nieudanych sprawdzeń: gdy bieżące zadanie z planu wyczerpało limit,
//      skrypt odrzuca wywołanie testera i implementera oraz zapis plików poza
//      specs/<task>/.
//   3. Tryb podagenta: skrypt odrzuca wywołanie podagenta task-flow z polem mode
//      innym niż "sync". W trybie "background" narzędzie task wraca od razu, bez
//      odpowiedzi podagenta, więc blokada i licznik nie działają. Wywołanie bez
//      pola mode skrypt przepuszcza, bo schemat CLI nie podaje wartości domyślnej.
//   4. Jeden podagent naraz: skrypt odrzuca wywołanie podagenta task-flow, gdy
//      inny jeszcze pracuje. Blokada to plik tworzony atomowo (flaga wx).
//      Pętla implementacji (task-flow:mortgage-implementation-loop) sama wywołuje
//      testera, implementera i verifiera, więc blokada jej nie obejmuje.
//
// Po udanym albo nieudanym użyciu narzędzia task skrypt zwalnia blokadę. Po
// udanym liczy też odpowiedzi verifiera. Odpowiedź, której ostatnia niepusta
// linia nie jest dokładnie "RESULT: PASS", liczy się jako nieudane sprawdzenie.
// Pętla implementacji czyta wynik według tej samej reguły. Licznik jest osobny
// dla każdego zadania z planu. Numer zadania skrypt czyta z pola planTask
// w specs/<task>/state.json. Po osiągnięciu maxFailedChecks skrypt podmienia
// odpowiedź verifiera na polecenie zatrzymania pętli.
//
// Licznik, znacznik zatrzymania i blokada leżą w folderze tymczasowym systemu,
// w plikach nazwanych identyfikatorem sesji Copilota. Nowa sesja zaczyna od zera.
//
// Skrypt zawsze kończy się kodem 0, więc błąd wewnętrzny nie blokuje narzędzia.
// Z TASK_FLOW_DEBUG=1 skrypt dopisuje każde wywołanie do dziennika
// <folder tymczasowy>/task-flow/hooks.log.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const AGENT_PREFIX = 'task-flow:mortgage-';
const LOOP_AGENT = AGENT_PREFIX + 'implementation-loop';
const SYNC_MODE = 'sync';
const RESULT_PASS = 'RESULT: PASS';
const TASK_BRANCH = /^feature\/task-flow\/(.+)$/;
const CONFIG_PATH = /\.github\/+plugin\/+task-flow\/+settings\.json/i;
const READ_TOOLS = /^(view|read|glob|grep|search|ls)$/i;
const WRITE_TOOLS = /(edit|create|write|patch|str_replace)/i;
const STATE_DIR = path.join(os.tmpdir(), 'task-flow');

// Początek polecenia git razem z opcjami globalnymi, np. `git -C repo push`.
// Dzięki temu słowo "push" w opisie commita nie uruchamia blokady.
const GIT = String.raw`\bgit(?:\s+-[cC]\s+\S+|\s+--?[\w-]+(?:=\S+)?)*\s+`;
const GIT_PUSH = new RegExp(GIT + String.raw`push\b`, 'i');
const GIT_RESET_HARD = new RegExp(GIT + String.raw`reset\b.*--hard\b`, 'i');
const GIT_CLEAN = new RegExp(GIT + String.raw`clean\b`, 'i');
const READ_COMMAND = /^\s*(cat|type|get-content|gc)\b/i;

const event = process.argv[2];

function debug(entry) {
  if (process.env.TASK_FLOW_DEBUG !== '1') return;
  fs.mkdirSync(STATE_DIR, { recursive: true });
  const line = JSON.stringify({ t: new Date().toISOString(), event, ...entry });
  fs.appendFileSync(path.join(STATE_DIR, 'hooks.log'), line + '\n');
}

function parseMaybe(value) {
  if (typeof value !== 'string') return value;
  try { return JSON.parse(value); } catch (e) { return value; }
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^﻿/, ''));
  } catch (e) {
    return fallback;
  }
}

function deny(reason) {
  return { permissionDecision: 'deny', permissionDecisionReason: reason };
}

// Zwraca korzeń repozytorium i bieżącą gałąź albo null poza repozytorium git.
function gitInfo(cwd) {
  try {
    const output = execFileSync('git', ['rev-parse', '--show-toplevel', '--abbrev-ref', 'HEAD'], {
      cwd,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    const [root, branch] = output.trim().split(/\r?\n/);
    return { root, branch };
  } catch (e) {
    return null;
  }
}

// Zwraca powód odrzucenia polecenia powłoki albo null, gdy polecenie jest dozwolone.
// Polecenie złożone ze średników, && lub | skrypt sprawdza po kawałku.
function guardCommand(command) {
  for (const part of command.split(/[;&|\n]+/)) {
    if (GIT_PUSH.test(part)) return 'task-flow: git push is done by the human.';
    if (GIT_RESET_HARD.test(part)) return 'task-flow: git reset --hard is blocked on task-flow branches.';
    if (GIT_CLEAN.test(part)) return 'task-flow: git clean is blocked on task-flow branches.';
    if (CONFIG_PATH.test(part.replace(/\\/g, '/')) && !READ_COMMAND.test(part)) {
      return 'task-flow: the task-flow config is read-only for agents.';
    }
  }
  return null;
}

function decide(payload) {
  const git = gitInfo(payload.cwd || process.cwd());
  const branchMatch = git && TASK_BRANCH.exec(git.branch);
  if (!branchMatch) return null;

  const task = branchMatch[1];
  const tool = String(payload.toolName || '');
  const argsRaw = typeof payload.toolArgs === 'string'
    ? payload.toolArgs
    : String(JSON.stringify(payload.toolArgs === undefined ? null : payload.toolArgs));
  const parsedArgs = parseMaybe(payload.toolArgs);
  const args = parsedArgs && typeof parsedArgs === 'object' ? parsedArgs : {};
  const agentType = String(args.agent_type || '');
  const isFlowAgent = tool === 'task' && agentType.startsWith(AGENT_PREFIX);
  const usesLock = isFlowAgent && agentType !== LOOP_AGENT;
  const command = String(args.command || '');
  const filePath = String(args.path || args.file_path || args.filePath || '').replace(/\\/g, '/');

  const settings = readJson(path.join(git.root, '.github', 'plugin', 'task-flow', 'settings.json'), {});
  const limit = Number.isInteger(settings.maxFailedChecks) ? settings.maxFailedChecks : null;
  const planTask = readJson(path.join(git.root, 'specs', task, 'state.json'), {}).planTask ?? 0;
  const key = `${task}#${planTask}`;

  const sessionId = String(payload.sessionId || 'unknown').replace(/[^\w.-]/g, '_');
  fs.mkdirSync(STATE_DIR, { recursive: true });
  const stateFile = path.join(STATE_DIR, sessionId + '.json');
  const lockFile = path.join(STATE_DIR, sessionId + '.lock');
  const state = readJson(stateFile, { counts: {}, stopped: {} });
  let out = null;
  let lock = null;
  let lastLine;

  if (event === 'preToolUse') {
    // 1. Blokady ochronne.
    if (command) {
      const reason = guardCommand(command);
      if (reason) out = deny(reason);
    } else if (tool !== 'task' && !READ_TOOLS.test(tool)) {
      const argsText = argsRaw.replace(/\\\\/g, '/').replace(/\\/g, '/');
      if (CONFIG_PATH.test(argsText)) out = deny('task-flow: the task-flow config is read-only for agents.');
    }

    // 2. Limit nieudanych sprawdzeń dla bieżącego zadania z planu.
    if (!out && state.stopped[key]) {
      const inTaskFolder = ('/' + filePath).toLowerCase().includes(`/specs/${task.toLowerCase()}/`);
      if (isFlowAgent && /:mortgage-(tester|implementer)$/.test(agentType)) {
        out = deny(`task-flow: failed-check limit reached for plan task ${planTask}.`);
      } else if (WRITE_TOOLS.test(tool) && !inTaskFolder) {
        out = deny('task-flow: after the limit only files in the task folder may change.');
      }
    }

    // 3. Tryb podagenta.
    if (!out && isFlowAgent && args.mode !== undefined && args.mode !== SYNC_MODE) {
      out = deny(`task-flow: call task-flow subagents with mode "${SYNC_MODE}". Repeat this call with mode "${SYNC_MODE}".`);
    }

    // 4. Jeden podagent naraz.
    if (!out && usesLock) {
      try {
        const fd = fs.openSync(lockFile, 'wx');
        fs.writeSync(fd, argsRaw);
        fs.closeSync(fd);
        lock = 'acquired';
      } catch (e) {
        if (e.code !== 'EEXIST') throw e;
        lock = 'busy';
        out = deny('task-flow: another task-flow subagent is still running. Call subagents one at a time. '
          + 'If no subagent is running, the human starts a new Copilot session.');
      }
    }
  } else if ((event === 'postToolUse' || event === 'postToolUseFailure') && usesLock) {
    // Blokadę zwalnia tylko wywołanie, które ją założyło. Odrzucone wywołanie
    // ma inne argumenty, więc nie zwalnia cudzej blokady i nie trafia do licznika.
    // Nieudane wywołanie zwalnia blokadę, ale nie ma odpowiedzi do policzenia.
    try {
      if (fs.readFileSync(lockFile, 'utf8') === argsRaw) {
        fs.unlinkSync(lockFile);
        lock = 'released';
      } else {
        lock = 'not-ours';
      }
    } catch (e) {
      lock = 'none';
    }

    if (event === 'postToolUse' && agentType.endsWith(':mortgage-verifier') && limit !== null && lock === 'released') {
      const result = parseMaybe(payload.toolResult) || {};
      const lines = String(result.textResultForLlm || '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
      lastLine = lines[lines.length - 1] ?? '';
      if (lastLine !== RESULT_PASS) {
        state.counts[key] = (state.counts[key] || 0) + 1;
        if (state.counts[key] >= limit) {
          state.stopped[key] = true;
          out = {
            modifiedResult: {
              resultType: 'success',
              textResultForLlm: `LIMIT REACHED for plan task ${planTask} (${state.counts[key]}/${limit}). `
                + 'Stop the loop and end with "LOOP: STOPPED".',
            },
          };
        }
      }
    }
  }

  fs.writeFileSync(stateFile, JSON.stringify(state));
  debug({ sessionId, tool, agentType, branch: git.branch, planTask, lock, lastLine, count: state.counts[key] || 0, out });
  return out;
}

let raw = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => { raw += chunk; });
process.stdin.on('end', () => {
  let out = null;
  try {
    out = decide(JSON.parse(raw.replace(/^﻿/, '').trim() || '{}'));
  } catch (e) {
    try { debug({ error: String((e && e.stack) || e) }); } catch (e2) { /* dziennik jest opcjonalny */ }
  }
  if (out) process.stdout.write(JSON.stringify(out));
  process.exit(0);
});
