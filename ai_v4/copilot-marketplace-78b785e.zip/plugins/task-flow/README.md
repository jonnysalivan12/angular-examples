# Plugin task-flow

Plugin Copilot CLI. Prowadzi gotowe, przeanalizowane zadanie od nowej gałęzi do raportu.

## Szybki start

1. Zainstaluj plugin:

   ```bash
   copilot plugin install task-flow@mortgage-copilot-tools
   ```

   W trybie `frontend` zainstaluj też `figma-design-ir@mortgage-copilot-tools`. Przy pierwszej instalacji najpierw dodaj marketplace według [README pluginów](../../README.md).
2. Dodaj w repozytorium projektu plik `.github/plugin/task-flow/settings.json` (sekcja „Konfiguracja”).
3. W folderze repozytorium projektu uruchom orchestratora:

   ```bash
   copilot --agent task-flow:mortgage-orchestrator
   ```

4. Podaj identyfikator zgłoszenia z Jiry albo ścieżkę do pliku zadania w `specs/<task>/`.
5. Zaakceptuj plan albo odrzuć go z uwagami.

Po raporcie zrób push i merge request.

## Co robi plugin

1. Orchestrator tworzy gałąź `feature/task-flow/<task>` od `baseBranch` i zapisuje zadanie w `specs/<task>/`.
2. Analyst dzieli zadanie na małe, ponumerowane zadania planu.
3. Akceptujesz plan albo odrzucasz go z uwagami.
4. Standards-scout wybiera sekcje standardów dla zadań planu.
5. Pętla implementacji wywołuje dla każdego zadania planu trzech agentów, każdego w świeżym kontekście:
   - tester pisze testy przed kodem według standardów repozytorium,
   - implementer pisze kod, który przechodzi te testy,
   - verifier uruchamia polecenia sprawdzające.

   Po zaliczeniu orchestrator robi commit.
6. Orchestrator pisze raport.

- Każdy krok zapisuje artefakt, a każdy agent na starcie sprawdza artefakty poprzednich kroków.
- Agenci pilnują tylko przepływu i nie wiedzą nic o repozytorium, w którym pracują. Tryb repozytorium, standardy, limit nieudanych sprawdzeń, gałąź bazowa i polecenia sprawdzające pochodzą z konfiguracji.

Szczegóły kroków i plików zadania: [docs/flow.md](docs/flow.md).

## Konfiguracja

Każde repozytorium projektu ma własny plik `.github/plugin/task-flow/settings.json`. Wartości w przykładzie są pokazowe:

```json
{
  "mode": "frontend",
  "standards": "docs/standards/00-meta.md",
  "maxFailedChecks": 2,
  "baseBranch": "develop",
  "verifyCommands": ["npm test"]
}
```

| Klucz | Znaczenie | Kto czyta |
|---|---|---|
| `mode` | Tryb repozytorium: `frontend` albo `backend`. Z zadania trafia do planu tylko część dla tej warstwy. W trybie `backend` orchestrator nie pobiera makiet. | orchestrator |
| `standards` | Plik wejściowy standardów repozytorium. | standards-scout |
| `maxFailedChecks` | Liczba nieudanych sprawdzeń jednego zadania z planu, po której pętla staje. | hook |
| `baseBranch` | Gałąź, od której powstaje gałąź zadania. | orchestrator |
| `verifyCommands` | Polecenia sprawdzające. Działają lokalnie, bez skutków ubocznych i nigdy nie uruchamiają migracji. | implementer, verifier |

Plik musi być na gałęzi bazowej, bo gałąź zadania powstaje z niej.

## Co trzeba mieć

1. Copilot CLI.
2. Node.js i git na każdej maszynie. Hook to skrypt Node bez zależności.
3. Serwer MCP Jiry o nazwie `jira`, wpisany w `.mcp.json` repozytorium projektu. Bez niego podajesz orchestratorowi plik zadania zamiast identyfikatora zgłoszenia.
4. W trybie `frontend`:
   - plugin `figma-design-ir` z serwerem MCP Figmy i plikami projektu (README tego pluginu, sekcja „Konfiguracja projektu”),
   - osobisty token Figmy w zmiennej środowiskowej `FIGMA_API_KEY`, z zakresami `file_content:read` i `file_metadata:read`.

Gdy zadanie ma linki do Figmy, a serwera `figma-design-ir` nie ma, orchestrator zatrzymuje się z błędem i poleceniem instalacji pluginu.

## Gdy praca stanie

| Co widzisz | Co zrobić |
|---|---|
| Hook odmawia z komunikatem „another task-flow subagent is still running”, a żaden podagent nie pracuje. | Zacznij nową sesję Copilota. Orchestrator wznowi zadanie z `state.json`. |
| Pętla skończyła się wynikiem `LOOP: STOPPED`, bo minął limit nieudanych sprawdzeń. | Wznów zadanie w nowej sesji Copilota, bo licznik działa w jednej sesji. Orchestrator najpierw pokaże ostatnie uwagi verifiera i zapyta, co zmienić. |

## Dokumentacja

- [docs/flow.md](docs/flow.md): kroki przepływu, folder zadania, etapy i warunek startu agentów.
- [docs/hook.md](docs/hook.md): blokady hooka, limit nieudanych sprawdzeń i dziennik.
- [docs/agents.md](docs/agents.md): agenci, kroki bez orchestratora i uruchomienie bez instalacji.
- [README pluginów](../../README.md): aktualizacja i wydanie nowej wersji.
