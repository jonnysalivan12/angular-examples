#!/usr/bin/env node
/*
 * Porównuje dwie wersje tej samej ramy i wypisuje różnice między ich design_ir.
 *
 * Każde z dwóch źródeł to plik IR zapisany przez extract-design-ir.js albo link do ramy
 * w Figmie. Pierwsze źródło to stan wcześniejszy, drugie późniejszy.
 *
 * Kroki (kroki 1–4 i złożenie strony wykonuje lib/frame-comparison/frame-comparison.js):
 *   1. Dla pliku IR czyta design_ir i sprawdza, czy powstał w bieżącej wersji skryptów.
 *   2. Dla linku buduje design_ir z Figmy tak jak extract-design-ir.js. Link z parametrem
 *      version-id wskazuje starszą wersję pliku.
 *   3. Sprawdza, czy oba źródła opisują tę samą ramę.
 *   4. Porównuje elementy po identyfikatorze warstwy (lib/design-ir/ir-diff.js) i wypisuje
 *      wynik jako JSON na stdout albo do pliku z --out.
 *   5. Z opcją --html pobiera z Figmy obraz i drzewo warstw obu wersji ramy i zapisuje stronę
 *      z obrysami różnic na obrazach (lib/diff-report).
 *
 * Komunikaty trafiają na stderr (lib/logging/script-logger.js).
 */

import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { settings } from './settings.js';
import { EXIT_CODE, ScriptError, readCliArguments, runScript } from './lib/cli/script-runner.js';
import { readFigmaToken } from './lib/figma-api/figma-rest-client.js';
import { createLinkIrLoader } from './lib/ir-sources/figma-link-source.js';
import { cssVariableMapPathOf } from './lib/css-variables/css-variable-map.js';
import { buildFrameComparisonPage, compareFrameSources } from './lib/frame-comparison/frame-comparison.js';

const JSON_INDENT = 2;
const SOURCE_COUNT = 2;
const HELP_HINT = 'Opis opcji: node compare-design-ir.js --help.';

const CLI_OPTIONS = {
  out: { type: 'string' },
  html: { type: 'string' },
  cache: { type: 'string' },
  'css-variable-map': { type: 'string' },
  variables: { type: 'string' },
  'component-map': { type: 'string' },
  'local-component-map': { type: 'string' },
  'no-variables': { type: 'boolean', default: false },
  refresh: { type: 'boolean', default: false },
  help: { type: 'boolean', short: 'h', default: false },
};

const USAGE = `Użycie: node compare-design-ir.js <źródło-przed> <źródło-po> [opcje]

Porównuje dwie wersje tej samej ramy. Źródłem jest plik IR zapisany przez extract-design-ir.js
albo link do ramy w Figmie (z node-id). Link z parametrem version-id wskazuje starszą wersję
pliku, a bez niego wersję bieżącą. Możliwe pary: plik i plik, plik i link, link i link.

Wynik to JSON z elementami dodanymi (added), usuniętymi (removed), przeniesionymi (moved)
i zmienionymi (changed). Skrypt łączy warstwy po identyfikatorze z Figmy (node_id).

Opcje:
  --out <plik>               zapisz wynik do pliku zamiast wypisywać go na stdout
  --html <plik>              zapisz stronę HTML: obrazy obu wersji ramy z obrysami różnic
  --cache <folder>           folder na kopie odpowiedzi Figmy (domyślnie modules/figma/.cache)
  --css-variable-map <plik>  mapa zmiennych CSS dla źródeł podanych linkiem
                             (domyślnie modules/figma/config/css-variable-map.json, gdy istnieje)
  --variables <plik>         plik nazw zmiennych Figmy (domyślnie modules/figma/config/variables.json)
  --component-map <plik>     mapa komponentów DS dla źródeł podanych linkiem
                             (domyślnie modules/figma/config/component-map.json)
  --local-component-map <plik>
                             mapa komponentów z pliku makiet (spoza DS) na komponenty
                             w repozytorium (bez opcji albo bez pliku: brak odpowiedników)
  --no-variables             buduj IR z linku bez nazw zmiennych
  --refresh                  pobierz bieżącą wersję ramy bez sprawdzania wersji pliku
  -h, --help                 pokaż ten opis

Plik IR musi pochodzić z bieżącej wersji skryptów (${settings.scriptVersion}). Oba źródła powinny powstać
z tą samą mapą zmiennych CSS, tym samym plikiem zmiennych i tymi samymi mapami komponentów, inaczej
wynik pokaże różnice, których nie ma w makiecie.

Z opcją --out albo --html skrypt wypisuje na stdout ścieżki zapisanych plików zamiast wyniku.
Strona HTML pokazuje obraz i położenie warstw z Figmy, z wersji pliku zapisanej w każdym źródle.

Token: źródło podane linkiem i opcja --html wymagają zmiennej środowiskowej FIGMA_API_KEY.`;

/** Zwraca token Figmy. Kończy skrypt błędem, gdy zmienna środowiskowa z tokenem jest pusta. */
function requireFigmaToken() {
  const token = readFigmaToken();
  if (!token) {
    throw new ScriptError('Brak tokenu Figmy. Ustaw zmienną środowiskową FIGMA_API_KEY i uruchom skrypt ponownie.');
  }
  return token;
}

/** Porównuje dwa źródła i wypisuje różnice. */
async function main() {
  const { values: options, positionals: sources } = readCliArguments(CLI_OPTIONS, HELP_HINT);
  if (options.help) {
    process.stdout.write(`${USAGE}\n`);
    return;
  }
  if (sources.length !== SOURCE_COUNT) {
    throw new ScriptError(`Podaj dokładnie dwa źródła: stan wcześniejszy i późniejszy. ${HELP_HINT}`, EXIT_CODE.usage);
  }
  const cacheDir = resolve(options.cache ?? settings.cacheDir);
  const loadIrFromLink = createLinkIrLoader({
    requireToken: requireFigmaToken,
    variablesPath: options['no-variables'] ? null : resolve(options.variables ?? settings.variablesPath),
    cssVariableMapPath: cssVariableMapPathOf(options['css-variable-map'], settings.cssVariableMapPath),
    componentMapPath: resolve(options['component-map'] ?? settings.componentMapPath),
    localComponentMapPath: options['local-component-map'] ? resolve(options['local-component-map']) : null,
    cacheDir,
    scriptVersion: settings.scriptVersion,
    skipVersionCheck: options.refresh,
  });
  const { designIrDiff, designIrs, differences } = await compareFrameSources({ sources, loadIrFromLink, scriptVersion: settings.scriptVersion });

  const diffJson = `${JSON.stringify({ design_ir_diff: designIrDiff }, null, JSON_INDENT)}\n`;
  const filesToWrite = [];
  if (options.out) {
    filesToWrite.push({ filePath: resolve(options.out), content: diffJson });
  }
  if (options.html) {
    const reportPage = await buildFrameComparisonPage({
      sources,
      designIrs,
      differences,
      scriptVersion: settings.scriptVersion,
      requireToken: requireFigmaToken,
      cacheDir,
    });
    filesToWrite.push({ filePath: resolve(options.html), content: reportPage });
  }
  if (filesToWrite.length === 0) {
    process.stdout.write(diffJson);
    return;
  }
  for (const { filePath, content } of filesToWrite) {
    writeFileSync(filePath, content, 'utf8');
    process.stdout.write(`${filePath}\n`);
  }
}

runScript(main);
