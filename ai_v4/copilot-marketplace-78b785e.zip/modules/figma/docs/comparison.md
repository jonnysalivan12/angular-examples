# Porównanie wersji ramy

`compare-design-ir.js` porównuje dwie wersje tej samej ramy. Narzędzie `compare_frames` serwera MCP robi to samo.

## Uruchomienie

```bash
node compare-design-ir.js <źródło-przed> <źródło-po>
```

Źródło to jedno z dwóch:

- plik IR zapisany przez `extract-design-ir.js`;
- link do ramy w Figmie. Link bez `version-id` wskazuje bieżącą wersję pliku, a z `version-id` starszą.

Para może być dowolna: plik i plik, plik i link, link i link. Źródło podane linkiem wymaga tokenu `FIGMA_API_KEY`.

## Warunki poprawnego wyniku

1. Oba źródła opisują tę samą ramę.
   - Skrypt łączy warstwy po identyfikatorze z Figmy (`node_id`).
   - Kopia ramy ma w Figmie inne identyfikatory. Dwie różne ramy kończą skrypt kodem 2.
2. Plik IR pochodzi z bieżącej wersji skryptów.
   - Przy innej wersji skrypt kończy pracę kodem 1.
   - Komunikat podaje link, z którego skrypt zbuduje IR tej samej wersji makiety od nowa.
3. Oba źródła powstały z tą samą mapą zmiennych CSS, tym samym plikiem zmiennych i tą samą mapą komponentów.
   - Źródło podane linkiem skrypt buduje z opcjami `--css-variable-map`, `--variables` i `--component-map` podanymi przy porównaniu.

Warstwa usunięta i narysowana od nowa ma nowy identyfikator. Dlatego trafia do `removed` i do `added`.

## Wynik

Wynik to JSON na stdout. Opcja `--out <plik>` zapisuje go w pliku.

| Pole | Zawartość |
|---|---|
| `from`, `to` | Podane źródła, wersja pliku Figmy i rozmiar ramy. |
| `summary` | Liczba elementów w każdej grupie. |
| `added` | Elementy tylko w nowszym źródle, z pełnym opisem w kształcie IR (`content`). |
| `removed` | Elementy tylko w starszym źródle. |
| `moved` | Warstwy z innym rodzicem albo z inną kolejnością wśród rodzeństwa, z położeniem przed i po. |
| `changed` | Elementy z innymi wartościami pól. Każda zmiana ma nazwę pola (np. `styles.gap`), wartość `before` i wartość `after`. |

Dodane albo usunięte poddrzewo to jeden wpis dla jego korzenia.

Elementem jest warstwa z `layout` albo definicja komponentu lokalnego z `components_to_build` razem z warstwami jej wnętrza. Zmiana nazwanego stylu tekstu to zmiana pola `typography` w każdej warstwie z tym stylem.

Pytań z `open_questions` skrypt nie porównuje.

## Strona HTML z różnicami

```bash
node compare-design-ir.js <źródło-przed> <źródło-po> --html porownanie.html
```

Strona pokazuje obraz ramy przed i po. Każda różnica ma obrys na obrazie i pozycję na liście z wartościami przed i po.

- Kliknięcie obrysu albo pozycji zaznacza obie części.
- Filtry nad listą ukrywają wybrany rodzaj różnic albo wszystkie obrysy.

| Różnica | Gdzie jest obrys |
|---|---|
| Warstwa dodana | tylko na obrazie „po” |
| Warstwa usunięta | tylko na obrazie „przed” |
| Warstwa przeniesiona albo zmieniona | na obu obrazach |
| Definicja komponentu lokalnego | na każdym wystąpieniu komponentu |

Gdy obrazy obu wersji są identyczne, strona podaje, że różnice nie zmieniają wyglądu ramy. Tak jest na przykład po zamianie tokenu na inny z tą samą wartością.

### Uwagi

- `--html` wymaga tokenu także dla dwóch plików IR. Skrypt pobiera z Figmy obraz ramy (`GET /images/:key`) i położenie warstw (`GET /files/:key/nodes`).
- Obraz i położenie warstw pochodzą z wersji pliku zapisanej w każdym źródle (`file_version`).
- Strona jest jednym plikiem z osadzonymi obrazami.
- Kopie obrazów (`<klucz>__<node-id>@<wersja>@2x.png`) trafiają do `.cache/` i się nie przedawniają.
- Z opcją `--out` albo `--html` skrypt wypisuje na stdout ścieżki zapisanych plików zamiast wyniku JSON.
