# IR ramy

IR ramy (`design_ir`) to plik JSON z opisem jednej ramy z Figmy. Tworzą go `extract-design-ir.js` i narzędzie `frame_to_ir` serwera MCP.

## Pola

| Pole | Zawartość |
|---|---|
| `script_version` | Wersja skryptów, które utworzyły IR. |
| `source_frames` | Klucz pliku, identyfikator ramy, wersja pliku Figmy (`file_version`) i rozmiar ramy w makiecie (`width`, `height`). |
| `layout` | Rama rozwinięta warstwa po warstwie, z układem, rozmiarem, tekstem i mapą `styles`. |
| `components_to_build` | Definicje komponentów lokalnych pliku Figmy bez odpowiednika w repozytorium. |
| `open_questions` | Luki makiety, po jednym pytaniu (`topic`, `question`) na lukę. |

Rozmiar ramy w `source_frames` mówi, w jakiej szerokości projektant narysował ramę. Tak jest także wtedy, gdy rama wypełnia rodzica.

## layout

- Każda warstwa ma identyfikator z Figmy (`node_id`). Identyfikator wskazuje warstwę jednoznacznie, bo nazwy warstw się powtarzają.
- Kontener z auto layoutem ma zawsze `justify` i `align`. Tak jest także przy domyślnym wyrównaniu do początku osi (`start`).
- Tekst, który pokazuje właściwość komponentu, ma jej nazwę w `input_binding`.
- Każdy tekst ma wartości czcionki w bloku `typography` warstwy. Tekst z nazwanym stylem ma też nazwę stylu w `styles.typography`, a wartości stylu powtarzają się przy każdym takim tekście.

Instancja komponentu jest referencją. Ma trzy pola:

1. `ref`: nazwa komponentu.
2. `repo_component`: odpowiednik w repozytorium albo null, gdy odpowiednika nie ma. Odpowiednik komponentu z DS pochodzi z mapy komponentów DS, a komponentu lokalnego z mapy komponentów lokalnych. Obie mapy opisuje [config.md](config.md).
3. `inputs`: wartości wejściowe.

Wartości wejściowe instancji to jej właściwości z nazwami z Figmy. Pod nazwą warstwy instancji zagnieżdżonej są właściwości tej instancji. Trafiają tam, gdy komponent wystawia ją na zewnątrz albo gdy projektant zmienił w niej właściwości, np. wybraną wartość pola wyboru.

## components_to_build

- Definicja zawiera właściwości, style korzenia każdego użytego wariantu i strukturę wnętrza.
- Struktura ma ten sam kształt co `layout`. Każda warstwa ma nazwę i własne style, a komponent zagnieżdżony jest referencją z wartościami wejściowymi.
- Wnętrze opisuje największa instancja komponentu w ramie. Dlatego `node_id` warstw wnętrza to identyfikatory warstw tej instancji, w postaci `I<instancja>;<warstwa>`.
- Komponent lokalny jest opisany w całości w `components_to_build`, razem z tekstami wewnątrz.

## open_questions

- Ta sama wartość bez zmiennej w kilku warstwach daje jedno pytanie z listą warstw.
- Gdy któraś luka w IR nie ma pytania w `open_questions`, skrypt wypisuje ostrzeżenie na stderr.

Zmienna może obejmować tylko część boków odstępu wewnętrznego albo część rogów. Wtedy pozostałe boki i rogi z wartością większą od zera mają w `styles` własny wpis z surową wartością, np. `padding-left`.

## Cienie i efekty

- Styl cienia z Figmy jest tokenem, tak jak zmienna. Warstwa ma go w `styles.elevation`.
- Gdy mapa zmiennych CSS ma wpis dla nazwy stylu, wpisem jest zmienna CSS.
- Bez wpisu w mapie zostaje nazwa stylu z wartością `box-shadow`: `{ "resolved": false, "token": …, "value": … }`. Do `open_questions` trafia pytanie o wpis.
- Rozmycia warstwy zostają w `visual.effects`.

## Czego IR nie opisuje

- Warstw ukrytych.
- Wnętrza instancji komponentów z biblioteki DS. Wnętrze należy do komponentu DS. Wszystko, co makieta przekazuje takiemu komponentowi, jest w `inputs`.
