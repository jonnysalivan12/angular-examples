import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/*
 * Ustawienia modułu figma dla skryptów uruchomieniowych: wersja skryptów i domyślne miejsca
 * plików. Pliki konfiguracji (plik zmiennych, mapa komponentów i mapa zmiennych CSS) leżą
 * w folderze config/ i są plikami domyślnymi pluginu figma-design-ir. Folder może ich nie mieć.
 * Opcje wywołania --out, --cache, --variables, --component-map i --css-variable-map zmieniają
 * miejsca plików na jedno uruchomienie.
 */

const MODULE_DIR = dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = join(MODULE_DIR, 'config');

export const settings = Object.freeze({
  /**
   * Wersja skryptów z package.json. Trafia do każdego IR (`script_version`), a porównanie
   * przyjmuje tylko IR z tej samej wersji. Podnieś ją przy każdej zmianie kształtu IR.
   */
  scriptVersion: JSON.parse(readFileSync(join(MODULE_DIR, 'package.json'), 'utf8')).version,
  /** Folder na pliki IR skryptów. Serwer MCP bierze folder wyników z ustawień projektu. */
  outputDir: join(MODULE_DIR, 'ir'),
  /** Folder na kopie odpowiedzi Figmy. */
  cacheDir: join(MODULE_DIR, '.cache'),
  /** Plik nazw zmiennych Figmy. */
  variablesPath: join(CONFIG_DIR, 'variables.json'),
  /** Mapa komponentów: nazwa komponentu z Figmy → komponent w repozytorium. */
  componentMapPath: join(CONFIG_DIR, 'component-map.json'),
  /** Mapa zmiennych CSS: nazwa tokenu Figmy → zmienna CSS. Skrypty używają jej, gdy plik istnieje. */
  cssVariableMapPath: join(CONFIG_DIR, 'css-variable-map.json'),
});
