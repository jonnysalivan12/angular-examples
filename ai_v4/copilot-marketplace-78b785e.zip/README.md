# Pluginy zespołu

Pluginy Copilota z marketplace `mortgage-copilot-tools`. Listę pluginów i ich wersje zawiera plik `marketplace.json`.

## Pluginy

| Plugin | Dla kogo | Co robi | Wymaga |
|---|---|---|---|
| [figma-design-ir](plugins/figma-design-ir/README.md) | wszyscy | Serwer MCP Figmy z plikami konfiguracji makiet. Działa z pluginami poniżej i ze zwykłym agentem Copilota. | — |
| [figma-designer](plugins/figma-designer/README.md) | projektanci | Sprawdza ramę w Figmie i daje prompt naprawy dla agenta Figmy. | figma-design-ir |
| [figma-analyst](plugins/figma-analyst/README.md) | analitycy | Opisuje ekran z ramy i zmiany między wersjami ramy. | figma-design-ir |
| [task-flow](plugins/task-flow/README.md) | programiści | Prowadzi zadanie od nowej gałęzi do raportu. | figma-design-ir w trybie `frontend` |

## Instalacja

1. Przy pierwszej instalacji dodaj marketplace. Podaj adres SSH repozytorium, ten sam co do `git clone`:

   ```bash
   copilot plugin marketplace add git@<serwer>:<ścieżka repozytorium>.git
   ```

2. Zainstaluj plugin, np.:

   ```bash
   copilot plugin install figma-design-ir@mortgage-copilot-tools
   ```

Copilot pobiera marketplace poleceniem `git clone`, więc potrzebujesz dostępu do repozytorium przez SSH.

## Nowa wersja

```bash
copilot plugin update --all
```

- `copilot plugin list` pokazuje zainstalowaną wersję.
- Zmiany w każdej wersji opisuje `CHANGELOG.md` w folderze pluginu.
- Po instalacji `CHANGELOG.md` jest też w `~/.copilot/installed-plugins/mortgage-copilot-tools/<plugin>/`.

## Plugin zainstalowany wcześniej z folderu

1. Odinstaluj go:

   ```bash
   copilot plugin uninstall <plugin>
   ```

2. Zainstaluj go z marketplace (sekcja „Instalacja”).

Zachowaj tę kolejność. Gdy są obie instalacje, `copilot plugin uninstall` usuwa instalację z marketplace, a zostawia tę z folderu.

## VS Code

Ta sekcja dotyczy pluginów Figmy. Plugin task-flow jest pluginem Copilot CLI.

1. Włącz ustawienie `chat.plugins.enabled`.
2. W ustawieniu `chat.pluginLocations` dodaj wpis `"<folder repozytorium>/plugins/figma-design-ir": true`.
3. Dodaj taki sam wpis dla pluginu, którego używasz: `figma-designer` albo `figma-analyst`.

## Wydanie nowej wersji pluginu

Ta sekcja jest dla opiekunów pluginów.

1. Tylko figma-design-ir: po zmianie serwera albo plików w `modules/figma/config/` skopiuj serwer do pluginu poleceniem `node scripts/build-plugins.js`. Szczegóły: [modules/figma/README.md](modules/figma/README.md), sekcja „Pluginy Copilota”.
2. Podnieś `version` w `plugin.json` pluginu i w jego wpisie w `marketplace.json`.
3. Dopisz na górze `CHANGELOG.md` pluginu sekcję `## <wersja> (RRRR-MM-DD)` z datą wydania i z tym, co zauważy użytkownik.
4. Zatwierdź zmiany i wypchnij je do zdalnego repozytorium.
5. Użytkownicy pobierają nową wersję poleceniem `copilot plugin update --all`.

## Układ repozytorium

| Folder albo plik | Co zawiera |
|---|---|
| `marketplace.json` | Marketplace `mortgage-copilot-tools`: nazwa, opis, wersja i folder każdego pluginu. |
| `plugins/<plugin>/` | Plugin Copilota. Przy instalacji Copilot kopiuje tylko ten folder. |
| `modules/figma/` | Moduł źródłowy serwera MCP Figmy: skrypty, testy i dokumentacja. Opis: [modules/figma/README.md](modules/figma/README.md). |
| `scripts/build-plugins.js` | Kopiuje serwer z `modules/figma/` do `plugins/figma-design-ir/server/`. |
| `package.json` | Polecenia `npm run build` (kopia serwera) i `npm test` (testy modułu figma). |
