# Konfiguracja pluginu figma-design-ir

## Pliki projektu

Repozytorium projektu musi mieć folder `.github/plugin/figma-design-ir/` z plikiem `settings.json`. Pozostałe pliki w tym folderze zastępują pliki domyślne pluginu.

| Plik w projekcie | Co zawiera | Bez tego pliku |
|---|---|---|
| `settings.json` | Pole `outputDir`: folder na wszystkie pliki wyników, czyli IR, obrazy ram, wyniki audytu, prompty naprawy i strony porównania. Opcjonalne pole `localComponentMap`: plik mapy komponentów lokalnych. Ścieżki względne serwer liczy od głównego folderu repozytorium. | Każde narzędzie kończy pracę błędem. |
| `variables.json` | Nazwy zmiennych z biblioteki Figmy. Dają nazwy tokenów w IR i podpowiedzi zmiennych w audycie. | Plik domyślny pluginu, a bez niego błąd. |
| `component-map.json` | Mapa komponentów z biblioteki DS na komponenty w kodzie. | Plik domyślny pluginu, a bez niego błąd. |
| `css-variable-map.json` | Mapa tokenów Figmy na zmienne CSS w kodzie. | Plik domyślny pluginu, a bez niego błąd. |

Format plików i sposób przygotowania pliku zmiennych opisuje [figma/docs/config.md](../../../../figma/docs/config.md) w repozytorium z pluginem.

## Mapa komponentów lokalnych

Komponenty utworzone w pliku z makietami, spoza biblioteki DS, mają osobną mapę. Ma ten sam kształt co `component-map.json`.

- Plik wskazuje pole `localComponentMap` w `settings.json`. Plugin nie ma pliku domyślnego.
- Bez pola albo bez pliku komponenty lokalne nie mają odpowiedników. Trafiają do `open_questions` i do `components_to_build`.
- Plik, który istnieje, musi mieć poprawny kształt. Inaczej narzędzie kończy pracę błędem.
- Komponent z DS szuka odpowiednika tylko w `component-map.json`, a komponent lokalny tylko w mapie komponentów lokalnych.

## Które narzędzie potrzebuje których plików

| Narzędzie | Potrzebne pliki |
|---|---|
| `frame_to_ir` | `settings.json`, `variables.json`, `component-map.json`, `css-variable-map.json` |
| `audit_frame` | `settings.json`, `variables.json`, `component-map.json` |
| `compare_frames` | `settings.json`, a gdy jednym ze źródeł jest link, także trzy pliki jak `frame_to_ir` |
| `get_frame_image` | `settings.json` |

Komunikat błędu podaje ścieżkę pliku, który trzeba dodać w repozytorium projektu.

## Jak serwer wybiera pliki

1. Serwer pluginu działa w folderze pluginu. Folder roboczy sesji podaje mu agent w argumencie `project_dir`, który każde narzędzie wymaga.
2. Serwer szuka folderu `.github/plugin/figma-design-ir/` od folderu roboczego w górę, aż do głównego folderu repozytorium.
3. Serwer czyta pliki przy każdym wywołaniu narzędzia, więc zmiana działa od razu.

Gdy agent poda w `output_dir` ścieżkę bezwzględną, pliki wyników trafiają tam zamiast do `outputDir`. Tak robi orchestrator z task-flow, który zapisuje IR w folderze zadania.

## Pliki domyślne

Pliki domyślne leżą w `server/config/` pluginu. Pochodzą z folderu `figma/config/` w repozytorium z pluginem. Każdego z nich może nie być. Wtedy każde repozytorium projektu musi podać własny plik.

Po zmianie plików domyślnych wydaj nową wersję pluginu według [README pluginów](../../README.md), sekcja „Wydanie nowej wersji pluginu”.

## Serwer o tej samej nazwie

Gdy plik `.mcp.json` w repozytorium projektu albo konfiguracja użytkownika ma serwer o nazwie `figma-design-ir`, Copilot CLI uruchamia serwer pluginu zamiast niego.

## Pluginy, które korzystają z serwera

| Plugin | Kiedy potrzebuje serwera |
|---|---|
| `figma-designer` | zawsze |
| `figma-analyst` | zawsze |
| `task-flow` | w trybie `frontend`, gdy zadanie ma linki do Figmy |
