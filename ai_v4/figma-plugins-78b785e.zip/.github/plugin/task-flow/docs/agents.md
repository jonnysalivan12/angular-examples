# Agenci task-flow

## Kto kogo wywołuje

- Orchestrator ma w nagłówku `disable-model-invocation: true`, więc inny agent nie uruchomi go jako podagenta.
- Pętlę implementacji wywołuje orchestrator albo człowiek. Testera, implementera i verifiera wywołuje pętla.
- Wszyscy agenci poza orchestratorem mają `user-invocable: true`, więc możesz ich uruchomić ręcznie.
- Agenci nie mają pola `model`, więc model dobiera Copilot.
- Orchestrator ma w narzędziach `jira/*`.

## Kroki bez orchestratora

Każdy krok uruchamiasz w nowej sesji, np. `copilot --agent task-flow:mortgage-analyst`. Kolejność:

1. `mortgage-analyst`: podaj tryb, plik zadania, folder `specs/<task>/design/` i ścieżkę `plan.md`. Przeczytaj plan przed następnym krokiem.
2. `mortgage-standards-scout`: podaj ścieżki `plan.md` i `standards.md`.
3. `mortgage-implementation-loop` dla każdego zadania N z planu: podaj numer N i ścieżki pliku zadania, `plan.md`, `standards.md`, `design/`, `checks.md`, `tests.md` i `changes.md`. Pętla sama wywołuje testera, implementera i verifiera.
4. Po `LOOP: DONE` zatwierdź zmiany z opisem z linii `COMMIT:` w sekcji zadania N w `changes.md`. Po `LOOP: NEEDS-HUMAN` albo `LOOP: STOPPED` uruchom pętlę ponownie w nowej sesji i podaj swoją decyzję.

Gałąź, plik zadania, pliki IR makiet i commity przygotowujesz sam. Żaden podagent nie ma narzędzi Figmy.

Hook przy pętli:

- Pętla wywołuje podagentów przez narzędzie `task`, więc hook pilnuje limitu, kolejności i trybu `sync` tak samo jak przy orchestratorze.
- Bez `state.json` hook liczy próby dla całej sesji, dlatego każde zadanie planu uruchamiaj w nowej sesji.
- Testera, implementera i verifiera możesz też uruchomić pojedynczo, ale wtedy hook pilnuje tylko blokad ochronnych.

## Uruchomienie bez instalacji

Copilot uruchomiony z `--plugin-dir` czyta folder pluginu bez instalacji:

```bash
copilot --plugin-dir <ścieżka>/.github/plugin/task-flow --plugin-dir <ścieżka>/.github/plugin/figma-design-ir --agent task-flow:mortgage-orchestrator
```

Drugi `--plugin-dir` jest potrzebny tylko w trybie `frontend`.
