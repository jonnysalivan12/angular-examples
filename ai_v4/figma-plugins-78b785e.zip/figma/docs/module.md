# Budowa modułu

Testy, komunikaty, kopie odpowiedzi Figmy, wersja skryptów i układ folderów.

## Testy

```bash
npm test
```

Uruchom w folderze `figma/`.

## Komunikaty i kody wyjścia

- Komunikaty trafiają na stderr z etykietą `[info]`, `[uwaga]` albo `[błąd]`.
- Komunikat błędu mówi, co się nie udało i co zrobić.
- Błąd kończy skrypt kodem 1.
- Złe wywołanie, np. brak linku albo nieznana opcja, kończy skrypt kodem 2.

## Kopie odpowiedzi Figmy

Odpowiedzi Figmy dla ram i komponentów trafiają jako kopie do `.cache/`. Folder `.cache/` jest ignorowany przez git.

Kopie mają znaczenie przez limity Figmy. Zapytania o ramy (`/nodes`) należą do grupy Tier 1, w której miejsca View i Collab mają limit miesięczny. Szczegóły: [limity REST API Figmy](https://developers.figma.com/docs/rest-api/rate-limits/).

1. Przy każdym uruchomieniu skrypt sprawdza bieżącą wersję pliku (`GET /files/:key/meta`).
2. Kopia jest używana tylko wtedy, gdy wersja pliku się nie zmieniła. Każda zmiana w pliku Figmy, także poza pobieraną ramą, oznacza ponowne pobranie.
3. Kopię, która nie jest poprawnym plikiem JSON, skrypt pobiera ponownie i ostrzega o tym na stderr.
4. Opcja `--refresh` pobiera ramę i komponenty bez sprawdzania wersji.
5. Rama ze starszej wersji pliku ma osobną kopię `<klucz>__<node-id>@<wersja>.json`, która się nie przedawnia.

## Wersja skryptów

- Każdy IR ma pole `script_version` z wersją skryptów, które go utworzyły.
- Wersja pochodzi z pola `version` w `package.json`.
- Podnieś ją przy każdej zmianie kształtu IR. IR z dwóch różnych wersji nie da się wiarygodnie porównać.

## Układ folderów

```text
figma/
├── extract-design-ir.js    plik wejściowy (main w package.json): tworzy IR ramy
├── compare-design-ir.js    plik wejściowy: porównuje dwie wersje tej samej ramy
├── audit-design.js         plik wejściowy: audyt ramy i prompt naprawy dla agenta Figmy
├── mcp-server.js           plik wejściowy: serwer MCP z narzędziami frame_to_ir, compare_frames, get_frame_image i audit_frame
├── build-plugins.js        plik wejściowy: kopiuje serwer MCP do pluginu figma-design-ir
├── settings.js             ustawienia: wersja skryptów, domyślne foldery i pliki z config/
├── package.json            wersja skryptów, typ modułu i polecenie npm test
├── config/                 pliki domyślne; każdego z nich może nie być
│   ├── variables.json      plik nazw zmiennych z REST API albo z pluginu
│   ├── component-map.json  mapa komponentów z biblioteki DS na komponenty w repozytorium
│   └── css-variable-map.json  mapa tokenów Figmy na zmienne CSS (opcjonalna)
├── lib/                    sub-moduły, testy jednostkowe (*.test.js) obok testowanych plików
│   ├── cli/                przebieg skryptu: opcje wywołania, kody wyjścia, błąd kończący
│   ├── figma-api/          klient REST API Figmy z kopiami odpowiedzi w .cache/
│   ├── figma-variables/    odczyt, zapis i sprawdzenie kształtu pliku zmiennych
│   ├── css-variables/      mapa zmiennych CSS (--css-variable-map)
│   ├── repo-components/    mapy komponentów DS i lokalnych oraz wyszukiwanie odpowiedników komponentów z makiety
│   ├── project-settings/   ustawienia repozytorium projektu dla serwera MCP: folder wyników i pliki konfiguracji
│   ├── design-ir/          parser ramy, asembler design_ir, pytania o luki makiety i porównanie dwóch IR
│   ├── ir-sources/         źródła IR: budowa IR z linku do Figmy, obraz ramy, zapis i odczyt pliku IR
│   ├── frame-comparison/   porównanie dwóch źródeł tej samej ramy: wynik porównania i strona HTML
│   ├── diff-report/        strona HTML porównania: położenie warstw na obrazie ramy i obrysy różnic
│   ├── design-audit/       audyt ramy: uchybienia, decyzje i prompt naprawy
│   ├── mcp/                serwer MCP: protokół JSON-RPC przez stdio i narzędzia dla ram
│   └── logging/            wspólne logowanie skryptów na stderr
├── tools/
│   └── variables-plugin/   plugin Figmy, który eksportuje plik zmiennych na każdym planie
├── docs/                   opisy szczegółowe (*.md) i diagram design_ir oraz serwera MCP (design-ir-flow.svg, design-ir-flow.png)
├── ir/                     pliki zapisane przez skrypty: IR, obrazy ram, wyniki audytu i prompty naprawy
└── .cache/                 kopie odpowiedzi Figmy, ignorowane przez git
```

- Foldery `ir/` i `.cache/` powstają przy pierwszym uruchomieniu.
- Domyślne miejsca folderów i plików z `config/` ustawia `settings.js`.
- Opcje `--out`, `--cache`, `--variables`, `--component-map` i `--css-variable-map` zmieniają je na jedno uruchomienie skryptu. Serwer MCP przyjmuje te opcje bez `--out` na czas działania.

## Zasady importów

- Pliki wejściowe importują sub-moduły z `lib/`.
- Sub-moduły nie importują plików wejściowych ani `settings.js`.
- IR z Figmy pliki wejściowe budują przez `lib/ir-sources/figma-link-source.js`.
- Porównanie dwóch źródeł wykonuje `lib/frame-comparison/`, z którego korzystają `compare-design-ir.js` i serwer MCP.
- Stronę HTML porównania składa `lib/diff-report/`.
