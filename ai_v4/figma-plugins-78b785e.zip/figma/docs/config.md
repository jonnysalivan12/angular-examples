# Pliki konfiguracji

Skrypty, serwer MCP i plugin `figma-design-ir` czytają trzy pliki konfiguracji. Pliki domyślne leżą w folderze `config/`.

| Plik | Zawartość | Opcja z inną ścieżką |
|---|---|---|
| `config/variables.json` | Nazwy zmiennych Figmy. | `--variables` |
| `config/component-map.json` | Komponenty w repozytorium dla komponentów z makiety. | `--component-map` |
| `config/css-variable-map.json` | Zmienne CSS dla tokenów Figmy. | `--css-variable-map` |

- Po zmianie plików w `config/` uruchom `node build-plugins.js`, żeby plugin `figma-design-ir` dostał nową kopię. To są pliki domyślne pluginu.
- Folder `config/` może nie mieć pliku domyślnego. Skrypty bez pliku zmiennych próbują pobrać zmienne przez REST, bez mapy komponentów kończą się błędem, a bez mapy zmiennych CSS ją pomijają.
- Repozytorium projektu może podać własne pliki o tych samych nazwach w folderze `.github/plugin/figma-design-ir/`. Serwer MCP użyje ich zamiast plików domyślnych, a bez pliku w żadnym z tych miejsc narzędzie kończy się błędem. Opis: [mcp-server.md](mcp-server.md), sekcja „Ustawienia projektu”.

## Plik zmiennych

`config/variables.json` zawiera nazwy zmiennych Figmy (tokenów). Odpowiedź Figmy dla ramy (`/nodes`) ma tylko identyfikatory zmiennych, bez nazw. Bez tego pliku tokeny zostają nierozwiązane.

- Inną ścieżkę podaje opcja `--variables`.
- Opcja `--no-variables` pomija plik. Tokeny zostaną wtedy nierozwiązane.

### Jak powstaje plik zmiennych

Plan Enterprise:

- Gdy pliku nie ma, skrypt pobiera zmienne z `/files/:key/variables/local` i zapisuje plik.
- Opcja `--refresh-variables` pobiera je ponownie i nadpisuje plik.

Inny plan: REST odmawia dostępu i skrypt kończy pracę z instrukcją. Wygeneruj wtedy plik raz pluginem:

1. W Figmie desktop otwórz plik z makietami i włącz w nim bibliotekę DS (Assets → Libraries). Plugin widzi tylko biblioteki włączone w pliku.
2. Wybierz Plugins → Development → Import plugin from manifest i wskaż `tools/variables-plugin/manifest.json`.
3. Uruchom Plugins → Development → DS Variables Export.
4. Kliknij „Pobierz variables.json” i zapisz plik jako `figma/config/variables.json`. Plik dla jednego projektu zapisz jako `.github/plugin/figma-design-ir/variables.json` w repozytorium projektu.

Nie uruchamiaj pluginu w pliku biblioteki DS. Zmienne mają tam inne identyfikatory niż w pliku z makietami, więc skrypt nie dopasuje ich nazw.

### Kiedy odświeżyć plik zmiennych

- Odśwież plik, gdy w bibliotece DS przybędzie zmiennych albo zmienią się ich nazwy.
- Nowa zmienna z włączonej biblioteki w makiecie nie wymaga ponownego eksportu.

### Co plugin zapisuje

- zmienne lokalne pliku z makietami;
- wszystkie zmienne z bibliotek włączonych w tym pliku, także te, których makiety jeszcze nie używają;
- zmienne z innych bibliotek przypięte do warstw.

Identyfikator każdej zmiennej z biblioteki plugin dostaje przez import zmiennej po kluczu (`importVariableByKeyAsync`). Dokumentacja Figmy nie mówi, czy taki import zmienia plik.

### Kształt pliku zmiennych

Kształt jest ten sam bez względu na źródło:

```json
{
  "VariableID:1:10": { "name": "space/md", "resolvedType": "FLOAT", "collection": "<kolekcja>" }
}
```

`collection` to nazwa kolekcji zmiennej w Figmie albo null, gdy nie da się jej odczytać. Skrypt tego pola nie czyta. Pole pokazuje tylko, skąd pochodzi zmienna.

## Mapa komponentów DS

`config/component-map.json` przypisuje komponentowi z biblioteki DS odpowiednik w repozytorium. Inną ścieżkę podaje opcja `--component-map`. Komponenty pliku Figmy spoza DS opisuje osobna mapa komponentów lokalnych (sekcja „Mapa komponentów lokalnych”).

```json
{
  "components": {
    "<nazwa komponentu z Figmy>": { "name": "<nazwa komponentu w kodzie>", "path": "<ścieżka w repozytorium>" },
    "<nazwa komponentu bez odpowiednika>": null
  }
}
```

### Jak dodać wpis

1. Znajdź nazwę komponentu w IR. To wartość pola `ref` warstwy albo nazwa w pytaniu z `open_questions`.
2. Dopisz wpis z polami `name` i `path`.
3. Uruchom skrypt ponownie.

### Co daje wpis

- Warstwa z tym komponentem ma w IR pole `repo_component` z polami `origin`, `path` i `name`.
- `origin` ma wartość `ds` dla komponentu z biblioteki DS, a `custom` dla komponentu pliku Figmy.
- Komponent z odpowiednikiem nie trafia do `open_questions` ani do `components_to_build`.

### Komponent bez odpowiednika

Dotyczy obu map komponentów.

Komponent bez wpisu albo z wartością `null` nie ma odpowiednika.

- Komponent z biblioteki trafia wtedy do `open_questions`.
- Komponent pliku Figmy trafia do `open_questions` i do `components_to_build`.

Wpis `null` zostawia na liście komponent, który jeszcze czeka na odpowiednik.

### Błędy mapy komponentów

Skrypt kończy pracę kodem 1, gdy:

- pliku nie ma;
- JSON ma błąd składni;
- plik nie ma sekcji `components`;
- wpis nie ma niepustych pól `name` i `path`.

Mapę czyta funkcja `readComponentMap` z `lib/repo-components/repo-component-lookup.js`.

## Mapa komponentów lokalnych

Mapa komponentów lokalnych przypisuje odpowiednik w repozytorium komponentom utworzonym w pliku z makietami, czyli spoza biblioteki DS. Ma ten sam kształt co mapa komponentów DS.

| Gdzie | Jak wskazać plik |
|---|---|
| Skrypty | Opcja `--local-component-map <plik>`. |
| Serwer MCP | Pole `localComponentMap` w `.github/plugin/figma-design-ir/settings.json` repozytorium projektu. Ścieżkę względną serwer liczy od głównego folderu repozytorium. |

- Mapa nie ma pliku domyślnego.
- Bez opcji albo pola, a także bez pliku pod podaną ścieżką, komponenty lokalne nie mają odpowiedników.
- Plik, który istnieje, musi mieć poprawny kształt. Błędy są te same co w mapie komponentów DS.
- Komponent z DS szuka odpowiednika tylko w mapie komponentów DS, a komponent lokalny tylko w mapie komponentów lokalnych.
- Odpowiednik komponentu lokalnego ma w IR `origin: "custom"`.

Mapę czyta funkcja `readLocalComponentMap` z `lib/repo-components/repo-component-lookup.js`.

## Mapa zmiennych CSS

Opcja `--css-variable-map` wskazuje plik JSON, który przypisuje nazwie tokenu Figmy (zmiennej albo stylu) zmienną CSS w kodzie. Mapa jest opcjonalna.

```json
{
  "tokens": {
    "<nazwa tokenu w Figmie>": "--<zmienna-css>"
  }
}
```

- Wartość wpisu musi zaczynać się od `--`.
- Wpis z wartością `null` skrypt pomija.
- Wartości nie mają właściwości czcionki, bo ich liczby są w bloku `typography` warstwy.

Token bez wpisu trafia do IR jako brak wpisu w mapie:

- w `styles` zostaje nazwa tokenu z Figmy i wartość z makiety (`{ "resolved": false, "token": …, "value": … }`);
- `open_questions` dostaje pytanie o wpis.

Skrypt kończy pracę kodem 1, gdy podanego pliku nie ma, gdy JSON ma błąd składni albo gdy plik nie ma sekcji `tokens`.
