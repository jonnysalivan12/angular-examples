#!/usr/bin/env node
/*
 * Kopiuje serwer MCP modułu figma do pluginu Copilota figma-design-ir z .github/plugin.
 *
 * Plugin po instalacji działa z własnej kopii plików, więc ma w folderze server/ komplet plików
 * serwera: mcp-server.js, settings.js, package.json, sub-moduły z lib/ bez testów i folder config/
 * z plikami domyślnymi pluginu (plik zmiennych, mapa komponentów i mapa zmiennych CSS). Pliku
 * domyślnego może nie być. Wtedy każde repozytorium projektu musi podać własny plik, a skrypt
 * wypisuje ostrzeżenie. Pozostałe pluginy Figmy nie mają serwera, tylko korzystają z serwera tego
 * pluginu. Skrypt usuwa poprzednią zawartość server/ i kopiuje pliki od nowa. Uruchom go po każdej
 * zmianie serwera, sub-modułów albo plików z config/.
 *
 * Ścieżki zapisanych folderów trafiają na stdout, a komunikaty na stderr (lib/logging/script-logger.js).
 */

import { cpSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { EXIT_CODE, ScriptError, readCliArguments, runScript } from './lib/cli/script-runner.js';
import { logWarning } from './lib/logging/script-logger.js';

const MODULE_DIR = dirname(fileURLToPath(import.meta.url));
const PLUGINS_DIR = join(MODULE_DIR, '..', '.github', 'plugin');
/** Plugin, który dostaje kopię serwera. */
const PLUGIN_NAME = 'figma-design-ir';
const SERVER_DIR_NAME = 'server';
/** Pliki serwera z folderu modułu. */
const SERVER_FILES = ['mcp-server.js', 'settings.js', 'package.json'];
const CONFIG_DIR = 'config';
/** Pliki domyślne pluginu w folderze config/. */
const CONFIG_FILES = ['variables.json', 'component-map.json', 'css-variable-map.json'];
const LIB_DIR = 'lib';
const TEST_FILE_SUFFIX = '.test.js';
const HELP_HINT = 'Opis opcji: node build-plugins.js --help.';

const CLI_OPTIONS = {
  help: { type: 'boolean', short: 'h', default: false },
};

const USAGE = `Użycie: node build-plugins.js

Kopiuje serwer MCP do folderu server/ pluginu ${PLUGIN_NAME} w .github/plugin.
Kopia zawiera ${SERVER_FILES.join(', ')}, folder ${CONFIG_DIR}/ i lib/ bez testów.
Gdy ${CONFIG_DIR}/ nie ma pliku domyślnego (${CONFIG_FILES.join(', ')}), skrypt wypisuje ostrzeżenie.
Uruchom skrypt po każdej zmianie serwera, sub-modułów albo plików z ${CONFIG_DIR}/.`;

/** Sprawdza, czy plik albo folder z lib/ należy do kopii serwera. Testy zostają w module. */
function isServerFile(sourcePath) {
  return !sourcePath.endsWith(TEST_FILE_SUFFIX);
}

/** Kopiuje pliki serwera do pluginu i zwraca ścieżkę folderu server/. */
function copyServerToPlugin(pluginName) {
  const pluginDir = join(PLUGINS_DIR, pluginName);
  if (!existsSync(join(pluginDir, 'plugin.json'))) {
    throw new ScriptError(`Folder ${pluginDir} nie zawiera pliku plugin.json. Sprawdź nazwę pluginu w PLUGIN_NAME.`);
  }
  const serverDir = join(pluginDir, SERVER_DIR_NAME);
  rmSync(serverDir, { recursive: true, force: true });
  mkdirSync(serverDir, { recursive: true });
  for (const fileName of SERVER_FILES) {
    cpSync(join(MODULE_DIR, fileName), join(serverDir, fileName));
  }
  cpSync(join(MODULE_DIR, LIB_DIR), join(serverDir, LIB_DIR), { recursive: true, filter: isServerFile });
  if (existsSync(join(MODULE_DIR, CONFIG_DIR))) {
    cpSync(join(MODULE_DIR, CONFIG_DIR), join(serverDir, CONFIG_DIR), { recursive: true });
  }
  for (const configFile of CONFIG_FILES) {
    if (!existsSync(join(MODULE_DIR, CONFIG_DIR, configFile))) {
      logWarning(`Folder ${CONFIG_DIR}/ nie ma pliku ${configFile}, więc plugin ${pluginName} nie ma pliku domyślnego. Każde repozytorium projektu musi podać własny plik w .github/plugin/${pluginName}/.`);
    }
  }
  return serverDir;
}

/** Kopiuje serwer do pluginu. */
async function main() {
  const { values: options, positionals } = readCliArguments(CLI_OPTIONS, HELP_HINT);
  if (options.help) {
    process.stdout.write(`${USAGE}\n`);
    return;
  }
  if (positionals.length > 0) {
    throw new ScriptError(`Skrypt nie przyjmuje argumentu ${positionals[0]}. ${HELP_HINT}`, EXIT_CODE.usage);
  }
  process.stdout.write(`${copyServerToPlugin(PLUGIN_NAME)}\n`);
}

runScript(main);
