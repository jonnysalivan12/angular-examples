#!/usr/bin/env node
/*
 * Sprawdza, czy rama Figmy jest przygotowana do wygenerowania IR, i zapisuje prompt naprawy
 * dla agenta Figmy.
 *
 * Kroki:
 *   1. Z linku odczytuje klucz pliku, identyfikatory ram i opcjonalną wersję pliku.
 *   2. Wczytuje nazwy zmiennych z pliku zmiennych, mapę komponentów i ramę z Figmy, tak jak
 *      extract-design-ir.js.
 *   3. Szuka uchybień w ramie (lib/design-audit) i zbiera decyzje, których wymaga ich
 *      poprawienie.
 *   4. Odpowiedzi na decyzje bierze z pliku podanego w --decisions, a bez wpisu z jedynej
 *      podpowiedzi z ramy.
 *   5. Zapisuje <out>/<klucz>__<rama>.audit.json i prompt naprawy
 *      <out>/<klucz>__<rama>.fix-prompt.md. Rama bez uchybień do naprawy promptem nie dostaje
 *      pliku promptu.
 *
 * Ścieżki zapisanych plików trafiają na stdout, a komunikaty na stderr (lib/logging/script-logger.js).
 */

import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { settings } from './settings.js';
import { EXIT_CODE, ScriptError, readCliArguments, runScript } from './lib/cli/script-runner.js';
import { logInfo, logWarning } from './lib/logging/script-logger.js';
import { parseFigmaUrl, readFigmaToken } from './lib/figma-api/figma-rest-client.js';
import { createFigmaFrameLoader, loadVariableNames } from './lib/ir-sources/figma-link-source.js';
import { buildFrameAudit, saveFrameAudit } from './lib/design-audit/frame-audit-report.js';
import { createRepoComponentLookup, readComponentMap, readLocalComponentMap } from './lib/repo-components/repo-component-lookup.js';

/** Znacznik na początku pliku, który dopisuje część programów na Windowsie. JSON.parse go nie przyjmuje. */
const UTF8_BYTE_ORDER_MARK = /^﻿/;
const HELP_HINT = 'Opis opcji: node audit-design.js --help.';

const CLI_OPTIONS = {
  decisions: { type: 'string' },
  out: { type: 'string' },
  cache: { type: 'string' },
  variables: { type: 'string' },
  'component-map': { type: 'string' },
  'local-component-map': { type: 'string' },
  'no-variables': { type: 'boolean', default: false },
  refresh: { type: 'boolean', default: false },
  help: { type: 'boolean', short: 'h', default: false },
};

const USAGE = `Użycie: node audit-design.js <link-figmy> [opcje]

Sprawdza ramę wskazaną linkiem (z node-id) i zapisuje dwa pliki: wynik audytu (.audit.json)
i prompt naprawy dla agenta Figmy (.fix-prompt.md). Rama bez uchybień do naprawy promptem
nie dostaje promptu.

Reguły z poprawką w prompcie naprawy:
  no-auto-layout                 kontener z tekstem albo komponentem nie ma auto layoutu
  raw-value                      kolor, odstęp, zaokrąglenie albo obrys bez zmiennej
  shadow-without-style           cień bez stylu efektu
  text-without-style             tekst bez stylu tekstu i bez zmiennych czcionki
  default-layer-name             kontener o domyślnej nazwie Figmy, np. "Frame 12"
  component-definition-in-frame  definicja komponentu stoi w ramie zamiast instancji

Reguły do decyzji projektanta, bez poprawki w prompcie:
  hidden-layer                   ukryta warstwa poza instancjami komponentów
  empty-container                ramka albo grupa bez widocznych dzieci, wypełnienia, obrysu i efektu
  repeated-structure             budowa kontenera powtórzona w ramie: kandydat na komponent

Opcje:
  --decisions <plik>   plik JSON z odpowiedziami: identyfikator decyzji z .audit.json → nazwa
                       zmiennej albo stylu, np. { "gap/12px": "spacing/md" }
  --out <folder>       folder na wyniki (domyślnie figma/ir)
  --cache <folder>     folder na kopie odpowiedzi Figmy (domyślnie figma/.cache)
  --variables <plik>   plik nazw zmiennych Figmy (domyślnie figma/config/variables.json)
  --component-map <plik>
                       mapa komponentów z biblioteki DS na komponenty w repozytorium
                       (domyślnie figma/config/component-map.json)
  --local-component-map <plik>
                       mapa komponentów z pliku makiet (spoza DS) na komponenty
                       w repozytorium (bez opcji albo bez pliku: brak odpowiedników)
  --no-variables       działaj bez nazw zmiennych (audyt nie podpowie wtedy zmiennych)
  --refresh            pobierz ramę z Figmy bez sprawdzania wersji pliku
  -h, --help           pokaż ten opis

Token: ustaw zmienną środowiskową FIGMA_API_KEY.`;

/**
 * Czyta plik decyzji: obiekt JSON z nazwą zmiennej albo stylu dla identyfikatora decyzji.
 * Pomija znacznik kolejności bajtów na początku pliku. Kończy skrypt błędem, gdy pliku nie ma
 * albo ma inny kształt.
 * @returns {Record<string, string>}
 */
function readDecisionsFile(decisionsPath) {
  if (!existsSync(decisionsPath)) {
    throw new ScriptError(`Nie ma pliku decyzji ${decisionsPath}. Popraw ścieżkę w --decisions.`);
  }
  let answersById;
  try {
    answersById = JSON.parse(readFileSync(decisionsPath, 'utf8').replace(UTF8_BYTE_ORDER_MARK, ''));
  } catch (parseError) {
    throw new ScriptError(`Plik decyzji ${decisionsPath} nie jest poprawnym JSON-em (${parseError.message}). Popraw składnię pliku.`);
  }
  const isAnswerMap = answersById !== null && typeof answersById === 'object' && !Array.isArray(answersById)
    && Object.values(answersById).every((answer) => typeof answer === 'string' && answer.trim() !== '');
  if (!isAnswerMap) {
    throw new ScriptError(`Plik decyzji ${decisionsPath} ma zły kształt. Zapisz w nim obiekt: identyfikator decyzji → nazwa zmiennej albo stylu.`);
  }
  return answersById;
}

/** Sprawdza wszystkie ramy wskazane w linku i zapisuje wyniki. */
async function main() {
  const { values: options, positionals: figmaUrls } = readCliArguments(CLI_OPTIONS, HELP_HINT);
  if (options.help) {
    process.stdout.write(`${USAGE}\n`);
    return;
  }
  if (figmaUrls.length !== 1) {
    throw new ScriptError(`Podaj dokładnie jeden link Figmy. ${HELP_HINT}`, EXIT_CODE.usage);
  }
  const { fileKey, nodeIds, versionId } = parseFigmaUrl(figmaUrls[0]);
  if (!fileKey) {
    throw new ScriptError('Link nie zawiera klucza pliku Figmy. Skopiuj link w postaci figma.com/design/<klucz>/….', EXIT_CODE.usage);
  }
  if (nodeIds.length === 0) {
    throw new ScriptError('Link nie wskazuje ramy, bo nie ma parametru node-id. W Figmie zaznacz ramę i skopiuj link do zaznaczenia (Copy link to selection).', EXIT_CODE.usage);
  }
  const answersById = options.decisions ? readDecisionsFile(resolve(options.decisions)) : {};
  const token = readFigmaToken();
  if (!token) {
    throw new ScriptError('Brak tokenu Figmy. Ustaw zmienną środowiskową FIGMA_API_KEY i uruchom skrypt ponownie.');
  }

  const outputDir = resolve(options.out ?? settings.outputDir);
  const variablesById = options['no-variables']
    ? {}
    : await loadVariableNames({ variablesPath: resolve(options.variables ?? settings.variablesPath), refreshFromFigma: false, fileKey, token });
  const findRepoComponent = createRepoComponentLookup(
    readComponentMap(resolve(options['component-map'] ?? settings.componentMapPath)),
    readLocalComponentMap(options['local-component-map'] ? resolve(options['local-component-map']) : null),
  );
  const loadFrame = createFigmaFrameLoader({
    token,
    cacheDir: resolve(options.cache ?? settings.cacheDir),
    skipVersionCheck: options.refresh,
  });

  for (const nodeId of nodeIds) {
    const { frameResponse } = await loadFrame({ fileKey, nodeId, versionId });
    const { designAudit, fixPrompt } = buildFrameAudit({
      frameResponse, fileKey, nodeId, variablesById, findRepoComponent, answersById, scriptVersion: settings.scriptVersion,
    });
    designAudit.warnings.forEach((warning) => logWarning(warning));
    const { auditPath, promptPath } = saveFrameAudit({ outputDir, designAudit, fixPrompt, versionId });
    process.stdout.write(`${auditPath}\n`);
    if (promptPath) {
      process.stdout.write(`${promptPath}\n`);
    } else {
      logInfo(`Rama ${nodeId} nie ma uchybień do naprawy promptem, więc nie dostaje promptu naprawy.`);
    }
  }
}

runScript(main);
