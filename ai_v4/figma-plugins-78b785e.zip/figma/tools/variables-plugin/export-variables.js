/*
 * Plugin Figmy: eksportuje nazwy zmiennych do mapy
 * { "VariableID:…": { name, resolvedType, collection } } w kształcie pliku figma/config/variables.json.
 * `collection` to nazwa kolekcji zmiennej albo null, gdy kolekcji nie da się odczytać. Mapa obejmuje zmienne lokalne pliku, wszystkie zmienne
 * z bibliotek włączonych w pliku (także te, których makiety jeszcze nie używają) i zmienne
 * z innych bibliotek przypięte do warstw. Identyfikatory są takie jak w odpowiedzi REST /nodes.
 * Wynik trafia do okna pluginu (export-window.html), skąd użytkownik go pobiera albo kopiuje.
 */

const PLUGIN_WINDOW = { width: 460, height: 420, title: 'DS Variables Export' };
const VARIABLE_ID_PREFIX = 'VariableID:';
const VARIABLE_ALIAS_TYPE = 'VARIABLE_ALIAS';
const JSON_INDENT = 2;

figma.showUI(__html__, PLUGIN_WINDOW);

/** Zwraca identyfikator zmiennej w postaci REST API, z prefiksem VariableID:. */
function toRestVariableId(variableId) {
  if (variableId.indexOf(VARIABLE_ID_PREFIX) === 0) {
    return variableId;
  }
  return VARIABLE_ID_PREFIX + variableId;
}

/** Zwraca wpis pliku zmiennych dla zmiennej Figmy i nazwy jej kolekcji. */
function toVariablesFileEntry(variable, collectionName) {
  return { name: variable.name, resolvedType: variable.resolvedType, collection: collectionName };
}

/** Zwraca nazwę kolekcji o podanym identyfikatorze albo null, gdy kolekcji nie da się odczytać. */
async function readCollectionName(collectionId) {
  try {
    const collection = await figma.variables.getVariableCollectionByIdAsync(collectionId);
    return collection ? collection.name : null;
  } catch (readError) {
    return null;
  }
}

/** Zwraca opis błędu do komunikatu w oknie pluginu. */
function reasonOf(error) {
  return (error && error.message) || String(error);
}

/** Dopisuje do zbioru identyfikatory aliasów zmiennych zapisanych w wartości boundVariables (obiektach i listach). */
function collectAliasIds(boundValue, aliasIds) {
  if (!boundValue || typeof boundValue !== 'object') {
    return;
  }
  if (boundValue.type === VARIABLE_ALIAS_TYPE && typeof boundValue.id === 'string') {
    aliasIds.add(toRestVariableId(boundValue.id));
    return;
  }
  for (const nestedValue of Object.values(boundValue)) {
    collectAliasIds(nestedValue, aliasIds);
  }
}

/** Dopisuje do zbioru identyfikatory zmiennych przypiętych do warstwy i wszystkich warstw w niej. */
function collectBoundVariableIds(node, aliasIds) {
  if ('boundVariables' in node) {
    collectAliasIds(node.boundVariables, aliasIds);
  }
  if ('children' in node) {
    for (const childNode of node.children) {
      collectBoundVariableIds(childNode, aliasIds);
    }
  }
}

/** Zwraca identyfikatory zmiennych przypiętych do warstw na wszystkich stronach pliku. */
async function findBoundVariableIds() {
  await figma.loadAllPagesAsync();
  const aliasIds = new Set();
  for (const page of figma.root.children) {
    collectBoundVariableIds(page, aliasIds);
  }
  return aliasIds;
}

/** Importuje zmienną z biblioteki po kluczu. Zwraca zmienną albo null, gdy import się nie udał. */
async function importLibraryVariable(variableKey) {
  try {
    return await figma.variables.importVariableByKeyAsync(variableKey);
  } catch (importError) {
    return null;
  }
}

/**
 * Zwraca wszystkie zmienne z kolekcji bibliotek włączonych w pliku, każdą z nazwą jej kolekcji.
 * Lista zmiennych biblioteki podaje tylko nazwę, klucz i typ, więc identyfikator każdej zmiennej
 * daje import po kluczu.
 */
async function loadEnabledLibraryVariables() {
  const libraryCollections = await figma.teamLibrary.getAvailableLibraryVariableCollectionsAsync();
  const libraryVariables = [];
  let failedImportCount = 0;
  for (const collection of libraryCollections) {
    const collectionVariables = await figma.teamLibrary.getVariablesInLibraryCollectionAsync(collection.key);
    const importedVariables = await Promise.all(
      collectionVariables.map((collectionVariable) => importLibraryVariable(collectionVariable.key)),
    );
    for (const importedVariable of importedVariables) {
      if (importedVariable) {
        libraryVariables.push({ variable: importedVariable, collectionName: collection.name });
      } else {
        failedImportCount += 1;
      }
    }
  }
  return { libraryVariables, collectionCount: libraryCollections.length, failedImportCount };
}

/**
 * Zbiera zmienne lokalne pliku, wszystkie zmienne z bibliotek włączonych w pliku i pozostałe
 * zmienne przypięte do warstw. Zwraca mapę zmiennych jako tekst JSON i liczby do komunikatu w oknie.
 */
async function exportVariables() {
  const variablesById = {};
  const localVariables = await figma.variables.getLocalVariablesAsync();
  const localCollections = await figma.variables.getLocalVariableCollectionsAsync();
  const localCollectionNames = {};
  for (const collection of localCollections) {
    localCollectionNames[collection.id] = collection.name;
  }
  for (const variable of localVariables) {
    const collectionName = localCollectionNames[variable.variableCollectionId] || null;
    variablesById[toRestVariableId(variable.id)] = toVariablesFileEntry(variable, collectionName);
  }

  let libraryExport = { libraryVariables: [], collectionCount: 0, failedImportCount: 0 };
  let libraryError = null;
  try {
    libraryExport = await loadEnabledLibraryVariables();
  } catch (loadError) {
    libraryError = reasonOf(loadError);
  }
  const libraryVariableIds = new Set();
  for (const { variable, collectionName } of libraryExport.libraryVariables) {
    const variableId = toRestVariableId(variable.id);
    libraryVariableIds.add(variableId);
    variablesById[variableId] = toVariablesFileEntry(variable, collectionName);
  }

  const boundVariableIds = await findBoundVariableIds();
  const otherBoundVariableIds = [...boundVariableIds].filter((variableId) => !variablesById[variableId]);
  const otherBoundLookups = await Promise.all(otherBoundVariableIds.map(async (variableId) => ({
    variableId,
    variable: await figma.variables.getVariableByIdAsync(variableId),
  })));
  let unreadableCount = 0;
  for (const { variableId, variable } of otherBoundLookups) {
    if (!variable) {
      unreadableCount += 1;
      continue;
    }
    variablesById[variableId] = toVariablesFileEntry(variable, await readCollectionName(variable.variableCollectionId));
  }

  return {
    localCount: localVariables.length,
    libraryCount: libraryVariableIds.size,
    libraryCollectionCount: libraryExport.collectionCount,
    failedImportCount: libraryExport.failedImportCount,
    libraryError,
    otherBoundCount: otherBoundVariableIds.length - unreadableCount,
    unreadableCount,
    variablesJson: JSON.stringify(variablesById, null, JSON_INDENT),
  };
}

exportVariables()
  .then((exportResult) => {
    figma.ui.postMessage(Object.assign({ type: 'variables' }, exportResult));
  })
  .catch((exportError) => {
    figma.ui.postMessage({
      type: 'error',
      message: `Nie udało się odczytać zmiennych pliku (${reasonOf(exportError)}). Zamknij plugin i uruchom go ponownie w pliku z makietami.`,
    });
  });

figma.ui.onmessage = (uiMessage) => {
  if (uiMessage && uiMessage.type === 'close') {
    figma.closePlugin();
  }
};
