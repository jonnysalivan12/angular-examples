# figma

Skrypty i serwer MCP zamieniają ramę z Figmy na plik JSON z opisem ramy dla programistów i agentów. Ten plik to IR ramy (`design_ir`). Wystarczy Node, moduł nie ma zależności.

## Szybki start

1. Ustaw zmienną środowiskową `FIGMA_API_KEY` na osobisty token dostępu Figmy.
2. W Figmie zaznacz ramę i skopiuj link do zaznaczenia. Link musi zawierać `node-id`.
3. Uruchom:

   ```bash
   node extract-design-ir.js "<link do ramy>"
   ```

Skrypt zapisze IR w folderze `ir/` i wypisze ścieżkę pliku.

O tokenie:

- Token potrzebuje zakresów `file_content:read` i `file_metadata:read`.
- Do pobierania zmiennych przez REST potrzebuje też `file_variables:read`.
- Na Windowsie terminal widzi nową zmienną dopiero po ponownym uruchomieniu programu, w którym działa, np. VS Code.

## Co chcesz zrobić

| Zadanie | Polecenie |
|---|---|
| Zapisz IR ramy | `node extract-design-ir.js <link>` |
| Porównaj dwie wersje ramy | `node compare-design-ir.js <przed> <po>` |
| Sprawdź makietę | `node audit-design.js <link>` |
| Daj narzędzia agentowi | serwer MCP `mcp-server.js` |
| Przypisz komponent z kodu | wpis w `config/component-map.json` |

Każde zadanie ma niżej swoją sekcję. Foldery, pliki i opcje opisuje sekcja „Ustawienia”.

## Zapisz IR ramy

```bash
node extract-design-ir.js "<link do ramy>"
```

Wynik: plik `ir/<klucz>__<node-id>.ir.json`.

- Starsza wersja pliku Figmy: dodaj do linku `version-id=<wersja>`. Wynik trafi do pliku `ir/<klucz>__<node-id>@<wersja>.ir.json`.
- Wszystkie opcje pokazuje `node extract-design-ir.js --help`.
- Pola IR opisuje [docs/design-ir.md](docs/design-ir.md).

## Porównaj dwie wersje ramy

```bash
node compare-design-ir.js <przed> <po>
```

`<przed>` i `<po>` to plik IR albo link do ramy. Para może być dowolna: plik i plik, plik i link, link i link.

Wynik: lista różnic w JSON na stdout. Opcja `--out <plik>` zapisuje ją w pliku.

Różnice na obrazach ramy pokazuje strona HTML:

```bash
node compare-design-ir.js <przed> <po> --html porownanie.html
```

Zanim porównasz, sprawdź:

1. Oba źródła to ta sama rama. Kopia ramy ma w Figmie inne identyfikatory, więc skrypt jej nie porówna z oryginałem.
2. Plik IR powstał w bieżącej wersji skryptów.
3. Oba źródła powstały z tymi samymi plikami z `config/` i tą samą mapą zmiennych CSS.

Token jest potrzebny przy linku. Strona HTML wymaga tokenu zawsze, także przy dwóch plikach IR.

Szczegóły: [docs/comparison.md](docs/comparison.md).

## Sprawdź makietę

```bash
node audit-design.js "<link do ramy>"
```

Wynik w `ir/`:

1. `<klucz>__<node-id>.audit.json`: uchybienia i decyzje.
2. `<klucz>__<node-id>.fix-prompt.md`: prompt naprawy. Plik nie powstaje, gdy prompt nie ma czego naprawić.

Ukryte warstwy, puste kontenery i powtórzoną budowę kontenerów audyt zgłasza do Twojej decyzji. Prompt ich nie naprawia.

Naprawa w Figmie:

1. Zaznacz audytowaną ramę.
2. Otwórz agenta Figmy przyciskiem „Agents”.
3. Wklej prompt.

Odpowiedzi na decyzje podaje opcja `--decisions <plik>`. Reguły, wynik i decyzje opisuje [docs/audit.md](docs/audit.md).

## Daj narzędzia agentowi

`mcp-server.js` to serwer MCP. Agent, np. Copilot, wywołuje przez niego te same operacje co skrypty.

Klient MCP uruchamia serwer sam z wpisu `figma-design-ir` w swojej konfiguracji, np. w `.mcp.json` albo `.vscode/mcp.json` repozytorium.

| Narzędzie | Co robi |
|---|---|
| `frame_to_ir` | Zapisuje IR ramy. |
| `compare_frames` | Porównuje dwie wersje ramy, opcjonalnie ze stroną HTML. |
| `get_frame_image` | Zapisuje obraz PNG ramy. |
| `audit_frame` | Sprawdza ramę i zapisuje prompt naprawy. |

Trzy zasady:

1. Agent podaje w `project_dir` ścieżkę bezwzględną folderu roboczego sesji.
2. Repozytorium projektu musi mieć folder `.github/plugin/figma-design-ir/` z plikiem `settings.json` (folder wyników w polu `outputDir`). Pliki `variables.json`, `component-map.json` i `css-variable-map.json` serwer bierze z tego folderu, a bez nich z `config/`. Gdy pliku nie ma w żadnym z tych miejsc, narzędzie, które go potrzebuje, kończy się błędem.
3. Zmienna `FIGMA_API_KEY` musi być w środowisku klienta MCP.

Szczegóły: [docs/mcp-server.md](docs/mcp-server.md).

### Pluginy Copilota

Serwer trafia do pluginu `figma-design-ir`. Pozostałe pluginy Figmy nie mają serwera, tylko korzystają z serwera tego pluginu i bez niego kończą pracę błędem:

| Plugin | Dla kogo | Instalacja |
|---|---|---|
| `figma-design-ir` | wszyscy: serwer MCP dla pluginów poniżej i dla zwykłego agenta Copilota | [README pluginu](../.github/plugin/figma-design-ir/README.md) |
| `figma-designer` | projektanci | [README pluginu](../.github/plugin/figma-designer/README.md) |
| `figma-analyst` | analitycy | [README pluginu](../.github/plugin/figma-analyst/README.md) |
| `task-flow` | programiści, serwer potrzebny w trybie `frontend` | [README pluginu](../.github/plugin/task-flow/README.md) |

Pluginy instaluje się z marketplace `mortgage-copilot-tools`, opisanego w `.github/plugin/marketplace.json`. Instalację opisuje [README pluginów](../.github/plugin/README.md).

Po zmianie serwera, `settings.js`, `package.json`, plików w `lib/` albo w `config/` wydaj nową wersję pluginu `figma-design-ir`:

1. Skopiuj serwer do pluginu:

   ```bash
   node build-plugins.js
   ```

2. Podnieś `version` w `plugin.json` pluginu i w jego wpisie w `.github/plugin/marketplace.json`.
3. Dopisz na górze `CHANGELOG.md` pluginu sekcję `## <wersja> (RRRR-MM-DD)` z datą wydania i z tym, co zauważy użytkownik.
4. Zatwierdź zmiany razem z folderem `server/` pluginu i wypchnij je do zdalnego repozytorium.
5. Użytkownicy pobierają nową wersję poleceniem `copilot plugin update --all`.

Zmiany w skryptach `extract-design-ir.js`, `compare-design-ir.js` i `audit-design.js`, w testach, w `docs/` i w `tools/` nie trafiają do pluginu. Copilot uruchomiony z `--plugin-dir` czyta folder pluginu bez instalacji, więc tam wystarczy nowa sesja.

## Przypisz komponent z kodu

Mapa komponentów mówi, który komponent z kodu odpowiada komponentowi z makiety. Są dwie mapy:

| Komponent w makiecie | Mapa | Gdzie |
|---|---|---|
| Z biblioteki DS | mapa komponentów DS | `config/component-map.json`; projekt może podać własną w `.github/plugin/figma-design-ir/component-map.json` |
| Utworzony w pliku z makietami | mapa komponentów lokalnych | plik z opcji `--local-component-map` albo z pola `localComponentMap` w `settings.json` projektu; bez pliku brak odpowiedników |


1. Znajdź nazwę komponentu w IR. To pole `ref` warstwy albo nazwa w pytaniu z `open_questions`.
2. Dopisz w mapie wpis z polami `name` i `path` albo wpisz je w miejsce `null`.
3. Uruchom skrypt ponownie.
4. Po zmianie mapy domyślnej `config/component-map.json` uruchom `node build-plugins.js`, żeby plugin `figma-design-ir` dostał nową mapę.

Wynik: warstwa z tym komponentem ma w IR pole `repo_component`. Komponent znika z `open_questions` i z `components_to_build`.

Format mapy: [docs/config.md](docs/config.md).

## Ustawienia

Ustawienie zmienisz na trzy sposoby:

| Sposób | Na jak długo | Przykład |
|---|---|---|
| Opcja w poleceniu | Jedno uruchomienie skryptu. | `node extract-design-ir.js <link> --out C:\moje\ir` |
| Opcja w `args` wpisu serwera MCP | Cały czas działania serwera. | `"args": ["figma/mcp-server.js", "--cache", "C:\\moje\\cache"]` |
| Wartość w `settings.js` | Na stałe, dla skryptów i serwera MCP. | `outputDir: join(MODULE_DIR, 'ir')` |

- Ścieżkę względną w opcji skrypt liczy od folderu, w którym uruchamiasz polecenie. Serwer MCP liczy ją od swojego folderu roboczego.
- Domyślne ścieżki z `settings.js` są liczone od folderu `figma/`, niezależnie od folderu, w którym uruchamiasz polecenie.
- Po zmianie `settings.js` albo plików w `config/` uruchom `node build-plugins.js`. Inaczej plugin `figma-design-ir` zostanie przy starej kopii.

W kolumnie „Działa w” extract to `extract-design-ir.js`, compare to `compare-design-ir.js`, a audit to `audit-design.js`. „Wszystkich” oznacza te trzy skrypty i serwer MCP.

### Pliki i foldery

| Opcja | Co ustawia | Domyślnie | Działa w |
|---|---|---|---|
| `--out <folder>` | Folder na IR, wyniki audytu i obrazy ram. | `figma/ir` | extract, audit |
| `--cache <folder>` | Folder na kopie odpowiedzi Figmy. | `figma/.cache` | wszystkich |
| `--variables <plik>` | Plik nazw zmiennych Figmy. | `figma/config/variables.json` | wszystkich |
| `--component-map <plik>` | Mapa komponentów DS. | `figma/config/component-map.json` | wszystkich |
| `--local-component-map <plik>` | Mapa komponentów lokalnych. Serwer MCP bierze ją z pola `localComponentMap` w `settings.json` projektu. | brak: komponenty lokalne bez odpowiedników | extract, compare, audit |
| `--css-variable-map <plik>` | Mapa zmiennych CSS. | `figma/config/css-variable-map.json`, gdy istnieje | extract, compare, serwer MCP |

W `compare-design-ir.js` opcja `--out <plik>` wskazuje plik z wynikiem porównania, a `--html <plik>` plik strony HTML.

Serwer MCP bierze folder wyników i pliki konfiguracji najpierw z repozytorium projektu, a pliki konfiguracji bez projektu z tej tabeli. Gdy pliku nie ma w żadnym z tych miejsc, narzędzie kończy się błędem.

### Pobieranie danych

| Opcja | Co robi | Działa w |
|---|---|---|
| `--refresh` | Pobiera ramę z Figmy bez sprawdzania wersji pliku. | extract, compare, audit |
| `--no-variables` | Pomija plik zmiennych. Tokeny zostają nierozwiązane, a audyt nie podpowiada zmiennych. | wszystkich |
| `--refresh-variables` | Pobiera zmienne przez REST ponownie i nadpisuje plik zmiennych. Działa tylko na planie Enterprise. | extract |
| `--decisions <plik>` | Podaje odpowiedzi na decyzje audytu. | audit |

Narzędzia serwera MCP mają argumenty na jedno wywołanie: `project_dir`, `output_dir`, `refresh`, `decisions`, `html_file` i `scale`. Folder wyników serwera MCP opisuje [docs/mcp-server.md](docs/mcp-server.md), sekcja „Ustawienia projektu”.

Pełny opis opcji pokazuje `node <skrypt>.js --help`. Format plików z `config/` i sposób przygotowania pliku zmiennych opisuje [docs/config.md](docs/config.md).

## Więcej

- Kopie odpowiedzi Figmy, komunikaty, kody wyjścia, układ folderów i testy: [docs/module.md](docs/module.md).
- Diagram przepływu: [docs/design-ir-flow.png](docs/design-ir-flow.png).
