#!/usr/bin/env node
/*
 * Tworzy design_ir z ramy Figmy wskazanej linkiem i zapisuje go do pliku JSON.
 *
 * Kroki:
 *   1. Z linku odczytuje klucz pliku, identyfikatory ram i opcjonalną wersję pliku.
 *   2. Wczytuje nazwy zmiennych z pliku zmiennych. Gdy pliku nie ma, pobiera zmienne
 *      z REST API i zapisuje plik.
 *   3. Wczytuje opcjonalną mapę zmiennych CSS i mapę komponentów.
 *   4. Sprawdza bieżącą wersję pliku Figmy i pobiera każdą ramę, o ile jej kopia
 *      na dysku pochodzi z innej wersji.
 *   5. Składa design_ir (lib/design-ir) i zapisuje <out>/<klucz>__<rama>.ir.json, a dla linku
 *      z wersją pliku <out>/<klucz>__<rama>@<wersja>.ir.json.
 *
 * Wersja skryptów, domyślne foldery, plik zmiennych i mapa komponentów pochodzą z settings.js. Ścieżki zapisanych
 * plików trafiają na stdout, a komunikaty na stderr (lib/logging/script-logger.js).
 */

import { resolve } from 'node:path';

import { settings } from './settings.js';
import { EXIT_CODE, ScriptError, readCliArguments, runScript } from './lib/cli/script-runner.js';
import { parseFigmaUrl, readFigmaToken } from './lib/figma-api/figma-rest-client.js';
import { cssVariableMapPathOf, readCssVariableMap } from './lib/css-variables/css-variable-map.js';
import { createFigmaIrBuilder, loadVariableNames } from './lib/ir-sources/figma-link-source.js';
import { saveDesignIr } from './lib/ir-sources/ir-file-source.js';
import { createRepoComponentLookup, readComponentMap, readLocalComponentMap } from './lib/repo-components/repo-component-lookup.js';

const HELP_HINT = 'Opis opcji: node extract-design-ir.js --help.';

const CLI_OPTIONS = {
  out: { type: 'string' },
  cache: { type: 'string' },
  'css-variable-map': { type: 'string' },
  variables: { type: 'string' },
  'component-map': { type: 'string' },
  'local-component-map': { type: 'string' },
  'refresh-variables': { type: 'boolean', default: false },
  'no-variables': { type: 'boolean', default: false },
  refresh: { type: 'boolean', default: false },
  help: { type: 'boolean', short: 'h', default: false },
};

const USAGE = `Użycie: node extract-design-ir.js <link-figmy> [opcje]

Link musi zawierać node-id ramy, np. https://www.figma.com/design/<klucz>/<nazwa>?node-id=12-34.
Przy kilku node-id w linku skrypt zapisze osobny plik IR dla każdej ramy.
Link z parametrem version-id daje IR ramy z tej wersji pliku Figmy.

Opcje:
  --out <folder>             folder na pliki IR (domyślnie figma/ir)
  --cache <folder>           folder na kopie odpowiedzi Figmy (domyślnie figma/.cache)
  --css-variable-map <plik>  plik JSON z mapą nazw tokenów Figmy na zmienne CSS (sekcja "tokens")
                             (domyślnie figma/config/css-variable-map.json, gdy istnieje)
  --variables <plik>         plik nazw zmiennych Figmy (domyślnie figma/config/variables.json)
  --component-map <plik>     mapa komponentów z biblioteki DS na komponenty w repozytorium
                             (domyślnie figma/config/component-map.json)
  --local-component-map <plik>
                             mapa komponentów z pliku makiet (spoza DS) na komponenty
                             w repozytorium (bez opcji albo bez pliku: brak odpowiedników)
  --refresh-variables       pobierz zmienne przez REST ponownie i nadpisz plik zmiennych
  --no-variables             działaj bez nazw zmiennych (tokeny zostaną nierozwiązane)
  --refresh                  pobierz ramę i komponenty z Figmy bez sprawdzania wersji pliku
  -h, --help                 pokaż ten opis

Token: ustaw zmienną środowiskową FIGMA_API_KEY. Token potrzebuje zakresów file_content:read
i file_metadata:read; dla zmiennych przez REST także file_variables:read.

Plik zmiennych: gdy go nie ma, skrypt pobiera zmienne przez REST (tylko plan Enterprise)
i zapisuje plik. Na innym planie wygeneruj plik pluginem figma/tools/variables-plugin.`;

/** Tworzy pliki IR dla wszystkich ram wskazanych w linku. */
async function main() {
  const { values: options, positionals: figmaUrls } = readCliArguments(CLI_OPTIONS, HELP_HINT);
  if (options.help) {
    process.stdout.write(`${USAGE}\n`);
    return;
  }
  if (figmaUrls.length !== 1) {
    throw new ScriptError(`Podaj dokładnie jeden link Figmy. ${HELP_HINT}`, EXIT_CODE.usage);
  }
  const { fileKey, nodeIds, versionId } = parseFigmaUrl(figmaUrls[0]);
  if (!fileKey) {
    throw new ScriptError('Link nie zawiera klucza pliku Figmy. Skopiuj link w postaci figma.com/design/<klucz>/….', EXIT_CODE.usage);
  }
  if (nodeIds.length === 0) {
    throw new ScriptError('Link nie wskazuje ramy, bo nie ma parametru node-id. W Figmie zaznacz ramę i skopiuj link do zaznaczenia (Copy link to selection).', EXIT_CODE.usage);
  }
  const token = readFigmaToken();
  if (!token) {
    throw new ScriptError('Brak tokenu Figmy. Ustaw zmienną środowiskową FIGMA_API_KEY i uruchom skrypt ponownie.');
  }

  const outputDir = resolve(options.out ?? settings.outputDir);
  const variablesById = options['no-variables']
    ? {}
    : await loadVariableNames({
      variablesPath: resolve(options.variables ?? settings.variablesPath),
      refreshFromFigma: options['refresh-variables'],
      fileKey,
      token,
    });
  const cssVariableMapPath = cssVariableMapPathOf(options['css-variable-map'], settings.cssVariableMapPath);
  const buildIrFromFigma = createFigmaIrBuilder({
    token,
    cacheDir: resolve(options.cache ?? settings.cacheDir),
    variablesById,
    cssVariableMap: cssVariableMapPath ? readCssVariableMap(cssVariableMapPath) : {},
    findRepoComponent: createRepoComponentLookup(
      readComponentMap(resolve(options['component-map'] ?? settings.componentMapPath)),
      readLocalComponentMap(options['local-component-map'] ? resolve(options['local-component-map']) : null),
    ),
    scriptVersion: settings.scriptVersion,
    skipVersionCheck: options.refresh,
  });

  for (const nodeId of nodeIds) {
    const designIr = await buildIrFromFigma({ fileKey, nodeId, versionId });
    process.stdout.write(`${saveDesignIr({ outputDir, designIr, versionId })}\n`);
  }
}

runScript(main);
