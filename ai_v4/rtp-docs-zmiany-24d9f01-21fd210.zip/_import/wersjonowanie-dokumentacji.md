# Wersjonowanie dokumentacji

Decyzje przyjęte 2026-10-12. Plik opisuje, jak dokumentacja
powstaje przed implementacją i równolegle z nią, jak się zmienia, skąd wiadomo,
co jest zaimplementowane i na jakiej dokumentacji opiera się zadanie, oraz jak
pracuje kilku analityków naraz.

## Zasada

Dokumentacja opisuje system i wie tylko o sobie. Nie zapisuje zadań Jira,
wydań kodu, wdrożeń ani zakresu zmian. `rtp-monorepo` nie wie, gdzie leży
`rtp-docs`. Wersje dokumentów przechodzą z dokumentacji do kodu wyłącznie przez
zadanie Jira.

| Pytanie | Gdzie jest odpowiedź |
|---|---|
| Czy opis wolno implementować? | pole `status` dokumentu |
| Która wersja dokumentu obowiązuje? | pole `version` dokumentu na develop w `rtp-docs` |
| Na jakiej dokumentacji opiera się zadanie albo wydanie? | pole „Dokumentacja” w zadaniu Jira |
| Co jest już zaimplementowane i w jakiej wersji? | plik `docs-versions.yaml` w `rtp-monorepo` |
| Jaka dokumentacja opisuje wersję na produkcji? | gałąź main w `rtp-docs` |

## 1. Status i wersja dokumentu

Każdy dokument poza ADR ma w front matter dwa pola:

```yaml
status: active        # draft | active
version: "2.1"        # X.Y
```

| Status | Znaczenie |
|---|---|
| `draft` | Opis jest w przygotowaniu. Nie wolno go implementować. |
| `active` | Właściciel dokumentu zatwierdził opis. Ta wersja obowiązuje i wolno ją implementować. |

Zasady numeracji:

1. Pierwsza wersja dokumentu ma numer `1.0`.
2. Zmiana zachowania podnosi `X` i zeruje `Y`: `2.1` daje `3.0`. Zmiana zachowania to zmiana, po której kod zgodny z poprzednią wersją przestaje być zgodny z opisem. Dodanie, zmiana i usunięcie wiersza, na przykład wymagania REQ, to zawsze zmiana zachowania.
3. Zmiana, po której kod nadal jest zgodny z opisem, podnosi `Y`: `2.1` daje `2.2`. Taka zmiana to doprecyzowanie, poprawka literówki albo nowy przykład.
4. Jedna zmiana podnosi numer raz, w swoim pierwszym commicie. Kolejne commity tej zmiany zmieniają numer tylko wtedy, gdy doprecyzowanie okazało się zmianą zachowania: `2.2` daje wtedy `3.0`.
5. Numer nigdy nie maleje. Zmiana treści dokumentu `active` bez nowego numeru jest błędem.
6. Numer stoi w cudzysłowie, bo czytnik YAML odczytałby `1.10` jako liczbę `1.1`.

Wiersze, na przykład REQ albo STEP, nie mają własnych wersji. Wersja wiersza to
wersja jego dokumentu. Numerów wierszy nadal nie używa się ponownie
(`methodology.md`, sekcja 3).

ADR nie ma pola `version`. Zatwierdzonej decyzji się nie zmienia. Zastępuje ją
nowa decyzja wpisem `supersedes`.

## 2. Gdzie leży każda wersja

Repozytorium ma dwie stałe gałęzie:

| Gałąź | Co zawiera | Jak się zmienia |
|---|---|---|
| develop | Bieżącą dokumentację: szkice i zatwierdzone wersje. | przez bezpośrednie commity i pull requesty |
| main | Dokumentację wersji wydanej na produkcję. | wyłącznie przez pull request scalany commitem scalenia przy wydaniu na produkcję |

Na develop dokument ze statusem `active` ma zawsze treść zatwierdzoną przez
właściciela.

| Praca | Jak trafia na develop |
|---|---|
| nowy dokument albo zmiana dokumentu, który ma tylko status `draft` | bezpośrednim commitem albo pull requestem, który autor scala sam |
| zatwierdzenie dokumentu, czyli zmiana statusu na `active` | pull requestem zatwierdzonym przez właściciela dokumentu |
| zmiana dokumentu `active` | pull requestem zatwierdzonym przez właściciela dokumentu |

1. Status `active` trafia na develop wyłącznie przez pull request zatwierdzony przez właściciela każdego zmienianego dokumentu. Bitbucket tego nie wymusza, bo develop przyjmuje bezpośrednie commity. Bezpośredni commit, który zmienia dokument `active` albo ustawia ten status, zgłasza skrypt develop (sekcja 8).
2. Zmiana dokumentu `active` zaczyna się od commita, który podnosi wersję i ustawia status `draft`. Ostatni commit przed scaleniem ustawia status `active`.
3. Pull request do develop scala się wyłącznie commitem scalenia. Spłaszczony commit wyglądałby w historii jak bezpośredni commit, a przewinięcie gałęzi (*fast-forward*) przeniosłoby na develop pośrednie commity ze statusem `draft`.
4. Develop ma w Bitbucket blokadę usuwania i blokadę przepisywania historii. Od historii develop zależy numer dokumentacji.
5. Dokument `active` nie wskazuje dokumentu `draft` ani jego wiersza. Nowy dokument, którego potrzebuje zmiana, zatwierdza się w tym samym pull requeście.

### Gałąź main

1. Main zawiera dokumentację, na której opiera się wersja wydana na produkcję.
2. Przy wydaniu na produkcję osoba wydająca zakłada gałąź z commita develop o numerze dokumentacji wydania, na przykład `release/docs-412`. Otwiera pull request do main i scala go commitem scalenia.
3. Main nie dostaje żadnych innych commitów. Dzięki temu po scaleniu ma tę samą treść co scalony commit develop.
4. Numer dokumentacji main to numer commita develop, który przyniosło ostatnie scalenie. Ten commit jest drugim rodzicem commita scalenia na main, więc skrypt liczy go poleceniem `git rev-list --count --first-parent main^2 -- project/`.
5. Main ma w Bitbucket blokadę bezpośrednich commitów, usuwania i przepisywania historii. Zmienia się tylko przez pull request.

## 3. Numer dokumentacji

Numer dokumentacji to liczba commitów na develop, które zmieniły folder
`project/`. Wylicza go git:

```bash
git rev-list --count --first-parent develop -- project/
```

1. Numer rośnie przy każdej zmianie dokumentacji na develop. Wyższy numer oznacza późniejszą dokumentację, a najwyższy zawiera wszystkie wcześniejsze zmiany.
2. Numer wskazuje dokładnie jeden stan dokumentacji: commit na develop, który dał ten numer. Skrypt znajduje ten commit. Automat może oznaczać każde scalenie tagiem, na przykład `docs-412`.
3. Numer nie leży w żadnym pliku, więc równoległe gałęzie nie mają przez niego konfliktów.
4. Bieżący numer pokazują skrypt i warsztat.

## 4. Zadanie i wydanie w Jira

Zadanie Jira ma pole „Dokumentacja” z jedną linią: numerem dokumentacji
i wersją każdego dokumentu zadania.

```text
412: UC-002 3.0, API-002 2.1, SCR-003 1.2
```

1. Analityk przekazuje zadanie, gdy wszystkie dokumenty zadania mają status `active`. Uruchamia w `rtp-docs` skrypt z listą doc-id zadania i wkleja wynik do pola „Dokumentacja”.
2. Gdy dokument zadania zmieni się w trakcie implementacji, analityk generuje linię jeszcze raz i zastępuje nią poprzednią.
3. Wydanie kodu opiera się na dokumentacji o najwyższym numerze spośród swoich zadań.
4. Dokumentacja o tym numerze może zawierać zatwierdzone opisy, których wydanie jeszcze nie realizuje. To, co wydanie realizuje, podaje spis z sekcji 5.

## 5. Co jest zaimplementowane

Plik `docs-versions.yaml` w głównym folderze `rtp-monorepo` podaje wersję
każdego dokumentu, którą realizuje kod:

```yaml
UC-002: "3.0"
API-002: "2.1"
```

1. Programista zmienia spis w tym samym pull requeście co kod. Wersje przepisuje z pola „Dokumentacja” zadania Jira.
2. Spis podaje tylko wersje z pola „Dokumentacja” zadań. Recenzent pull requesta porównuje zmienione wpisy z zadaniem.
3. Gdy kod przestaje realizować dokument, programista usuwa wpis ze spisu.
4. Spis w tagu wydania podaje, co realizuje wydanie.
5. `rtp-monorepo` nie ma żadnego odwołania do `rtp-docs`. Spis zawiera tylko doc-id i numery wersji.

Do spisu trafiają dokumenty, które kod realizuje wprost: UC, TUC, API, INT,
QUE, CONV, NFR, SCR, SCRSEC, FLOW, ACT, BPMS, SPEC-WF, ENT i STM. Pozostałe
typy (BFS, ACTOR, CAP, DDM, LDM, UCMAP, NAV) opisują i porządkują inne
dokumenty, więc do spisu nie trafiają. Wymaganie BFS jest zaimplementowane,
gdy wszystkie UC i TUC, które mają do niego wpis `realizes`, mają stan
„aktualny”.

Skrypt raportu w `rtp-docs` dostaje plik spisu jako argument. Osoba, która go
uruchamia, podaje plik z wybranego commita albo tagu `rtp-monorepo`. Skrypt
porównuje spis z develop w `rtp-docs` i dla każdego dokumentu podaje stan:

| Stan | Warunek | Znaczenie |
|---|---|---|
| w przygotowaniu | dokument ma status `draft` i nie ma zatwierdzonej wersji | Opisu nie implementuje się. |
| niezaimplementowany | dokument `active`, brak wpisu w spisie | Kod tego nie ma. |
| aktualny | `X` we wpisie równe `X` na develop | Kod jest zgodny z opisem. `Y` na develop mogło wzrosnąć. |
| nieaktualny | `X` we wpisie mniejsze niż `X` na develop | Kod realizuje starsze zachowanie. |
| do usunięcia z kodu | wpis w spisie, brak dokumentu na develop | Dokumentacja usunęła opis, a kod nadal go realizuje. |

## 6. Strategie dla przypadków

### Dokumentacja przed implementacją

1. Analityk tworzy dokumenty na develop jako `draft` w wersji `1.0`.
2. Właściciel zatwierdza je w pull requeście, więc dostają status `active`.
3. Analityk przekazuje zadanie i wypełnia pole „Dokumentacja”.

Gdzie jesteśmy: raport pokazuje zatwierdzone dokumenty jako
niezaimplementowane, dopóki programista nie wpisze ich do spisu.

### Implementacja równolegle z dokumentacją

Programista zaczyna, zanim cały opis jest gotowy.

1. Programista implementuje tylko wersje `active`.
2. Analityk zatwierdza opis częściami: najpierw dokumenty potrzebne na start, potem kolejne. Gdy jeden dokument rośnie w kilku krokach, każdy zatwierdzony krok dostaje kolejną wersję.
3. Po każdym zatwierdzeniu analityk generuje nową linię pola „Dokumentacja”.
4. Programista wpisuje do spisu wersję, którą zrealizował, z bieżącej linii pola.

Gdzie jesteśmy: raport pokazuje, które zatwierdzone części mają kod (stan
„aktualny”), których kod jeszcze nie ma („niezaimplementowany”) i które zmieniły
się po implementacji („nieaktualny”).

### Zmiana dokumentacji

Dotyczy dokumentu `active`, także takiego, który kod już realizuje.

1. Analityk przygotowuje zmianę na gałęzi z nowym numerem wersji według sekcji 1.
2. Do scalenia obowiązuje poprzednia wersja na develop.
3. Po scaleniu obowiązuje nowa wersja. Gdy wzrosło `X`, raport pokazuje dokument jako nieaktualny. Gdy wzrosło tylko `Y`, dokument zostaje aktualny.
4. Gdy dokument należy do zadania w toku, analityk generuje nową linię pola „Dokumentacja” tego zadania.

Gdzie jesteśmy: wersja na develop to stan docelowy, wpis w spisie to stan kodu.
Skrypt wypisuje różnicę treści między tymi dwiema wersjami.

## 7. Praca wielu analityków

1. Jedna gałąź niesie jedną zmianę. Pull request zatwierdzają właściciele wszystkich dokumentów, które zmienia. Zmiana wchodzi na develop w całości.
2. Nowy dokument zajmuje swój doc-id bezpośrednim commitem do develop: sam front matter z doc-id, tytułem, statusem `draft` i wersją `1.0`. Od tej chwili doc-id jest zajęty dla wszystkich, a dokument widać w walidatorach, warsztacie i knowledge-index.
3. Przed rozpoczęciem zmiany analityk uruchamia skrypt, który dla doc-id wypisuje niescalone gałęzie zmieniające ten dokument i wersję na każdej z nich.
4. Przed scaleniem autor aktualizuje gałąź z develop. Skrypt sprawdza każdy zmieniony dokument: wersja na gałęzi musi być wyższa o jeden krok niż wersja na bieżącym develop. Gdy ktoś w międzyczasie scalił zmianę tego samego dokumentu, autor podnosi numer jeszcze raz.
5. Gdy dwie gałęzie dodały wiersz o tym samym numerze, na przykład `REQ-06`, druga gałąź zmienia swój wiersz na kolejny wolny numer i poprawia wpisy, które go wskazują. Skrypt wypisuje wpisy z gałęzi, które wskazują wiersze dodane na develop po rozgałęzieniu.
6. Konflikt w tym samym fragmencie dokumentu rozstrzyga autor drugiej gałęzi razem z właścicielem dokumentu.

## 8. Walidatory, skrypty i narzędzia

| Element | Gdzie | Co sprawdza albo robi |
|---|---|---|
| `validate-form` | `rtp-docs` | Pole `version` w każdym typie poza ADR i zapis `"X.Y"`. |
| `validate-relations` | `rtp-docs` | Dokument `active` nie wskazuje dokumentu `draft` ani jego wiersza. |
| skrypt gałęzi | `rtp-docs` | Sekcja 7, punkty 3, 4 i 5. |
| skrypt develop | `rtp-docs` | Bezpośrednie commity na develop, czyli commity bez scalenia, które zmieniają dokument `active` albo ustawiają ten status (sekcja 2, punkt 1). |
| skrypt numeru dokumentacji | `rtp-docs` | Bieżący numer, commit dla numeru, linia pola „Dokumentacja” dla listy doc-id, dokument w dokumentacji o podanym numerze, różnica między dwoma numerami. |
| skrypt raportu | `rtp-docs` | Porównanie podanego pliku spisu z develop (sekcja 5). |
| pole „Dokumentacja” | Jira | Numer dokumentacji i wersje dokumentów zadania. |
| knowledge-index i warsztat | `rtp-docs` | Wersja dokumentu obok statusu, bieżący numer dokumentacji. |

Kolejność wdrożenia. Każdy etap kończy się uruchomieniem trzech walidatorów na
`standards/examples` z wynikiem bez błędów.

1. Szablony wszystkich typów poza `adr` i `standards/templates/_00-meta.md`: pole `version: "1.0"`, opis pól i zasad numeracji.
2. Przykłady w `standards/examples` poza ADR: pole `version: "1.0"`.

   Etapy 1 i 2 wykonano razem 2026-10-13, bo samo pole w szablonach dałoby błąd FORM-01 w każdym przykładzie. Pole dostały 22 szablony i 128 przykładów; pominięto szablon ADR i 3 przykłady ADR. Walidatory na `standards/examples` (131 dokumentów) dają wynik jak przed zmianą: `validate-relations` 0 błędów i 1 ostrzeżenie, `validate-form` 0 błędów i 10 ostrzeżeń, `validate-consistency` 0 i 0. Usunięcie pola z kopii przykładu daje błąd FORM-01.
3. Walidatory: `validate-form` i `validate-relations`. Każde nowe sprawdzenie dostaje kod w obiekcie `CHECKS` walidatora i wpis z `enabled` i `level` w `standards/config/validators.yaml`. Bez wpisu walidator go nie uruchamia.
4. `standards/methodology.md`: nowa sekcja o wersjach i numerze dokumentacji, krok z numerem wersji w sekcji 6 „Zmiana dokumentu”.
5. knowledge-index i warsztat.
6. Skrypty gałęzi, develop, numeru dokumentacji i raportu.
7. Pole „Dokumentacja” w Jira, plik `docs-versions.yaml` w `rtp-monorepo` oraz ochrona develop i main w Bitbucket. Jedyny dozwolony sposób scalania w repozytorium to commit scalenia. Gałąź develop założono 2026-10-12 z commita `24d9f01`. Blokady usuwania i przepisywania historii develop ustawiono 2026-10-13. Tego samego dnia main dostała blokadę bezpośrednich commitów, usuwania i przepisywania historii.

## Zgodność z wcześniejszymi decyzjami

| Decyzja | Co się dzieje |
|---|---|
| Statusy `draft` i `active` (`decyzje.md`, decyzja 5) | Zostają. Opis `active` w `_00-meta.md` dostaje dopowiedzenie: wersja obowiązuje i wolno ją implementować. |
| Bez sekcji „Historia zmian” (`decyzje.md`, decyzja 5) | Zostaje. Treść poprzednich wersji trzyma git. |
| Bez odnośników do Jira (`decyzje.md`, T11) | Zostaje. Dokumentacja nie wskazuje zadań ani kodu. |
| `process-version` w BPMS | Bez zmian. To pole wskazuje wersję pliku BPMN. |

## Decyzje z 2026-10-12

1. Numer dokumentacji to licznik commitów na gałęzi develop, które zmieniły `project/`. Zatwierdzona dokumentacja leży na develop.
2. Dokumenty `active` zmieniają się tylko przez pull request. Develop nie przyjmuje scalania przez przewinięcie gałęzi i ma blokadę przepisywania historii.
3. ADR nie ma pola `version`.
4. Main zawiera dokumentację wersji wydanej na produkcję i zmienia się tylko przez pull request scalany commitem scalenia.
5. Develop przyjmuje bezpośrednie commity. Bitbucket blokuje usunięcie develop.
