import { useCallback, useEffect, useRef, useState } from 'react';
import { useData } from '../state/data';
import { useRoute } from '../state/route';
import { STEPS } from './steps';

// Przewodnik dla nowych osób: karta z opisem kroku przy podświetlonym
// elemencie aplikacji. Podświetlenie nie blokuje kliknięć, więc zadanie kroku
// wykonuje się w samej aplikacji. Zadanie wykonane w trakcie kroku przełącza
// krok dalej po chwili. Zadanie wykonane wcześniej (na przykład po „Wstecz”)
// tylko pokazuje znacznik, a dalej prowadzi przycisk „Dalej”.

const GAP = 12;
const PAD = 6;
const NEXT_DELAY = 700;
const CARD = { width: 320, height: 220 };

// Lista selektorów kroku: target może być selektorem, listą albo funkcją.
function targetsOf(step, ctx) {
  const target = typeof step.target === 'function' ? step.target(ctx) : step.target;
  if (!target) return [];
  return Array.isArray(target) ? target : [target];
}

// Część prostokąta widoczna w oknie przeglądarki albo null.
function visiblePart(rect) {
  const left = Math.max(rect.left, 0);
  const top = Math.max(rect.top, 0);
  const right = Math.min(rect.right, window.innerWidth);
  const bottom = Math.min(rect.bottom, window.innerHeight);
  return right > left && bottom > top ? { left, top, width: right - left, height: bottom - top } : null;
}

// Prostokąt pierwszego widocznego elementu z listy. Element może się pojawić
// później (układ Mapy liczy się w tle) i przesuwać (zoom, przewijanie),
// dlatego pomiar powtarza się co klatkę.
function useTargetRect(selectorKey, scroll) {
  const [rect, setRect] = useState(null);
  useEffect(() => {
    const selectors = selectorKey ? selectorKey.split('\n') : [];
    let frame = 0;
    let last = null;
    let scrolled = !scroll;
    const tick = () => {
      let next = null;
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        const part = element && visiblePart(element.getBoundingClientRect());
        if (!part) continue;
        if (!scrolled) {
          scrolled = true;
          element.scrollIntoView({ block: 'nearest' });
        }
        next = part;
        break;
      }
      const key = next && [next.left, next.top, next.width, next.height].map(Math.round).join(',');
      if (key !== last) {
        last = key;
        setRect(next);
      }
      frame = requestAnimationFrame(tick);
    };
    tick();
    return () => cancelAnimationFrame(frame);
  }, [selectorKey, scroll]);
  return rect;
}

// Położenie karty: pod elementem, z prawej, z lewej albo nad nim, w tej
// kolejności. Strona prefer (bottom, right, left, top) jest sprawdzana
// pierwsza. Gdy nic się nie mieści albo elementu nie ma, karta stoi w prawym
// dolnym rogu.
function placeCard(rect, size, prefer) {
  const width = window.innerWidth;
  const height = window.innerHeight;
  const corner = { left: width - size.width - 16, top: height - size.height - 16 };
  if (!rect) return corner;
  const box = { left: rect.left - PAD, top: rect.top - PAD, right: rect.left + rect.width + PAD, bottom: rect.top + rect.height + PAD };
  const clampX = x => Math.min(Math.max(x, GAP), width - size.width - GAP);
  const clampY = y => Math.min(Math.max(y, GAP), height - size.height - GAP);
  const centerX = clampX((box.left + box.right - size.width) / 2);
  const centerY = clampY((box.top + box.bottom - size.height) / 2);
  const options = [
    { side: 'bottom', fits: box.bottom + GAP + size.height <= height - GAP, left: centerX, top: box.bottom + GAP },
    { side: 'right', fits: box.right + GAP + size.width <= width - GAP, left: box.right + GAP, top: centerY },
    { side: 'left', fits: box.left - GAP - size.width >= GAP, left: box.left - GAP - size.width, top: centerY },
    { side: 'top', fits: box.top - GAP - size.height >= GAP, left: centerX, top: box.top - GAP - size.height },
  ];
  const choice = options.find(option => option.side === prefer && option.fits) || options.find(option => option.fits);
  return choice ? { left: choice.left, top: choice.top } : corner;
}

export default function Guide({ palette, onPalette, onPanel, hidden, onClose }) {
  const { mode, params } = useRoute();
  const { graph, docIndex, nodeInfo } = useData();
  // start to stan aplikacji z chwili wejścia w krok (warunek done może go użyć).
  const [{ index, start }, setStep] = useState(() => ({ index: 0, start: null }));
  const [size, setSize] = useState(CARD);
  const cardRef = useRef(null);
  const timer = useRef(null);
  const step = STEPS[index];
  const ctx = { mode, params, palette, graph, docIndex, nodeInfo };
  const ctxRef = useRef(ctx);
  ctxRef.current = ctx;
  const controlsRef = useRef(null);
  controlsRef.current = { openPalette: onPalette, openPanel: onPanel };

  const go = useCallback(next => {
    clearTimeout(timer.current);
    if (next >= STEPS.length) onClose();
    else setStep({ index: Math.max(next, 0), start: ctxRef.current });
  }, [onClose]);

  // Przejście do następnego kroku po chwili, jeśli użytkownik nadal jest w kroku from.
  const nextLater = useCallback(from => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      setStep(current => (current.index === from ? { index: from + 1, start: ctxRef.current } : current));
    }, NEXT_DELAY);
  }, []);
  useEffect(() => () => clearTimeout(timer.current), []);

  useEffect(() => {
    STEPS[index].enter?.(ctxRef.current, controlsRef.current);
    if (STEPS[index].blur && cardRef.current?.contains(document.activeElement)) document.activeElement.blur();
  }, [index]);

  const done = step.task ? Boolean(step.done(ctx, start || ctx)) : true;
  const previous = useRef({ index: -1, done: false });
  useEffect(() => {
    if (!step.task) return;
    const before = previous.current;
    previous.current = { index, done };
    if (before.index === index && !before.done && done) nextLater(index);
  }, [index, done, step.task, nextLater]);

  const selectorKey = hidden ? '' : targetsOf(step, ctx).join('\n');
  const rect = useTargetRect(selectorKey, Boolean(step.scroll));

  useEffect(() => {
    const card = cardRef.current;
    if (!card) return undefined;
    const observer = new ResizeObserver(() => {
      const next = { width: card.offsetWidth, height: card.offsetHeight };
      setSize(current => (current.width === next.width && current.height === next.height ? current : next));
    });
    observer.observe(card);
    return () => observer.disconnect();
  }, [hidden]);

  if (hidden) return null;

  const centered = !step.target;
  const first = index === 0;
  const last = index === STEPS.length - 1;
  const position = centered ? null : placeCard(rect, size, step.place);
  // Obwódka elementu przy krawędzi okna (pasek górny, panele) zostaje w oknie.
  const ring = rect && {
    left: Math.max(rect.left - PAD, 2),
    top: Math.max(rect.top - PAD, 2),
    right: Math.min(rect.left + rect.width + PAD, window.innerWidth - 2),
    bottom: Math.min(rect.top + rect.height + PAD, window.innerHeight - 2),
  };

  return (
    <>
      {centered && <div className="guide-dim" />}
      {ring && (
        <div className={`guide-ring ${step.task && !done ? 'is-task' : ''}`} aria-hidden="true"
          style={{ left: ring.left, top: ring.top, width: ring.right - ring.left, height: ring.bottom - ring.top }} />
      )}
      <div ref={cardRef} className={`guide-card ${centered ? 'is-center' : ''}`} style={position || undefined}
        role="dialog" aria-modal={centered ? 'true' : 'false'} aria-labelledby="guide-title">
        <div className="guide-head">
          <span>Przewodnik · krok {index + 1} z {STEPS.length}</span>
          <button type="button" className="guide-x" onClick={onClose} aria-label="Zamknij przewodnik" title="Zamknij przewodnik">×</button>
        </div>
        <div className="guide-progress" aria-hidden="true"><span style={{ width: `${((index + 1) / STEPS.length) * 100}%` }} /></div>
        <div aria-live="polite">
          <div className="guide-title" id="guide-title">{step.title}</div>
          <div className="guide-body">{step.body}</div>
          {step.task && (
            <div className={`guide-task ${done ? 'is-done' : ''}`}>
              <i aria-hidden="true">{done ? '✓' : ''}</i>
              <span>{done && <span className="guide-sr">Zrobione: </span>}{step.task}</span>
            </div>
          )}
        </div>
        <div className="guide-acts">
          {first && <button type="button" className="btn btn-ghost" onClick={onClose}>Pomiń przewodnik</button>}
          {!first && <button type="button" className="btn btn-ghost" onClick={() => go(index - 1)}>Wstecz</button>}
          {step.task && !done && (
            <button type="button" className="btn btn-secondary" onClick={() => { step.show(ctxRef.current, controlsRef.current); nextLater(index); }}>Pokaż mi</button>
          )}
          {(!step.task || done) && (
            <button type="button" className="btn btn-primary" autoFocus={first} onClick={() => go(index + 1)}>{first ? 'Zaczynamy' : last ? 'Zakończ' : 'Dalej'}</button>
          )}
        </div>
      </div>
    </>
  );
}
