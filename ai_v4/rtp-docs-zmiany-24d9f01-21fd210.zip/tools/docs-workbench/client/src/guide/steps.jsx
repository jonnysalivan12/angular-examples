import { useData } from '../state/data';
import { listParam, navigate } from '../state/route';
import { relPath } from '../components/common';

// Kroki przewodnika po przykładach ze standards/examples.
//
// Pola kroku:
//   title, body  nagłówek i treść karty,
//   target       selektor elementu do podświetlenia, lista selektorów (wygrywa
//                pierwszy widoczny) albo funkcja (ctx) => selektor; bez target
//                karta stoi na środku ekranu,
//   place        strona karty sprawdzana pierwsza: bottom, right, left, top,
//   scroll       przewiń panel do elementu, gdy element się pojawi,
//   blur         zdejmij fokus z przycisku karty (Space na przycisku go klika),
//   enter        (ctx, controls) => void: stan aplikacji potrzebny w kroku,
//   task         zadanie dla użytkownika; krok czeka na done(ctx, start),
//   show         (ctx, controls) => void: działanie przycisku „Pokaż mi”.
// ctx to { mode, params, palette, graph, docIndex, nodeInfo }, start to ctx
// z chwili wejścia w krok, a controls to { openPalette(open), openPanel(side) }.

// ID i tytuł dokumentu z przykładów.
function Ref({ id }) {
  const { docIndex } = useData();
  const title = docIndex.get(id)?.title;
  return <><span className="m">{id}</span>{title ? ` „${title}”` : ''}</>;
}

const Key = ({ children }) => <span className="kbd">{children}</span>;

const isDoc = key => Boolean(key) && !key.startsWith('grupa:');
const START_DOC = 'UC-001';
const START_GROUP = 'BFS-001';
// Pierwszy wynik wyszukiwania „reklamacji”; jego zasięg ma kilkanaście plików.
const SEARCH_DOC = 'CAP-004';
// Lista rozwiniętych grup z grupą START_GROUP.
const withStartGroup = params => [...listParam(params.rozwin).filter(key => key !== START_GROUP), START_GROUP].join(',');

// Zaznacza dokument startowy, gdy nic nie jest zaznaczone albo zaznaczona jest
// grupa. Z noAdr także wtedy, gdy zaznaczona jest decyzja ADR (nie ma Zasięgu).
function ensureDoc({ params, nodeInfo }, { noAdr = false } = {}) {
  if (isDoc(params.sel) && !(noAdr && nodeInfo(params.sel)?.type === 'ADR')) return;
  navigate({ sel: START_DOC }, { replace: true });
}

export const STEPS = [
  {
    title: 'Pierwsze kroki w Warsztacie',
    body: <>
      <p>Warsztat pokazuje dokumentację jako graf. Dokument albo jego wiersz to węzeł, a wpis w polu <span className="m">relations</span> to linia między węzłami.</p>
      <p>Teraz Warsztat pokazuje przykłady z folderu <span className="m">standards/examples</span>. W części kroków wykonasz działanie w aplikacji, a przewodnik sam przejdzie dalej. Przycisk „Pokaż mi” wykona to działanie za ciebie.</p>
      <p>Przycisk × zamyka przewodnik. Ponownie uruchomisz go przyciskiem ze znakiem zapytania w pasku górnym.</p>
    </>,
  },
  {
    title: 'Pasek górny',
    target: '.tb',
    body: <>
      <p>Po lewej są cztery tryby: Mapa, Zasięg, Przepływ i Pliki. Tryb zmienisz kliknięciem albo klawiszem od <Key>1</Key> do <Key>4</Key>.</p>
      <p>Po prawej są liczniki walidacji, wyszukiwanie i przełącznik motywu.</p>
    </>,
  },
  {
    title: 'Mapa i grupy',
    target: `.react-flow__node[data-id="grupa:${START_GROUP}"]`,
    enter: () => navigate({ mode: 'map', zakres: undefined, grupuj: undefined, wezel: undefined, panel: undefined, podglad: undefined }, { replace: true }),
    body: <p>Mapa pokazuje wszystkie dokumenty w grupach. Grupa zbiera dokumenty jednego procesu biznesowego (BFS). Grupa z dwoma numerami ma dokumenty wspólne dla dwóch procesów.</p>,
    task: <>Kliknij dwukrotnie grupę <Ref id={START_GROUP} />, żeby ją rozwinąć.</>,
    done: ({ mode, params }) => mode === 'map' && listParam(params.rozwin).includes(START_GROUP),
    show: ({ params }) => navigate({ mode: 'map', rozwin: withStartGroup(params) }, { replace: true }),
  },
  {
    title: 'Dokumenty w grupie',
    target: `.react-flow__node[data-id="${START_DOC}"]`,
    enter: ({ mode, params }) => {
      if (mode !== 'map' || !listParam(params.rozwin).includes(START_GROUP)) navigate({ mode: 'map', rozwin: withStartGroup(params) }, { replace: true });
    },
    body: <p>Rozwinięta grupa układa dokumenty w kolumnach według warstw. Kolor kropki przy ID oznacza warstwę, a linie to relacje. Kółko myszy przybliża mapę, a przeciąganie tła ją przesuwa.</p>,
    task: <>Kliknij kartę <Ref id={START_DOC} /> albo dowolną inną kartę dokumentu.</>,
    done: ({ params }) => isDoc(params.sel),
    show: () => navigate({ sel: START_DOC }),
  },
  {
    title: 'Inspektor',
    target: '.ins',
    enter: (ctx, { openPanel }) => { openPanel('right'); ensureDoc(ctx); },
    body: <>
      <p>Inspektor po prawej opisuje zaznaczony węzeł: typ, tytuł i ścieżkę pliku. Niżej są relacje wychodzące, dokumenty wskazujące węzeł, wiersze dokumentu i problemy walidacji.</p>
      <p>Klik w ID na liście zaznacza ten dokument. Prawy klik na karcie na Mapie otwiera menu z tymi samymi działaniami.</p>
    </>,
  },
  {
    title: 'Podgląd pliku',
    target: '.ins [data-guide="podglad"]',
    place: 'left',
    scroll: true,
    blur: true,
    enter: (ctx, { openPanel }) => { openPanel('right'); ensureDoc(ctx); },
    body: <p>Podgląd pokazuje front matter i treść dokumentu. Identyfikatory w treści są linkami, a diagramy Mermaid są narysowane.</p>,
    task: <>Naciśnij <Key>Space</Key> albo kliknij „Podgląd pliku”.</>,
    done: ({ params }) => Boolean(params.podglad) && isDoc(params.sel),
    show: () => navigate({ podglad: '1' }, { replace: true }),
  },
  {
    title: 'Zamykanie podglądu',
    target: '.preview-modal',
    body: <p>Okno podglądu ma te same działania co inspektor, na przykład „Edytuj”. Klik obok okna też je zamyka.</p>,
    task: <>Naciśnij <Key>Esc</Key>, żeby zamknąć podgląd.</>,
    done: ({ params }) => !params.podglad,
    show: () => navigate({ podglad: undefined }, { replace: true }),
  },
  {
    title: 'Wyszukiwanie',
    target: '.search',
    body: <p>Wyszukiwanie znajduje dokument po ID, słowie z tytułu albo opisie. Wpis <span className="m">typ:API</span> otwiera katalog wszystkich dokumentów typu API.</p>,
    task: <>Naciśnij <Key>Ctrl K</Key> albo kliknij pole „Szukaj…”.</>,
    done: ({ palette }) => palette,
    show: (ctx, { openPalette }) => openPalette(true),
  },
  {
    title: 'Wybór wyniku',
    target: ({ palette }) => (palette ? '.pal' : '.search'),
    enter: (ctx, { openPalette }) => openPalette(true),
    body: <p>Wyniki są w trzech grupach: dokumenty, wiersze dokumentów i katalogi typów. Strzałki zmieniają wybrany wynik.</p>,
    task: <>Wpisz „reklamacji” i naciśnij <Key>Enter</Key>, żeby zaznaczyć pierwszy wynik.</>,
    done: ({ params, palette }, start) => !palette && isDoc(params.sel) && params.sel !== start.params.sel,
    show: (ctx, { openPalette }) => { openPalette(false); navigate({ sel: SEARCH_DOC, panel: undefined }); },
  },
  {
    title: 'Zasięg zmiany',
    target: '.ins [data-guide="zasieg"]',
    place: 'left',
    scroll: true,
    enter: (ctx, { openPanel }) => { openPanel('right'); ensureDoc(ctx, { noAdr: true }); },
    body: <>
      <p>Zasięg pokazuje pliki do przejrzenia, gdy zmieniasz dokument. Warsztat liczy go z relacji między dokumentami.</p>
      <p>Klawisz <Key>Z</Key> dodaje zaznaczony dokument do koszyka zasięgu bez zmiany trybu.</p>
    </>,
    task: <>Kliknij „Zasięg” w inspektorze.</>,
    done: ({ mode, params }) => mode === 'scope' && listParam(params.start).length > 0,
    show: ({ params }) => navigate({ mode: 'scope', start: isDoc(params.sel) ? params.sel : START_DOC, zapytanie: undefined, podglad: undefined }),
  },
  {
    title: 'Wynik zasięgu',
    target: '.ins',
    enter: ({ mode, params }, { openPanel }) => {
      openPanel('right');
      const start = params.start || (isDoc(params.sel) ? params.sel : START_DOC);
      navigate({ mode: 'scope', start, ins: undefined, panel: undefined }, { replace: true });
    },
    body: <>
      <p>Płótno układa dokumenty w kolumnach według liczby kroków od dokumentu startowego. Inspektor ma listę plików do przejrzenia.</p>
      <p>W panelu po lewej zmienisz zapytanie, dodasz dokumenty do koszyka i skopiujesz wynik jako listę Markdown.</p>
    </>,
  },
  {
    title: 'Przepływ',
    target: '.tb .seg',
    body: <p>Przepływ pokazuje zdolności CAP w kolumnach procesów. Linie między zdolnościami to zdarzenia i wywołania. Klik w linię pokazuje w inspektorze, z czego wynika jej kierunek.</p>,
    task: <>Naciśnij <Key>3</Key> albo kliknij „Przepływ”.</>,
    done: ({ mode }) => mode === 'flow',
    show: () => navigate({ mode: 'flow', podglad: undefined }),
  },
  {
    title: 'Widoki przepływu',
    target: '.lp select[aria-label="Widok przepływu"]',
    place: 'right',
    enter: ({ mode }, { openPanel }) => { openPanel('left'); if (mode !== 'flow') navigate({ mode: 'flow' }, { replace: true }); },
    body: <p>Pole „Widok” przełącza przepływ danych między zdolnościami na przepływ pracy: nawigację ekranów, przepływy i aktywności, procesy BPMS, mapy scenariuszy albo decyzje architektoniczne.</p>,
    task: <>Wybierz w polu „Widok” na przykład „Procesy BPMS i kroki”.</>,
    done: ({ mode, params }) => mode === 'flow' && Boolean(params.widok),
    show: () => navigate({ mode: 'flow', widok: 'bpms', dok: undefined, lin: undefined }, { replace: true }),
  },
  {
    title: 'Pliki',
    target: '.tb .seg',
    body: <p>Tryb Pliki pokazuje drzewo folderu dokumentacji tak, jak leży na dysku.</p>,
    task: <>Naciśnij <Key>4</Key> albo kliknij „Pliki”.</>,
    done: ({ mode }) => mode === 'files',
    show: () => navigate({ mode: 'files', podglad: undefined }),
  },
  {
    title: 'Drzewo plików',
    target: ['.files-tree', '.lp'],
    enter: ({ mode }, { openPanel }) => { openPanel('left'); if (mode !== 'files') navigate({ mode: 'files' }, { replace: true }); },
    body: <>
      <p>Klik w plik pokazuje jego treść na płótnie. Przycisk „Edytuj” otwiera edytor Markdown z podglądem, a <Key>Ctrl S</Key> zapisuje plik na dysku, także w przykładach.</p>
      <p>Prawy klik na folderze otwiera menu z działaniem „Nowy dokument…”. Nowy plik powstaje z szablonu typu.</p>
    </>,
    task: <>Kliknij dowolny dokument w drzewie.</>,
    done: ({ mode, params }) => mode === 'files' && Boolean(params.plik),
    show: ({ graph, docIndex }) => {
      const doc = docIndex.get(START_DOC);
      if (doc) navigate({ mode: 'files', plik: relPath(doc, graph), fraza: undefined }, { replace: true });
    },
  },
  {
    title: 'Walidacja',
    target: '.val',
    body: <p>Liczniki pokazują błędy i ostrzeżenia z trzech walidatorów: relacji, formy i spójności. Znak „!” na karcie na Mapie oznacza dokument z problemem.</p>,
    task: <>Kliknij licznik, żeby otworzyć panel walidacji.</>,
    done: ({ params }) => params.panel === 'walidacja',
    show: () => navigate({ panel: 'walidacja', problem: undefined }),
  },
  {
    title: 'Panel walidacji',
    target: '.ins',
    enter: ({ params }, { openPanel }) => { openPanel('right'); if (params.panel !== 'walidacja') navigate({ panel: 'walidacja', problem: undefined }, { replace: true }); },
    body: <>
      <p>Klik w problem rozwija go: widać podpowiedź naprawy i ścieżkę pliku z numerem linii. Klik w ścieżkę otwiera podgląd z podświetloną linią i przyciskiem „Kopiuj prompt dla agenta”.</p>
      <p>Przycisk „Pokaż” wskazuje dokument na Mapie. <Key>Esc</Key> zamyka panel.</p>
    </>,
  },
  {
    title: 'Gotowe',
    body: <>
      <p>Znasz już główne części Warsztatu. Najważniejsze skróty:</p>
      <ul className="guide-keys">
        <li><Key>Ctrl K</Key> wyszukiwanie</li>
        <li><Key>1</Key>–<Key>4</Key> tryby</li>
        <li><Key>Space</Key> podgląd pliku zaznaczonego węzła</li>
        <li><Key>Z</Key> dodanie węzła do koszyka zasięgu</li>
        <li><Key>F</Key> dopasowanie widoku do zaznaczenia</li>
      </ul>
      <p>Pełny opis aplikacji jest w pliku <span className="m">tools/docs-workbench/README.md</span>. Przewodnik uruchomisz ponownie przyciskiem ze znakiem zapytania w pasku górnym.</p>
    </>,
  },
];
