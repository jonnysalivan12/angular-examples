// Wersja statyczna, tylko do podglądu (vite build --mode static).
//
// Odpowiedzi /api pochodzą z plików, które zapisał server/static.js: dane
// w folderze data/, a pliki dokumentacji w folderze files/ pod ścieżką
// względem folderu repozytorium. Przeglądarka sama liczy to, czego nie da się
// zapisać z góry: wyszukiwanie, zapytanie Zasięgu dla kilku węzłów naraz
// i symulację usunięcia. Zapisu plików ta wersja nie ma.

export const STATIC = import.meta.env.MODE === 'static';

const loaded = new Map();

// Plik data/<name>.json, pobierany raz.
function load(name) {
  if (!loaded.has(name)) {
    const request = fetch(`data/${name}.json`).then(response => {
      if (!response.ok) throw new Error(`Wersja statyczna nie ma pliku data/${name}.json (${response.status}). Zbuduj ją ponownie poleceniem npm run build:static.`);
      return response.json();
    });
    // Po błędzie następne żądanie pobiera plik od nowa.
    loaded.set(name, request.catch(error => { loaded.delete(name); throw error; }));
  }
  return loaded.get(name);
}

// Adres pliku dokumentacji; repoPath jest względem folderu repozytorium.
export const staticFileUrl = repoPath => `files/${repoPath.split('/').map(encodeURIComponent).join('/')}`;

// Opis węzła. Wiersz nie ma w pliku treści, bierze ją z opisu swojego dokumentu.
async function describe(key) {
  const nodes = await load('nodes');
  const node = nodes[key];
  if (!node) throw new Error('Nie ma takiego dokumentu ani wiersza.');
  return node.content === undefined ? { ...node, content: nodes[node.docId]?.content ?? null } : node;
}

// Wyszukiwanie jak findDocuments w scripts/knowledge-index/index.js i search
// w server/workbench.js. Dokładne ID daje ten dokument, nazwa typu wszystkie
// dokumenty typu, a słowa dokumenty, w których ID, tytule albo opisie każde
// słowo jest początkiem jakiegoś słowa. Kolejność: dopasowanie w ID, na
// początku słowa tytułu, w ID albo tytule, w opisie; potem warstwa i ID.
const normalize = text => String(text ?? '').normalize('NFD').replace(/\p{M}/gu, '').replace(/ł/g, 'l').replace(/Ł/g, 'L').toLowerCase();
const wordsOf = text => normalize(text).split(/[^\p{L}\p{N}]+/u).filter(Boolean);

async function search(text, { type, limit }) {
  const graph = await load('graph');
  const trimmed = text.trim();
  const docs = graph.documents.filter(doc => !type || doc.type === type);
  const ownerId = graph.rows.find(row => row.id === trimmed)?.doc || trimmed;
  let found = docs.filter(doc => doc.id === ownerId);
  if (!found.length && graph.layers.some(layer => layer.types.includes(trimmed))) found = docs.filter(doc => doc.type === trimmed);
  if (!found.length) {
    const words = wordsOf(trimmed);
    if (!words.length) return [];
    found = docs.filter(doc => {
      const tokens = [doc.id, doc.title, doc.description].flatMap(wordsOf);
      return words.every(word => tokens.some(token => token.startsWith(word)));
    });
  }
  const needle = trimmed.toLowerCase();
  const rank = doc => {
    const id = doc.id.toLowerCase();
    const title = (doc.title || '').toLowerCase();
    if (id === needle || id.startsWith(needle)) return 0;
    if (title.split(/[^\p{L}\p{N}]+/u).some(word => word.startsWith(needle))) return 1;
    if (id.includes(needle) || title.includes(needle)) return 2;
    return 3;
  };
  const layerRank = new Map(graph.layers.map((layer, position) => [layer.id, position]));
  const layer = doc => layerRank.get(doc.layer) ?? graph.layers.length;
  return found
    .map(doc => ({ doc, rank: rank(doc), layer: layer(doc) }))
    .sort((a, b) => a.rank - b.rank || a.layer - b.layer || a.doc.id.localeCompare(b.doc.id, 'pl', { numeric: true }))
    .slice(0, limit)
    .map(({ doc }) => ({ docId: doc.id, type: doc.type, title: doc.title, description: doc.description, status: doc.status, path: doc.path, fileName: doc.fileName }));
}

// Zapytanie dla kilku węzłów startowych złożone z wyników pojedynczych węzłów
// w kolejności startów; węzeł zostaje z pierwszą drogą, jak w runQuery.
async function query({ query: name = 'change_scope', starts = [], simulateRemoval = false }) {
  if (!starts.length) throw new Error('Podaj co najmniej jeden węzeł startowy (starts).');
  const queries = await load('queries');
  if (!queries[name]) throw new Error(`Nie ma zapytania „${name}”. Dostępne: ${Object.keys(queries).join(', ')}.`);
  const nodes = new Map();
  const missing = [];
  for (const start of starts) {
    const found = queries[name][start];
    if (!found) { missing.push(start); continue; }
    for (const node of found) if (!nodes.has(node.node)) nodes.set(node.node, node);
  }
  const files = new Map();
  for (const item of nodes.values()) {
    const key = `${item.path}/${item.fileName}`;
    if (!files.has(key)) files.set(key, { path: item.path, fileName: item.fileName, docId: item.docId, title: item.title, nodes: [] });
    files.get(key).nodes.push({ node: item.node, type: item.type, via: item.via });
  }
  const result = { query: name, starts, missing, nodes: [...nodes.values()], files: [...files.values()] };
  if (simulateRemoval) result.removal = removal(await load('graph'), starts.filter(key => !missing.includes(key)));
  return result;
}

// Skutki usunięcia węzłów startowych. Kopia removal() z server/workbench.js:
// zmiana jednej wymaga tej samej zmiany w drugiej. Klucz z kropką to wiersz,
// a część przed kropką to doc-id.
function removal(graph, starts) {
  const docOf = key => key.split('.')[0];
  const isRow = key => key.includes('.');
  const removedDocs = new Set(starts.filter(key => !isRow(key)));
  const removedRows = new Set(starts.filter(isRow));
  const removed = new Set([...starts, ...graph.rows.filter(row => removedDocs.has(row.doc)).map(row => row.id)]);
  const isRemoved = key => removed.has(key) || removedDocs.has(docOf(key));
  const ownRowEntry = edge => edge.relation === 'contains' && removedRows.has(edge.target) && edge.source === edge.targetDoc;

  const broken = graph.edges
    .filter(edge => isRemoved(edge.target) && !removedDocs.has(edge.source) && !ownRowEntry(edge))
    .map(edge => ({ source: edge.source, relation: edge.relation, target: edge.target, line: edge.line, reason: 'cel nie istnieje' }));

  const nodes = [...graph.documents.map(doc => doc.id), ...graph.rows.map(row => row.id)];
  const componentsOf = skip => {
    const adjacent = new Map(nodes.filter(key => !skip(key)).map(key => [key, []]));
    for (const edge of graph.edges) {
      if (!adjacent.has(edge.source) || !adjacent.has(edge.target)) continue;
      adjacent.get(edge.source).push(edge.target);
      adjacent.get(edge.target).push(edge.source);
    }
    const component = new Map();
    let count = 0;
    for (const start of adjacent.keys()) {
      if (component.has(start)) continue;
      count++;
      const stack = [start];
      component.set(start, count);
      while (stack.length) {
        for (const next of adjacent.get(stack.pop())) {
          if (component.has(next)) continue;
          component.set(next, count);
          stack.push(next);
        }
      }
    }
    const sizes = new Map();
    for (const id of component.values()) sizes.set(id, (sizes.get(id) || 0) + 1);
    const main = [...sizes].sort((a, b) => b[1] - a[1])[0];
    return { component, main: main ? main[0] : null };
  };
  const before = componentsOf(() => false);
  const after = componentsOf(isRemoved);
  const disconnected = [...after.component]
    .filter(([key, id]) => id !== after.main && before.component.get(key) === before.main)
    .map(([key]) => key);

  return { removed: [...removed], broken, disconnected };
}

const FILES = { '/api/meta': 'meta', '/api/graph': 'graph', '/api/validation': 'validation', '/api/flow': 'flow', '/api/workflows': 'workflows', '/api/tree': 'tree' };

// Odpowiedź na żądanie api(path, body) z state/data.jsx.
export async function staticApi(path, body) {
  const url = new URL(path, 'http://wersja-statyczna');
  if (FILES[url.pathname]) return load(FILES[url.pathname]);
  if (url.pathname === '/api/doc') return describe(url.searchParams.get('id') || '');
  if (url.pathname === '/api/search') {
    return search(url.searchParams.get('q') || '', { type: url.searchParams.get('type') || undefined, limit: Number(url.searchParams.get('limit')) || 20 });
  }
  if (url.pathname === '/api/query') return query(body || {});
  throw new Error('Wersja tylko do podglądu nie zapisuje plików.');
}
