#!/usr/bin/env node
'use strict';

// Wersja statyczna Warsztatu dokumentacji, tylko do podglądu.
//
// Skrypt zapisuje w folderze wyjściowym to, co serwer zwraca pod /api:
//   data/*.json   meta, graf, walidacja, przepływ, widoki przepływu pracy,
//                 drzewo plików, opisy węzłów (nodes.json) i zapytania Zasięgu
//                 (queries.json),
//   files/…       pliki dokumentacji, które serwer udostępnia pod /api/file,
//                 pod tą samą ścieżką względem folderu repozytorium.
// Interfejs zbudowany w trybie static (vite build --mode static) czyta te
// pliki zamiast serwera (client/src/state/static.js).
//
// Zapytanie Zasięgu idzie po bazie indeksu, więc skrypt liczy je z góry dla
// każdego dokumentu i wiersza osobno. Wynik dla kilku węzłów interfejs składa
// z wyników pojedynczych węzłów: runQuery (scripts/lib/query.js) przechodzi
// węzły startowe po kolei i zostawia pierwszą drogę do węzła, więc złożenie
// daje ten sam wynik.

const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { REPO_ROOT } = require('../../../scripts/knowledge-index/sync');
const { openWorkbench } = require('./workbench');
const { metaOf, DOC_FILES } = require('./index');

const USAGE = `Użycie: node tools/docs-workbench/server/static.js --root <folder> [--out <folder>] [--db <plik>]

  --root  folder dokumentacji, na przykład project (wymagany)
  --out   folder z interfejsem zbudowanym przez vite build --mode static;
          domyślnie tools/docs-workbench/dist-static
  --db    plik bazy indeksu; domyślnie node_modules/.cache/docs-workbench-static.db`;

const OUT_DIR = path.join(__dirname, '..', 'dist-static');
// Osobna baza: wersja statyczna zwykle indeksuje inny folder niż serwer, a zmiana
// folderu przebudowuje bazę od nowa.
const DB_FILE = path.join(REPO_ROOT, 'node_modules', '.cache', 'docs-workbench-static.db');

function parseArgs(argv) {
  const options = { out: OUT_DIR, dbFile: DB_FILE };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--help' || arg === '-h') options.help = true;
    else if (arg === '--root') options.root = argv[++i];
    else if (arg === '--out') options.out = path.resolve(argv[++i]);
    else if (arg === '--db') options.dbFile = path.resolve(argv[++i]);
    else throw new Error(`Nieznana opcja: ${arg}`);
  }
  return options;
}

// Wynik polecenia git albo null poza repozytorium git.
function git(args) {
  try {
    return execFileSync('git', args, { cwd: REPO_ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
  } catch {
    return null;
  }
}

// Pliki folderu dokumentacji, które serwer udostępnia pod /api/file. Pominięte
// są nazwy od kropki i node_modules, tak jak w drzewie plików.
function docFiles(dir) {
  return fs.readdirSync(dir, { withFileTypes: true })
    .filter(entry => !entry.name.startsWith('.') && entry.name !== 'node_modules')
    .flatMap(entry => {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) return docFiles(full);
      return entry.isFile() && DOC_FILES.has(path.extname(entry.name).toLowerCase()) ? [full] : [];
    });
}

async function exportStatic({ root, out, dbFile }) {
  if (!fs.existsSync(path.join(out, 'index.html'))) {
    throw new Error(`W folderze ${out} nie ma interfejsu. Zbuduj go najpierw w folderze tools/docs-workbench: npx vite build --mode static`);
  }
  const workbench = openWorkbench({ root, dbFile });
  try {
    const dataDir = path.join(out, 'data');
    const filesDir = path.join(out, 'files');
    fs.rmSync(dataDir, { recursive: true, force: true });
    fs.rmSync(filesDir, { recursive: true, force: true });
    fs.mkdirSync(dataDir, { recursive: true });
    const sizes = {};
    const write = (name, data) => {
      const text = JSON.stringify(data);
      fs.writeFileSync(path.join(dataDir, `${name}.json`), text);
      sizes[name] = text.length;
    };

    // W CI gałąź i commit podaje Bitbucket Pipelines; git w klonie CI może
    // nie znać nazwy gałęzi.
    const meta = metaOf(workbench);
    const commit = process.env.BITBUCKET_COMMIT || git(['rev-parse', 'HEAD']);
    write('meta', {
      ...meta,
      repoRoot: null,
      branch: process.env.BITBUCKET_BRANCH || meta.branch,
      commit,
      builtAt: new Date().toISOString(),
      static: true,
    });
    const graph = workbench.graph();
    write('graph', graph);
    write('validation', await workbench.validation());
    write('flow', workbench.flow());
    write('workflows', workbench.workflows());
    write('tree', workbench.tree());

    // Opis każdego dokumentu i wiersza. Wiersz nie powtarza treści pliku:
    // interfejs bierze ją z opisu dokumentu (docId).
    const keys = [...graph.documents.map(doc => doc.id), ...graph.rows.map(row => row.id)];
    const nodes = {};
    for (const key of keys) {
      const node = workbench.describe(key);
      if (!node) continue;
      nodes[key] = node.node === node.docId ? node : { ...node, content: undefined };
    }
    write('nodes', nodes);

    // Węzły wyniku każdego zapytania dla każdego węzła startowego osobno.
    const queries = {};
    for (const name of workbench.queries()) {
      queries[name] = {};
      for (const key of keys) queries[name][key] = workbench.query(name, [key]).nodes;
    }
    write('queries', queries);

    const rootDir = path.resolve(REPO_ROOT, workbench.root);
    const files = docFiles(rootDir);
    for (const file of files) {
      const target = path.join(filesDir, path.relative(REPO_ROOT, file));
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(file, target);
    }

    const kb = bytes => `${Math.round(bytes / 1024)} KB`;
    console.log(`Wersja statyczna: ${out}`);
    console.log(`  folder dokumentacji: ${workbench.root}, commit ${commit ? commit.slice(0, 7) : 'nieznany'}`);
    console.log(`  dokumenty: ${graph.documents.length}, wiersze: ${graph.rows.length}, pliki: ${files.length}`);
    console.log(`  dane: ${Object.entries(sizes).map(([name, size]) => `${name} ${kb(size)}`).join(', ')}`);
  } finally {
    workbench.close();
  }
}

async function main(argv) {
  let options;
  try {
    options = parseArgs(argv);
  } catch (error) {
    console.error(`${error.message}\n\n${USAGE}`);
    return 2;
  }
  if (options.help || !options.root) {
    console.log(USAGE);
    return options.help ? 0 : 2;
  }
  try {
    await exportStatic(options);
    return 0;
  } catch (error) {
    console.error(error.message);
    return 1;
  }
}

if (require.main === module) {
  main(process.argv.slice(2)).then(code => { process.exitCode = code; });
}

module.exports = { exportStatic, parseArgs };
