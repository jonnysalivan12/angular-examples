import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Klient leży w client/, a zbudowany trafia do dist/, skąd serwuje go serwer.
// W trybie deweloperskim zapytania /api idą do serwera na porcie 4180.
// Tryb static (vite build --mode static) buduje wersję tylko do podglądu do
// dist-static/. Ta wersja czyta dane z plików (server/static.js), a adresy ma
// względne, więc działa z dowolnego folderu serwera plików.
export default defineConfig(({ mode }) => ({
  root: 'client',
  base: mode === 'static' ? './' : '/',
  plugins: [react()],
  build: { outDir: mode === 'static' ? '../dist-static' : '../dist', emptyOutDir: true },
  server: {
    port: 5173,
    strictPort: true,
    proxy: { '/api': { target: 'http://127.0.0.1:4180', changeOrigin: false } },
  },
}));
