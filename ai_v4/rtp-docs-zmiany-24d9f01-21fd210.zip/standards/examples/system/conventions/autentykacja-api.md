---
doc-id: CONV-002
title: "Autentykacja API"
description: "Rodzaje tokenów, którymi wywołujący potwierdza tożsamość w endpointach API."
status: draft
version: "1.0"
owner: "Tomasz Lewandowski"
relations: []
---

# Autentykacja API

## Cel

Ujednolicić sposób, w jaki endpoint sprawdza, kto go wywołuje: klient,
pracownik, usługa albo osoba, która wypełnia wniosek bez logowania.

## Zakres

Wszystkie endpointy API. Dokument API podaje rodzaj tokenu oraz wymaganą
rolę albo zakres.

## Zasady

### Token użytkownika

Klient i pracownik wywołują endpoint tokenem JWT w nagłówku
`Authorization: Bearer {token}`. Identyfikator i rolę użytkownika endpoint
bierze z tokenu, nie z treści żądania.

### Token usługi

Krok procesu i zadanie wsadowe wywołują endpoint tokenem JWT usługi,
wydanym w przepływie client credentials, w nagłówku `Authorization`. Token ma
rolę System albo zakres podany w dokumencie API. Klient ani pracownik nie
wywoła endpointu, który przyjmuje tylko token usługi.

### Token sesji wniosku

Endpoint formularza wniosku, dostępny bez logowania do bankowości,
przyjmuje token sesji wniosku w nagłówku `X-Application-Session`.

### Odrzucenie wywołania

Wywołanie bez ważnego tokenu kończy się kodem 401, a wywołanie tokenem bez
wymaganej roli albo zakresu kodem 403. Treść odpowiedzi opisuje konwencja
„Model odpowiedzi błędnej API”.
