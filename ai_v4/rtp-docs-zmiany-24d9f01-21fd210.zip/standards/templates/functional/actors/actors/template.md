---
doc-id: ACTOR-{nnn}
title: "{Nazwa bazy aktorów}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
version: "1.0"                                 # X.Y, pierwsza wersja to 1.0
owner: "{Imię Nazwisko}"
relations:
  - type: contains
    target: ROLE-{nn}                          # własna rola
---

# {Nazwa bazy aktorów}

## Kontekst biznesowy

{Środowisko biznesowe, w którym działają aktorzy}

## Cel

{Po co powstaje baza aktorów}

## Zakres

### W zakresie

{Aktorzy i role objęci bazą}

### Poza zakresem

{Aktorzy i role spoza bazy}

## Klasyfikacja aktorów

| Klasa | Definicja lokalna | Kryterium kwalifikacji |
|---|---|---|
| Biznesowy | {Kim jest aktor tej klasy w tym systemie} | {Kiedy rola jest biznesowa} |
| Systemowy | {Kim jest aktor tej klasy w tym systemie} | {Kiedy rola jest systemowa} |

## Przykład minimalny

{Jeden aktor opisany od początku do końca}

## Aktorzy

| ID | Nazwa kanoniczna | Klasa | Odpowiedzialność | Uprawnienia | Dziedziczy po |
|---|---|---|---|---|---|
| ROLE-01 | {Nazwa} | biznesowy / systemowy | {Odpowiedzialność} | {Uprawnienia} | ROLE-{nn} |

## Słownik nazw i aliasów

| Nazwa kanoniczna | Alias / nazwa historyczna |
|---|---|
| {Nazwa kanoniczna} | {Jeden alias} |
