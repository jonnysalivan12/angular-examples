---
doc-id: INT-{nnn}
title: "{Nazwa systemu}: {operacja}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
version: "1.0"                                 # X.Y, pierwsza wersja to 1.0
owner: "{Imię Nazwisko}"
relations:
  - type: realizes
    target: CAP-{nnn}                          # zdolność
  - type: consumes
    target: ENT-{Nazwa}                        # Encje
  - type: constrained_by
    target: NFR-{nnn}.NFRT-{KATEGORIA}-{nn}    # Ograniczenia NFR
  - type: applies
    target: CONV-{nnn}                         # Obsługa błędów
---

# {Nazwa systemu}: {operacja}

| Pole | Wartość |
|---|---|
| Zdolność | CAP-{nnn} |

## Cel

{Po co wołamy system zewnętrzny}

## Protokół

<!-- Dodatkowe wiersze dozwolone: pola właściwe dla protokołu, np. WSDL przy SOAP albo nazwa kolejki przy JMS. -->

| Pole | Wartość |
|---|---|
| Typ | REST / SOAP / gRPC / JMS |
| Właściciel | {Area / Tribe / Squad} |
| Endpoint | {Adres} |
| API Catalog | {Odnośnik} |

## Operacja

<!-- Źródło w żądaniu: skąd bierze się wartość pola; w odpowiedzi: dokąd trafia. Pole powiązane z encją wskazuje mapowanie ENT-{Nazwa}.{atrybut}. -->

Żądanie:

| Pole | Lokalizacja | Typ | Źródło | Opis |
|---|---|---|---|---|
| {Pole} | query / header / path / body | {Typ} | {ENT-Nazwa.atrybut, stała, parametr albo konfiguracja} | {Opis} |

Odpowiedź (tylko pola istotne dla nas):

| Pole | Lokalizacja | Typ | Źródło | Opis |
|---|---|---|---|---|
| {Pole} | header / body | {Typ} | {ENT-Nazwa.atrybut albo —} | {Opis} |

## Warunek wywołania

{Kiedy wołamy operację}

## Obsługa błędów

<!-- Limit czasu i ponawianie wywołań opisuje konwencja; tu dopisujesz skutek dla procesu. Integracja, która odstępuje od konwencji, nie wskazuje jej i opisuje własną obsługę. -->

| Sytuacja | Obsługa |
|---|---|
| 404 | {Obsługa} |
| 5xx | Ponowienia według CONV-{nnn}. {Skutek, gdy ponowienia zawiodą} |
| Przekroczenie czasu | Limit czasu według CONV-{nnn}. {Obsługa} |

## Diagram sekwencji

<!-- Wywołanie i warianty odpowiedzi. -->

```mermaid
sequenceDiagram
```

## Encje

- ENT-{Nazwa}: {jak występuje w operacji}

## Ograniczenia NFR

- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}
