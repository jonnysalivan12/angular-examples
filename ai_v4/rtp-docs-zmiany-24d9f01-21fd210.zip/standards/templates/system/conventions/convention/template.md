---
doc-id: CONV-{nnn}
title: "{Nazwa}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
version: "1.0"                                 # X.Y, pierwsza wersja to 1.0
owner: "{Imię Nazwisko}"
relations: []
---

# {Nazwa}

## Cel

{Co konwencja ujednolica i po co}

## Zakres

<!-- Bez ID dokumentów: kontrakty, które stosują konwencję, zwraca change_scope. -->

{Których kontraktów dotyczy konwencja, opisanych cechą, np. „wszystkie endpointy API” albo „endpointy z parametrem stage”}

## Zasady

<!-- Sekcja przyjmuje dowolne tabele, np. model danych albo katalog kodów. -->

### {Nazwa zasady}

{Treść zasady: tabela, model danych, przykład JSON}
