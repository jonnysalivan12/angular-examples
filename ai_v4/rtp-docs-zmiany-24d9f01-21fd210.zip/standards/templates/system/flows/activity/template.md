---
doc-id: ACT-{nnn}
title: "{Nazwa aktywności}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
version: "1.0"                                 # X.Y, pierwsza wersja to 1.0
owner: "{Imię Nazwisko}"
relations: []
---

# {Nazwa aktywności}

## Cel

{Jedno zdanie: jaki efekt daje aktywność i po co istnieje}

## Opis akcji

{Co aktywność robi, krok po kroku}

## Wejście i wyjście

| Kierunek | Dane | Opis |
|---|---|---|
| Wejście | {Dane} | {Opis} |
| Wyjście | {Dane} | {Opis} |

## Warunki i reguły

### Warunki uruchomienia

- {Warunek uruchomienia aktywności}

### Reguły i ograniczenia

- Jeśli {X}, to {Y}.

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| {Scenariusz} | {Zachowanie aktywności} |

## Zależności

<!-- Bez ID dokumentów: wywołania INT, QUE i BPMS wskazuje przepływ w kolumnie „Wywołanie”. -->

{Zależności aktywności, podane nazwą}
