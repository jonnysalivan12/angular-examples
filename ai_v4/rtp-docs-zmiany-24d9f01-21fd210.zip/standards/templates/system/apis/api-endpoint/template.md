---
doc-id: API-{nnn}
title: "{METODA} /{zasób}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
version: "1.0"                                 # X.Y, pierwsza wersja to 1.0
owner: "{Imię Nazwisko}"
relations:
  - type: realizes
    target: CAP-{nnn}                          # zdolność
  - type: consumes
    target: ENT-{Nazwa}                        # Encje
  - type: consumes
    target: INT-{nnn}                          # Zależności
  - type: consumes
    target: FLOW-{nnn}                         # Zachowanie; także BPMS-{nnn}, BPMS-{nnn}.STEP-{nn}, SPEC-WF-{nnn}
  - type: constrained_by
    target: NFR-{nnn}.NFRT-{KATEGORIA}-{nn}    # Ograniczenia NFR
  - type: applies
    target: CONV-{nnn}                         # Autentykacja; Struktura odpowiedzi błędnej
---

# {METODA} /{zasób}

| Pole | Wartość |
|---|---|
| Zdolność | CAP-{nnn} |

## Cel

{Po co istnieje endpoint}

## Parametry wejściowe

<!-- Nagłówków opisanych w konwencji nie powtarzasz. -->

| Parametr | Typ | Wymagany | Lokalizacja | Opis |
|---|---|---|---|---|
| {nazwa} | {typ} | tak / nie | query / header / path / body | {Co niesie parametr} |

## Walidacja pól wejściowych

<!-- Wszystkie reguły: format, zakresy, długość, zależności warunkowe. Bez reguł poza wymagalnością wpisz „Nie dotyczy (wymagalność opisana w Parametrach wejściowych)”. -->

| Parametr | Reguła | Kod błędu HTTP | Komunikat zwracany przez system |
|---|---|---|---|
| {nazwa} | {Reguła} | {Kod błędu HTTP} | {Komunikat zwracany przez system} |

## Złożone parametry wejściowe

<!-- Opcjonalnie, np. zaszyfrowany token zawierający kilka informacji. -->

{Budowa złożonego parametru}

## Autentykacja

<!-- Sposób autentykacji opisuje konwencja. Bez konwencji albo przy odstępstwie od niej opisujesz go tutaj. -->

Według CONV-{nnn}. {Wymagana rola}

## Zachowanie

### Przebieg podstawowy

{Co robi endpoint w typowym wywołaniu}

- FLOW-{nnn}: {którą część przebiegu opisuje przepływ}
- BPMS-{nnn}: {kiedy endpoint uruchamia proces}
- BPMS-{nnn}.STEP-{nn}: {które zadanie użytkownika endpoint przypisuje, odkłada albo kończy; zadanie złożone wskazujesz plikiem SPEC-WF-{nnn}}

### Przypadek brzegowy

<!-- Opcjonalnie. -->

- {Nazwa przypadku}: {zachowanie}

## Model odpowiedzi

<!-- Opcjonalnie, gdy struktura odpowiedzi jest nietrywialna: classDiagram i tabela pól, bez kopiowania OpenAPI. -->

```mermaid
classDiagram
```

| Pole | Typ | Opis |
|---|---|---|
| {Pole} | {Typ} | {Opis} |

## Struktura odpowiedzi błędnej

<!-- Model odpowiedzi błędnej i kody wspólne opisuje konwencja. Bez konwencji albo przy odstępstwie od niej opisujesz format tutaj. -->

Według CONV-{nnn}. {Kody błędów własnych endpointu i warunki, w których występują}

## Encje

- ENT-{Nazwa}: {jak występuje w żądaniu lub odpowiedzi}

## Zależności

<!-- Tylko integracje wołane poza przepływami; wywołań zapisanych w przepływie nie powtarzasz. -->

- INT-{nnn}: {po co endpoint go woła}

## Ograniczenia NFR

- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}
