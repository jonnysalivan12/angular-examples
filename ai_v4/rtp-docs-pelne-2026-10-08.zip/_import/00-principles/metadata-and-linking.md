---
title: "Metadane i linkowanie"
status: active
tags:
  - standard
  - principles
---

# Metadane i linkowanie

## Model metadanych

Każdy artefakt projektowy (w `docs/`, poza `docs/standard/`) używa metadanych z unikalnym identyfikatorem dokumentu:

```yaml
---
doc-id: UC-001
title: "Use Case: Zarządzanie danymi klienta"
status: draft | active | deprecated
type: capability | non-functional-requirements | use-case | api | flow | adr | integration
component: {nazwa-komponentu}          # opcjonalnie
owner: {Imię Nazwisko}                  # opcjonalnie
source-spec-ids:                       # opcjonalnie
  - BFS-001
related-doc-ids:                       # opcjonalnie
  - CAP-001
  - FLOW-001
---
```

Pliki standardu (`docs/standard/`) mogą używać uproszczonego front matter (np. bez `doc-id`).

## Zasady linkowania

### Linkowanie po ID (preferowane)

Powiązania utrzymujemy przez `doc-id`, nie przez ścieżki.

- `source-spec-ids` -> sekcja „Specyfikacje źródłowe"
- `related-doc-ids` -> sekcja „Powiązane dokumenty"
- `examples-ids` -> sekcja „Przykłady"

Hook MkDocs sam wylicza:

- tytuł dokumentu docelowego,
- typ dokumentu docelowego,
- poprawną ścieżkę względną.

To podejście jest odporne na przenoszenie plików między katalogami.

### Odnośniki inline w treści (`{{DOC-ID}}`)

Gdy w treści dokumentu wspominasz inny artefakt po jego identyfikatorze, otocz go
podwójnymi nawiasami klamrowymi: `{{TUC-07}}`. Hook MkDocs zamienia taki token na
link do dokumentu o tym `doc-id` (tekstem linku jest sam identyfikator).

- Działa wyłącznie poza blokami kodu (` ``` ` oraz inline `` ` ``) — dzięki temu
  placeholdery w przykładach szablonów (`UC-{numer}`) i literalny zapis konwencji
  pozostają nietknięte.
- Gdy `{{DOC-ID}}` nie wskazuje istniejącego `doc-id`, hook renderuje goły tekst,
  a walidator `validate_doc_ids.py` zgłasza błąd (ochrona przed literówką).
- Token musi mieć kształt identyfikatora (prefiks + segmenty, np. `{{BFS-09}}`,
  `{{EX-CAP-001}}`); zwykłe `{{slowo}}` nie jest traktowane jako odnośnik.

Aby pokazać zapis konwencji dosłownie (bez zamiany na link), umieść go w backtikach.

### Pole `owner`

`owner` (opcjonalne) wskazuje osobę odpowiedzialną za dokument (Imię Nazwisko).
Hook renderuje je w karcie dokumentu jako wiersz **Owner**. Pomiń pole, jeśli
właściciel nie jest ustalony — wiersz się wtedy nie pojawia.

`owner` zawsze wskazuje człowieka odpowiedzialnego merytorycznie za dokument.
Nie wpisujemy tu nazw modeli, agentów AI ani narzędzi, np. `GitHub Copilot`.

## Lokalizacja docelowa: mapa `type → folder`

Folder, w którym powstaje spec, jest **funkcją jego `type`** — nie wpisujemy go ręcznie
w treści. Jedynym źródłem prawdy mapy `type → folder` (+ prefiks `doc-id`) jest plik
`hooks/spec_taxonomy.yml`. Hook renderuje w karcie dokumentu wiersz **Lokalizacja docelowa**
wyliczony z `type` (folder względem `docs/`). Gdy `type` jest spoza mapy, hook używa
realnego folderu pliku; brak `type` (np. szablony `TPL-*`) → wiersz się nie renderuje.

Pełną listę typów, folderów i prefiksów znajdziesz w `hooks/spec_taxonomy.yml`.

## Walidacja i spójność

Spójność metadanych jest walidowana skryptem:

- `scripts/validate_doc_ids.py`

Skrypt sprawdza:

- unikalność `doc-id` w całym `docs/`,
- wymagane `doc-id` dla artefaktów projektowych,
- wymagane pole `type` dla plików w `docs/project/**` (poza stronami `index.md`),
- poprawność referencji: `source-spec-ids`, `related-doc-ids`,
- poprawność odnośników inline `{{DOC-ID}}` w treści (poza blokami kodu),
- brak nieobsługiwanych pól `source-spec` / `related-docs`,
- zgodność folderu specu z jego `type` wg `hooks/spec_taxonomy.yml`.

Walidacja jest uruchamiana także w CI (`validate-doc-ids` w `.gitlab-ci.yml`).

## Sekcje generowane automatycznie

Hook `hooks/doc_metadata.py` renderuje na stronie:

- „Karta dokumentu" (w tym wiersz „Lokalizacja docelowa" z `type`),
- „Specyfikacje źródłowe" (jeśli zdefiniowane),
- „Powiązane dokumenty" (jeśli zdefiniowane),
- „Przykłady" (jeśli zdefiniowane w `examples-ids`).

### Przykłady (`examples-ids`)

`examples-ids` to lista `doc-id` dokumentów-przykładów żyjących w `docs/standard/examples/`.
Używamy ich w **szablonach**, aby podpiąć w pełni wypełniony przykład bez wstawiania
go w treść szablonu. Dokumenty-przykłady:

- mają `doc-id` z prefiksem `EX-` (np. `EX-CAP-001`, `EX-NFR-001`),
- **nie** mają pola `type` (nie są specem projektowym — nie trafiają do mapy
  `type → folder` i nie wymuszają lokalizacji),
- leżą w `docs/standard/examples/{obszar}/...` w strukturze odzwierciedlającej szablon.

Hook renderuje sekcję „Przykłady" z linkami wyliczonymi po `doc-id`. Jeśli dokument
zawiera ręcznie nagłówek „Przykłady", hook nie dubluje sekcji.

Jeśli dokument zawiera ręcznie nagłówki sekcji „Specyfikacje źródłowe"
lub „Powiązane dokumenty”, hook nie duplikuje ich treści.

Sekcja „Karta dokumentu” jest zawsze renderowana automatycznie na początku strony.

## Rozszerzalność metadanych

Jeśli pojawi się potrzeba obsługi nowych metadanych, rozszerzamy hook
`hooks/doc_metadata.py` i odpowiadające reguły walidacji w `scripts/validate_doc_ids.py`.

## Statusy artefaktów

| Status | Znaczenie |
|--------|-----------|
| `draft` | W trakcie tworzenia, niezweryfikowany |
| `active` | Zweryfikowany, odzwierciedla aktualny stan systemu |
| `deprecated` | Nieaktualny — zachowujemy historię, nie usuwamy |
