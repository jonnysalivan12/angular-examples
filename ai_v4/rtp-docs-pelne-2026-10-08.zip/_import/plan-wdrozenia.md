# Plan wdrożenia decyzji z `decyzje.md`

Plan opisuje, w jakiej kolejności i w jakich plikach wdrażamy decyzje z pliku `decyzje.md`. Każdy etap kończy się uruchomieniem trzech walidatorów na przykładach i wynikiem bez błędów. Plan powstał 2026-10-08 po sprawdzeniu kodu skryptów, narzędzi i szablonów; fakty z tego sprawdzenia są w sekcji „Co wynika z kodu”.

## Stan wyjściowy

Walidatory na `standards/examples` (128 dokumentów) przed zmianami:

| Walidator | Błędy | Ostrzeżenia |
|---|---|---|
| `validate-relations.js` | 0 | 1 (REL-05 w API-005) |
| `validate-form.js` | 0 | 9 (FORM-03, brak sekcji opcjonalnych w wariantach) |
| `validate-consistency.js` | 0 | 0 |

Ten wynik jest punktem odniesienia: po każdym etapie liczba błędów ma być 0, a liczba ostrzeżeń nie większa niż tu, chyba że etap celowo zmienia regułę.

Folder `tools/docs-workbench/node_modules` nie istnieje, więc warsztat nie uruchomi się do czasu `npm install --prefix tools/docs-workbench`. Nic nie jest zatwierdzone w git: skopiowane `scripts/`, `standards/`, `tools/` i folder `_import/` czekają na zatwierdzenie.

## Kolejność etapów

| Etap | Co zmienia | Dlaczego w tym miejscu |
|---|---|---|
| 0 | zatwierdzenie stanu wyjściowego, instalacja pakietów warsztatu | czytelne różnice w git dla każdego etapu |
| 1 | model grafu: BPMN → BPMS, wiersz STEP, relacja `supersedes`, typ ADR, reguły walidatorów | wszystkie dalsze etapy odwołują się do nowych nazw typów |
| 2 | drzewo folderów szablonów, `_00-meta.md`, odczyt szablonów w `templates.js` | struktura przed treścią: późniejsze zmiany treści nie przenoszą plików |
| 3 | układ dokumentów projektu (M4): mapa typ → folder, nazwy plików, FORM-05 i FORM-06, przeniesienie przykładów | to samo: pliki na docelowych miejscach, zanim zaczniemy je edytować |
| 4 | treść szablonów i opisów typ po typie razem z przykładami, w pięciu partiach | największy etap; walidatory po każdej partii |
| 5 | docs-workbench: grupowanie z relacji, widok ADR, tabela zadań BPMS, zmiany nazw | narzędzie dostosowuje się do gotowego standardu |
| 6 | opisy: `methodology.md` w całości, README skryptów i narzędzi, agent `docs-fixer`, korpus, zamknięcie `decyzje.md` | ostatni przegląd spójności |

Fragmenty `methodology.md` i komentarzy w matrycy, które należą do etapu, zmieniamy w tym etapie. Etap 6 tylko sprawdza całość.

## Etap 0. Przygotowanie

1. Zatwierdzić w git stan wyjściowy: skopiowane foldery, konfigurację Claude, `_import/`. Jedno zatwierdzenie „stan przed wdrożeniem standardu”.
2. Uruchomić `npm install --prefix tools/docs-workbench`.
3. Zapisać wynik walidatorów ze stanu wyjściowego (tabela wyżej).

Sprawdzenie: walidatory dają wynik z tabeli „Stan wyjściowy”, `npm run build` w `tools/docs-workbench` kończy się bez błędu.

## Etap 1. Model grafu

Decyzje: ogólna 4 (BPMS, ADR), M2 (STEP i matryca), „Typ adr” 3–6, M1.1 (definicja CAP w komentarzu matrycy).

| Plik | Zmiana |
|---|---|
| `scripts/lib/ids.js` | `DOC_FORMATS`: `BPMN` → `BPMS`, nowy `ADR`. `ROW_FORMATS`: nowy `STEP` (zapis `STEP-01`). |
| `scripts/validate-relations.js` | REL-07: dokumenty typu ADR pominięte w `checkConnectivity`. REL-08: `STEP` dochodzi do `NUMBERED_ROWS`, bo numer usuniętego zadania nie wraca do obiegu (M2.1). |
| `standards/config/relation-matrix.yaml` | Komentarz typów: `BPMS`, `ADR`, nowa definicja CAP, wiersz `STEP`. Lista `relation_types`: `supersedes`. Trójki: `BPMS contains STEP` (1:N), `BPMS consumes API/INT/QUE`, `BPMS involves ROLE`, `API consumes STEP`, `SPEC-WF consumes STEP`, `ADR supersedes ADR` (1:N); odpada `SPEC-WF involves ROLE`; wszystkie `BPMN` → `BPMS`. Komentarze przy trójkach i w części „Czego nie wolno zapisać” dostosowane. |
| `standards/config/query-patterns.yaml` | `BPMN` → `BPMS`. Wzorce dla `STEP` (`change_scope`: `<-consumes- API|SPEC-WF`), dla `BPMS` dochodzi `-consumes-> API|INT|QUE` i `-involves-> ROLE` w `implementation`, wzorzec `ROLE` z `UC|TUC|BPMS` zamiast `SPEC-WF`, z `implementation` SPEC-WF znika `-involves-> ROLE`. Bez wzorców dla ADR. |
| `scripts/validate-consistency.js` | `PLACES`: miejsca dla `BPMS contains STEP` (kolumna `ID`), `BPMS involves ROLE` (kolumna `Rola`), `BPMS consumes API/INT/QUE` (kolumna `Wywołanie`) w sekcji „Zadania procesu”; `API consumes STEP` w sekcji „Zachowanie”; `SPEC-WF consumes STEP` w kolumnie `Źródło`; odpada miejsce `SPEC-WF involves ROLE` (pole „Aktor / serwis”). CONS-03 czyta typ zadania z kolumny `Typ` tabeli BPMS zamiast z pola `task-type` i sprawdza wiersz `STEP` albo plik SPEC-WF. CONS-04: nazwa typu. |
| `standards/templates/bpmn-process/` → `bpms-process/` | Tylko zmiana nazwy folderu, prefiksu w `_00-meta.md` i wzmianek `BPMN` w obu plikach. Treść szablonu zmienia etap 4. |
| `standards/examples/**` | `doc-id: BPMN-…` → `BPMS-…`, wzmianki w treści i w `relations`, nazwy plików i folderów `BPMN-001/` → `BPMS-001/` (tymczasowo, do etapu 3). |
| `standards/methodology.md` | Sekcja 3: wiersz `STEP` w tabeli wierszy i na liście numerów, które nie wracają do obiegu. Sekcja 7: przykłady z `BPMS`. Sekcja 10: tabela „Przepływy” z `BPMS`, nowa tabela dla `ADR`, definicja CAP w „Odpowiedzialność”. Sekcja 5: zdanie o CAP według M1.1. |

Ten etap nie zmienia jeszcze treści szablonów SPEC-WF i BPMS, więc przykłady nadal mają pole `task-type` i tabelę zadań ze starymi kolumnami. CONS-03 w tym etapie dostaje nową logikę, ale przykłady bez kolumny `Typ` nie mają zadań `user-task` do sprawdzenia, więc wynik jest pusty do etapu 4.

Sprawdzenie: trzy walidatory na `standards/examples` bez błędów; `node scripts/knowledge-index/cli.js sync --root standards/examples` bez błędu; zapytanie `scope` dla `BPMS-001` zwraca kroki SPEC-WF-001…003.

## Etap 2. Drzewo szablonów

Decyzje: ogólne 3, 6, 7; „Typ adr” 1 (miejsce szablonu).

Docelowe drzewo `standards/templates/`:

```text
_00-meta.md
architecture/decision-records/adr/
functional/actors/actors/
functional/business-functional-specs/business-functional-spec/
functional/data-models/ddm/
functional/technical-use-cases/technical-use-case/
functional/use-case-technical-map/use-case-technical-map/
functional/use-cases/use-case/
system/apis/api-endpoint/
system/asyncapi/asyncapi-event/
system/capabilities/capability/
system/conventions/convention/
system/data-models/ldm/
system/data-models/ldm-entity/
system/flows/activity/
system/flows/flow/
system/gui/navigation-map/navigation-map/
system/gui/screen/screen/
system/gui/screen/ui-spec/screen-section/
system/integrations/integration/
system/non-functional-requirements/non-functional-requirements/
system/state-machines/state-machine/
system/workflows/bpms-process/
system/workflows/workflow-step/
```

Każdy folder typu ma `template.md` i `guide.md`. Folder `adr/` powstaje w etapie 4 (partia 4e); tutaj tylko miejsce w spisie.

| Plik | Zmiana |
|---|---|
| `standards/templates/**` | Przeniesienie 22 folderów typów do drzewa wyżej. Odnośniki między opisami (`../api/guide.md`) na nowe ścieżki. |
| `standards/templates/_00-meta.md` | Kolumna „Typ” podaje ścieżkę folderu typu względem `templates/`, na przykład `system/apis/api-endpoint`. Opis budowy folderu typu i zdanie o nowym typie dostosowane do drzewa. |
| `scripts/lib/templates.js` | Wyrażenie czytające spis typów dopuszcza ukośnik w kolumnie „Typ”. Pole `folder` szablonu to ścieżka względna, więc komunikaty walidatora (`templates/{folder}/template.md`) pokazują pełną ścieżkę. |
| `.claude/agents/docs-fixer.md` | Ścieżki `standards/templates/{typ}/…` na nową postać. |
| `standards/methodology.md` | Sekcja 10: zdanie o miejscu szablonu i kolumna „Szablon” ze ścieżką. |

Sprawdzenie: walidatory bez błędów (forma przykładów się nie zmienia); `grep` nie znajduje starych ścieżek `templates/<typ>/` poza `_import/`.

## Etap 3. Układ dokumentów projektu (M4)

Decyzje: M4.1–M4.7, „Typ adr” 9, stm 8 i bpms 18 w wersji z M4.5.

Nowy plik `standards/config/folders.yaml`: mapa typ → folder według `_import/hooks/spec_taxonomy.yml`, kluczowana prefiksem, z regułą podfolderów (`none`, `one`, `process`, `steps`). Czytają ją `validate-form.js` (FORM-06) i `docs-workbench` (grupowanie „Folder” i widok ADR). Plik trafia do tabeli plików na początku `methodology.md`.

| Typ | Folder pod głównym folderem dokumentacji | Podfoldery |
|---|---|---|
| BFS | `functional/business-functional-specs` | jeden poziom |
| ACTOR | `functional/actors` | jeden poziom |
| DDM | `functional/data-models` | jeden poziom |
| UC | `functional/use-cases` | jeden poziom |
| TUC | `functional/technical-use-cases` | jeden poziom |
| UCMAP | `functional/use-case-technical-map` | jeden poziom |
| CAP | `system/capabilities` | jeden poziom |
| API | `system/apis` | jeden poziom |
| INT | `system/integrations` | jeden poziom |
| QUE | `system/asyncapi` | jeden poziom |
| CONV | `system/conventions` | jeden poziom |
| NFR | `system/non-functional-requirements` | jeden poziom |
| FLOW, ACT | `system/flows` | jeden poziom |
| STM | `system/state-machines` | jeden poziom |
| LDM, ENT | `system/data-models` | jeden poziom |
| SCR | `system/gui/screen` | brak |
| SCRSEC | `system/gui/screen/ui-spec` | brak |
| NAV | `system/gui/navigation-map` | brak |
| BPMS | `system/workflows/{proces}` | folder nazwany jak plik procesu |
| SPEC-WF | `system/workflows/{proces}/steps` | folder procesu, który krok zawiera |
| ADR | `architecture/decision-records` | jeden poziom |

| Plik | Zmiana |
|---|---|
| `scripts/validate-form.js` | FORM-05: nazwa pliku to małe litery, cyfry i myślniki (`^[a-z0-9]+(-[a-z0-9]+)*\.md$`), jedyna w folderze typu razem z podfolderami; encja ENT ma nazwę z doc-id (`disposition.md`). FORM-06: folder z `folders.yaml` i reguły podfolderów; folder procesu BPMS z nazwy pliku procesu, folder kroku z pliku procesu, który ma wpis `contains`. Główny folder dokumentacji to folder podany walidatorowi (albo pierwszy folder nadrzędny z `functional/`, `system/` lub `architecture/`). Funkcje `docsRoot` i `locator` znikają. |
| `standards/examples/**` | Przeniesienie 128 plików do `standards/examples/{functional,system,architecture}/…` i zmiana nazw na opisowe. Nazwy proponuje skrypt pomocniczy ze skrótu tytułu, a ostateczną listę ustalam ręcznie, bo tytuły API (`POST /account-applications/{id}/manual-verification/decision`) nie dają dobrej nazwy automatycznie. Lista nazw do akceptacji przed przeniesieniem. |
| `standards/methodology.md` | Sekcja 11 w całości od nowa: folder główny `project/`, tabela wyżej, reguła jednego poziomu podfolderów, nazwy plików, pliki pomocnicze w `assets/`, zdanie, że narzędzia liczą grupowanie z relacji, a nie z folderu. Odpadają reguły z M4.6. |
| `scripts/README.md` | Opis FORM-05 i FORM-06 oraz sekcja „Jak walidator wylicza folder”. Ścieżki w przykładach wywołań. |
| `scripts/knowledge-index/README.md` | Ścieżki w przykładach wyników. |

`.mcp.json` zostaje z `--root standards/examples`, bo folder `project/` powstanie dopiero z pierwszym dokumentem projektu.

Sprawdzenie: walidatory bez błędów, w tym FORM-05 i FORM-06 na wszystkich 128 plikach; `knowledge-index sync` indeksuje 128 dokumentów; `find standards/examples -name "*.md"` nie zawiera nazw z doc-id (`uc-001.md`).

## Etap 4. Treść szablonów i opisów typ po typie

Decyzje: T1–T11, M1, M2 (treść BPMS i SPEC-WF), M3, cała sekcja „Decyzje typ po typie”, „Typ adr” 1–2, usterki 1–4.

Zasady wspólne dla wszystkich partii:

- `template.md` dostaje nowe sekcje, tabele i pola z decyzji; komentarz HTML tylko tam, gdzie oznacza regułę sekcji albo kolumnę opcjonalną (T4).
- `guide.md` dostaje uzasadnienia sekcji (T4), listę pytań przygotowawczych (T9), odesłania „Nie używaj gdy” (T10) i reguły z decyzji typu.
- Przykłady w `standards/examples` dostają nową formę w tej samej partii, więc `validate-form` po partii jest bez błędów.
- Sekcja „Powiązane dokumenty” znika z `event`, `bpms-process`, `workflow-step` i z ich przykładów (usterka 1).

| Partia | Typy | Co szczególnego |
|---|---|---|
| 4a | actors, business-functional-spec, ddm, use-case, technical-use-case, use-case-technical-map | UC bez BFS dozwolony (uc 16); nagłówki `### A1.` i `### E1.` zostają, bo `templates.js` rozpoznaje wiersz tylko z kropką albo spacją (uc 19). |
| 4b | capability, api-endpoint, asyncapi-event, integration, convention, non-functional-requirements | CAP według M1: nowe sekcje i cztery tabele. int 6: nowy znacznik w szablonie „dodatkowe wiersze dozwolone” dla tabeli „Pole \| Wartość” i obsługa w `validate-form.js` (dziś walidator odrzuca nieznany wiersz). |
| 4c | flow, activity, bpms-process, workflow-step | M2: tabela „Zadania procesu” z kolumnami `ID \| W silniku \| Typ \| Nazwa \| Rola \| Wywołanie \| Opis działania \| SPEC-WF`, osiem typów zadań (wf 9), bramki i zdarzenia graniczne jako tabele; SPEC-WF bez `task-type`, „Kontekst” i „Aktor / serwis”. W pięciu przykładowych BPMS każde zadanie dostaje wiersz `STEP`; 15 plików SPEC-WF zostaje jako kroki złożone; w co najmniej jednym procesie dochodzi małe zadanie tylko jako wiersz `STEP` z rolą i wywołaniem, żeby nowe trójki miały przykład. Role dwóch kroków `user-task` przechodzą z SPEC-WF do kolumny `Rola`. bpms 7: puste `process-version` przechodzi przez walidator już dziś. |
| 4d | ldm, ldm-entity, state-machine, screen, screen-section, navigation-map | Tabele w LDM (ldm 2, 4, 5), podsekcje typów wyliczeniowych (ent 6), tabela scenariuszy błędów STM (stm 4), konwencja krawędzi NAV (nav 2). |
| 4e | adr | Nowy folder `architecture/decision-records/adr/` z `template.md` i `guide.md`; `status` z listą `draft \| active \| deprecated`; wpis w `_00-meta.md` w nowej grupie „Architektura”. Przykłady: trzy ADR w `standards/examples/architecture/decision-records/`, w tym jedna para `supersedes` ze statusem `deprecated`. |

Po partii 4e: `standards/templates/_00-meta.md` dostaje zasady wspólne „Nie dotyczy” (T5) i `> Założenie:` (T6), zdanie o statusie `deprecated` tylko dla ADR, tabelę pól wspólnych bez zmian. `standards/methodology.md`: sekcja 4 o spójności grafu dostaje zdanie o wyjątku dla ADR, sekcja 8 wiersz o REL-07.

Sprawdzenie po każdej partii: trzy walidatory bez błędów; liczba ostrzeżeń FORM-03 może się zmienić, bo zmieniają się warianty, i jest zapisywana w raporcie etapu. Po 4e dodatkowo: `validate-relations` nie zgłasza REL-07 dla ADR, a zgłasza je dla dokumentu testowego innego typu bez relacji.

## Etap 5. docs-workbench

Decyzje: M4.3 i M4.7 (grupowanie z relacji), wymaganie przy typach (grupowanie po BFS jako opcja), „Typ adr” 7, M2 (tabela zadań), ogólna 4 (nazwy).

| Plik | Zmiana |
|---|---|
| `server/workbench.js` | `groupOf` liczy grupę z relacji zamiast z folderu: opcja „Proces” to BFS, do którego dokument dochodzi łańcuchem `realizes` (jak dawny `locator` w `validate-form.js`); dokument bez drogi do BFS nie ma grupy procesu i nie jest widoczny w tym grupowaniu. Opcja „Folder” bierze folder z `folders.yaml`. Etykiety wierszy `STEP` z kolumny `Nazwa`, a nie z drugiej komórki. |
| `server/layers.js` | `BPMS` zamiast `BPMN`, wiersz `STEP` w warstwie przepływów, nowa warstwa `arch` dla `ADR`. |
| `server/workflows.js` | Parser tabeli „Zadania procesu” czyta kolumny `ID`, `W silniku`, `Typ`, `Nazwa`, `Rola`, `Wywołanie`, `SPEC-WF`; zadania bez SPEC-WF pokazują opis z wiersza. Nowe dane widoku ADR: lista decyzji ze statusem i łańcuchem `supersedes`. |
| `client/src/catalog/model.js`, `map/model.js`, `workflow/model.js`, `components/LeftPanel.jsx`, `components/Inspector.jsx`, `flow/model.js` | `BPMN` → `BPMS`; `supersedes` na liście relacji; etykieta grupy bez `processes/`; ADR wyłączone z Mapy i Zasięgu; nowy widok „Decyzje architektoniczne” w trybie Przepływ albo jako osobny tryb. |
| `client/src/styles/app.css` | Kolor warstwy `--l-arch` w obu motywach. |
| `README.md` warsztatu | Grupy, widoki, nazwy typów. |

Sprawdzenie: `npm run build` bez błędów; serwer na `standards/examples` przez `.claude/launch.json`; w przeglądarce sprawdzam Mapę z grupowaniem „Proces” i „Folder”, katalog typu BPMS, widok „Procesy BPMS i kroki” z wierszami STEP, widok ADR z łańcuchem zastąpień, panel walidacji z wynikiem zgodnym z wierszem poleceń.

## Etap 6. Opisy i zamknięcie

| Plik | Zmiana |
|---|---|
| `standards/methodology.md` | Przegląd całości po etapach 1–5: słownik pojęć, sekcje 3–11, przykłady z korpusu po nowych nazwach. |
| `standards/config/relation-matrix.yaml` | Przegląd komentarzy po etapie 4: nazwy sekcji i kolumn, w których stoją cele wpisów. |
| `standards/examples/documentation-corpus.yaml` | `BPMN` → `BPMS`, wpisy STEP w pięciu procesach, trzy ADR. Nagłówek pliku mówi o 211 dokumentach, a przykładów jest 128; do wyjaśnienia, czy korpus ma zostać, bo odwołuje się do niego tylko `methodology.md`. |
| `scripts/README.md`, `scripts/knowledge-index/README.md`, `tools/docs-workbench/README.md` | Nazwy typów, kody walidatorów, ścieżki, opis CONS-03. |
| `.claude/agents/docs-fixer.md` | Nowe reguły (ADR bez relacji, STEP, nazwy plików). |
| `_import/decyzje.md` | „Otwarte sprawy” → brak; odnośnik do tego planu. |
| pamięć sesji | Notatka o zamkniętym wdrożeniu. |

Sprawdzenie końcowe: trzy walidatory bez błędów; `knowledge-index` CLI i serwer MCP startują na `standards/examples`; warsztat buduje się i działa; `grep -r "BPMN"` poza `_import/`, `package-lock.json` i nazwami pliku `.bpmn` zwraca tylko odwołania do notacji BPMN 2.0.

## Co wynika z kodu

Fakty sprawdzone w skryptach i narzędziach 2026-10-08, na których opiera się plan:

1. `scripts/lib/templates.js` czyta spis typów z `_00-meta.md` wyrażeniem, które w kolumnie „Typ” dopuszcza tylko `[a-z0-9-]`, więc nowe drzewo wymaga zmiany tego wyrażenia (etap 2).
2. `scripts/lib/ids.js` ma typy dokumentów i wierszy na stałe w `DOC_FORMATS` i `ROW_FORMATS`; `scripts/lib/matrix.js` odrzuca trójkę z nieznanym typem. Dlatego `BPMS`, `ADR` i `STEP` dochodzą najpierw w `ids.js` (etap 1).
3. `matrix.js` liczy właścicieli wierszy z trójek `contains`, więc `BPMS contains STEP` w matrycy wystarczy, żeby `STEP-01` był wierszem BPMS. Lista `relation_types` też pochodzi z matrycy, więc `supersedes` nie wymaga zmian w walidatorach.
4. `validate-form.js`, funkcja `checkTable`: w tabeli „Pole | Wartość” nieznany wiersz jest błędem FORM-04. Decyzja int 6 (dodatkowe wiersze protokołu) wymaga nowego znacznika w szablonie i obsługi w walidatorze.
5. `validate-form.js`, funkcja `checkFrontMatter`: pole bez listy wartości może być puste. Puste `process-version` (bpms 7) przechodzi bez zmian w kodzie.
6. `validate-consistency.js`, CONS-03, czyta pole `task-type` z front matter SPEC-WF. Po M2 to pole znika, więc reguła musi czytać kolumnę `Typ` z tabeli BPMS.
7. `validate-relations.js`, `checkConnectivity` (REL-07), zgłasza każdy dokument bez powiązań, więc ADR wymaga wyjątku.
8. `sync-relations.js` wylicza relacje ze wzmianek identyfikatorów w treści, bez wiedzy o sekcjach, więc zmiany układu szablonów go nie dotyczą.
9. `tools/docs-workbench/server/workbench.js`, `groupOf`, bierze grupę z segmentów ścieżki `processes/` i `shared/`. Po M4 ten kod traci sens i grupowanie musi wynikać z relacji.
10. `tools/docs-workbench/server/workflows.js` szuka makiety po nazwie pliku dokumentu w `assets/`, co zgadza się z M4.5 bez zmian w kodzie. Tabelę zadań czyta po nagłówkach `ID zadania`, `Nazwa`, `SPEC-WF`, więc nowe kolumny wymagają zmiany parsera.
11. `scripts/knowledge-index` zapisuje ścieżki względem folderu repozytorium i nie zakłada układu folderów; zmiana układu nie wymaga zmian w kodzie, tylko w README.
12. W przykładach jest 15 plików SPEC-WF: 10 `service-task`, 2 `user-task`, 2 `script-task`, 1 `call-activity`.

## Założenia planu do potwierdzenia

1. **Nazwy folderów typów.** Decyzja ogólna 6 daje folder typu z nazwy ich pliku, więc trzy typy zmieniają nazwę folderu: `actor` → `actors`, `api` → `api-endpoint`, `event` → `asyncapi-event`. Nazwa folderu jest też nazwą typu w komunikatach walidatora. W kilku miejscach drzewa nazwa się dubluje, na przykład `system/gui/screen/screen/`.
2. **Miejsce mapy typ → folder.** Plan zakłada nowy plik `standards/config/folders.yaml`. Alternatywa to kolumna w `_00-meta.md`, ale wtedy warsztat musiałby czytać Markdown.
3. **Nazwy plików przykładów.** Plan zakłada nazwy dobrane ręcznie ze skrótu tytułu, a nie wyliczone automatycznie. Listę 128 nazw przedstawię do akceptacji w etapie 3.
4. **Jedyność nazwy pliku.** Decyzja M4.4 mówi o nazwie jedynej „w folderze”. Plan przyjmuje: jedyna w folderze typu razem z jego podfolderami.
5. **Układ przykładów.** Przykłady zostają w `standards/examples/`, a w środku mają układ `functional/`, `system/`, `architecture/`, czyli taki, jaki dostanie `project/`.
6. **Korpus `documentation-corpus.yaml`.** Zostaje i jest tylko dostosowany, chyba że ma zniknąć.
7. **Zatwierdzenie w git przed etapem 1.** Plan zakłada jedno zatwierdzenie stanu wyjściowego i po jednym na etap.

## Dziennik wdrożenia

Wpis na etap: co zrobiono, czym się różni od planu, wynik sprawdzenia, zatwierdzenie w git.

### Etap 0 (2026-10-08)

Zatwierdzenie `c6a9bdc` z folderem `_import/`; skopiowane foldery były już zatwierdzone wcześniej (`3b23f56`). Pakiety warsztatu zainstalowane, `npm run build` przechodzi. Walidatory: wynik z tabeli „Stan wyjściowy”.

### Etap 1 (2026-10-08)

Zrobione według planu: `ids.js` (BPMS, ADR, STEP), `validate-relations.js` (REL-07 pomija ADR, REL-08 liczy STEP), `validate-consistency.js` (miejsca dla nowych trójek BPMS i STEP), `validate-form.js` (nazwa typu), matryca (trójki, `supersedes`, grupa 8, komentarze), wzorce zapytań (STEP, blok `implementation` dla BPMS), `methodology.md` (sekcje 3, 4, 5, 7, 8, 10), zmiana nazw w szablonach i przykładach (folder `bpms-process`, pliki `bpms-00x.md`, foldery `BPMS-00x/`, wzmianki typu). Słowo „BPMN” zostało tam, gdzie oznacza notację: „BPMN XML”, „Silnik BPMN”, „błąd BPMN”, „task BPMN”.

Różnice od planu:
- Trójka `SPEC-WF involves ROLE` zostaje do partii 4c, bo dwa przykładowe kroki `user-task` podają rolę w polu „Aktor / serwis”, a tabela procesu nie ma jeszcze kolumny `Rola`. Wzorce zapytań dla ROLE i `implementation` SPEC-WF też tymczasowo zachowują SPEC-WF.
- CONS-03 nadal czyta pole `task-type`; przejście na kolumnę `Typ` w partii 4c, razem ze zmianą tabeli.
- Sekcje 4 i 8 `methodology.md` (wyjątek ADR w REL-07) zmienione już teraz, razem z kodem walidatora, a nie w partii 4e.

Sprawdzenie: trzy walidatory na przykładach bez błędów (ostrzeżenia 1, 9, 0 jak w stanie wyjściowym); `knowledge-index` indeksuje 128 dokumentów; `scope BPMS-001` zwraca trzy kroki i API-006; test na plikach tymczasowych: ADR-001 i ADR-002 z relacją `supersedes` bez zgłoszeń, CONV-099 bez relacji dostaje REL-07.

### Etap 2 (2026-10-08)

Zrobione według planu: 22 foldery typów przeniesione do drzewa `functional/`, `system/` (skrypt pomocniczy z `git mv`), odnośniki między opisami i do `methodology.md` przepisane na nowe ścieżki (sprawdzone: żaden odnośnik w `standards/templates` nie wskazuje brakującego pliku), `_00-meta.md` z kolumną „Typ” jako ścieżką i opisem warstw, `scripts/lib/templates.js` czyta ścieżkę z ukośnikami, `docs-fixer.md` i `methodology.md` (sekcja 10, nazwy typów `actors`, `api-endpoint`, `asyncapi-event`) dostosowane. Folder `adr/` powstanie w partii 4e.

Różnice od planu: brak. Do etapu 6 zostają wzmianki „`guide.md` typu api” w `scripts/README.md`.

Sprawdzenie: `loadTemplates()` zwraca 22 typy ze ścieżkami; trzy walidatory bez błędów (ostrzeżenia 1, 9, 0).

### Etap 3 (2026-10-08)

Zrobione według planu: `standards/config/folders.yaml` (23 typy, reguły `none`, `one`, `process`, `steps`) i czytnik `scripts/lib/folders.js`; `validate-form.js` z nowymi FORM-05 i FORM-06 (funkcja `locator` i stary `docsRoot` usunięte); 128 przykładów przeniesionych skryptem pomocniczym z `git mv` według zaakceptowanej listy `_import/nazwy-przykladow.md`, foldery `processes/` i `shared/` usunięte; sekcja 11 i tabela plików w `methodology.md`; opis FORM-05 i FORM-06 oraz ścieżki w `scripts/README.md` i `scripts/knowledge-index/README.md`. `.mcp.json` bez zmian.

Różnice od planu:
- Główny folder dokumentacji to zawsze pierwszy folder nadrzędny pliku z podfolderem `functional/`, `system/` albo `architecture/`, a nie folder podany walidatorowi. Wersja z planu dawała 128 fałszywych błędów FORM-06 przy wywołaniu na samej warstwie (`validate-form.js standards/examples/system`).
- Lista nazw leży w `_import/nazwy-przykladow.md`, a skrypt przenoszący czyta ją z tabel; skrypt pomocniczy nie proponował nazw automatycznie.
- Ekrany nadal wskazują pliki `assets/scr-00x-….png`, których nie ma w repozytorium; nazwy według M4.5 w etapie 4 razem z treścią szablonu ekranu.
- `documentation-corpus.yaml` i opisy warsztatu w `tools/docs-workbench` nadal opisują układ `processes/`, `shared/`; warsztat w etapie 5, korpus w etapie 6.

Sprawdzenie: trzy walidatory bez błędów (ostrzeżenia 1, 9, 0); FORM-05 i FORM-06 dają ten sam wynik dla całości, dla dwóch warstw osobno, dla jednego folderu typu i dla jednego pliku; kopia `uc-001.md` w `system/apis/x/` dostaje FORM-05 z podpowiedzią `zlozenie-dyspozycji.md` i FORM-06 z folderem `functional/use-cases/`; `knowledge-index sync` indeksuje 128 plików, `scope BFS-001.REQ-01` nadal 14 węzłów w 14 plikach, `scope ENT-Disposition` 14 węzłów w 13 plikach; żaden plik w `standards/examples` nie nosi doc-id.

### Etap 4 (2026-10-08)

Zrobione według planu, w pięciu partiach:
- 4a: `actors`, `business-functional-spec`, `ddm`, `use-case`, `technical-use-case`, `use-case-technical-map`: nowe sekcje i tabele z decyzji, pytania przygotowawcze i uzasadnienia sekcji w opisach, warianty UC i TUC „Uproszczony” i „Złożony”; 18 przykładów dostosowanych skryptem pomocniczym.
- 4b: `capability` według M1 (nowe sekcje, cztery tabele; sześć przykładów CAP napisanych od nowa), `api-endpoint`, `asyncapi-event` (bez „Powiązanych dokumentów”), `integration` (znacznik „Dodatkowe wiersze dozwolone” w szablonie i obsługa `extraRows` w `templates.js` i `validate-form.js`), `convention`, `non-functional-requirements`.
- 4c: M2. Tabela „Zadania procesu” z kolumnami `ID | W silniku | Typ | Nazwa | Rola | Wywołanie | Opis działania | SPEC-WF`, osiem typów zadań, bramki i zdarzenia graniczne jako tabele, ścieżki `assets/{nazwa-pliku}.bpmn` i `.svg`; pięć procesów BPMS napisanych od nowa z wierszami `STEP` (BPMS-003 dostał małe zadanie STEP-01 z wywołaniem API-007, a SPEC-WF-009 bierze z niego zmienne: przykład trójek `BPMS consumes API` i `SPEC-WF consumes STEP`); 15 kroków SPEC-WF bez `task-type`, „Kontekstu”, „Aktora / serwisu” i „Powiązanych dokumentów”, z tabelami błędów i zdarzeń granicznych i nazwami kryteriów `### AC-01. {Nazwa}`; role dwóch zadań `user-task` w kolumnie „Rola”; przepływy bez dopisku „— przebieg podstawowy”, plik błędów z dopiskiem „: obsługa błędów”, aktywności z podziałem „Warunki uruchomienia” i „Reguły i ograniczenia”. `validate-consistency.js`: CONS-03 czyta wiersze `user-task` tabeli procesu (rola w kolumnie i API z wpisem `consumes` do wiersza STEP albo pliku SPEC-WF), miejsce `SPEC-WF involves ROLE` usunięte; trójka usunięta z matrycy i wzorców zapytań; opis CONS-03 w `scripts/README.md`.
- 4d: `ldm` (tabele encji, relacji i słowników, legenda liczebności, tabela typów logicznych i lista „Czego nie umieszczać” w opisie), `ldm-entity` (podsekcje `### {NazwaEnum}` z tabelą wartości, sekcja opcjonalna), `state-machine` (zdanie pod tabelą, stany jako `{Kod}. {Status}` w tabeli przejść i na diagramie, tabela błędów `| Scenariusz | Stan | Zachowanie |`), `navigation-map` (konwencja krawędzi, dwa punkty nawigacji, tabela błędów), `screen` (akapit opisu, dwa obrazy całego ekranu `assets/{nazwa-pliku}.png` i `-sekcje.png`, punkt „Odnośniki i akcje dodatkowe”), `screen-section` (wiersz „WCAG”, zapis analityki, numerowane reguły z nazwą, podsekcje zachowań); 44 przykłady dostosowane skryptem pomocniczym.
- 4e: nowy folder `standards/templates/architecture/decision-records/adr/` z `template.md` i `guide.md`, grupa „Architektura” w `_00-meta.md`, trzy przykłady w `standards/examples/architecture/decision-records/` (ADR-003 `supersedes` ADR-001, ADR-001 ze statusem `deprecated`). `_00-meta.md` dostał zasady wspólne „Nie dotyczy” (T5) i `> Założenie:` (T6) oraz zdanie o statusie `deprecated` tylko dla ADR.

Różnice od planu:
- 4c: żadne małe zadanie nie ma roli; rola stoi tylko w dwóch zadaniach `user-task`, które mają pliki SPEC-WF. Trójka `BPMS involves ROLE` ma przykład, ale nie w wierszu bez pliku.
- 4c: sekcja „Scenariusze błędów” przepływu ma w szablonie komentarz z „opcjonalna”, bo plik podstawowy pomija ją, gdy obsługę błędów opisuje osobny plik; bez komentarza FLOW-001 dostawałby ostrzeżenie FORM-03.
- 4d: tabela błędów STM zawiera tylko scenariusze, które kończą obiekt poza główną ścieżką (stm 4); odrzucone operacje bez zmiany stanu przeszły do „Kluczowych elementów”. Kolumna „Stan” używa zapisu `{Kod}. {Status}` jak tabela przejść.
- 4d: w NAV-002 krawędź „silnik procesów tworzy zadanie” zniknęła z diagramu, bo nie jest ani akcją użytkownika, ani błędem technicznym (nav 2); lista zadań została osobnym wejściem, a prozę o przejściu przez silnik zachowały „Kluczowe elementy”. NAV-002 i NAV-010 dostały po jednej przerywanej krawędzi błędu technicznego, żeby konwencja miała przykład.
- 4d: pseudokod „Zachowań specjalnych” w sekcjach ekranu przepisany na podsekcje prozą; opis typu dopuszcza prozę albo pseudokod.
- 4e: nowa decyzja musi wymienić w treści ID decyzji zastępowanej, bo REL-01 zgłasza wpis `supersedes` bez wzmianki; opis typu to zapisuje.
- Odesłania „Nie używaj gdy” dostały dodatkowe typy tam, gdzie decyzja T10 ich nie wymieniała, np. `state-machine` w opisach LDM i ENT.

Sprawdzenie: trzy walidatory na przykładach bez błędów (dokumenty 131; ostrzeżenia 1, 10, 0; FORM-03: UC-005 bez dwóch sekcji wariantu uproszczonego, CAP-002 bez pięciu sekcji, UCMAP-001 bez tabeli i dwóch sekcji); `loadTemplates()` zwraca 23 typy; test tymczasowy CONS-03: usunięcie roli i pliku SPEC-WF z wiersza `user-task` BPMS-002 daje dwa błędy; test tymczasowy REL-07: CONV-099 bez relacji dostaje błąd, trzy ADR nie; `knowledge-index sync` indeksuje 131 plików, `describe ADR-003` pokazuje `supersedes ADR-001`, `scope BPMS-003.STEP-01` zwraca BPMS-003 i SPEC-WF-009; żaden odnośnik względny w `standards/templates` nie wskazuje brakującego pliku. Do etapu 5: `tools/docs-workbench` nadal parsuje starą tabelę zadań. Do etapu 6: `.claude/agents/docs-fixer.md` opisuje CONS-03 przez `task-type`, `documentation-corpus.yaml` nie zna STEP ani ADR.

### Etap 5 (2026-10-08)

Zrobione według planu, w folderze `tools/docs-workbench`:
- `server/layers.js`: `BPMS` zamiast `BPMN`, wiersz `STEP` w warstwie przepływów, nowa warstwa `arch` („Architektura”) z typem `ADR`.
- `server/workbench.js`: funkcja `processesOf` liczy procesy dokumentu z relacji łańcuchem do BFS (jak dawny `locator`), graf dostaje pole `group` (proces) i `folder` (folder typu z `folders.yaml`), grupy mają rodzaj `process` albo `shared`; etykieta wiersza bierze komórkę kolumny „Nazwa”, gdy tabela ją ma; widok przepływu danych zalicza SPEC-WF do zdolności przez `BPMS`.
- `server/workflows.js`: parser tabeli „Zadania procesu” czyta kolumny `ID`, `W silniku`, `Typ`, `Nazwa`, `Rola`, `Wywołanie`, `Opis działania`, `SPEC-WF`; zadanie bez pliku SPEC-WF pokazuje opis z wiersza; bramki z tabeli „Bramki i warunki”, zdarzenia graniczne z tabeli, uwagi do zadań z prozy sekcji; kolumna „Źródło” wejścia SPEC-WF przyjmuje też zadanie `BPMS-nnn.STEP-nn`; plik diagramu i makieta szukane najpierw względem folderu dokumentu (`assets/{nazwa-pliku}.bpmn`, `assets/{nazwa-pliku}.png`); nowe dane `decisions` dla widoku ADR (status, wybrana opcja, łańcuch `supersedes` w obie strony).
- Klient: widoki `bpms` (dawne `bpmn` w adresie nadal działa) i `adr` w trybie Przepływ; karta zadania z ID wiersza, typem, rolą, wywołaniami i krokiem SPEC-WF albo opisem; karta decyzji ze statusem, przekreślona dla `deprecated`; Mapa grupuje według „Proces” (pole `group`), „Folder typu” (pole `folder`) albo warstwy, a ADR nie trafia na Mapę, do Zasięgu ani do wyszukiwarki koszyka (klawisze `Z` i `I` pokazują komunikat); szczegóły ADR mają przycisk „Decyzje” zamiast Zasięgu i Implementacji; panel po lewej: opcja „Folder typu”, warstwy bez `arch`, notka z liczbą dokumentów bez procesu, sekcje „Bramki i warunki”, „Zdarzenia graniczne” i „Uwagi do zadań” dla BPMS, lista ADR według statusu; inspektor podpisuje grupę jako „proces BFS”, „wspólne dla procesów” albo „folder typu”; kolor warstwy `--l-arch` w obu motywach.
- `README.md` warsztatu: grupy z relacji, widoki BPMS i ADR, nazwy makiet według M4.5, etykieta wiersza z kolumny „Nazwa”, tabela API.

Różnice od planu:
- Dokument z drogą do kilku BFS trafia do grupy wspólnej (`BFS-001 + BFS-002`), a nie do jednej z nich; w korpusie to jeden dokument.
- Panel po lewej podaje liczbę dokumentów bez procesu i odsyła do grupowania według warstwy albo folderu; sama Mapa ich w grupowaniu „Proces” nie pokazuje, zgodnie z planem.
- Widok ADR to pozycja listy „Widok” w trybie Przepływ, nie osobny tryb; wyszukiwarka `Ctrl K` nadal znajduje ADR i otwiera inspektor.
- Opcja grupowania nazywa się „Folder typu”, nie „Folder”, bo bierze folder typu z `folders.yaml`, a nie podfolder pliku.
- Etykieta zadania na diagramie bpmn-js pokazuje ID wiersza `STEP`, gdy zadanie nie ma pliku SPEC-WF.
- README warsztatu ma końce wierszy CRLF; skrypt pomocniczy musiał je zachować.

Sprawdzenie: `npm run build` bez błędów; serwer przez `.claude/launch.json` na `standards/examples`; w przeglądarce Mapa „Proces” pokazuje 106 dokumentów w 4 grupach (BFS-001, BFS-002, BFS-003, BFS-001 + BFS-002) i notkę o 22 dokumentach bez procesu, „Folder typu” 128 dokumentów w 19 grupach, katalog typu BPMS 5 dokumentów (BPMS-004 bez użyć); widok „Procesy BPMS i kroki” dla BPMS-003 pokazuje STEP-01 (`service-task`, wywołanie API-007, opis z wiersza) i STEP-02 z krokiem SPEC-WF-009 oraz linię zmiennych z SPEC-WF-008 jako kroku spoza procesu; widok „Decyzje architektoniczne” pokazuje ADR-001 przekreślone ze statusem `deprecated`, strzałkę `supersedes` od ADR-003 i listę według statusu; inspektor wiersza `BPMS-003.STEP-01` ma etykietę „Pobranie reklamowanej dyspozycji” i wpis przychodzący `consumes` z SPEC-WF-009; inspektor ADR-003 pokazuje `supersedes ADR-001` bez przycisków Zasięgu; panel walidacji liczy 131 dokumentów, 0 błędów i 11 ostrzeżeń (1 relacje, 10 forma, 0 spójność), tyle samo co trzy walidatory z wiersza poleceń; konsola przeglądarki bez błędów. Do etapu 6: README warsztatu do przeglądu razem z pozostałymi opisami; folder `dist/` nie jest w repozytorium.

### Etap 6 (2026-10-08)

Zrobione według planu:
- `standards/methodology.md`: przegląd sekcji 1–11 po etapach 1–5; nazwy BPMS, STEP, ADR, układ folderów i nazwy plików były już wpisane w etapach 1–3. Zmieniony opis korpusu w tabeli plików (214 wpisów; identyfikatory w przykładach pochodzą z korpusu, nazwy plików z `examples/`) i dopisek o drugim obrazie ekranu `-sekcje.png` w „Plikach pomocniczych”.
- `standards/config/relation-matrix.yaml`: komentarze porównane z szablonami po etapie 4. Poprawione trzy miejsca: tabele „Wejście” i „Wyjście” sekcji „Zmienne procesowe” (SPEC-WF consumes SPEC-WF, STEP), podsekcja „Odbierane” (CAP consumes QUE), kolumna „Relacja” tabeli „Powiązania” (ENT contains ENT). Pozostałe nazwy pól, kolumn i sekcji zgadzają się z szablonami.
- `standards/examples/documentation-corpus.yaml`: nagłówek (214 dokumentów), wpisy `contains STEP-nn` w trzech procesach korpusu (BPMS-001, BPMS-010, BPMS-011), nowa sekcja `architecture` z ADR-001 (`deprecated`), ADR-002 i ADR-003 (`supersedes ADR-001`). Korpus zostaje: z niego pochodzą identyfikatory w przykładach metodyki i matrycy (np. UC-011, API-016, SPEC-WF-014), których nie ma w `standards/examples`; żaden skrypt go nie czyta.
- `scripts/README.md`: BPMS zamiast BPMN w sześciu miejscach (reguły wzmianek, tabela niezgodności, przykład kolejności wpisów, CONS-04, tabela miejsc CONS-01), nowy wiersz miejsc BPMS (kolumny „ID”, „SPEC-WF”, „Rola”, „Wywołanie”), STEP w miejscach API i SPEC-WF. `scripts/knowledge-index/README.md` i `tools/docs-workbench/README.md` bez zmian: po etapach 3 i 5 nie mają starych nazw ani ścieżek.
- `.claude/agents/docs-fixer.md`: wiersz `folders.yaml` w źródłach zasad, trzecia zasada wspólna (ADR bez wpisów do innych typów; wzmianka o ID innego typu → nazwa dokumentu), przykład `BPMS-001.STEP-01` przy REL-01, uwaga o REL-07 i ADR, CONS-03 przez kolumnę „Rola” tabeli „Zadania procesu” i sekcję „Zachowanie” API z wierszem STEP albo plikiem SPEC-WF, FORM-05 i FORM-06 z zasadami nazw, folderów i plików `assets/`.
- `_import/decyzje.md`: „Otwarte sprawy” → brak, z odnośnikiem do tego planu.
- Komentarze w kodzie warsztatu (`client/src/styles/app.css`, `client/src/map/model.js`): nazwy widoków i grup bez BPMN i `shared/domains`.
- Pamięć sesji: notatka o decyzjach ze standardu docs-standards opisuje wdrożenie jako zakończone.

Różnice od planu:
- Korpus ma trzy procesy BPMS, nie pięć; wpisy STEP dostały wszystkie trzy.
- Korpus nie został usunięty ani zastąpiony przykładami; pytanie z planu, czy ma zostać, czeka na decyzję użytkownika.
- `scripts/knowledge-index/README.md` i `tools/docs-workbench/README.md` nie wymagały zmian.

Sprawdzenie końcowe: trzy walidatory na `standards/examples` bez błędów (131 dokumentów; ostrzeżenia 10, 1, 0); `knowledge-index sync` indeksuje 131 plików, `describe ADR-003` pokazuje `supersedes ADR-001`; serwer MCP `scripts/knowledge-index/mcp-server.js --root standards/examples` odpowiada na `initialize` i `tools/list`; `npm run build` warsztatu bez błędów; `grep -r "BPMN"` poza `_import/`, `node_modules`, `dist`, `package-lock.json` i nazwami `.bpmn` zwraca 44 linie, wszystkie o notacji, diagramach, silniku, plikach XML, zadaniach albo błędach BPMN; `processes/` występuje już tylko w przykładowym adresie Camunda Operate w BPMS-010; `shared/` i `task-type` nie występują.
