# event

Wersje różnią się mocno: ich szablon obejmuje obszar komunikacji z wieloma kanałami, nasz jedno zdarzenie, a trzy ich sekcje wskazują dokumenty, które według naszej metodyki same wskazują zdarzenie.

1. Zakres pliku. U nich: „Jeden plik = jeden obszar logiczny komunikacji (jeden lub kilka tematycznie powiązanych kanałów i operacji)”, nagłówek `# AsyncAPI: {Nazwa obszaru}` i tytuł `"QUE - publikacja eventu"`. U nas: „Jeden plik to jedno zdarzenie” i nagłówek `# {NazwaZdarzenia}`, zgodnie z inwariantem I3 w `templates/_00-meta.md`. Ich szablon jest tu niespójny, bo `## Informacje podstawowe` i schemat opisują jedno zdarzenie (`Nazwa eventu`, `Wersja eventu`). Przyjęcie ich wersji łamie I3 i sprawia, że jeden QUE obejmuje kilka zdarzeń.

2. Wiersze tabeli `## Informacje podstawowe`. U nich nagłówek `| Właściwość | Wartość |` i wiersze `Nazwa eventu`, `Wersja eventu`, `System producenta`, `Address kanału`, `Format` („JSON / AVRO (Schema Registry)”), `Producent` („{Komponent lub proces publikujący}”) oraz opcjonalny `Konsument(ci)` („{Domena lub system odbierający}”). U nas nagłówek `| Pole | Wartość |` i wiersze `Nazwa zdarzenia`, `Wersja`, `System producenta`, `Adres kanału`, `Format` („JSON / AVRO”) oraz `Zdolność publikująca` z `CAP-{nnn}`. Przyjęcie ich wersji zastępuje identyfikator zdolności tekstowym opisem producenta i dodaje konsumentów. Konsumenci wpisani identyfikatorami UC, TUC lub CAP byliby sprzeczni z sekcją 7 metodyki, ale ich placeholder przewiduje nazwę domeny lub systemu.

3. Dokument nadrzędny w `## Kontekst biznesowy`. U nich: „Wskazanie dokumentu nadrzędnego (TUC/UC/BFS), jeżeli istnieje.”, a guide każe sprawdzić, „Czy istnieje już dokument nadrzędny (BFS, UC, TUC)”. U nas sekcja ma tylko `{Sytuacja biznesowa, w której powstaje zdarzenie}`, a guide mówi, że zdarzenie wskazują ci, którzy je publikują albo odbierają (`UC-001 consumes QUE-001`). Przyjęcie ich wersji łamie sekcję 7 metodyki („Zdarzenie QUE-001 nie wymienia scenariusza UC-001”), a matryca relacji nie ma trójki od QUE do UC, TUC ani BFS.

4. (drobna) Miejsce i wzorzec diagramu przepływu. U nich to podsekcja `### Przepływ danych` w „Kontekst biznesowy” z gotowym wzorcem: uczestnicy Producent, Broker i Konsument, dwa komunikaty i `mirrorActors: false`. U nas to osobna sekcja `## Przepływ danych` z pustym diagramem i tymi samymi uczestnikami. Przyjęcie ich wersji obniża poziom nagłówka i daje przykład diagramu.

5. Sekcja nagłówków komunikatu. U nich `## Header komunikatu` z odesłaniem do wytycznych AsyncAPI 3.0 w Confluence i tabelą `| Pole | Przyklad | Cel |` z sześcioma stałymi wierszami: `correlationId`, `messageId`, `ce_id`, `ce_source`, `ce_time`, `content-type`. U nas `## Nagłówek komunikatu` z tekstem „Według CONV-{nnn}.” i tylko nagłówkami własnymi zdarzenia (`QUE-001 applies CONV-004`). Przyjęcie ich wersji powtarza nagłówki wspólne w każdym zdarzeniu i zastępuje konwencję linkiem do Confluence.

6. Układ `## Specyfikacja schematu`. U nich każdy atrybut ma podsekcję `### Atrybut: {nazwaAtrybutu}` z tabelą `| Właściwość | Wartość |` i wierszami `Typ`, `Obligatoryjny`, `Wartości / Format`, `Opis`. U nas jest jedna tabela `| Atrybut | Typ | Obligatoryjność | Wartości / format | Opis biznesowy |`. Przyjęcie ich wersji daje każdemu atrybutowi własny nagłówek i osobną tabelę.

7. Jawne założenia. U nich szablon ma blok `> Założenie: [jawne braki lub założenia dotyczące schematu]`, a guide każe: „Braki oznaczaj jawnie przez `> Założenie:` zamiast zgadywania”. U nas tego mechanizmu nie ma. Przyjęcie ich wersji wprowadza stały zapis braków w schemacie.

8. Przykład ładunku. U nich podsekcja `### Przykład payloadu` w „Specyfikacja schematu” z kopertą: `eventId`, `eventType`, `eventVersion`, `occurredAt`, `producerSystem`, `correlationId`, `messageId` i `payload`. U nas osobna sekcja `## Przykład ładunku` z pustym `{}`. Przyjęcie ich wersji narzuca tę samą kopertę w każdym zdarzeniu.

9. Opcjonalność `## Charakterystyka dostarczenia`. U nich sekcja ma znacznik `<!-- OPCJONALNIE -->`. U nas nie jest oznaczona jako opcjonalna. Przyjęcie ich wersji pozwala ją pominąć.

10. Tabela `## Charakterystyka dostarczenia`. U nich `| Właściwość | Wartość | Opis |` z dozwolonymi wartościami w komórkach, np. „at-least-once / exactly-once / at-most-once” i „wymagana / nie wymagana”, z objaśnieniem każdej cechy w kolumnie „Opis” i z regułą „Wymagana zawsze przy `at-least-once`” dla idempotencji konsumenta. U nas `| Cecha | Wartość |` z samymi placeholderami, a wiersze `Kolejność wiadomości` i `DLQ` nazywają się `Kolejność` i `Kolejka wiadomości niedostarczonych`. Przyjęcie ich wersji podaje listy dozwolonych wartości i regułę idempotencji, ale objaśnienia trafiają do każdego dokumentu zamiast do guide.

11. Sekcja `## Encje` jest tylko u nas (`QUE-002 consumes ENT-Client`). Ich szablon nie wskazuje encji LDM. Przyjęcie ich wersji sprawia, że graf nie wie, które zdarzenie przenosi daną encję.

12. Powiązanie z przepływem. U nich `## Powiązanie z przepływem end-to-end` z punktami „**Poprzedni krok**: [{TUC lub UC triggujący publikację}]”, „**Bieżący krok**” i „**Kolejny krok po stronie konsumenta**: {ścieżka do artefaktu konsumenta lub opis lokalizacji}”. U nas `## Powiązanie z przepływem od początku do końca` z placeholderem `{Miejsce zdarzenia w przepływie od początku do końca}`, a nasz guide nie mówi, co tam wpisać. Przyjęcie ich wersji łamie sekcję 7 metodyki, bo publikujący UC lub TUC i dokument konsumenta wskazują zdarzenie, a nie odwrotnie.

13. Zawartość `## Powiązane dokumenty`. U nich sekcja zawiera link do historii w JIRA: `[{STORY-ID} — {tytuł}](https://jira.example.com/browse/{STORY-ID})`. U nas ma placeholder `{Dokumenty związane ze zdarzeniem}`, a guide jej nie opisuje. Według `relation-matrix.yaml` QUE ma trójki tylko do CAP, ENT i CONV, więc identyfikator innego dokumentu w naszej wersji tej sekcji walidator zgłosi jako wzmiankę bez relacji. Przyjęcie ich wersji zawęża sekcję do linku JIRA.

14. Odesłanie do nieistniejących sekcji. Ich „Warianty” każą dokumentować specyfikę brokera „w sekcji **Runtime i technologia** oraz **Model kanałów i operacji**”, ale ich szablon takich sekcji nie ma. U nas nie ma ani tych sekcji, ani tej reguły. Przyjęcie ich reguły wymaga dodania dwóch sekcji, bo inaczej odesłanie wskazuje sekcje, których nie ma.

15. (drobna) Wariant z Enterprise Architect. Oba guide go mają. U nich generowanie wymaga zdefiniowania w EA „całej kolejki (kanałów, operacji, wiadomości)”, a szablon „nie zastępuje wygenerowanego pliku JSON”. U nas: „Każde zdarzenie z pliku AsyncAPI ma własny dokument QUE.” Przyjęcie ich wersji dodaje warunek wstępny w EA, a nasze zdanie zależy od decyzji w punkcie 1.

16. (drobna) Lista „Nie używaj gdy”. U nich są odesłania: integracja synchroniczna REST/SOAP → `api-endpoint`, integracja z zewnętrznym systemem → `integration`, logika przetwarzania po odbiorze → `flow` lub `workflow-step`, decyzja lub proces publikacji → `TUC`, `UC` lub `BFS`. U nas są odesłania: synchroniczny punkt końcowy → `api` i zasada wspólna, np. nagłówki komunikatu → `convention`. Przyjęcie ich wersji dodaje trzy odesłania, a odesłanie do `convention` zostaje tylko u nas.

17. Nazwa komunikatu według standardu CAIT. U nich guide mówi: „nazwa komunikatu jest określana przez standard CAIT; należy ją znać przed wypełnianiem sekcji kontraktu”. U nas nie ma reguły nazwy zdarzenia. Przyjęcie ich wersji wiąże pole „Nazwa zdarzenia” i tytuł dokumentu ze standardem CAIT.

18. Reszta sekcji 3 guide. U nich to lista wiedzy wejściowej: producent i konsument, adres kanału i kierunek operacji (`send` / `receive`), struktura `payload` i platforma brokera. U nas sekcja 3 zawiera reguły wskazań w grafie: CONV, CAP, ENT i to, kto wskazuje zdarzenie. Przyjęcie ich wersji dodaje listę kontrolną, przy czym kierunek `receive` nie pasuje do naszego QUE, bo odbiór zapisuje `CAP consumes QUE` albo `TUC consumes QUE`.

19. Nazwa pliku. U nich: „Konwencja nazwy pliku: `kebab-case`, angielski. Przykłady: `asyncapi-overdraft-renewal.md`, `asyncapi-loan-origination.md`.” U nas plik ma nazwę `que-001.md` (`methodology.md`, sekcja 11). Przyjęcie ich wersji jest sprzeczne z metodyką.

Zgodnie z decyzją pominięto różnice w front matter (`source-spec-ids`, `related-doc-ids`), sekcję `## Historia zmian` i sekcję 7 z promptem.
