# screen-section

Wersje są bardzo bliskie: mają te same sekcje i te same 15 atrybutów pola, a różnią się wartościami atrybutów `Źródło danych`, `Miejsce utrwalenia` i `Zachowanie` oraz założeniem o jednym ekranie nadrzędnym.

1. (drobna) Ich tytuł i nagłówek `#` mają przedrostek typu: `Sekcja ekranu: {Nazwa sekcji}`. Nasz tytuł i nagłówek to `{Nazwa sekcji}`. Przyjęcie ich wersji dodaje słowa „Sekcja ekranu:” na początku tytułu.

2. (drobna) Ich sekcja `## Opis sekcji` ma limit „Maksymalnie 3-4 zdania”. Nasza nie ma limitu. Przyjęcie ich wersji ogranicza długość opisu.

3. (drobna) Ich blok pola ma nagłówek `### Pole: {Nazwa pola / elementu}`, nasz `### {Etykieta pola}`. Ich przykłady typów pola obejmują też „Tekst stały”, „Przycisk” i „Link”, które nie zawsze mają etykietę. Przyjęcie ich wersji nazywa blok nazwą pola lub elementu zamiast etykiety.

4. Ich atrybut `Źródło danych` przyjmuje dowolny opis, np. „API: GET /endpoint, autouzupełnienie, dane statyczne, wybór użytkownika”. Nasz przyjmuje encję `ENT-{Nazwa}`, która tworzy wpis `SCRSEC consumes ENT`. Nasz opis podaje też regułę wyboru: wskazuje się encję, która w sekcji jest osobnym bytem, a część zagnieżdżona dochodzi przez `ENT contains ENT`. Przyjęcie ich wersji pozwala wpisać tu API, choć u nas API sekcji trafia tylko do atrybutu `Zachowanie`, a źródło bez encji nie daje relacji do modelu danych.

5. Ich atrybut `Miejsce utrwalenia` przyjmuje dowolny opis, np. „payload Kroku 2, baza danych, local/session storage”. Nasz przyjmuje encję `ENT-{Nazwa}`. Przyjęcie ich wersji dopuszcza miejsca, które nie są encją, i usuwa relację sekcji do encji, w której dane są zapisywane.

6. Ich atrybut `Zachowanie` opisuje „autouzupełnienie, efekty, zależności od innych pól”, bez wskazania API. Nasz ma wartość `{Opis}, API-{nnn}`, a opis podaje regułę: sekcja wskazuje API wywołania, które nie jest krokiem scenariusza (podpowiadanie, walidacja w locie, słownik wartości), oraz test z listą rozwijaną. Przyjęcie ich wersji usuwa miejsce na wpis `SCRSEC consumes API` i regułę, który dokument zapisuje takie wywołanie.

7. (drobna) Ich atrybut dostępności nazywa się `WCAG` i przyjmuje „atrybut aria lub element HTML”. Nasz nazywa się `WCAG (atrybut aria)`. Przyjęcie ich wersji dopuszcza też element HTML.

8. (drobna) Ich atrybut `Analityka zdarzeń (opcjonalnie)` ma stały zapis: Event: `{nazwa_eventu}`, atrybuty: `{ klucz: "wartość" }`. Nasz ma dowolny tekst `{Analityka zdarzeń}`. Przyjęcie ich wersji ujednolica zapis zdarzeń analitycznych.

9. (drobna) Ich sekcja `## Reguły biznesowe` jest listą numerowaną z nazwą reguły: `1. **{Nazwa reguły}**: {Opis reguły}`. Nasza ma `{Reguły biznesowe działające w sekcji}`. Przyjęcie ich wersji wprowadza numerowane i nazwane reguły; ich numery nie są identyfikatorami w grafie.

10. Ich sekcja `## Reguły biznesowe` ma blok `> Założenie: {Założenie wymagające potwierdzenia z zespołem / product ownerem}`, a opis każe oznaczać braki przez `> Założenie: ...`. Nasz szablon nie ma takiego znacznika. Przyjęcie ich wersji wprowadza blok `> Założenie:`. Ta sama różnica dotyczy `activity`, `navigation-map` i `screen`.

11. (drobna) Ich sekcja `## Zachowania specjalne` ma podsekcje `### {Stan lub scenariusz}` z blokiem kodu, a ich „Warianty” każą pominąć sekcję, gdy sekcja ekranu nie ma niestandardowych stanów ani interakcji. Nasza ma jeden wpis i komentarz „Opcjonalnie, pseudokod.”. Przyjęcie ich wersji dzieli zachowania na podsekcje według stanów.

12. Ich opis zakłada jeden ekran nadrzędny: analityk ma wiedzieć, „Do którego ekranu (`screen`) sekcja należy”. Nasz opis dopuszcza sekcję wspólną kilku ekranów (`SCR contains SCRSEC`, liczebność `N:N`) i wskazanie jej przez scenariusz UC, a sekcja nie wymienia ani ekranów, ani scenariuszy (`methodology.md`, sekcja 7). Przyjęcie ich wersji wiąże sekcję z jednym ekranem; ich opis nie przewiduje sekcji wspólnej kilku ekranów, którą u nas kładzie się w `screens/shared/`.

13. (drobna) Ich „Nie używaj gdy” odsyła też do `navigation-map`, gdy opisujesz nawigację między ekranami. Nasz opis odsyła tylko do `screen`. Przyjęcie ich wersji dodaje jedno odesłanie.

Zgodnie z decyzją pominięto pola `type`, `component` i `source-spec-ids`, regułę folderu wyliczanego z pola `type`, sekcję `## Historia zmian` oraz sekcję „Powiązany prompt generujący”.
