# use-case-technical-map

Wersje są bliskie: mają te same sekcje w tej samej kolejności, a różnią się głównie sekcją `Powiązanie z artefaktami szczegółowymi`, opisem aktorów systemowych i przykładami wpisanymi w szablon.

1. Sekcja `Powiązanie z artefaktami szczegółowymi`.
   - U nich: tabela `| Element | Szablon szczegółów | Link |` z linkami względnymi do plików, np. `[UC-01](../use-cases/uc-01-nazwa.md)`. Sekcja 3 pyta, „do których plików należy linkować”.
   - U nas: lista samych ID `- UC-{nnn}` i `- TUC-{nnn}`, a każdy z nich ma w front matter relację `groups`. Plik UC ma nazwę równą doc-id, np. `uc-001.md`, i leży w `processes/BFS-…/scenarios/` (`methodology.md`, sekcja 11).
   - Po przyjęciu ich wersji: mapa trzymałaby ścieżki do plików, które trzeba poprawiać przy przeniesieniu pliku, a ich wzór ścieżki `../use-cases/uc-01-nazwa.md` nie pasuje do naszego układu katalogów ani nazw plików.

2. Aktorzy systemowi na mapie.
   - U nich: wiersz `Aktorzy systemowi` ma przykład `[np. Scheduler, Event Bus]`, a sekcja 3 pyta, „kto jest aktorem dla TUC (system/scheduler)”. Diagram ma węzeł `Aktor: System Scheduler`.
   - U nas: wiersze aktorów mają wartość `{Nazwy ról}`, a guide mówi: „Aktorów na mapie podajesz nazwą. Matryca nie ma trójki UCMAP z rolą, więc ID roli w treści mapy jest błędem walidatora.”
   - Po przyjęciu ich wersji: aktorami systemowymi na mapie byłyby komponenty techniczne, a nie role z bazy ACTOR, a guide straciłby zakaz podawania ID roli.

3. Nagłówek i zakres mapy (drobna).
   - U nich: `# Use Case Technical Map: {Nazwa procesu}`, a sekcja 3 pyta, „Jakie UC i TUC wchodzą w zakres procesu”.
   - U nas: `# {Nazwa mapy}`. Mapa może zestawiać scenariusze kilku procesów i wtedy leży w `shared/maps/` (`methodology.md`, sekcja 11).
   - Po przyjęciu ich wersji: nagłówek dostałby prefiks typu i nazwę jednego procesu, co nie pasuje do mapy kilku procesów.

4. Sekcja diagramu (drobna).
   - U nich: `## Diagram relacji UC i TUC` z pełnym przykładowym diagramem: aktorzy, węzły `UC-01` … `TUC-03`, relacje i kolory klas.
   - U nas: `## Diagram` z komentarzem `<!-- Klasy dla aktorów, UC i TUC. -->` i pustym `flowchart LR`.
   - Po przyjęciu ich wersji: zmieniłaby się nazwa sekcji, a szablon niósłby gotowy przykład, który trzeba usuwać z każdej nowej mapy.

5. Zapis nazw relacji (drobna).
   - U nich: w `Legenda relacji` i w `Opis relacji` relacje mają zapis `<<include>>`, `<<extend>>`, `<<exclude>>`, a kolumna legendy to `Znaczenie praktyczne`.
   - U nas: zapis `include`, `extend`, `exclude`, a kolumna legendy to `Znaczenie`.
   - Po przyjęciu ich wersji: w tabelach pojawiłby się zapis stereotypu UML zamiast samej nazwy relacji.

6. Treść sekcji `Otwarte pytania` (drobna).
   - U nich: gotowy tekst „Założenie: Uzupełnij pytania, jeśli relacje `extend/include/exclude` nie są jeszcze potwierdzone przez analityka biznesowego i technicznego.”
   - U nas: pole `{Pytania do wyjaśnienia}`.
   - Po przyjęciu ich wersji: szablon mówiłby, że relacje na mapie potwierdza analityk biznesowy i techniczny.

7. Warunek wariantu `Rozbudowany` (drobna).
   - U nich: „gdy mapa obejmuje wiele domen”, z przykładami obszarów „(np. onboarding, przetwarzanie, archiwizacja)”.
   - U nas: „diagram podzielony na obszary, jeden plik mapy”, bez warunku.
   - Po przyjęciu ich wersji: wariant miałby warunek użycia i przykłady obszarów.

Pominięte zgodnie z decyzją: pola `type`, `component`, `related-doc-ids`, „Lokalizacja docelowa” liczona z pola `type`, sekcje `Historia zmian` i `7. Powiązany prompt generujący`.
