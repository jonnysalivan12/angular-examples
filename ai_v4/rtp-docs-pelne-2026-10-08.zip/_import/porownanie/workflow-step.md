# workflow-step

Wersje różnią się znacznie: u nich krok jest opcjonalnym rozwinięciem tasku i wymienia proces, sąsiednie kroki, ekran i zdolność, czego nasza metodyka i matryca relacji nie dopuszczają.

1. SPEC-WF opcjonalny albo obowiązkowy. U nich SPEC-WF jest „opcjonalnym, szczegółowym rozwinięciem logiki pojedynczego tasku”, a „Nie używaj gdy” wyklucza prosty task, którego działanie wynika z opisu w `bpms-process`. U nas „Jeden task BPMN to jeden plik” bez wyjątków. Przyjęcie ich wersji sprawia, że prosty krok nie ma pliku, więc jego wywołania, źródła zmiennych, rola i kryteria akceptacji nie mają miejsca w grafie (szczegóły w `bpms-process.md`, punkt 1).

2. Wskazanie procesu nadrzędnego w kroku. U nich krok ma pole `bpms-process-id: BPMS-{NNN}` i wiersz `**Proces BPMS**` w `## Kontekst` z odnośnikiem do pliku procesu. U nas krok nie wymienia procesu, bo relację zapisuje proces (`BPMN-001 contains SPEC-WF-001`), a `methodology.md`, sekcja 7, podaje dokładnie ten przykład: „Krok SPEC-WF-001 nie wymienia procesu BPMN-001.” Przyjęcie ich wersji oznacza, że krok wymienia dokument, który go wskazuje, wbrew metodyce.

3. Treść `## Powiązane dokumenty`. U nich sekcja wymienia `**Proces BPMS**`, `**Poprzedni task**`, `**Następny task**`, `**API SPEC**` i `**JIRA**`. U nas sekcja ma tylko tekst `{Dokumenty związane z zadaniem}`. Wymienienie procesu jest sprzeczne z `methodology.md`, sekcja 7, a poprzedni i następny task zapisują kolejność kroków, której graf nie zapisuje (`relation-matrix.yaml`, „Czego nie wolno zapisać”, punkt 2). Przyjęcie ich wersji wprowadza do kroku listę, którą obie te reguły wykluczają.

4. Wiersz `UI` dla User Task. U nich User Task musi mieć w `## Wywoływane zasoby` wiersz `**UI**` z `{{SCR-NNN}}`, a wariant User Task mówi „powiązanie z SPEC-UI obowiązkowe”. U nas krok nie wskazuje ekranu ani API, które go obsługują: relację zapisuje API (`API-008 consumes SPEC-WF-005`), a ekran wskazuje scenariusz UC (`relation-matrix.yaml`, „Czego nie wolno zapisać”, punkt 10). Przyjęcie ich wersji wymaga trójki `SPEC-WF contains SCR`, którą punkt 10 wprost wyklucza.

5. Wiersz `Capability`. U nich `## Wywoływane zasoby` ma wiersz `**Capability**` („Jak task korzysta z tej zdolności”), obowiązkowy dla Business Rule Task (reguły, DMN). U nas krok nie wskazuje zdolności, bo wynika ona z wpisu `realizes` wołanego zasobu (`SPEC-WF-014 consumes INT-017`, a `INT-017 realizes CAP-022`). Przyjęcie ich wersji wymaga trójki `SPEC-WF consumes CAP`, którą wyklucza punkt 5 części „Czego nie wolno zapisać” w `relation-matrix.yaml`.

6. Kolumna konsumenta w zmiennych wyjściowych. U nich nagłówek `| Zmienna procesowa | Typ | Konsument (następny task / bramka) | Opis |`. U nas `| Zmienna | Typ | Źródło | Opis |`, przy czym `Źródło` wypełnia tylko krok `call-activity` ID kroku podprocesu. U nas zależność zapisuje krok, który zmienną czyta (`SPEC-WF-002 consumes SPEC-WF-001`), więc krok zapisujący nie wymienia kroków czytających. Przyjęcie ich wersji oznacza, że krok wymienia kroki, które go wskazują, wbrew `methodology.md`, sekcja 7.

7. Call Activity a dokumentacja podprocesu. U nich wariant Call Activity mówi „powiązanie z dokumentacją subprocesu obowiązkowe”. U nas krok `call-activity` wskazuje tylko kroki podprocesu w kolumnie `Źródło` zmiennych wyjściowych (`SPEC-WF-008 consumes SPEC-WF-009`), a matryca zna tylko kierunek `BPMN contains SPEC-WF`. Przyjęcie ich wersji tworzy w kroku wzmiankę o procesie, którą reguła wzmianek z `relation-matrix.yaml` każe usunąć.

8. Nagłówek i wiersze `## Wywoływane zasoby`. U nich `| Typ | Identyfikator | Opis powiązania |` z wierszami `**API**`, `**Capability**`, `**Integracja**`, `**UI**`, a guide wymaga wierszy zależnie od typu: User Task `UI`, Service, Send i Receive Task `API` lub `Integracja`, Business Rule Task `Capability`. U nas `| Rodzaj | ID | Jak zadanie go używa |` z wierszami `API`, `Integracja`, `Zdarzenie`; tabela ma tylko zasoby, które krok woła sam, a krok bez wywołań ma wiersz „—”. Przyjęcie ich wersji usuwa wiersz na publikowane zdarzenie QUE (`SPEC-WF consumes QUE`) i dodaje wiersze z punktów 4 i 5.

9. Lista typów zadań. U nich `task-type` ma osiem wartości z BPMN 2.0: `user-task`, `service-task`, `script-task`, `business-rule-task`, `send-task`, `receive-task`, `manual-task`, `call-activity`, a guide zabrania tworzyć własnych. Ich sekcja 6 opisuje wariant dla każdego typu. U nas `task-type` ma cztery wartości (`service-task`, `user-task`, `script-task`, `call-activity`) i tyle samo wariantów. Przyjęcie ich wersji dodaje typy `business-rule-task`, `send-task`, `receive-task` i `manual-task` wraz z opisem wariantu.

10. Identyfikator tasku w silniku. U nich krok ma pole `bpmn-task-id`, a guide każe znać „id tasku w silniku”. U nas ID zadania w silniku podaje proces w kolumnie `ID zadania` tabeli `## Zadania procesu`, a guide mówi: „Identyfikatory procesu i zadania w silniku podaje dokument BPMN.” Przyjęcie ich wersji zapisuje ID tasku w dwóch miejscach, bo ich proces też ma kolumnę `ID tasku (BPMN)`.

11. Wartość pola „Aktor / Serwis”. U nich to „rola użytkownika lub nazwa serwisu” opisana tekstem. U nas krok user-task podaje ID roli `ACTOR-{nnn}.ROLE-{nn}`, które tworzy wpis `involves ROLE`, a nazwa serwisu w kroku service-task relacji nie tworzy. Przyjęcie ich wersji sprawia, że krok nie wskazuje roli w grafie.

12. Odnośnik do JIRA w treści. U nich wiersz `**JIRA**` w `## Kontekst` i pozycja `**JIRA**` w `## Powiązane dokumenty`, oba z adresem zgłoszenia. U nas krok nie ma odnośnika do zgłoszenia. Przyjęcie ich wersji dodaje do treści kroku źródłowe zgłoszenie JIRA.

13. Forma `## Scenariusze błędów`. U nich tabela `| ID | Scenariusz błędu | Reakcja systemu | Komunikat / status |` z ID `E1`. U nas tekst `{Sytuacje błędne i reakcja zadania}`. W naszej metodyce prefiks `E` oznacza sytuację błędną w UC i TUC (`methodology.md`, sekcja 3), a matryca nie ma trójki `SPEC-WF contains E`. Przyjęcie ich wersji daje numerowane scenariusze z kodem błędu, ale numery `E1` w kroku nie są wierszami w rozumieniu naszej matrycy.

14. Forma zdarzeń granicznych. U nich `## Obsługa zdarzeń granicznych (Boundary Events)` jest oznaczona jako opcjonalna i ma tabelę `| Zdarzenie | Warunek | Obsługa |`. U nas `## Obsługa zdarzeń granicznych` to tekst `{Zdarzenia graniczne zadania i reakcja}` bez oznaczenia opcjonalności. Przyjęcie ich wersji rozdziela warunek i obsługę na kolumny i pozwala pominąć sekcję.

15. (drobna) Pole „Etap procesu” w `## Kontekst`. U nich wiersz `**Etap procesu**` z przykładem „Decyzja wstępna”. U nas tego pola nie ma. Przyjęcie ich wersji dodaje nazwę etapu procesu, do którego należy krok.

16. (drobna) Pole „Typ tasku” w `## Kontekst`. U nich wiersz `**Typ tasku**` powtarza w treści wartość `task-type` z front matter. U nas typ jest tylko w `task-type`. Przyjęcie ich wersji zapisuje typ w dwóch miejscach dokumentu.

17. (drobna) Diagram w `## Reguły i logika`. U nich: „Gdy mają rozgałęzienia — wstaw diagram flowchart Mermaid.”, a sekcja jest nazwana najważniejszą. U nas sekcja ma tylko wzór „Jeśli {X}, to {Y}.” Przyjęcie ich wersji pozwala pokazać rozgałęzione reguły diagramem.

18. (drobna) Opcjonalność `## Efekty uboczne`. U nich sekcja ma dopisek „Opcjonalne” i przykład zmiany stanu encji. U nas ta sama sekcja nie jest oznaczona jako opcjonalna. Przyjęcie ich wersji pozwala pominąć sekcję.

19. (drobna) Zapis kryteriów akceptacji. U nich `## Acceptance Criteria` z wierszem `**AC-01**: Happy path` i wciętymi liniami Given, When, Then. U nas `## Kryteria akceptacji` z podsekcją `### AC-01` i listą Given, When, Then. Przyjęcie ich wersji dodaje nazwę kryterium obok ID, a ID przestaje być nagłówkiem.

20. (drobna) Lista „Nie używaj gdy”. U nich odesłania do `bpms-process` (mapa procesu), `api` (kontrakt API) i `capability` (logika wielokrotnego użytku) oraz wyłączenie prostego tasku z punktu 1. U nas odesłania do `api`, `capability` i `business-functional-spec` (logika zdolności, reguły globalne) oraz `ddm` i `ldm-entity` (schemat danych domenowych). Przyjęcie ich wersji dodaje odesłanie do procesu i usuwa odesłania do BFS i modeli danych.

21. (drobna) Przedrostek w tytule. U nich `title: "Workflow SPEC: {Nazwa tasku z BPMN}"` i taki sam nagłówek `#`. U nas `# {Nazwa zadania}`. Przyjęcie ich wersji dodaje „Workflow SPEC:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto pola `type`, `source-spec-ids`, `related-doc-ids` i `examples-ids`, odnośniki `{{DOC-ID}}`, opcjonalność `owner`, regułę lokalizacji pliku według pola `type`, sekcję `## Historia zmian` i sekcję 7 z promptem.
