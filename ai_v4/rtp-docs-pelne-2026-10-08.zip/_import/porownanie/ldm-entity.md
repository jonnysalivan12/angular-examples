# ldm-entity

Wersje mają prawie tę samą strukturę sekcji, ale różnią się regułami: ich `## Reguły biznesowe` odpowiadają naszym `## Reguły walidacyjne` z innym prefiksem, a pojęcie DDM i powiązania zapisują inaczej, niż wymaga nasz graf.

1. `## Reguły biznesowe` w miejscu `## Reguły walidacyjne`. U nich lista `- **RB-001:** Opis reguły.`, której komentarz mówi: „nietrywialna logika zapisu/odczytu specyficzna dla encji”, a reguły domenowe RD tylko się przywołuje. U nas tabela `| ID | Reguła | RD |` z `RW-{nnn}` i kolumną RD, która tworzy wpis `realizes DDM-{nnn}.RD-{nnn}`. Przyjęcie ich wersji jest sprzeczne z metodyką: prefiks RB oznacza regułę biznesową w BFS (`methodology.md`, sekcja 3), a matryca nie ma trójki `ENT contains RB`.

2. Liczba realizowanych pojęć. U nich encja „realizuje jedno lub więcej pojęć z DDM”. U nas encja wskazuje jedno pojęcie (trójka `ENT realizes DOM` ma liczebność `N:1`), rodzaj pojęcia ogólnego wskazuje pojęcie ogólne (`ENT-Deposit realizes DDM-002.DOM-Rachunek`), a encja techniczna, np. `ENT-StatusDict`, nie wskazuje żadnego. Przyjęcie ich wersji łamie liczebność zapisaną w `relation-matrix.yaml`.

3. Forma wskazania pojęcia. U nich `**Realizuje pojęcie (DDM):** [DOM-{Pojęcie}](../ddm-{obszar}.md)`, czyli krótki identyfikator z linkiem do pliku. U nas `DDM-{nnn}.DOM-{Nazwa}`. Przyjęcie ich wersji jest sprzeczne z sekcją 3 metodyki, która wymaga pełnego identyfikatora wiersza.

4. (drobna) Forma bloku pod tytułem. U nich trzy pogrubione wiersze: `**ID:**`, `**Alias biznesowy:**`, `**Realizuje pojęcie (DDM):**`. U nas tabela `| Pole | Wartość |` z tymi samymi trzema polami. Przyjęcie ich wersji zmienia tylko formę zapisu.

5. Tabela w `## Powiązania`. U nich `| Relacja | Encja docelowa | Liczebność (ta → cel) | Opis |`, przykład relacji „posiada”, liczebność „1 do 0..*” i cel jako link `[{EncjaB}](encja-b.md)`. U nas `| Relacja | Encja docelowa | Liczebność | Opis |`, przykład „zawiera”, liczebność `1:N` i cel `ENT-{Nazwa}`, a wartość „zawiera” tworzy wpis `ENT contains ENT`. Przyjęcie ich wersji usuwa umówione słowo „zawiera”, więc graf traci zawieranie encji, na którym opiera się reguła wskazywania encji przez API, INT i QUE.

6. `## Typy wyliczeniowe`. U nich każdy typ ma podsekcję `### {NazwaEnum}` z tabelą `| Wartość | Opis |`, a szablon mówi: „Usuń sekcję, jeśli encja nie ma typów Enum.” U nas placeholder `{Typy wyliczeniowe i ich wartości}`. Przyjęcie ich wersji daje stały układ wartości i pozwala usunąć pustą sekcję.

7. Zasada „Nie dotyczy” i komentarze „dlaczego”. U nich: „Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem.”, a każda sekcja ma komentarz `<!-- dlaczego: … -->`. Ta zasada przeczy ich własnemu poleceniu usunięcia pustej sekcji typów wyliczeniowych. U nas nie ma ani tej zasady, ani komentarzy. Przyjęcie ich wersji czyni wszystkie sekcje obowiązkowymi i wymaga rozstrzygnięcia tej sprzeczności.

8. (drobna) Wartości w tabeli `## Atrybuty`. Kolumny są te same. U nich wartości to `Wymagany` / `Opcjonalny` i `Tak` / `—`, a guide definiuje oba stopnie wymagalności i mówi: „Wymagalność wynika z modelu logicznego, nie z walidacji aplikacyjnej.” U nas wartości to `tak / nie` i `Tak / Nie`, bez definicji. Przyjęcie ich wersji zmienia słowa w komórkach i dodaje definicję do guide.

9. (drobna) Lista „Czego nie umieszczać” w guide encji. U nich obejmuje klucze PK/FK, długości pól, precyzję, indeksy, partycje, adnotacje ORM/JPA, wartości domyślne zależne od środowiska i referencje do konsumentów, a guide odsyła też do słownika typów w indeksie LDM. U nas taka lista jest tylko w guide `ldm`, a szablon encji ma komentarz „Bez kluczy fizycznych.” Przyjęcie ich wersji powtarza tę listę w guide encji.

10. (drobna) Braki w modelu źródłowym. U nich `## Uwagi` ma blok `> Uwaga: [opis znanych braków lub rozbieżności w modelu]`, a guide każe zostawić pustą komórkę lub wpisać `(nie zmodelowano)`. U nas `## Uwagi` ma placeholder `{Jawne braki, „nie zmodelowano”}`, bez reguły w guide. Przyjęcie ich wersji dodaje regułę dla pustych komórek tabel.

11. (drobna) Wskazówka w `## Opis`. U nich komentarz każe wskazać momenty zapisu, jeśli są istotne (np. „pole zapisywane przy inicjalizacji”). U nas placeholder `{Czym jest encja i do czego służy}`. Przyjęcie ich wersji dodaje wskazówkę o momentach zapisu.

12. Nazwa pliku. U nich: „Konwencja nazwy pliku: `kebab-case`, angielski, bez przedrostka `t_` i sufiksu `_table`. Przykłady: `cases.md`, `case-data.md`, `loan-application.md`.” U nas reguła bez `t_` i `_table` dotyczy doc-id, a plik ma nazwę równą doc-id małymi literami, np. `ent-disposition.md` (`methodology.md`, sekcja 11). Przyjęcie ich wersji jest sprzeczne z metodyką.

13. (drobna) Format doc-id. U nich front matter ma `ENT-{numer}`, a treść `ENT-{NazwaEncji}`. U nas `ENT-{Nazwa}` w obu miejscach, unikalne w całej dokumentacji. Przyjęcie numeru z ich front matter zmieniłoby schemat identyfikatorów encji w całym grafie.

14. (drobna) Przedrostek w tytule. U nich `# Encja: {NazwaEncji}`. U nas `# {Nazwa encji}`. Przyjęcie ich wersji dodaje „Encja:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto różnice w front matter (`source-spec-ids`, `related-doc-ids`), sekcję `## Historia zmian` i sekcję 7 z promptem.
