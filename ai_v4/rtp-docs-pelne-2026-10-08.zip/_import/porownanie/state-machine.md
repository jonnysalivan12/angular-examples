# state-machine

Wersje mają te same sekcje w tej samej kolejności, a ich wersja dodaje głównie reguły wypełniania tabel stanów i konwencję nazw stanów na diagramie.

1. Pola „Obiekt (pojęcie DDM)” i „Zdolność” pod tytułem są tylko u nas. Nasza tabela `| Pole | Wartość |` ma wiersze `Obiekt (pojęcie DDM) | DDM-{nnn}.DOM-{Nazwa}` i `Zdolność | CAP-{nnn}`, z wpisami `realizes` do obu celów. Guide dodaje, że maszyna techniczna, np. `STM-013` z cyklem życia sesji, zostawia pole pojęcia puste. U nich maszyna nie wskazuje ani obiektu, ani zdolności, a szablon mówi o maszynie „procesu [PROCESS_NAME]”. Przyjęcie ich wersji usuwa z treści informację, cykl życia którego pojęcia DDM opisuje dokument, a od tego zależy folder dokumentu (`methodology.md`, sekcja 11).

2. Reguły `### Słownik statusów`. U nich nagłówek `| Kod statusu | Status | Opis | Status końcowy |`, u nas `| Kod | Status | Opis | Czy końcowy |`. U nich tabela zawiera wszystkie statusy, pośrednie i końcowe, a kolumna przyjmuje „wyłącznie `TAK` lub `NIE`” i „jest jedynym źródłem identyfikacji stanów terminalnych”. U nas kolumna ma wartości `tak / nie` bez dalszych reguł. Przyjęcie ich wersji ustala, że stan końcowy wynika tylko z tej kolumny, także przy rysowaniu diagramu.

3. Reguły tabeli przejść. U nich nagłówek `| Stan (z) | Stan (do) | Opis przejścia | Flow |`, u nas `| Stan z | Stan do | Opis przejścia | Typ przepływu |`. U nich jeden wiersz to jedno przejście, tabela zawiera wszystkie przejścia, stan zapisuje się jako `[ID]. [STATE_NAME]`, a wartości mają definicje: `MAIN` to główna ścieżka sukcesu, `ALTERNATIVE` to akceptowalne odgałęzienie (np. rezygnacja, ręczna obsługa), `ERROR` to błąd techniczny lub decyzja negatywna. Ich guide wymaga też, by analityk przed wypełnianiem wiedział, które przejścia są którego typu. U nas są tylko wartości `MAIN / ALTERNATIVE / ERROR` bez definicji. Przyjęcie ich wersji daje jednakowy zapis stanów i jednakowe kryterium podziału przejść.

4. Forma i zakres `## Scenariusze błędów`. U nich tabela `| Scenariusz | Stan | Zachowanie |` z regułą, że zawiera „tylko wyjątkowe scenariusze, które prowadzą do stanów końcowych niezaplanowanych”. U nas tekst `{Sytuacje błędne i stany, do których prowadzą}`. Przyjęcie ich wersji przypisuje każdy scenariusz do stanu i zawęża sekcję do niezaplanowanych stanów końcowych.

5. Szkielet diagramu i konwencja nazw stanów. U nich blok `stateDiagram-v2` ma gotowy szkielet: aliasy `S_ALIAS`, etykiety `[ID]. [NAME]` takie jak w tabelach i przedrostek `END:` przy stanach końcowych. U nas blok jest pusty, z komentarzem, że diagram powstaje z tabel albo z eksportu EA. Przyjęcie ich wersji daje wszystkim maszynom to samo nazewnictwo stanów na diagramie, zgodne z tabelami.

6. Oznaczanie braków blokiem `> Założenie:`. U nich guide mówi „Braki oznaczaj jawnie: `> Założenie: ...`”, a szablon ma takie bloki w kilku sekcjach. U nas szablon ma pola do wypełnienia w nawiasach klamrowych i komentarze HTML, a guide nie ma reguły o brakach. Przyjęcie ich wersji wprowadza widoczne w treści oznaczenia założeń do uzupełnienia.

7. Akapit wstępny pod tytułem jest tylko u nich. Pod nagłówkiem `#` stoi „Krótki opis diagramu maszyny stanów — co reprezentuje i jakie są główne przepływy.”, bez własnego nagłówka sekcji. U nas po tabeli z polami następuje od razu `## Warunki wstępne`. Przyjęcie ich wersji dodaje krótki opis maszyny na początku dokumentu.

8. (drobna) Wariant z diagramem z EA. U nich sekcja 6 mówi, że przy diagramie z EA trzeba zachować „tabele stanów i przejść”, a szablon każe zapisać plik w `assets` „z odpowiednią nazwą”. U nas guide ma tylko „Diagram wyeksportowany z EA do katalogu `assets/`”. Przyjęcie ich wersji wprost wymaga tabel także przy diagramie z EA.

9. (drobna) Nazwa podsekcji przejść. U nich `### Stany procesowe (ObjectFlow)`, u nas `### Stany procesowe`. Przyjęcie ich wersji dodaje dopisek `(ObjectFlow)` do nagłówka.

10. (drobna) Lista „Nie używaj gdy”. U nich odesłania do `flow` i `use-case`. U nas do `flow` i `bpmn-process`. Przyjęcie ich wersji zamienia odesłanie do procesu w silniku na odesłanie do scenariusza użytkownika.

11. (drobna) Przedrostek w tytule. U nich `title: "Maszyna stanów: {Nazwa procesu}"` i taki sam nagłówek `#`. U nas `# {Nazwa maszyny stanów}`. Przyjęcie ich wersji dodaje „Maszyna stanów:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto pola `type` i `component`, opcjonalność `owner`, regułę lokalizacji pliku według pola `type`, sekcję `## Historia zmian` i sekcję 7 z promptem.
