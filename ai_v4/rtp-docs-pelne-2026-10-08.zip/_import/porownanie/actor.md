# actor

Wersje różnią się mocno: nazwy większości sekcji są wspólne, ale ich szablon wiąże aktorów z dokumentami, które ich używają, i dopuszcza bazę dla jednego procesu, a nasz trzyma role jako wiersze `ROLE` jednej bazy całego systemu.

1. Kolumna `Powiązane artefakty` w tabelach `Aktorzy` i `Przykład minimalny (BBC)`.
   - U nich: tabela `| Typ aktora | Rola | Przykład | Powiązane artefakty |` ma w ostatniej kolumnie wartości typu `<UC-XX, TUC-YY, CAP-01, API-01>`. Sekcja 2 dodaje cel „chcesz jednoznacznie powiązać role w procesie z artefaktami systemowymi (np. capability, API, integracje, flow)”.
   - U nas: tej kolumny nie ma. Według `methodology.md`, sekcja 7, ACTOR nie wymienia dokumentów, które go wskazują. Rolę wskazują UC, TUC i SPEC-WF wpisem `involves`, a matryca nie ma żadnej trójki między ACTOR lub ROLE a CAP, API, INT czy FLOW.
   - Po przyjęciu ich wersji: ACTOR wymieniałby dokumenty wskazujące wbrew sekcji 7, a wzmianki o CAP, API, INT i FLOW walidator zgłosiłby jako błąd, bo matryca nie ma dla tych par żadnej trójki.

2. Sekcja `Mapa udziału aktorów w procesach` (tylko u nich).
   - U nich: macierz `| ID aktora | P1: UC/TUC-01 | P2: UC/TUC-02 | … |` z wartościami `Inicjuje`, `Uczestniczy` i `-`. Sekcja jest obowiązkowa, gdy dokument obejmuje więcej niż jeden proces. Sekcja 3 pyta też, „Które przypadki użycia są inicjowane przez poszczególnych aktorów”, a wstęp do sekcji 5 wymaga „mapowanie aktorów do scenariuszy”.
   - U nas: takiej sekcji nie ma. `methodology.md`, sekcja 7, podaje „udział ról w scenariuszach” jako listę, którą graf wylicza z wpisów `involves`. Najbliższym odpowiednikiem rozróżnienia `Inicjuje` jest pole `Aktor główny` w tabeli nagłówkowej UC.
   - Po przyjęciu ich wersji: analityk utrzymywałby ręcznie listę, którą graf liczy sam, a każdy nowy UC lub TUC wymagałby edycji ACTOR, wbrew `methodology.md`, sekcja 2.

3. Identyfikator aktora.
   - U nich: tabela `Aktorzy` nie ma kolumny z ID, choć komentarz mówi o „kanoniczna lista aktorów z ID”. W macierzy udziału aktorzy mają ID `ACTOR-01` … `ACTOR-05`, czyli prefiks dokumentu z `doc-id: ACTOR-{numer}`.
   - U nas: kolumna `ID` z wierszami `ROLE-01`. Inne dokumenty wskazują rolę pełnym ID `ACTOR-001.ROLE-01` (`methodology.md`, sekcja 3).
   - Po przyjęciu ich wersji: wiersz z prefiksem `ACTOR` wyglądałby jak osobny dokument, bo prefiks przed myślnikiem oznacza typ dokumentu, a inne dokumenty nie miałyby jak wskazać roli wewnątrz bazy.

4. Kolumny opisu aktora w tabeli `Aktorzy`.
   - U nich: `| Typ aktora | Rola | Przykład | Powiązane artefakty |`. Odpowiedzialność trafia do kolumny `Przykład` („<Opis odpowiedzialności i kontekstu użycia>”). Nie ma kolumn na uprawnienia ani dziedziczenie, choć reguła z sekcji 2 każe pokazać hierarchię „jawnie w tabeli aktorów”.
   - U nas: `| ID | Nazwa kanoniczna | Klasa | Odpowiedzialność | Uprawnienia | Dziedziczy po |`.
   - Po przyjęciu ich wersji: tabela straciłaby uprawnienia i dziedziczenie, które sekcja 1 obu wersji wymienia jako treść dokumentu.
   - Uwaga: obie wersje każą pokazać dziedziczenie także na „diagramie relacji”, ale żaden z dwóch szablonów nie ma sekcji na ten diagram.

5. Treść sekcji `Przykład minimalny`.
   - U nich: `## Przykład minimalny (BBC)` to stała tabela trzech aktorów z procesu BBC: klienta, `Frontend procesu` (`clientId: FE-BBC`) i `Backend procesu` (`clientId: BE-BBC`).
   - U nas: `## Przykład minimalny` z polem `{Jeden aktor opisany od początku do końca}`, które analityk wypełnia dla własnej bazy. Przykład w `standards/examples/shared/actors/actor-001.md` ma jedną rolę systemową `System`.
   - Po przyjęciu ich wersji: szablon niósłby stały przykład z procesu BBC i pokazywałby frontend i backend jako osobnych aktorów systemowych, co jest innym sposobem modelowania ról systemowych niż nasz przykład.

6. Wariant bazy dla jednego procesu.
   - U nich: sekcja 6 ma dwa warianty, `Aktorzy per proces` i `Aktorzy per system`, z czego drugi jest preferowany. Tytuł to `# Actors: {Nazwa procesu}`, a przykład w `Cel` dotyczy jednego procesu.
   - U nas: „Brak wariantów: jedna baza aktorów systemu, wspólna dla wszystkich procesów”. ACTOR leży w `shared/actors/` (`methodology.md`, sekcja 11).
   - Po przyjęciu ich wersji: przy kilku bazach procesowych ta sama rola mogłaby dostać kilka ID, a nasza reguła mówi „Jeden aktor ma jedną nazwę kanoniczną i jedno ID”.

7. Reguła o poziomach uprawnień (tylko u nich).
   - U nich: „Gdy rola ma różne poziomy uprawnień, opisz je jako jeden aktor + warianty uprawnień.”
   - U nas: guide nie ma tej reguły. Przykład `actor-001.md` opisuje węższy zakres uprawnień osobną rolą `ROLE-04` z `Dziedziczy po` równym `ROLE-01`.
   - Po przyjęciu ich wersji: guide dostałby regułę, że różne poziomy uprawnień to jeden wiersz z wariantami, i trzeba by ustalić, kiedy zamiast tego stosować osobną rolę z `Dziedziczy po`.

8. Tabela `Klasyfikacja aktorów` (drobna).
   - U nich: `| Typ aktora | Definicja lokalna | Kryterium kwalifikacji |`.
   - U nas: `| Klasa | Kryterium kwalifikacji |`.
   - Po przyjęciu ich wersji: doszłaby kolumna `Definicja lokalna` z opisem klasy obok kryterium.

9. Podsekcja `Poza zakresem` (drobna).
   - U nich: `## Zakres` ma tylko `### W zakresie`.
   - U nas: `## Zakres` ma `### W zakresie` i `### Poza zakresem`.
   - Po przyjęciu ich wersji: zniknęłoby miejsce na aktorów i role spoza bazy, np. systemy zewnętrzne, które są stroną integracji.

10. Tabela `Słownik nazw i aliasów` (drobna).
    - U nich: `| Nazwa kanoniczna | Alias / nazwa historyczna |`, z jednym aliasem w wierszu.
    - U nas: `| Nazwa kanoniczna | Aliasy |`, ze wszystkimi aliasami w jednej komórce.
    - Po przyjęciu ich wersji: każdy alias dostałby osobny wiersz, a nagłówek kolumny wskazywałby też nazwy historyczne.

11. Nagłówek dokumentu (drobna).
    - U nich: `# Actors: {Nazwa procesu}`.
    - U nas: `# {Nazwa bazy aktorów}`.
    - Po przyjęciu ich wersji: nagłówek miałby prefiks typu i nazwę procesu, co pasuje tylko do wariantu z punktu 6.

12. Komentarze `DLACZEGO` i przykłady w szablonie (drobna).
    - U nich: każda sekcja ma komentarz `<!-- DLACZEGO: … -->`, a `Cel` i `Zakres` mają wpisane przykłady („Przykład: …”).
    - U nas: szablon nie ma takich komentarzy ani przykładów. Według `_00-meta.md` komentarz HTML w szablonie oznacza regułę sekcji, a przykłady leżą w `standards/examples/`.
    - Po przyjęciu ich wersji: komentarze w szablonie mieszałyby uzasadnienia sekcji z regułami, a przykłady trzeba by usuwać z każdego nowego dokumentu.

13. Sekcja 3 guide, czyli co analityk musi wiedzieć (drobna).
    - U nich: lista pytań: system docelowy i granica opisu, wsad źródłowy („np. BFS, UC/TUC, diagram procesu, VISION, prompt, warsztat”), role w procesach, granice odpowiedzialności i uprawnień, nazwy kanoniczne i aliasy historyczne.
    - U nas: reguły zapisu, czyli prefiks `ROLE`, wskazywanie roli pełnym ID i zakaz ponownego użycia numeru.
    - Po przyjęciu ich wersji: guide dostałby pytania przygotowawcze, a pytanie o inicjowanie przypadków użycia wymaga decyzji z punktu 2.

14. Odesłanie w „Nie używaj gdy” (drobna).
    - U nich: „dokumentujesz relacje między przypadkami użycia”, bez wskazania typu.
    - U nas: brak tego punktu. Jest za to odesłanie do `technical-use-case`, którego ich lista nie ma.
    - Po przyjęciu ich wersji: guide dostałby ten punkt. U nas relacje między przypadkami użycia opisuje typ `use-case-technical-map`.

Pominięte zgodnie z decyzją: pola `type`, `component`, `source-spec-ids`, `related-doc-ids`, „Lokalizacja docelowa” liczona z pola `type`, sekcje `Historia zmian` i `7. Powiązany prompt generujący`.
