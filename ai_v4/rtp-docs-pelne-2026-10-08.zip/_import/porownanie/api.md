# api

Wersje są bliskie: nazwy i kolejność głównych sekcji prawie się pokrywają, a różnice dotyczą kolumn tabel, wskazań konwencji CONV i sekcji, które nasz szablon dodaje dla grafu.

1. Pole „Zdolność” pod tytułem. U nich go nie ma, a zdolność trafia tylko do `related-doc-ids`. U nas przed `## Cel` stoi tabela `| Pole | Wartość |` z wierszem `Zdolność | CAP-{nnn}`, a guide każe podać zdolność w tym polu i wpisem `realizes`. Przyjęcie ich wersji usuwa z treści widoczne wskazanie zdolności.

2. Kolumna „Opis” w `## Parametry wejściowe`. U nich nagłówek tabeli to `| Parametr | Typ | Wymagany | Źródło | Opis |`. U nas `| Parametr | Typ | Wymagany | Źródło |` i komentarz „Nagłówków opisanych w konwencji nie powtarzasz.” Przyjęcie ich wersji dodaje opis każdego parametru.

3. Kolumny tabeli w `## Walidacja pól wejściowych`. U nich `| Parametr | Reguła walidacji | Kod błędu | Komunikat |`. U nas `| Reguła | Kod błędu HTTP | Komunikat zwracany przez system |`. Przyjęcie ich wersji przypisuje każdą regułę do parametru w osobnej kolumnie.

4. Wskazówki pod tabelą walidacji. U nich blok „Uwagi” każe wymienić wszystkie reguły (format, zakresy, długość, zależności warunkowe) i opisać walidację warunkową w kolumnie lub w sekcji Zachowanie. Kod HTTP i komunikat mają znacznik `<!--OPCJONALNIE-->`. Przy braku reguł wpisuje się „Nie dotyczy (wymagalność opisana w sekcji Parametry wejściowe)”. U nas tych wskazówek nie ma ani w szablonie, ani w guide, a kolumny kodu i komunikatu nie są opcjonalne. Przyjęcie ich wersji daje stały zapis pustej sekcji i zwalnia z podawania kodu i komunikatu.

5. Konwencja CONV w `## Autentykacja`, `## Struktura odpowiedzi błędnej` i `## Parametry wejściowe`. U nich `## Autentykacja` zawiera wprost „JWT Bearer / publiczny / rola wymagana.”, a `## Struktura odpowiedzi błędnej` opisuje strukturę JSON błędu w samym API. U nas obie sekcje zaczynają się od „Według CONV-{nnn}.” i dopisują tylko wymaganą rolę oraz kody błędów własnych punktu końcowego, a nagłówków z konwencji nie powtarza się w parametrach (`API-009 applies CONV-001`). Przyjęcie ich wersji oznacza, że każde API samo opisuje autentykację i format błędu, a API przestaje korzystać z typu `convention`.

6. Podsekcje `## Zachowanie`. U nich są to `### Scenariusz: {happy path}` i `### Scenariusz: {edge case}` z nazwą scenariusza w nagłówku, obie opcjonalne, a komentarz pozwala wstawić „link do flow, integracji itp”. U nas są to `### Przebieg podstawowy` i `### Przypadek brzegowy` bez nazwy, a przebieg podstawowy ma listę `FLOW-{nnn}`, `BPMN-{nnn}` i `SPEC-WF-{nnn}` z rolą każdego wskazania. Przyjęcie ich wersji pozwala nazywać i mnożyć scenariusze, ale usuwa wskazania procesów i kroków user-task (`API consumes SPEC-WF`), a integracje trafiałyby też do „Zachowanie”, choć u nas leżą tylko w „Zależności”.

7. Lista sekcji opcjonalnych. U nich sekcja „Warianty” wymienia jako opcjonalne: „Model odpowiedzi” (tylko przy nietrywialnej strukturze odpowiedzi), „Złożone parametry wejściowe”, „Struktura odpowiedzi błędnej” (tylko gdy „mamy założony format odpowiedzi przy błędnym przebiegu usługi”) i oba scenariusze w „Zachowanie”. U nas komentarz „Opcjonalnie” mają tylko „Złożone parametry wejściowe” i „Model odpowiedzi”, a guide mówi „Brak wariantów.” Przyjęcie ich wersji czyni „Struktura odpowiedzi błędnej” i podsekcje „Zachowanie” nieobowiązkowymi oraz dodaje warunek nietrywialnej struktury do „Model odpowiedzi”.

8. Sekcja `## Encje` jest tylko u nas. Wymienia encje, które w żądaniu lub odpowiedzi są osobnym bytem (`API-001 consumes ENT-Disposition`). Ich szablon API nie ma ani sekcji, ani pola na encje, choć ich szablon LDM zakłada, że API wskazuje `ENT-*`. Przyjęcie ich wersji sprawia, że graf nie wie, które API korzysta z danej encji.

9. Zakres `## Zależności`. U nich: „Lista integracji i serwisów, od których zależy endpoint.” U nas komentarz „Tylko integracje wołane poza przepływami; wywołań zapisanych w przepływie nie powtarzasz.”, a guide dodaje, że punkt końcowy nie woła innego punktu końcowego. Przyjęcie ich wersji powtarza integracje zapisane już w przepływie, a wpisanie innego API jako „serwisu” łamie zakaz 3 w `relation-matrix.yaml` (brak trójki `API consumes API`).

10. Sekcja `## Ograniczenia NFR` jest tylko u nas. Wskazuje wiersze NFR (`API-001 constrained_by NFR-001.NFRT-PERF-01`) bez powtarzania wierszy NFR zdolności. W ich szablonie API wymagania jakościowe nie występują. Przyjęcie ich wersji usuwa z API własne progi jakości.

11. Nazwa pliku. U nich: „Konwencja nazwy pliku: `{method}-{resource}.md` (np. `get-offers.md`, `post-reset-prelimit.md`).” U nas plik ma nazwę równą doc-id małymi literami, czyli `api-001.md` (`methodology.md`, sekcja 11, „Nazwy plików i folderów”). Przyjęcie ich wersji jest sprzeczne z metodyką i wymaga wyjątku dla API.

12. Treść sekcji 3 guide. U nich to lista informacji do zebrania przed pisaniem: metoda, ścieżka i cel biznesowy, parametry ze źródłem i wymagalnością, reguły walidacji, kody błędów HTTP i komunikaty, sposób autentykacji, struktura odpowiedzi z semantyką biznesową pól oraz integracje i serwisy, od których endpoint zależy. U nas sekcja 3 zawiera reguły wskazań w grafie i z ich listy ma tylko „Nie kopiujesz kontraktu OpenAPI.” Przyjęcie ich wersji dodaje do guide listę kontrolną, która w dużej części powtarza nazwy sekcji szablonu.

13. (drobna) Lista „Nie używaj gdy”. U nich jest odesłanie „opisujesz zdolność biznesową (co system robi i dlaczego) → użyj `capability`”, którego u nas nie ma. U nas są odesłania do `event` i `convention`, których nie ma u nich. Przyjęcie ich punktu dodaje odesłanie do `capability`.

14. (drobna) Przedrostek w tytule. U nich `title: "API: {METHOD} /{resource}"` i nagłówek `# API: {METHOD} /{resource}`. U nas `# {METODA} /{zasób}`. Przyjęcie ich wersji dodaje „API:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto różnice w front matter, sekcję `## Historia zmian` i sekcję 7 z promptem; nasze `BPMN-{nnn}` w „Zachowanie” przejdzie na BPMS.
