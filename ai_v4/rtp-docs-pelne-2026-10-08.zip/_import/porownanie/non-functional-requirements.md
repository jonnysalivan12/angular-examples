# non-functional-requirements

Wersje mają ten sam szkielet sekcji, ale różnią się prefiksem identyfikatorów wierszy, kolumnami macierzy i sekcją `## Traceability do artefaktów`, która jest sprzeczna z naszą metodyką.

1. Prefiks identyfikatora wiersza macierzy. U nich wiersze to `NFR-PERF-01`, `NFR-AVAIL-01`, `NFR-SEC-01` w kolumnie `NFR-ID`, a sekcja 4 mówi, że to „lokalne ID wierszy macierzy”. U nas `NFRT-PERF-01` w kolumnie `ID`, a inne dokumenty wskazują wiersz pełnym ID `NFR-001.NFRT-PERF-01`. Matryca wymaga, by prefiks wiersza różnił się od prefiksów dokumentów (`relation-matrix.yaml`, grupa 1), a tabela w `methodology.md`, sekcja 3, podaje prefiks `NFRT`. Przyjęcie ich wersji daje wierszowi ten sam prefiks co dokumentowi, wbrew obu regułom.

2. Sekcja `## Traceability do artefaktów` jest tylko u nich. Tabela `| NFR-ID | Capability | UC | TUC | API | Integracja |` wymienia dokumenty, które podlegają danemu wierszowi; ich „Użyj gdy” ma też punkt „potrzebujesz mapowania NFR do artefaktów funkcjonalnych i technicznych”. U nas te dokumenty mają wpisy `constrained_by`, a listę „wskazywany przez” wylicza graf (`methodology.md`, sekcja 7, przykład `NFR-001.NFRT-PERF-01`). Przyjęcie ich wersji oznacza, że NFR wymienia dokumenty, które go wskazują, i trzeba go zmieniać przy każdym nowym API, UC czy integracji.

3. Kolumny macierzy. U nich `| NFR-ID | Atrybut jakości | Metryka | Próg docelowy | Metoda pomiaru | Środowisko | Priorytet | Owner |`. U nas `| ID | Atrybut jakości | Metryka | Próg docelowy | Metoda pomiaru |`. Przyjęcie ich wersji dodaje do każdego wiersza środowisko (np. `PROD`, `ALL`), priorytet (np. `Must`) i zespół odpowiedzialny (np. `SRE`).

4. Wpisy w `Katalog według kategorii`. U nich każda kategoria ma wpisy z ID wiersza, np. `- [NFR-PERF-01] {Opis}`. U nas pod każdą kategorią jest dowolny tekst, np. `{Wymagania wydajności}`. Przyjęcie ich wersji wiąże każdy wpis katalogu z wierszem macierzy.

5. Obszar w doc-id. U nich komentarz przy `doc-id` dopuszcza obszar: „obszar opcjonalny (NFR-payments-001)”. U nas format to `NFR-{nnn}`. Przyjęcie ich wersji daje dokumentom NFR dwa formaty doc-id, a pełne ID wiersza mogłoby wyglądać tak: `NFR-payments-001.NFRT-PERF-01`.

6. Znaczenie pola „Właściciel” w tabeli pod tytułem. U nich wiersz `**Właściciel**` ma wartość `[zespół / rola]`, a `owner` we front matter to osoba. U nas `Właściciel | {Imię Nazwisko}`, czyli to samo co `owner`. Przyjęcie ich wersji rozdziela zespół odpowiedzialny za wymagania od osoby odpowiedzialnej za dokument.

7. Zasady numeracji wierszy są tylko u nas. Nasz guide mówi, że numer liczy się osobno w każdej kategorii (po `NFRT-PERF-02` następny jest `NFRT-PERF-03`) i nie wraca do obiegu po usunięciu wiersza. U nich nie ma reguł numeracji. Przyjęcie ich wersji usuwa z guide przypomnienie reguły z `methodology.md`, sekcja 3, o niepowtarzaniu numerów.

8. Zakres „Użyj gdy”. U nich NFR definiuje się „dla komponentu lub procesu”, a lista ma też punkty o etapie VISION i o jednym źródle prawdy dla SLA/SLO, bezpieczeństwa, dostępności i monitoringu. U nas jest jeden warunek: wymagania jakościowe „systemu lub komponentu”. Oba szablony mają w wariantach tylko `scope: system` i `scope: component`, choć tabela pod tytułem w obu dopuszcza `process`. Przyjęcie ich wersji dopuszcza w guide NFR procesu, dla którego nie ma wariantu.

9. (drobna) Kod kategorii ciągłości działania. U nich `### Continuity (RTO/RPO)` ma wpis `NFR-DR-01`. U nas kod tej kategorii to `CONT` (guide, sekcja 3). Przyjęcie ich wersji zmienia kod na `DR`.

10. (drobna) Wartości pola „Krytyczność”. U nich `[wysoka / średnia / niska]`, u nas `{Krytyczność}`. Przyjęcie ich wersji ogranicza pole do trzech wartości.

11. (drobna) Treść `## Cel i kontekst`. U nich: „po co definiujemy NFR i jakie ryzyka redukujemy”. U nas: „Po co są wymagania jakościowe i czego dotyczą”. Przyjęcie ich wersji dodaje opis ryzyk, które wymagania ograniczają.

12. (drobna) Nazwy sekcji i kolumn. U nich `## Macierz wymagań niefunkcjonalnych`, `## Katalog NFR wg kategorii`, `## Weryfikacja i monitoring` i `## Wyjątki / Waivery`. U nas `## Macierz wymagań`, `## Katalog według kategorii`, `## Weryfikacja i monitorowanie` i `## Wyjątki i odstępstwa`. Tabele weryfikacji i wyjątków mają te same kolumny pod innymi nazwami, np. u nich `| NFR-ID | Jak weryfikujemy przed release | Jak monitorujemy po release | Alert threshold |`, u nas `| ID | Przed wydaniem | Po wydaniu | Próg alertu |`. Przyjęcie ich nazw wymaga poprawienia odwołań do „Macierzy wymagań” w `relation-matrix.yaml` i do „Katalogu według kategorii” w naszym guide.

13. (drobna) Lista „Nie używaj gdy”. U nich są odesłania do `use-case` i `technical-use-case` (przebieg scenariusza), `api-endpoint` (kontrakt endpointu) i `capability` („capability alokuje NFR do komponentu”). U nas jest jedno odesłanie, do `business-functional-spec` (wymaganie funkcjonalne procesu). Przyjęcie ich punktów dodaje trzy odesłania.

14. (drobna) Lista wiedzy wstępnej w sekcji 3 guide. U nich analityk musi znać kontekst biznesowy i krytyczność procesu, oczekiwane SLA/SLO, wymagania regulacyjne i bezpieczeństwa oraz to, które metryki są mierzalne i kto je utrzymuje. U nas sekcja 3 ma etap VISION i zasady identyfikatorów, bez tych pytań. Przyjęcie ich wersji dodaje do guide te pytania przygotowawcze.

15. (drobna) Przedrostek w tytule. U nich `title: "NFR: {Nazwa obszaru}"` i taki sam nagłówek `#`. U nas `# {Nazwa}`. Przyjęcie ich wersji dodaje „NFR:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto pola `type`, `component`, `source-spec-ids`, `related-doc-ids` i `examples-ids`, opcjonalność `owner`, regułę lokalizacji pliku według pola `type`, sekcję `## Historia zmian` i sekcję 7 z promptem.
