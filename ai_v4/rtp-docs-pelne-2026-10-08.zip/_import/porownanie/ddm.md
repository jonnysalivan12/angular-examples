# ddm

Wersje są bliskie: mają te same sekcje w tej samej kolejności, a różnią się opisem tego, kto wskazuje pojęcia i reguły, nazwą pliku, miejscem Jiry wśród źródeł i kilkoma kolumnami tabel.

1. Kto wskazuje pojęcia `DOM` i reguły `RD`.
   - U nich: sekcja 2 mówi o „jedno źródło prawdy dla pojęć, do którego referują LDM, API i inne SPEC”. Komentarz do słownika: „Każde pojęcie dostaje stabilne ID (DOM-*), po którym referują inne SPEC.” Komentarz do reguł: „Stabilne ID (RD-*) pozwala referować je z LDM, API i testów.”
   - U nas: według `relation-matrix.yaml` pojęcie `DOM` wskazują tylko LDM, ENT i STM, a regułę `RD` tylko ENT (`ENT realizes RD`). API dociera do pojęcia przez encję (`API consumes ENT`).
   - Po przyjęciu ich wersji: API, LDM i inne dokumenty wspominałyby w treści reguły `RD`, a API także pojęcia `DOM`, choć matryca nie ma dla tych par trójki, więc walidator zgłosi błąd.

2. Nazwa pliku.
   - U nich: „Konwencja nazwy pliku: jeden obszar domenowy = jeden plik DDM (np. `ddm-case.md`, `ddm-loans.md`).”
   - U nas: plik ma nazwę równą doc-id małymi literami, np. `ddm-001.md`, i leży w folderze `shared/domains/DDM-001/` (`methodology.md`, sekcja 11). Zasada „jeden obszar to jeden DDM” jest w obu wersjach.
   - Po przyjęciu ich wersji: nazwa pliku DDM pochodziłaby od nazwy obszaru, co jest niezgodne z regułą nazewnictwa wspólną dla wszystkich typów.

3. Jira wśród źródeł modelu.
   - U nich: `## Źródła wymagań (w górę)` to lista z trzema pozycjami: `CaseRepository / EA`, `Jira` („[epiki/story/bugi wpływające na model]”) i `Polityki / regulacje`. Sposób pracy w sekcji 6 też zaczyna od Jiry.
   - U nas: jedno pole `{Źródła modelu: EA/CaseRepository, polityki i regulacje}`, bez Jiry. Guide wymienia jako źródła model EA i rozmowy.
   - Po przyjęciu ich wersji: DDM wymieniałby zgłoszenia Jira, które zmieniły model, a źródła miałyby stały podział na trzy pozycje.

4. Reguła o sekcjach, które nie dotyczą dokumentu.
   - U nich: komentarz nad strukturą: `Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem.`
   - U nas: ani szablon, ani guide nie mówią, co zrobić z sekcją, która nie dotyczy dokumentu.
   - Po przyjęciu ich wersji: każda sekcja byłaby obowiązkowa, a pusta sekcja musiałaby mieć wpis „Nie dotyczy” z uzasadnieniem.

5. Kolumna z nazwą pojęcia w `Słownik pojęć domenowych` (drobna).
   - U nich: `| ID | Pojęcie | Definicja biznesowa | Synonimy | Właściciel pojęcia |`.
   - U nas: `| ID | Definicja | Synonimy | Właściciel pojęcia |`. Nazwa pojęcia jest częścią ID `DOM-{Nazwa}`.
   - Po przyjęciu ich wersji: nazwa pojęcia stałaby w osobnej kolumnie obok ID, więc trzeba ustalić, czy obie nazwy mogą się różnić.

6. Kolumny tabeli `Encje i Value Objects` (drobna).
   - U nich: `| ID | Element | Typ (Encja / VO) | Tożsamość | Odpowiedzialność |`.
   - U nas: `| Pojęcie | Typ | Tożsamość | Odpowiedzialność |`, gdzie kolumna `Pojęcie` zawiera `DOM-{Nazwa}`.
   - Po przyjęciu ich wersji: obok ID doszłaby kolumna `Element` z nazwą, tak jak w punkcie 5.

7. Treść sekcji `Zakres poza dokumentem` (drobna).
   - U nich: sekcja ma gotowy tekst: DDM nie opisuje struktury logicznej ani konsumentów modelu.
   - U nas: pole `{Czego model nie opisuje}`. Te same dwie zasady są w guide, sekcja 3.
   - Po przyjęciu ich wersji: każdy DDM powtarzałby te dwie zasady w treści.

8. Lista „Czego nie umieszczać” (drobna).
   - U nich: sekcja 6 `Zasady wypełniania` wymienia też typy fizyczne (`VARCHAR`, indeksy, migracje) oraz „Kodu 1:1 i kontraktów OpenAPI/AsyncAPI”.
   - U nas: guide wymienia tylko strukturę logiczną i konsumentów. Zakaz kopiowania kodu i kontraktu OpenAPI jest ogólnym inwariantem I7 w `templates/_00-meta.md`.
   - Po przyjęciu ich wersji: guide DDM dostałby jawny zakaz typów fizycznych i kontraktów.

9. Sekcja 2 guide, czyli kiedy użyć (drobna).
   - U nich: „Użyj gdy” ma trzy punkty, w tym „opisujesz znaczenie danych całego przypadku (case), np. Case, Loans, CurrentAccounts”. „Nie używaj gdy” odsyła też przy fizycznej bazie („to nie jest dokumentowane na poziomie analizy”) i przy kontrakcie API lub przepływie do `api-endpoint.md` / `flow.md`.
   - U nas: jeden punkt „Użyj gdy” i jedno odesłanie do `ldm` i `ldm-entity`.
   - Po przyjęciu ich wersji: guide podpowiadałby wielkość obszaru i odsyłał do `api` i `flow`. U nas typ nazywa się `api`, nie `api-endpoint`.

10. Sekcja 3 guide, czyli co analityk musi wiedzieć (drobna).
    - U nich: pytania o obszar i jego granice, źródło domeny, pojęcia wymagające definicji oraz reguły i inwarianty, z definicją inwariantu i przykładami, np. „każda sprawa ma co najmniej jednego klienta”.
    - U nas: reguły zapisu i sposób pracy, bez definicji inwariantu.
    - Po przyjęciu ich wersji: guide dostałby pytania przygotowawcze i definicję inwariantu z przykładami.

11. Reguła o brakującym pojęciu (tylko u nas, drobna).
    - U nich: brak.
    - U nas: „Encja i maszyna stanów wskazują własne pojęcie. Brakujące pojęcie dopisujesz do DDM, zamiast wskazywać najbliższe.”
    - Po przyjęciu ich wersji: z guide zniknęłaby reguła, która jest też w `relation-matrix.yaml` (grupa 3).

12. Nagłówki (drobna).
    - U nich: `# DDM: {Nazwa obszaru domenowego}` i `## Źródła wymagań (w górę)`.
    - U nas: `# {Obszar domenowy}` i `## Źródła wymagań w górę`.
    - Po przyjęciu ich wersji: nagłówek dokumentu dostałby prefiks typu, a nagłówek źródeł nawias.

13. Komentarze `dlaczego` w szablonie (drobna).
    - U nich: każda sekcja ma komentarz `<!-- dlaczego: … -->` z uzasadnieniem sekcji.
    - U nas: jedyny komentarz to `<!-- Opcjonalnie diagram classDiagram. -->`. Według `_00-meta.md` komentarz HTML w szablonie oznacza regułę sekcji.
    - Po przyjęciu ich wersji: komentarze w szablonie mieszałyby uzasadnienia sekcji z regułami.

Pominięte zgodnie z decyzją: pola `type` i `component`, „Lokalizacja docelowa” liczona z pola `type`, sekcje `Historia zmian` i `7. Powiązany prompt generujący`.
