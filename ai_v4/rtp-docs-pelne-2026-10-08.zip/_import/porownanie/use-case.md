# use-case

Wersje mają te same sekcje w tej samej kolejności, ale różnią się mocno w treści: nasza zapisuje kroki w tabelach z kolumnami `Ekran`, `Sekcja` i `Wywołanie`, aktorów jako role z bazy ACTOR i odwołania pełnym ID, a ich wersja opisuje kroki listą, aktorów nazwą i używa krótkich ID.

1. Postać kroków, wariantów i błędów.
   - U nich: `## Kroki — co się dzieje po kolei` to lista numerowana („1. Użytkownik [wykonuje akcję] — widzi [efekt]”). Warianty `A` i błędy `E` też są listami numerowanymi.
   - U nas: `## Kroki` oraz każda podsekcja `A{n}` i `E{n}` to tabela `| Nr | Krok | Ekran | Sekcja | Wywołanie |`. Z kolumn wynikają relacje `UC contains SCR`, `UC contains SCRSEC` oraz `UC consumes API` i `QUE` (`relation-matrix.yaml`, grupy 2 i 4). Guide ma do tych kolumn kilka reguł: integracji INT scenariusz nie woła wprost, zadanie procesu obsługuje przez API, kroku SPEC-WF nie wymienia.
   - Po przyjęciu ich wersji: ekrany, sekcje i wywołania nie miałyby stałego miejsca w treści, a komentarze matrycy o kolumnach „Ekran”, „Sekcja” i „Wywołanie” nie miałyby oparcia w szablonie.

2. Krótkie ID w treści.
   - U nich: `Powiązane REQ` ma wartość `[REQ-01, REQ-04]`, tabela `Powiązanie z BFS` ma `REQ-01`, kryteria akceptacji kończą się na `(REQ-01)`, a progi NFR mają ID `NFR-PERF-01` i `NFR-SEC-01`.
   - U nas: pełne ID wierszy `BFS-{nnn}.REQ-{nn}`, `BFS-{nnn}.RB-{nn}` i `NFR-{nnn}.NFRT-{KATEGORIA}-{nn}` (`methodology.md`, sekcja 3).
   - Po przyjęciu ich wersji: krótkie ID nie mówi, z którego BFS albo NFR pochodzi wiersz, więc nie da się z niego zapisać relacji `realizes` ani `constrained_by`, a walidator nie sprawdzi, czy cel istnieje.

3. Własne ID reguł w `Reguły biznesowe`.
   - U nich: tabela `| ID RB | Zasada | Źródło w BFS |`. UC nadaje regułom ID `RB-01` i w kolumnie `Źródło w BFS` podaje `[RB-01]`.
   - U nas: lista `- BFS-{nnn}.RB-{nn}: {jak reguła działa w scenariuszu}`. Prefiks `RB` należy do wierszy BFS, a UC ma własne wiersze tylko `A` i `E` (`relation-matrix.yaml`, grupa 1).
   - Po przyjęciu ich wersji: prefiks `RB` oznaczałby wiersze w dwóch typach dokumentów, a matryca nie ma trójki `UC contains RB`.

4. Aktorzy podawani nazwą.
   - U nich: wiersz `Aktor główny` ma wartość `[np. Klient / Doradca / Pracownik oddziału]`, a sekcja `## Aktorzy` to opis tekstem: „Kto bierze udział w tym scenariuszu — opisz rolą, nie stanowiskiem technicznym.”
   - U nas: `Aktor główny` ma wartość `ACTOR-{nnn}.ROLE-{nn}`, a `## Aktorzy` to lista `- ACTOR-{nnn}.ROLE-{nn}: {udział w scenariuszu}`. Rola pochodzi ze wspólnej bazy ACTOR i daje relację `involves`.
   - Po przyjęciu ich wersji: UC nie wskazywałby roli z bazy aktorów, więc graf nie wyliczyłby udziału ról w scenariuszach (`methodology.md`, sekcja 7), a nazwy aktorów mogłyby się rozejść z nazwami kanonicznymi.

5. Wiersz `BFS / SPEC` w tabeli nagłówkowej.
   - U nich: `**BFS / SPEC**` z wartością „[SPEC-XXX — link względny do dokumentu nadrzędnego]”. Sekcja 3 pyta, „Który BFS/SPEC jest dokumentem nadrzędnym”.
   - U nas: wiersz `BFS` z wartością `BFS-{nnn}`. Dokumentem nadrzędnym jest zawsze BFS, a typu `SPEC` nie mamy; jest tylko `SPEC-WF`, czyli krok procesu.
   - Po przyjęciu ich wersji: dokumentem nadrzędnym mógłby być dokument innego typu niż BFS, wskazany linkiem względnym zamiast ID.

6. Wiersz `Makiety` i miejsce ekranów.
   - U nich: `**Makiety**` z wartością „[link do GUI SPEC/UI SPEC - [screen.md], [screen-section.md]]”, czyli linki do dokumentów ekranów i sekcji dla całego UC.
   - U nas: `Makiety` z wartością `{Odnośnik}`, a dokumenty ekranów i sekcji wskazuje każdy krok w kolumnach `Ekran` i `Sekcja`.
   - Po przyjęciu ich wersji: ekrany byłyby przypisane do całego scenariusza linkiem do pliku, a nie do kroku przez ID.

7. Opis ograniczeń NFR.
   - U nich: `## Ograniczenia NFR (referencje)` z tabelą `| NFR-ID | Ograniczenie w UC |`, czyli przy każdym progu jest opis, jak ogranicza scenariusz.
   - U nas: `## Ograniczenia NFR` z listą samych ID `- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}`, bez opisu. Guide dodaje regułę, której u nich nie ma: wiersza NFR swojej zdolności UC nie powtarza.
   - Po przyjęciu ich wersji: każdy próg dostałby opis wpływu na UC. Zmiana nagłówka wymaga też poprawki komentarza w `relation-matrix.yaml` (grupa 5), który wskazuje sekcję „Ograniczenia NFR”.

8. Kryteria akceptacji powiązane z wymaganiami.
   - U nich: lista z polami wyboru `- [ ]`, a każde kryterium kończy się ID wymagania albo reguły, np. „(`REQ-01`)”, „(`RB-03`)”.
   - U nas: `- Kiedy {sytuacja}, wtedy {oczekiwany wynik}.` bez pola wyboru i bez ID.
   - Po przyjęciu ich wersji: każde kryterium wskazywałoby wymaganie lub regułę, a to ID musiałoby mieć pełną formę i relację `realizes` w front matter.

9. Komunikat i możliwości użytkownika w sytuacji błędnej.
   - U nich: `E1` ma kroki `Widzi komunikat: _„[treść komunikatu dla użytkownika]"_` oraz `Może [spróbować ponownie / skontaktować się z doradcą / wrócić do poprzedniego ekranu]`.
   - U nas: tabela kroków `E1` bez wymogu podania treści komunikatu i dalszych możliwości użytkownika.
   - Po przyjęciu ich wersji: każda sytuacja błędna musiałaby podać treść komunikatu i to, co użytkownik może zrobić dalej.

10. Punkt powrotu po wariancie.
    - U nich: ostatni krok wariantu `A2` brzmi „Wraca do kroku [X] lub kończy operację”.
    - U nas: tabela wariantu nie wymaga wskazania, gdzie przebieg wraca.
    - Po przyjęciu ich wersji: każdy wariant musiałby kończyć się krokiem powrotu albo zakończeniem operacji.

11. Reguła o sekcjach, które nie dotyczą dokumentu.
    - U nich: komentarz nad strukturą: `Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem.` Wariant uproszczony każe wypełnić `Co może pójść inaczej` i `Co może pójść nie tak` jako „Nie dotyczy” z uzasadnieniem.
    - U nas: wariant uproszczony to „jeden przepływ, bez diagramu”, bez reguły o pustych sekcjach.
    - Po przyjęciu ich wersji: każda sekcja byłaby obowiązkowa, a pusta sekcja musiałaby mieć wpis „Nie dotyczy” z uzasadnieniem.

12. Wiersz `Zdolność` w tabeli nagłówkowej (tylko u nas, drobna).
    - U nich: brak. CAP jest tylko w `related-doc-ids`.
    - U nas: wiersz `Zdolność` z wartością `CAP-{nnn}`, a guide mówi, że przy kilku zdolnościach każda ma osobny wpis `realizes`.
    - Po przyjęciu ich wersji: zdolność zniknęłaby z treści i została tylko w `relations`.

13. Gotowy wariant `A1` (drobna).
    - U nich: szablon ma wypełniony wariant `A1: Użytkownik rezygnuje`: użytkownik wybiera „Anuluj” albo zamyka ekran i nic nie zostaje zapisane.
    - U nas: `### A1. {Nazwa wariantu}` bez treści.
    - Po przyjęciu ich wersji: każdy nowy UC zaczynałby od tego wariantu i trzeba by go usuwać, gdy nie dotyczy.

14. Wzorzec opisu kroku (drobna).
    - U nich: „Każdy krok: kto wykonuje akcję i co widzi / dostaje w odpowiedzi.”
    - U nas: kolumna `Krok` z polem `{Opis kroku}`, bez wzorca.
    - Po przyjęciu ich wersji: każdy krok podawałby wykonawcę i to, co użytkownik widzi w odpowiedzi.

15. Warunek dodania diagramu (drobna).
    - U nich: „Opcjonalny — dodaj gdy przebieg ma więcej niż jedno rozgałęzienie decyzyjne.” oraz pełny przykładowy diagram z kolorami.
    - U nas: `<!-- Opcjonalny, najwyżej 15 kroków. -->` i pusty `flowchart TD`.
    - Po przyjęciu ich wersji: szablon mówiłby, kiedy diagram jest potrzebny.

16. Treść wariantu `Po BFS` (drobna).
    - U nich: trzy zasady: obowiązkowo wypełnij `Powiązanie z BFS (wymagania nadrzędne)`, wpisz referencje do `REQ-*` i `RB-*`, „Nie duplikuj pełnych treści wymagań z BFS, tylko mapuj i uszczegóławiaj przebieg”.
    - U nas: „**Po BFS**: zalecany.” bez treści.
    - Po przyjęciu ich wersji: guide dostałby zakaz kopiowania treści wymagań z BFS.
    - Uwaga: obie wersje nazywają ten wariant zalecanym, czyli dopuszczają UC bez BFS. U nas UC bez wpisu `realizes` do wymagania BFS nie ma folderu procesu (`methodology.md`, sekcja 11).

17. Odesłania w „Nie używaj gdy” (drobna).
    - U nich: odesłania do `technical-use-case`, `capability`, `integration` i `flow`.
    - U nas: odesłania do `technical-use-case` i `business-functional-spec`.
    - Po przyjęciu ich wersji: guide odsyłałby też do zdolności, integracji i przepływu, a straciłby odesłanie do BFS.

18. Sekcja 3 guide, czyli co analityk musi wiedzieć (drobna).
    - U nich: pytania o głównego aktora i jego cele, kanały, warunki wstępne, punkt końcowy i sukces oraz dokument nadrzędny.
    - U nas: reguły zapisu relacji i kolumn tabel kroków.
    - Po przyjęciu ich wersji: guide dostałby pytania przygotowawcze.

19. Nagłówki (drobna).
    - U nich: `# Use Case: {Nazwa scenariusza}`, `## Powiązanie z BFS (wymagania nadrzędne)`, `## Kroki — co się dzieje po kolei`, `### A1: …`, `### E1: …`.
    - U nas: `# {Nazwa scenariusza}`, `## Powiązanie z BFS`, `## Kroki`, `### A1. …`, `### E1. …`.
    - Po przyjęciu ich wersji: zmieniłyby się nazwy nagłówków, bez wpływu na relacje.

20. Komentarze `DLACZEGO` w szablonie (drobna).
    - U nich: każda sekcja ma komentarz `<!-- DLACZEGO: … -->` z uzasadnieniem sekcji.
    - U nas: komentarze są tylko przy kolumnie `Sekcja` i przy diagramie. Według `_00-meta.md` komentarz HTML w szablonie oznacza regułę sekcji.
    - Po przyjęciu ich wersji: komentarze w szablonie mieszałyby uzasadnienia sekcji z regułami.

Pominięte zgodnie z decyzją: pola `type`, `component`, `source-spec-ids`, `related-doc-ids`, „Lokalizacja docelowa” liczona z pola `type`, łączenie plików wariantu złożonego przez `related-doc-ids`, sekcje `Historia zmian` i `7. Powiązany prompt generujący`.
