# ldm

Wersje są bliskie: sekcje pokrywają się poza `## Reguły walidacyjne i spójność`, a różnice dotyczą głównie tabel, które u nas są listą albo tekstem, i formy identyfikatorów.

1. Sekcja `## Reguły walidacyjne i spójność` jest tylko u nich. Ma tabelę `| ID | Reguła | Powiązanie z DDM | Kryterium |` z regułami `RW-001` obejmującymi wiele encji i z odwołaniem do `RD-001`. U nas „Reguły walidacyjne RW leżą w encji, którą walidują”, a regułę między agregatami zapisuje się jako RD w DDM albo RB w BFS. Przyjęcie ich wersji łamie `relation-matrix.yaml`, bo nie ma trójki `LDM contains RW` ani `LDM realizes RD`, a RW leży w encji (`ENT contains RW`).

2. Tabela w `## Encje`. U nich `| ID | Encja | Alias (biznesowy) | Opis | Szczegóły |` z linkiem do pliku `entities/encja-a.md`. U nas lista `- ENT-{Nazwa}`. Przyjęcie ich wersji dodaje alias i opis w indeksie, ale link do podfolderu `entities/` jest sprzeczny z metodyką: encja leży w folderze domeny obok LDM i ma plik nazwany od doc-id, np. `ent-disposition.md` (`methodology.md`, sekcja 11).

3. Tabela w `## Mapowanie DDM → LDM`. U nich `| Pojęcie domenowe (DDM) | Obiekt logiczny (LDM) | Uzasadnienie |` z krótkim `DOM-{Nazwa}`. U nas `| Pojęcie | Encja | Uzasadnienie |` z pełnym `DDM-{nnn}.DOM-{Nazwa}`. Przyjęcie krótkiego identyfikatora jest sprzeczne z sekcją 3 metodyki, według której inne dokumenty wskazują wiersz pełnym identyfikatorem.

4. Tabela w `## Kluczowe relacje`. U nich `| Encja źródłowa | Liczebność | Encja docelowa | Opis relacji |`. U nas tekst `{Najważniejsze relacje między encjami}`. Przyjęcie ich wersji wymusza liczebność każdej relacji w indeksie, obok diagramu ER i tabel `## Powiązania` w encjach.

5. (drobna) Tabela w `## Słowniki zewnętrzne`. U nich `| Słownik | Używany w | Źródło / ścieżka |`. U nas tekst `{Słowniki spoza modelu, z których korzystają encje}`. Przyjęcie ich wersji zapisuje słowniki w tabeli z miejscem użycia.

6. (drobna) Treść `## Zakres poza dokumentem`. U nich jest stała lista: znaczenie i reguły domeny z linkiem `../../functional/data-models/ddm.md`, klucze fizyczne, tabele, kolumny, indeksy i migracje, szczegóły ORM oraz konsumenci modelu. U nas placeholder `{Czego model nie opisuje}`. Przyjęcie ich wersji daje gotową listę, ale ścieżka w linku nie pasuje do naszego układu katalogów.

7. Zasada „Nie dotyczy” i komentarze „dlaczego”. U nich: „Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem.”, a każda sekcja ma komentarz `<!-- dlaczego: … -->`. U nas nie ma ani tej zasady, ani komentarzy. Przyjęcie ich wersji czyni wszystkie sekcje obowiązkowymi i dodaje do szablonu uzasadnienie każdej sekcji.

8. (drobna) `## Diagram ER`. U nich jest przykładowy diagram z dwiema encjami, atrybutami i relacją, legenda notacji liczebności w komentarzu i reguła „tożsamość encji opisz w komentarzu atrybutu”. U nas pusty `erDiagram` i komentarz „Bez kluczy PK/FK, z notacją liczebności.” Przyjęcie ich wersji daje wzór diagramu i legendę.

9. (drobna) Słownik typów logicznych. U nich tabela `| Typ logiczny | Opis | Typowe mapowania fizyczne |`. U nas te same dziewięć typów w jednym zdaniu guide, bez opisów i mapowań. Przyjęcie ich wersji dodaje opis i fizyczne odpowiedniki każdego typu.

10. (drobna) Lista „Czego nie umieszczać”. U nich jest punkt „Kopii kontraktów OpenAPI/AsyncAPI”, którego u nas nie ma. U nas jest punkt „wartości domyślnych zależnych od środowiska”, którego nie ma w ich LDM, tylko w ich encji. Przyjęcie ich wersji dodaje zakaz kopiowania kontraktów.

11. Reguły grafu tylko u nas. Nasz guide mówi, że LDM realizuje pojęcia „wszystkie z jednego DDM”, że jeden DDM może mieć kilka LDM, że encja należy do jednego LDM i że nazwa encji jest unikalna także między modelami (`ENT-Account`, `ENT-AccountSnapshot`). U nich tych reguł nie ma. Przyjęcie ich wersji bez tych zdań usuwa z guide reguły, które sprawdza walidator przy trójkach `LDM realizes DOM` i `LDM contains ENT`.

12. (drobna) Lista „Nie używaj gdy”. U nich są odesłania: fizyczna baza „poza zakresem analizy” oraz opis użycia danych przez API „w SPEC API, referując do `ENT-*`”. U nas jest odesłanie do `ldm-entity`, którego na ich liście nie ma. Przyjęcie ich wersji dodaje dwa odesłania.

13. (drobna) Identyfikator w tabeli pod tytułem. U nich wiersz `**ID**` ma `LDM-{obszar}`, choć ich front matter ma `LDM-{numer}`. U nas `LDM-{nnn}` w obu miejscach. Przyjęcie ich wersji wprowadza identyfikator od nazwy obszaru, niezgodny z ich własnym front matter.

14. (drobna) Przedrostek w tytule. U nich `# LDM: {Nazwa obszaru logicznego}`. U nas `# {Nazwa modelu}`. Przyjęcie ich wersji dodaje „LDM:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto różnice w front matter (`source-spec-ids`), sekcję `## Historia zmian` i sekcję 7 z promptem.
