# capability

Wersje są daleko od siebie: ich szablon opisuje jedną granularną zdolność z tabelami regulacji, miar i ryzyk oraz ze wskazaniami wymagań i API, a nasz opisuje zakres odpowiedzialności komponentu z sekcjami dla grafu.

1. Definicja i ziarnistość. U nich Capability to „konkretna, mierzalna zdolność systemu”, która „musi być granularne, domenowe”, a „Jedno Capability opisuje jedną spójną zdolność; nie może być ogólnym workiem na funkcje, komponenty ani integracje”. Szeroki zestaw funkcji każą rozbić na odrębne Capability. U nas CAP to „Zakres odpowiedzialności komponentu, modułu lub domeny, podobnie jak kontrakt komponentu” i „mapa artefaktów”, a metodyka mówi „Komponenty opisują dokumenty zdolności CAP” (`methodology.md`, sekcja 5). Przyjęcie ich wersji zmienia ziarnistość, bo jeden komponent może wtedy mieć kilka CAP, i wymaga zmiany opisu CAP w metodyce (sekcje 5 i 10).

2. Podział na `## Opis` i `## Wartość biznesowa`. U nich są dwie sekcje: `## Opis` (co system robi, dla kogo i jaki daje obserwowalny rezultat) oraz `## Wartość biznesowa` (wartość, odbiorca, problem, „możliwa do oceny miarami”). Obie należą do ich wariantu minimalnego. U nas jest jedna sekcja `## Cel biznesowy`. Przyjęcie ich wersji dodaje sekcję opisu i zmienia nazwę naszej sekcji.

3. (drobna) Nagłówki i forma zakresu. U nich `## Zakres odpowiedzialności (in-scope)` jako lista punktowana i `## Poza zakresem (out-of-scope)`. U nas `## Zakres odpowiedzialności` i `## Poza zakresem` bez angielskich dopisków, z tekstem ciągłym. Przyjęcie ich wersji zmienia nagłówki i zapisuje zakres jako listę.

4. Tabela w `## Poza zakresem`. U nich tabela `| Element poza zakresem / odpowiedzialność | System lub Capability właściciela | Odpowiedzialna jednostka / owner | Referencja do kontraktu lub dokumentacji właściciela |`, właściciel dla każdego elementu i zapis „Brak” z informacją, kto potwierdził granicę. U nas placeholder `{Za co zdolność nie odpowiada}`. Przyjęcie ich wersji jest sprzeczne z `relation-matrix.yaml`: CAP może wspomnieć tylko QUE i wiersze NFR, a trójki CAP–CAP nie ma w żadnym kierunku, więc identyfikator cudzej zdolności albo jej API w tej tabeli walidator zgłosi jako błąd.

5. Sekcja `## Regulacje` jest tylko u nich. Ma tabelę `| Identyfikator i źródło regulacji | Wymaganie lub artykuł | Wpływ na działanie systemu / Capability | Właściciel interpretacji | Sposób monitorowania zmian |` i zapis „Nie zidentyfikowano” z osobą i terminem potwierdzenia. Należy do ich wariantu pełnego. U nas regulacji nie ma ani w szablonie, ani w guide. Przyjęcie ich wersji dodaje sekcję do naszego wariantu pełnego.

6. Tabela w `## Miary i kryteria skuteczności`. U nich `| Miara | Definicja i jednostka | Wartość bazowa | Oczekiwany próg | Źródło pomiaru / częstotliwość | Owner |`, a nieuzgodniony próg oznacza się jako lukę do decyzji ownera. U nas tekst `{Miary skuteczności: KPI, SLA}`. Przyjęcie ich wersji wymusza wartość bazową, próg, źródło pomiaru i właściciela każdej miary. Progi SLA u nas leżą też w NFR i CAP wskazuje je wpisem `constrained_by`, więc kolumna „Oczekiwany próg” może je dublować.

7. Tabela w `## Ryzyka i ograniczenia`. U nich `| Ryzyko lub ograniczenie | Prawdopodobieństwo / warunek | Wpływ na Capability | Mitygacja / zachowanie systemu | Owner |` i obowiązek opisania skutków niedostępności zależności. U nas tekst `{Ryzyka i ograniczenia zdolności}`. Przyjęcie ich wersji wymusza ocenę, mitygację i właściciela każdego ryzyka.

8. Sekcja `## Zdarzenia i kontrakty domenowe` z podsekcją `### Odbierane` jest tylko u nas (`CAP-001 consumes QUE-002`). W ich szablonie odbierane zdarzenia nie mają miejsca. Przyjęcie ich wersji odcina zdolność od zdarzeń, które odbiera, bo matryca zapisuje odbiór przez zdolność tylko trójką `CAP consumes QUE`.

9. Sekcja `## Ograniczenia NFR` jest tylko u nas (`CAP-002 constrained_by NFR-001.NFRT-SEC-01`). U nich NFR trafia do `related-doc-ids` i do generowanej sekcji „Powiązane dokumenty”. Przyjęcie ich wersji usuwa z treści listę wierszy NFR.

10. Wskazania wymagań i API ze zdolności. U nich guide każe wskazać, „Jakie wymagania wynikają z Capability oraz które API ją realizują”, a sekcja 5 i „Warianty” każą wykazywać je w metadanych, z których hook generuje sekcje „Powiązane dokumenty” i „Specyfikacje źródłowe”. U nas: „Zdolność nie wymienia tych dokumentów; ich listę wylicza graf.” oraz „Zdolność nie wskazuje wymagań BFS.” Przyjęcie ich wersji łamie sekcję 7 metodyki (lista „zakres zdolności” wynika z wpisów `realizes`) i zakaz 4 w `relation-matrix.yaml` (brak trójki `CAP realizes REQ`).

11. Zależność od zdolności innych domen. U nich przy korzystaniu z Capability innych domen „dokument wskazuje zależność i sposób jej wykorzystania”, a guide każe podać Capability innych domen z odnośnikami do dokumentacji właściciela. U nas zdolność wskazuje tylko odbierane zdarzenia i wiersze NFR. Przyjęcie ich wersji wymaga trójki CAP–CAP, której matryca relacji nie ma.

12. Zapis braków danych. U nich: „W wymaganych sekcjach, dla których brakuje danych, wskaż lukę, ownera i wymagany krok weryfikacji; nie wymyślaj danych.” U nas takiej reguły nie ma. Przyjęcie ich wersji wprowadza jednolity zapis luk w CAP.

13. (drobna) Dokumentacja przyrostowa. U nich CAP rozwija się w tym samym artefakcie: „Nie twórz nowego dokumentu dla każdej zmiany tej samej zdolności.” Nasz guide tego nie mówi. Przyjęcie ich wersji dodaje to zdanie do guide.

14. (drobna) Listy „Użyj gdy” i „Nie używaj gdy”. U nich „Użyj gdy” ma cztery sytuacje, m.in. „projektujesz architekturę systemu i ustalasz jego konkretne zdolności”, a „Nie używaj gdy” obejmuje cudzą zdolność domenową i „szeroki, niespójny zestaw funkcji → rozbij go na odrębne Capability”. U nas „Użyj gdy” ma jedną sytuację, a „Nie używaj gdy” ma odesłanie reguł biznesowych do `business-functional-spec`, którego u nich nie ma. Przyjęcie ich wersji zależy od decyzji w punkcie 1.

15. (drobna) Przedrostek w tytule. U nich `# Capability: {Nazwa zdolności}`. U nas `# {Nazwa zdolności}`. Przyjęcie ich wersji dodaje „Capability:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto różnice w front matter (`source-spec-ids`, `related-doc-ids`), sekcję `## Historia zmian` i sekcję 7 z promptem.
