# business-functional-spec

Wersje są bliskie: mają te same sekcje w tej samej kolejności, a różnią się kolumnami tabel, zapisem ID wierszy NFR, odwołaniami do UC i Jiry oraz regułą o sekcjach „Nie dotyczy”.

1. Kolumna `Powiązany UC / Jira` w tabeli `Wymagania funkcjonalne`.
   - U nich: `| ID | Wymaganie | Priorytet | Powiązany UC / Jira |`, z wartościami `[UC-XXX / STORY-XXX]`. Komentarz sekcji mówi: „Każde wymaganie ma identyfikator, żeby można je linkować z UC, AC, ticketami.”
   - U nas: `| ID | Wymaganie | Priorytet (MoSCoW) |`. Guide mówi: „BFS nie wymienia scenariuszy. Relację zapisuje UC albo TUC, który realizuje wymaganie”.
   - Po przyjęciu ich wersji: BFS wymieniałby wskazujące go UC wbrew `methodology.md`, sekcja 7, a walidator kazałby te wzmianki usunąć. Numery zgłoszeń Jira to osobna decyzja, bo nasz szablon nie ma na nie miejsca.

2. Zapis ID wymagań niefunkcjonalnych.
   - U nich: tabela podaje ID w formie `NFR-PERF-01` i `NFR-AVAIL-01`.
   - U nas: pełne ID wiersza `NFR-{nnn}.NFRT-{KATEGORIA}-{nn}`, bo cały NFR nie może być celem relacji (`relation-matrix.yaml`, „Czego nie wolno zapisać”, punkt 1).
   - Po przyjęciu ich wersji: ID nie wskazywałoby, z którego dokumentu NFR pochodzi próg, więc nie da się z niego zapisać relacji `constrained_by`.

3. Odesłanie do ADR.
   - U nich: „Nie używaj gdy: dokumentujesz decyzję architektoniczną → użyj `adr`”, a `related-doc-ids` szablonu zawiera `TPL-ADR`.
   - U nas: guide nie ma tego punktu, a spis `templates/_00-meta.md` nie ma typu ADR.
   - Po przyjęciu ich wersji: guide odsyłałby do typu, którego nie mamy, więc trzeba by dodać typ ADR albo pominąć to odesłanie.

4. Skala priorytetów.
   - U nich: kolumna `Priorytet` z wartościami `Must Have`, `Should Have`, `Could Have` i notą „Założenie: priorytety wg MoSCoW. Jeśli projekt stosuje inną skalę — dostosuj.”
   - U nas: kolumna `Priorytet (MoSCoW)` z wartościami `Must / Should / Could / Won't`, bez zgody na inną skalę.
   - Po przyjęciu ich wersji: projekt mógłby przyjąć własną skalę priorytetów, a z szablonu zniknęłaby wartość `Won't`.

5. Reguła o sekcjach, które nie dotyczą dokumentu.
   - U nich: komentarz nad strukturą: `Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem.`
   - U nas: ani szablon, ani guide nie mówią, co zrobić z sekcją, która nie dotyczy dokumentu.
   - Po przyjęciu ich wersji: każda sekcja byłaby obowiązkowa, a pusta sekcja musiałaby mieć wpis „Nie dotyczy” z uzasadnieniem.

6. Nagłówek i postać sekcji wymagań niefunkcjonalnych (drobna).
   - U nich: `## Wymagania niefunkcjonalne (referencje)` z tabelą `| NFR-ID | Kategoria | Wpływ na proces |`.
   - U nas: `## Wymagania niefunkcjonalne` z listą `- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}: {czego dotyczy w procesie}`.
   - Po przyjęciu ich wersji: lista stałaby się tabelą z osobną kolumną `Kategoria`. Zmiana nagłówka wymaga też poprawki komentarza w `relation-matrix.yaml` (grupa 5), który wskazuje sekcję „Wymagania niefunkcjonalne”.

7. Wzorzec treści wymagania (drobna).
   - U nich: przykładowe wiersze „Proces musi [co robić]”, „Proces powinien [co robić]” i „Proces może [co robić]” odpowiadają priorytetom `Must Have`, `Should Have` i `Could Have`.
   - U nas: pole `{Opis}` bez wzorca.
   - Po przyjęciu ich wersji: szablon podpowiadałby czasownik zgodny z priorytetem.

8. Postać sekcji `Słownik pojęć` (drobna).
   - U nich: tabela `| Pojęcie | Definicja |`.
   - U nas: lista `- **{Pojęcie}**: {definicja}`.
   - Po przyjęciu ich wersji: słownik byłby tabelą.

9. Postać sekcji `Założenia i otwarte pytania` (drobna).
   - U nich: podsekcje `### Założenia` i `### Otwarte pytania`, a tabela pytań ma kolumnę numeru: `| # | Pytanie | Właściciel | Termin | Status |`.
   - U nas: bez podsekcji, tabela `| Pytanie | Właściciel | Termin | Status |`.
   - Po przyjęciu ich wersji: założenia i pytania dostałyby osobne nagłówki, a pytania numery.

10. Uzasadnienie w `Poza zakresem` (drobna).
    - U nich: `[Co NIE należy do tego procesu — z krótkim uzasadnieniem]`.
    - U nas: `{Czego proces nie obejmuje}`.
    - Po przyjęciu ich wersji: każda pozycja spoza zakresu wymagałaby uzasadnienia.

11. Nagłówek dokumentu (drobna).
    - U nich: `# Specyfikacja funkcjonalna: {Nazwa procesu}`.
    - U nas: `# {Nazwa procesu}`.
    - Po przyjęciu ich wersji: nagłówek dostałby prefiks typu dokumentu.

12. Komentarze `DLACZEGO` w szablonie (drobna).
    - U nich: każda sekcja ma komentarz `<!-- DLACZEGO: … -->` z uzasadnieniem sekcji.
    - U nas: szablon BFS nie ma komentarzy, a według `_00-meta.md` komentarz HTML w szablonie oznacza regułę sekcji.
    - Po przyjęciu ich wersji: komentarze w szablonie mieszałyby uzasadnienia sekcji z regułami.

13. Sekcja 3 guide, czyli co analityk musi wiedzieć (drobna).
    - U nich: cztery pytania: cel biznesowy i kontekst procesu, co jest w zakresie i poza nim, kto jest właścicielem biznesowym, które pojęcia domenowe wymagają definicji.
    - U nas: reguły zapisu i zmiany: jeden BFS to jeden proces, wiersze `REQ` i `RB` wskazywane pełnym ID, BFS nie wymienia scenariuszy, numery nie wracają do obiegu, zmiana zaczyna się od `change_scope`.
    - Po przyjęciu ich wersji: guide dostałby pytania przygotowawcze. Przejęcie ich sekcji w miejsce naszej usunęłoby regułę, że BFS nie dzieli się po iteracjach, ścieżkach ani komponentach (`methodology.md`, sekcja 5), bo ich wersja jej nie ma.

14. Wariant `BFS dla istniejącego procesu` (drobna).
    - U nich: wariant ma dodatkowo zasadę `Sekcję „Słownik pojęć" wypełnij na podstawie nazw z istniejących UC i kodu`.
    - U nas: wariant mówi tylko o starcie od reguł biznesowych wydobytych z kodu.
    - Po przyjęciu ich wersji: wariant dostałby wskazówkę, skąd brać pojęcia do słownika.

Pominięte zgodnie z decyzją: pola `type` i `component`, „Lokalizacja docelowa” liczona z pola `type`, zasada „Pozostaw `related-doc-ids` puste” z wariantu dla nowego procesu, sekcje `Historia zmian` i `7. Powiązany prompt generujący`.
