# activity

Wersje są bliskie: mają te same sześć sekcji w tej samej kolejności, a różnią się formą dwóch sekcji, treścią sekcji `## Zależności` i warunkiem, kiedy aktywność dostaje osobny plik.

1. (drobna) Ich tytuł i nagłówek `#` mają przedrostek typu: `Aktywność: {Nazwa aktywności}`. Nasz tytuł i nagłówek to sama nazwa `{Nazwa aktywności}`. Przyjęcie ich wersji dodaje słowo „Aktywność:” na początku tytułu każdej aktywności.

2. (drobna) Ich sekcja wejścia i wyjścia ma nagłówek `## Wejście / wyjście`, nasza `## Wejście i wyjście`. Przyjęcie ich wersji zmienia tylko nazwę nagłówka.

3. Ich sekcja wejścia i wyjścia jest listą dwóch punktów: „Dane wejściowe wymagane do wykonania aktywności” i „Dane wyjściowe przekazywane do kolejnych kroków”. Nasza jest tabelą `| Kierunek | Dane | Opis |` z wierszami `Wejście` i `Wyjście`. Przyjęcie ich wersji zastępuje tabelę listą bez osobnego opisu każdej danej.

4. (drobna) Ich sekcja `## Cel` ma limit: „Jedno zdanie: jaki efekt biznesowy realizuje ta aktywność i po co istnieje.” Nasza ma tylko `{Co aktywność ma osiągnąć}`. Przyjęcie ich wersji ogranicza cel do jednego zdania o efekcie biznesowym.

5. (drobna) Ich sekcja `## Opis akcji` ma zawierać „logikę biznesową oraz istotne reguły i decyzje”. Nasza ma `{Co aktywność robi, krok po kroku}`. Przyjęcie ich wersji znosi wymóg opisu krok po kroku i dopuszcza reguły w opisie akcji, choć obie wersje mają osobną sekcję `## Warunki i reguły`.

6. (drobna) Ich sekcja `## Warunki i reguły` ma dwa punkty: „Warunki uruchomienia aktywności” oraz „Reguły biznesowe i ograniczenia”. Nasza ma jeden wpis `{Warunki wykonania i reguły algorytmu}`. Przyjęcie ich wersji oddziela warunki uruchomienia od reguł i mówi o regułach biznesowych zamiast o regułach algorytmu.

7. Ich sekcja `## Scenariusze błędów` jest tabelą `| Scenariusz | Zachowanie |`. Nasza ma tekst `{Sytuacje błędne i reakcja aktywności}`. Przyjęcie ich wersji wprowadza w tej sekcji tabelę z dwiema kolumnami.

8. Ich sekcja „Warianty” każe wypełnić „Scenariusze błędów” tylko przy nietrywialnych odchyleniach, a w przeciwnym razie wpisać „Nie dotyczy”. Nasz opis nie mówi, co zrobić z tą sekcją, gdy aktywność nie ma sytuacji błędnych. Przyjęcie ich wersji wprowadza obowiązkowy wpis „Nie dotyczy”.

9. Ich sekcja `## Zależności` ma wymieniać „Przepływ, którego częścią jest aktywność, oraz powiązane artefakty.” Nasza podaje zależności tylko nazwą, a komentarz zabrania ID dokumentów, bo wywołania INT, QUE i BPMN wpisuje przepływ w kolumnie „Wywołanie”. Ich wersja jest sprzeczna z `methodology.md`, sekcja 7: aktywność nie wymienia przepływu, który ją zawiera. Matryca nie ma też trójek, w których aktywność wskazuje API, INT, QUE albo BPMN. Przyjęcie ich wersji sprawi, że walidator zgłosi błąd przy każdym ID przepływu lub innego dokumentu w tej sekcji.

10. Ich opis zakłada jeden przepływ nadrzędny: analityk ma wiedzieć, „Którego przepływu (`flow`) ta aktywność jest częścią”, a wyjście opisuje dane „przekazywane do kolejnych kroków”. Według naszego opisu aktywność może należeć do kilku przepływów (`FLOW contains ACT`, liczebność `N:N`), więc nie opisuje kontekstu żadnego z nich, a wejście nazywa dane zamiast kroku, który je dostarczył. Przyjęcie ich wersji wiąże aktywność z jednym przepływem i utrudnia użycie jej w kilku przepływach.

11. Ich warunek użycia jest szerszy: „uszczegóławiasz pojedynczą aktywność wskazaną w diagramie przepływu (`flow`)”. Według naszego opisu aktywność powstaje tylko dla logiki ze złożonym algorytmem albo logiki używanej przez kilka przepływów, a prosty krok zostaje w przepływie. Przyjęcie ich wersji pozwala tworzyć osobny plik dla każdej aktywności z diagramu, także prostej.

12. (drobna) Ich „Nie używaj gdy” odsyła także do `use-case`, gdy opisujesz scenariusz z perspektywy użytkownika. Nasz opis odsyła tylko do `flow`. Przyjęcie ich wersji dodaje jedno odesłanie.

13. Ich opis każe oznaczać braki jawnie wpisem `> Założenie: ...`. Nasz szablon i opis aktywności nie mają takiej konwencji, a wśród naszych szablonów występuje ona tylko w `business-functional-spec`. Przyjęcie ich wersji wprowadza blok `> Założenie:` do aktywności. Ta sama różnica dotyczy `navigation-map`, `screen` i `screen-section`.

14. Ich plik ma nazwę `{activity-name}.md` w `kebab-case`, np. `fetch-individual-offers.md`. Nasz plik ma nazwę równą doc-id małymi literami, np. `act-001.md` (`methodology.md`, sekcja 11). Przyjęcie ich wersji zmienia nazwę każdego pliku aktywności z identyfikatora na nazwę opisową. Ich folder wynika z pola `type`, które odpada zgodnie z decyzją, więc folder zostaje według naszego układu: `processes/BFS-001/activities/` albo `shared/activities/`.

Zgodnie z decyzją pominięto pola `type`, `component` i `source-spec-ids`, sekcję `## Historia zmian` oraz sekcję „Powiązany prompt generujący”.
