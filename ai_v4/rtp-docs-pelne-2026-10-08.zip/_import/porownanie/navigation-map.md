# navigation-map

Wersje są bardzo bliskie: mają te same sekcje w tej samej kolejności i tabelę odniesień o tych samych kolumnach, a różnią się przykładem diagramu, wartością w kolumnie `Dokument` i formą scenariuszy błędów.

1. (drobna) Ich tytuł i nagłówek `#` to `Mapa nawigacyjna ekranów: {Nazwa procesu}`, nasze to `{Nazwa procesu}: mapa nawigacyjna`. Przyjęcie ich wersji przestawia człony tytułu i dodaje słowo „ekranów”.

2. Ich sekcja `## Diagram nawigacji` ma gotowy przykład `flowchart TD` z węzłami `START`, `STEP2`, `STEP3`, `ERROR` i `EXIT`. Przykład ma konwencję krawędzi: akcja użytkownika to strzałka z etykietą (`-->|Dalej|`), a błąd techniczny to linia przerywana (`-. błąd techniczny .->`). Nasza sekcja ma pusty blok `flowchart TD` i komentarz z listą rodzajów ekranów, bez konwencji krawędzi. Przyjęcie ich wersji daje wzór diagramu i oznaczanie przejść po błędzie technicznym linią przerywaną.

3. (drobna) Ich opis każe używać `flowchart TD` „dla prostych przepływów ekranowych” i ograniczyć diagram do kluczowych ekranów i decyzji. Nasz opis nie ogranicza zawartości diagramu. Przyjęcie ich wersji pozwala pominąć na diagramie mniej ważne ekrany.

4. (drobna) Ich sekcja `## Kluczowe elementy nawigacji` ma trzy punkty: główne przejścia, przejścia terminalne z warunkami ich uruchomienia i miejsca, gdzie dokumentacja jest niekompletna. Nasza ma `{Najważniejsze przejścia i decyzje w nawigacji}`. Przyjęcie ich wersji dodaje opis przejść terminalnych i oznaczanie luk w dokumentacji.

5. W tabeli `| Ekran | Rola w mapie | Dokument |` ich kolumna `Dokument` ma ścieżkę do pliku (`{ścieżka-do-ekranu-1}`), a nasza ID `SCR-{nnn}`. Nagłówki tabel są takie same. U nas ID w tej kolumnie odpowiada wpisowi `groups SCR`, a walidator sprawdza, czy ekran istnieje. Przyjęcie ich wersji zastępuje ID ścieżką, której walidator nie łączy z relacją i która przestaje działać po przeniesieniu pliku.

6. (drobna) Nasza kolumna `Rola w mapie` ma zamkniętą listę wartości: `startowy / pośredni / końcowy / błędu`. Ich kolumna ma dowolny tekst `{Rola}`. Przyjęcie ich wersji pozwala wpisać dowolną rolę.

7. Ich sekcja `## Scenariusze błędów` jest tabelą `| Scenariusz | Zachowanie |` z wartością `{Przejście / reakcja UI}`. Nasza ma tekst `{Ścieżki błędne i ekrany błędów}`. Przyjęcie ich wersji wprowadza w tej sekcji tabelę z dwiema kolumnami.

8. Ich sekcja `## Warunki wstępne` ma blok `> Założenie: [...]` na ekrany i przejścia, których jeszcze nie opisano, a opis każe oznaczać braki przez `> Założenie:` zamiast zgadywać. Nasza sekcja ma `{Zakres mapy i założenia o kompletności}` bez stałego znacznika. Przyjęcie ich wersji wprowadza blok `> Założenie:`. Ta sama różnica dotyczy `activity`, `screen` i `screen-section`.

9. (drobna) Ich sekcja „Warianty” każe dzielić diagram procesu wieloetapowego na obszary, np. „onboarding, weryfikacja, finalizacja”, w jednym pliku mapy. Nasz opis ma tylko „Brak wariantów.”. Przyjęcie ich wersji dodaje regułę dzielenia dużego diagramu bez dzielenia pliku.

10. (drobna) Ich „Nie używaj gdy” odsyła też do `flow`, gdy opisujesz przepływ danych lub logiki między komponentami. Nasz opis odsyła tylko do `screen`. Przyjęcie ich wersji dodaje jedno odesłanie.

Zgodnie z decyzją pominięto pola `type`, `component` i `related-doc-ids`, regułę folderu wyliczanego z pola `type`, sekcję `## Historia zmian` oraz sekcję „Powiązany prompt generujący”.
