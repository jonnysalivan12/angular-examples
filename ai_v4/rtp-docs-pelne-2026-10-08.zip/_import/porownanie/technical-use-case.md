# technical-use-case

Wersje mają te same sekcje w tej samej kolejności, ale różnią się mocno w treści: nasza zapisuje kroki w tabelach z kolumną `Wywołanie`, aktora jako rolę z bazy ACTOR i odwołania pełnym ID, a ich wersja opisuje kroki listą i używa krótkich ID.

1. Postać kroków, wariantów i błędów.
   - U nich: `## Kroki — co dzieje się po kolei` to lista numerowana („1. System uruchamia [zadanie/proces]”). Warianty `A` i błędy `E` też są listami numerowanymi.
   - U nas: `## Kroki` oraz każda podsekcja `A{n}` i `E{n}` to tabela `| Nr | Akcja systemu | Wywołanie |`. Z kolumny `Wywołanie` wynikają relacje `TUC consumes API`, `INT` i `QUE` (`relation-matrix.yaml`, grupa 4).
   - Po przyjęciu ich wersji: wywołania API, INT i QUE nie miałyby stałego miejsca w treści, a komentarz matrycy o kolumnie „Wywołanie” w tabelach kroków nie miałby oparcia w szablonie.

2. Krótkie ID w treści.
   - U nich: `Powiązane REQ` ma wartość `[REQ-01, REQ-04]`, tabela `Powiązanie z BFS` ma `REQ-01`, kryteria akceptacji kończą się na `(REQ-01)`, a progi NFR mają ID `NFR-PERF-01`.
   - U nas: pełne ID wierszy `BFS-{nnn}.REQ-{nn}`, `BFS-{nnn}.RB-{nn}` i `NFR-{nnn}.NFRT-{KATEGORIA}-{nn}` (`methodology.md`, sekcja 3).
   - Po przyjęciu ich wersji: krótkie ID nie mówi, z którego BFS albo NFR pochodzi wiersz, więc nie da się z niego zapisać relacji `realizes` ani `constrained_by`, a walidator nie sprawdzi, czy cel istnieje.

3. Własne ID reguł w `Reguły biznesowe`.
   - U nich: tabela `| ID TUC | Zasada | Źródło w BFS |`. TUC nadaje regułom własne ID `RB-01` i w kolumnie `Źródło w BFS` podaje `[RB-01]`.
   - U nas: lista `- BFS-{nnn}.RB-{nn}: {jak reguła działa w scenariuszu}`. Prefiks `RB` należy do wierszy BFS, a TUC ma własne wiersze tylko `A` i `E` (`relation-matrix.yaml`, grupa 1).
   - Po przyjęciu ich wersji: prefiks `RB` oznaczałby wiersze w dwóch typach dokumentów, a matryca nie ma trójki `TUC contains RB`.

4. Sekcja `Aktor` i wiersz `Aktor`.
   - U nich: `## Aktor` ze stałym zdaniem „Jedynym aktorem jest system/komponent uruchamiający proces.” W tabeli nagłówkowej `Aktor` ma wartość `[System]`.
   - U nas: `## Aktorzy` z listą `- ACTOR-{nnn}.ROLE-{nn}: {udział w scenariuszu}`, a w tabeli nagłówkowej `ACTOR-{nnn}.ROLE-{nn} [System]`. Rola pochodzi ze wspólnej bazy ACTOR i daje relację `involves`.
   - Po przyjęciu ich wersji: TUC nie wskazywałby roli z bazy aktorów, więc graf nie wyliczyłby udziału roli systemowej w scenariuszach (`methodology.md`, sekcja 7).

5. Wiersz `BFS / SPEC` w tabeli nagłówkowej.
   - U nich: `**BFS / SPEC**` z wartością „[SPEC-XXX - link względny do dokumentu nadrzędnego]”. Sekcja 3 pyta, „Który BFS/SPEC jest dokumentem nadrzędnym”.
   - U nas: wiersz `BFS` z wartością `BFS-{nnn}`. Dokumentem nadrzędnym jest zawsze BFS, a typu `SPEC` nie mamy; jest tylko `SPEC-WF`, czyli krok procesu.
   - Po przyjęciu ich wersji: dokumentem nadrzędnym mógłby być dokument innego typu niż BFS, wskazany linkiem względnym zamiast ID.

6. Opis ograniczeń NFR.
   - U nich: `## Ograniczenia NFR (referencje)` z tabelą `| NFR-ID | Ograniczenie w TUC |`, czyli przy każdym progu jest opis, jak ogranicza scenariusz.
   - U nas: `## Ograniczenia NFR` z listą samych ID `- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}`, bez opisu.
   - Po przyjęciu ich wersji: każdy próg dostałby opis wpływu na TUC. Zmiana nagłówka wymaga też poprawki komentarza w `relation-matrix.yaml` (grupa 5), który wskazuje sekcję „Ograniczenia NFR”.

7. Kryteria akceptacji powiązane z wymaganiami.
   - U nich: lista z polami wyboru `- [ ]`, a każde kryterium kończy się ID wymagania albo reguły, np. „(`REQ-01`)”, „(`RB-03`)”.
   - U nas: `- Kiedy {sytuacja}, wtedy {oczekiwany wynik}.` bez pola wyboru i bez ID.
   - Po przyjęciu ich wersji: każde kryterium wskazywałoby wymaganie lub regułę, a to ID musiałoby mieć pełną formę i relację `realizes` w front matter.

8. Punkt powrotu po wariancie.
   - U nich: ostatni krok wariantu `A2` brzmi „Powrót do kroku [X] lub zamknięcie procesu”.
   - U nas: tabela wariantu nie wymaga wskazania, gdzie przebieg wraca.
   - Po przyjęciu ich wersji: każdy wariant musiałby kończyć się krokiem powrotu albo zamknięciem procesu.

9. Reguła o sekcjach, które nie dotyczą dokumentu.
   - U nich: komentarz nad strukturą: `Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem.` Wariant uproszczony każe wypełnić `Co może pójść inaczej` i `Co może pójść nie tak` jako „Nie dotyczy” z uzasadnieniem.
   - U nas: wariant uproszczony to „jeden przepływ, bez diagramu”, bez reguły o pustych sekcjach.
   - Po przyjęciu ich wersji: każda sekcja byłaby obowiązkowa, a pusta sekcja musiałaby mieć wpis „Nie dotyczy” z uzasadnieniem.

10. Wiersz `Zdolność` w tabeli nagłówkowej (tylko u nas, drobna).
    - U nich: brak. CAP jest tylko w `related-doc-ids`.
    - U nas: wiersz `Zdolność` z wartością `CAP-{nnn}`.
    - Po przyjęciu ich wersji: zdolność zniknęłaby z treści i została tylko w `relations`.

11. Gotowy wariant `A1` (drobna).
    - U nich: szablon ma wypełniony wariant `A1: Przerwanie działań`: trigger nie występuje, system nie uruchamia procesu, „Kolejna próba następuje w następnym cyklu”.
    - U nas: `### A1. {Nazwa wariantu}` bez treści.
    - Po przyjęciu ich wersji: każdy nowy TUC zaczynałby od tego wariantu i trzeba by go usuwać, gdy nie dotyczy.

12. Warunek dodania diagramu (drobna).
    - U nich: „Opcjonalny - dodaj gdy przebieg ma więcej niż jedno rozgałęzienie decyzyjne.” oraz pełny przykładowy diagram z kolorami.
    - U nas: `<!-- Opcjonalny, najwyżej 15 kroków. -->` i pusty `flowchart TD`.
    - Po przyjęciu ich wersji: szablon mówiłby, kiedy diagram jest potrzebny.

13. Treść wariantu `Po BFS` (drobna).
    - U nich: trzy zasady: obowiązkowo wypełnij `Powiązanie z BFS (wymagania nadrzędne)`, wpisz referencje do `REQ-*` i `RB-*`, „Nie duplikuj pełnych treści wymagań z BFS, tylko mapuj i uszczegóławiaj przebieg”.
    - U nas: „**Po BFS**: zalecany.” bez treści.
    - Po przyjęciu ich wersji: guide dostałby zakaz kopiowania treści wymagań z BFS.
    - Uwaga: obie wersje nazywają ten wariant zalecanym, czyli dopuszczają TUC bez BFS. U nas TUC bez wpisu `realizes` do wymagania BFS nie ma folderu procesu (`methodology.md`, sekcja 11).

14. Warunek wariantu `Złożony` (drobna).
    - U nich: „gdy wiele triggerów lub wiele wariantów systemowych”.
    - U nas: „jeden TUC na wariant; warianty zestawia mapa”, bez warunku o wielu triggerach.
    - Po przyjęciu ich wersji: kilka triggerów też oznaczałoby podział na osobne TUC.

15. Odesłania w „Nie używaj gdy” (drobna).
    - U nich: odesłania do `use-case`, `capability`, `integration` i `flow`.
    - U nas: tylko do `use-case`.
    - Po przyjęciu ich wersji: guide odsyłałby też do zdolności, integracji i przepływu.

16. Sekcja 3 guide, czyli co analityk musi wiedzieć (drobna).
    - U nich: pytania o komponent uruchamiający scenariusz, trigger, warunki startu, punkt końcowy i sukces oraz dokument nadrzędny.
    - U nas: reguły zapisu: tabela nagłówkowa, kolumna `Wywołanie`, Trigger ze zdarzeniem, brak ekranów, polityka błędu, relacje jak w UC.
    - Po przyjęciu ich wersji: guide dostałby pytania przygotowawcze.

17. Nagłówki (drobna).
    - U nich: `# Technical Use Case: {Nazwa scenariusza technicznego}`, `## Powiązanie z BFS (wymagania nadrzędne)`, `## Kroki — co dzieje się po kolei`, `### A1: …`, `### E1: …`.
    - U nas: `# {Nazwa scenariusza}`, `## Powiązanie z BFS`, `## Kroki`, `### A1. …`, `### E1. …`.
    - Po przyjęciu ich wersji: zmieniłyby się nazwy nagłówków, bez wpływu na relacje.

18. Komentarze `DLACZEGO` w szablonie (drobna).
    - U nich: każda sekcja ma komentarz `<!-- DLACZEGO: … -->` z uzasadnieniem sekcji.
    - U nas: komentarz jest tylko przy diagramie. Według `_00-meta.md` komentarz HTML w szablonie oznacza regułę sekcji.
    - Po przyjęciu ich wersji: komentarze w szablonie mieszałyby uzasadnienia sekcji z regułami.

Pominięte zgodnie z decyzją: pola `type`, `component`, `source-spec-ids`, `related-doc-ids`, „Lokalizacja docelowa” liczona z pola `type`, łączenie plików wariantu złożonego przez `related-doc-ids`, sekcje `Historia zmian` i `7. Powiązany prompt generujący`.
