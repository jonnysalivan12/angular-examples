# flow

Wersje mają te same sekcje w tej samej kolejności, ale różnią się budową opisu kroków (u nich lista z odnośnikami, u nas tabela z kolumnami `Aktywność` i `Wywołanie`) oraz polem zdolności, które ma tylko nasz szablon.

1. Ich tytuł i nagłówek `#` zawierają wariant: `Przepływ: {Nazwa} — {wariant}`. Nasz tytuł i nagłówek to `{Nazwa przepływu}`. Obie wersje trzymają przebieg podstawowy i obsługę błędów w osobnych plikach, ale tylko ich tytuł odróżnia te pliki. Przyjęcie ich wersji dodaje do tytułu przedrostek „Przepływ:” i nazwę wariantu.

2. Nasz szablon ma pod nagłówkiem tabelę `| Pole | Wartość |` z wierszem `Zdolność | CAP-{nnn}`, a opis każe wskazać zdolność wpisem `realizes`. Ich szablon nie ma miejsca na zdolność. Przyjęcie ich wersji usuwa wpis `FLOW realizes CAP`, a od niego zależy folder przepływu: FLOW należy do procesu zdolności, którą realizuje (`methodology.md`, sekcja 11).

3. Ich sekcja `## Diagram` jest opcjonalna. Komentarz każe ją pominąć „przy prostym flow, którego zobrazowanie nie wnosi dodatkowej wartości”, wymaga spójności diagramu z opisem kroków, a „Dobór diagramu zależy od specyficznego przypadku”. Nasza sekcja nie jest oznaczona jako opcjonalna, a komentarz wskazuje Mermaid z limitem 10–15 uczestników lub kroków. Przyjęcie ich wersji pozwala pominąć diagram w prostym przepływie i zostawia rodzaj diagramu autorowi.

4. Ich szablon pozwala podpiąć aktywność w diagramie odnośnikiem do pliku: `click E "./{activity-name}.md" "Przejdź do opisu aktywności"`. Nasz szablon wskazuje aktywność przez ID w kolumnie `Aktywność`. Ścieżka `./{activity-name}.md` zakłada, że aktywność leży obok przepływu, a u nas leży w `activities/` procesu albo w `shared/activities/`, bo może należeć do kilku przepływów (`methodology.md`, sekcja 11, „Folder aktywności”). Przyjęcie ich wersji daje odnośniki, które w naszym układzie katalogów nie trafią w plik, a walidator nie powiąże ich z wpisem `contains ACT`.

5. (drobna) Ich sekcja kroków ma nagłówek `## Opis flow`, nasza `## Opis przepływu`. Przyjęcie ich wersji zmienia tylko nazwę nagłówka.

6. Ich sekcja kroków jest listą numerowaną `1. Krok 1` z podpunktami „Szczegóły w ...” i tytułem aktywności. Nasza jest tabelą `| Nr | Krok | Aktywność | Wywołanie |`. Kolumna `Wywołanie` z ID INT, QUE albo BPMN tworzy wpisy `FLOW consumes`, a matryca relacji odwołuje się do tej kolumny wprost. Przyjęcie ich wersji usuwa kolumny `Aktywność` i `Wywołanie`, więc aktywności i wywołania trafią do luźnych podpunktów.

7. Ich podpunkt „Szczegóły w ...” ma komentarz „link do specyfikacji, integracji, innego flow itd.”, a komentarz przy ich `related-doc-ids` wymienia wśród powiązań przepływu także API. Według naszego opisu przepływ nie wymienia API, które z niego korzysta, bo relację zapisuje API (`API-001 consumes FLOW-001`, `methodology.md`, sekcja 7). Matryca nie ma też trójki między dwoma przepływami. Przyjęcie ich wersji pozwoli wpisać w krok ID API albo innego przepływu, a walidator zgłosi to jako błąd. Pole `related-doc-ids` odpada zgodnie z decyzją, więc różnica dotyczy odnośników w krokach.

8. Ich sekcja `## Scenariusze błędów` jest tabelą `| Scenariusz | Zachowanie |`. Nasza ma tekst `{Sytuacje błędne i reakcja przepływu}`. Przyjęcie ich wersji wprowadza w tej sekcji tabelę z dwiema kolumnami.

9. Ich sekcja `## Scenariusze błędów` zależy od wariantu: plik przebiegu podstawowego ją pomija, a plik obsługi błędów ją wypełnia. Nasz szablon ma tę sekcję w każdym pliku, a opis mówi tylko, że warianty są osobnymi plikami. Przyjęcie ich wersji usuwa tę sekcję z plików przebiegu podstawowego.

10. Nasz opis odsyła proces wykonywany przez silnik Workflow do `bpmn-process`, po decyzji `bpms-process`. Ich opis przepływu nie ma tego wykluczenia. Przyjęcie ich wersji usuwa z opisu granicę między przepływem a procesem w silniku.

11. (drobna) Ich „Nie używaj gdy” odsyła też do `use-case` (scenariusz z perspektywy użytkownika) i do `capability` (zdolność biznesowa komponentu). Nasz opis nie ma tych odesłań. Przyjęcie ich wersji dodaje dwa odesłania.

12. Ich plik ma nazwę `{operacja}-{wariant}.md`, np. `get-offers-happy-path.md`. Nasz plik ma nazwę równą doc-id małymi literami i leży w folderze `flows/FLOW-001/` procesu (`methodology.md`, sekcja 11). Przyjęcie ich wersji zmienia nazwę każdego pliku przepływu z identyfikatora na nazwę operacji z wariantem. Ich folder wynika z pola `type`, które odpada zgodnie z decyzją.

Zgodnie z decyzją pominięto pola `type`, `component` i `related-doc-ids`, sekcję `## Historia zmian` oraz sekcję „Powiązany prompt generujący”.
