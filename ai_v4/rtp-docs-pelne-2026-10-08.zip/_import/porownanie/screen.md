# screen

Wersje mają ten sam tytuł i te same sekcje w tej samej kolejności, a różnią się sposobem wskazania sekcji i sąsiednich ekranów; ich kolumna `Link` w tabeli `## Kolejne ekrany` jest sprzeczna z naszą matrycą relacji.

1. (drobna) Ich sekcja `## Opis ekranu` ma akapit `{Krótki opis celu i kontekstu ekranu.}`, listę `**Cel ekranu:**` i pole `**Link do Figmy:**`. Nasza ma dwa punkty: `Cele ekranu: {Cele}` i `Figma: {Odnośnik}`. Przyjęcie ich wersji dodaje akapit o kontekście ekranu.

2. Ich sekcja `## Mapa sekcji na ekranie` ma dwa obrazy całego ekranu, `![{Nazwa ekranu} - ekran]` i `![{Nazwa ekranu} - podział sekcji]`, oraz listę numerowaną sekcji „od góry do dołu”. Nasza ma `{Obrazy sekcji w kolejności od góry}`. Ich lista powtarza kolejność z kolumny `Kolejność` w tabeli sekcji `## Struktura ekranu`. Przyjęcie ich wersji zastępuje obrazy sekcji dwoma obrazami całego ekranu i dodaje drugą listę kolejności sekcji.

3. W tabeli `| Kolejność | Sekcja | Opis | Warunek wyświetlenia |` ich kolumna `Sekcja` ma nazwę sekcji jako odnośnik (`**[{Sekcja 0}]**`), a nasza ID `SCRSEC-{nnn}`. Nagłówki tabel są takie same. U nas ID odpowiada wpisowi `SCR-001 contains SCRSEC-001`, a walidator zgłasza błąd, gdy sekcja zniknie. Przyjęcie ich wersji zastępuje ID nazwą z odnośnikiem, której walidator nie łączy z relacją.

4. (drobna) Ich numeracja sekcji w tabeli `## Struktura ekranu` zaczyna się od `0` (`**0**`, `{Sekcja 0}`), nasza od `1`. Przyjęcie ich wersji zmienia tylko numer pierwszej sekcji.

5. Ich tabela w sekcji `## Kolejne ekrany` ma nagłówek `| Numer | Nazwa | Link | Status |`, nasza `| Krok | Numer i nazwa | Status |`. Ich kolumna `Link` wskazuje plik sąsiedniego ekranu, np. `[{screen-name}.md]`. U nas ekran nie wskazuje innych ekranów, bo matryca nie ma trójki SCR → SCR: sąsiednie kroki podaje się numerem i nazwą, a przejścia z ID ekranów opisuje mapa nawigacyjna. Przyjęcie ich wersji wprowadza odnośniki między ekranami, a ID ekranu wpisane w tę kolumnę walidator zgłosi jako błąd.

6. Ich sekcja `## Kolejne ekrany` ma blok `> Założenie: Lista kolejnych ekranów do uzupełnienia po potwierdzeniu pełnego flowu.`, a opis każe oznaczać braki przez `> Założenie: ...`. Nasz szablon nie ma takiego znacznika. Przyjęcie ich wersji wprowadza blok `> Założenie:`. Ta sama różnica dotyczy `activity`, `navigation-map` i `screen-section`.

7. (drobna) Ich sekcja `## Nawigacja` ma punkty „Przycisk poprzedni” i „Linki/akcje dodatkowe”, z wartością „Nie dotyczy”, gdy ich brak. Nasza ma „Przycisk wstecz” i „Odnośniki dodatkowe”. Przyjęcie ich wersji obejmuje ostatnim punktem także akcje, a nie tylko odnośniki.

Zgodnie z decyzją pominięto pola `type`, `component`, `source-spec-ids` i `related-doc-ids`, regułę folderu wyliczanego z pola `type`, sekcję `## Historia zmian` oraz sekcję „Powiązany prompt generujący”.
