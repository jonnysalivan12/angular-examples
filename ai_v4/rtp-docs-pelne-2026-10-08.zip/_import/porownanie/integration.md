# integration

Wersje są bliskie: mają te same główne sekcje w tej samej kolejności, a różnią się sekcjami, które nasz szablon dodaje dla grafu, i odesłaniem obsługi błędów do konwencji CONV.

1. Pole „Zdolność” pod tytułem. U nich go nie ma, a zdolność trafia tylko do opcjonalnego `related-doc-ids`. U nas przed `## Cel` stoi tabela `| Pole | Wartość |` z wierszem `Zdolność | CAP-{nnn}`, a guide każe podać zdolność w tym polu i wpisem `realizes` (`INT-017 realizes CAP-022`). Przyjęcie ich wersji usuwa z treści widoczne wskazanie zdolności.

2. Obsługa błędów a konwencja CONV. U nich `## Obsługa błędów` opisuje zachowanie dla 404, 5xx i przekroczenia czasu w każdej integracji osobno, a typu konwencji w ogóle nie ma. U nas komentarz w sekcji mówi, że „Limit czasu i ponawianie wywołań opisuje konwencja”, wiersze mają postać `Ponowienia według CONV-{nnn}` i `Limit czasu według CONV-{nnn}`, a integracja ma wpis `applies CONV-{nnn}`. Guide dodaje, że integracja odstępująca od konwencji jej nie wskazuje i sama opisuje obsługę (INT-003). Przyjęcie ich wersji oznacza, że każda integracja powtarza zasady ponawiania i limitu czasu, a trójka `INT applies CONV` z matrycy przestaje być używana.

3. Sekcja `## Encje` jest tylko u nas. Wymienia encje, które w operacji są osobnym bytem (`INT-010 consumes ENT-Client`). Matryca w grupie 4 wskazuje tę sekcję jako miejsce dla trójki `INT consumes ENT`. Ich szablon nie ma ani sekcji, ani pola na encje. Przyjęcie ich wersji sprawia, że wpisy `consumes ENT` nie mają odpowiednika w treści integracji.

4. Sekcja `## Ograniczenia NFR` jest tylko u nas. Wskazuje wiersze NFR (`INT-001 constrained_by NFR-001.NFRT-AVAIL-01`), a guide zabrania powtarzać wiersz NFR, któremu integracja podlega przez swoją zdolność. W ich szablonie integracji wymagania jakościowe nie występują; ich NFR sam wymienia integracje w tabeli `Traceability do artefaktów`. Przyjęcie ich wersji usuwa z integracji własne progi jakości.

5. Forma opisu odpowiedzi. U nich pod `**Odpowiedź:**` jest tekst: „Opis konsumowanych pól — tylko tych, które NAS interesują.” U nas jest tabela `| Pole | Opis |` z nagłówkiem „Odpowiedź (tylko pola istotne dla nas):”. Przyjęcie ich wersji zamienia tabelę pól odpowiedzi na opis prozą.

6. Pola sekcji `## Protokół` zależne od protokołu. U nich sekcja 6 mówi, że sekcja „Protokół” wygląda inaczej dla REST, SOAP, gRPC i JMS, i każe: „dostosuj pola do faktycznego protokołu”. U nas tabela ma stałe cztery wiersze (`Typ`, `Właściciel`, `Endpoint`, `API Catalog`), a guide mówi „Brak wariantów.” Przyjęcie ich wersji pozwala, by integracja SOAP albo JMS miała inne wiersze niż REST.

7. Nazwa pliku. U nich plik nazywa się `{system-name}.md`, a przy kilku operacjach jednego systemu `{system}-{operation}.md`. U nas plik ma nazwę równą doc-id małymi literami, czyli `int-001.md` (`methodology.md`, sekcja 11, „Nazwy plików i folderów”). Przyjęcie ich wersji jest sprzeczne z metodyką i wymaga wyjątku dla integracji.

8. (drobna) Nagłówek sekcji operacji. U nich `## Operacje konsumowane` z podsekcją `### {Nazwa operacji}` i etykietami `**Żądanie:**` oraz `**Odpowiedź:**`. U nas `## Operacja` bez podsekcji. Obie wersje i tak wymagają jednego pliku na operację (u nich sekcja 6, u nas guide, sekcja 1). Przyjęcie ich wersji dodaje podsekcję z nazwą operacji, która przy jednej operacji w pliku powtarza tytuł.

9. (drobna) Tabela błędów. U nich nagłówek `| Scenariusz | Zachowanie |` i wiersze `404` oraz `5xx / timeout`. U nas `| Sytuacja | Obsługa |` i wiersze `404`, `5xx` oraz `Przekroczenie czasu`. Przyjęcie ich wersji łączy błąd serwera i przekroczenie czasu w jednym wierszu.

10. (drobna) Nazwa sekcji diagramu. U nich `## Diagram` z samym komentarzem „Diagram sekwencji Mermaid — wywołanie i warianty odpowiedzi.” U nas `## Diagram sekwencji` z pustym blokiem `mermaid` `sequenceDiagram`. Przyjęcie ich wersji zmienia nazwę sekcji i dodaje wskazówkę, że diagram pokazuje warianty odpowiedzi.

11. (drobna) Podpowiedź w kolumnie `Źródło` tabeli żądania. Nagłówek `| Pole | Źródło | Opis |` jest w obu wersjach taki sam. U nich przykładowy wiersz ma w tej kolumnie „parametr / stała / nagłówek”, u nas `{Źródło}`. Przyjęcie ich wersji daje analitykowi listę typowych źródeł pola.

12. (drobna) Lista „Nie używaj gdy”. U nich są odesłania do `capability` („opisujesz zdolność biznesową”) i `flow` („opisujesz sekwencję kroków procesu”), których u nas nie ma. U nas są odesłania do `event` („kontrakt zdarzenia w brokerze”) i `convention` („zasadę wspólną dla wielu integracji”), których nie ma u nich. Przyjęcie ich punktów dodaje odesłania do `capability` i `flow`.

13. (drobna) Przedrostek w tytule. U nich `title: "Integracja: {Nazwa systemu} — {Operacja}"` i taki sam nagłówek `#`. U nas `# {Nazwa systemu}: {operacja}`. Przyjęcie ich wersji dodaje „Integracja:” do tytułu każdego dokumentu.

Zgodnie z decyzją pominięto pola `type`, `component` i `related-doc-ids`, opcjonalność `owner`, regułę lokalizacji pliku według pola `type`, sekcję `## Historia zmian` i sekcję 7 z promptem.
