---
title: "Template: ADR"
status: active
tags:
  - standard
  - template
---

# Template: ADR (Architecture Decision Record)

## 1. Jakiego artefaktu to szablon?

ADR rejestruje **pojedynczą decyzję architektoniczną** — kontekst, rozważane opcje, wybór i konsekwencje. Zachowuje historię decyzji (status `Deprecated` zamiast usuwania), nie dyskusję — ta zostaje w MR/Issue.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- podejmujesz istotną decyzję architektoniczną wymagającą uzasadnienia i śladu
- chcesz udokumentować rozważane opcje i konsekwencje wyboru

**Nie używaj gdy:**
- opisujesz zachowanie systemu (zdolność, przepływ) → użyj `capability` lub `flow`
- dokumentujesz dyskusję, nie rozstrzygniętą decyzję → zostaw ją w MR/Issue

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?

- Jaki problem rozwiązuje decyzja i dlaczego jest potrzebna
- Jakie opcje były rozważane i jakie mają zalety/wady
- Jaki jest status decyzji (Proposed / Accepted / Deprecated)
- ADR rejestruje decyzję, nie dyskusję — dyskusja jest w MR/Issue
- Jeden ADR = jeden plik (inwariancja I3)

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: ADR-{NNN}
title: "ADR: {Tytuł decyzji}"
status: Proposed | Accepted | Deprecated
type: adr
component: {nazwa-komponentu}
owner: {Imię Nazwisko}    # opcjonalne
---
```

Numeracja trzycyfrowa, sekwencyjna (`ADR-001`, `ADR-002`, …).

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

```markdown
# ADR: {Tytuł decyzji}

## Status
Proposed / Accepted / Deprecated

## Kontekst
Dlaczego ta decyzja jest potrzebna. Jaki problem rozwiązujemy.

## Opcje

### A: {Nazwa opcji}
Opis.
- Zalety: ...
- Wady: ...

### B: {Nazwa opcji} (wybrana)
Opis.
- Zalety: ...
- Wady: ...

## Decyzja
Wybrana opcja i uzasadnienie.

## Konsekwencje
Co zmienia ta decyzja. Jakie są ryzyka, trade-offy, ograniczenia.

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty

Brak wariantów — ADR ma jednolitą strukturę. Liczbę opcji w sekcji „Opcje” dopasuj do rzeczywistej liczby rozważanych rozwiązań (minimum dwie).

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. ADR można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
