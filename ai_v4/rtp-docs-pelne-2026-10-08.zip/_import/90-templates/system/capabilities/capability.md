---
doc-id: TPL-CAP
title: "Template: Capability"
status: active
tags:
  - standard
  - template
related-doc-ids⟦?:⟧ ⟦?[⟧TPL-UC, TPL-TUC, TPL-NFR, TPL-API, TPL-INT, TPL-ADR]
examples-ids: [EX-CAP-001]
---

# Template: Capability

## 1. Jakiego artefaktu to szablon?
Capability opisuje **konkretną, mierzalną zdolność systemu** do wykonania określonej czynności lub dostarczenia wartości biznesowej. Odpowiada na pytanie **co system potrafi**, a nie **jak to robi**.

Capability musi być granularne, domenowe i należeć do odpowiedzialności opisywanego systemu. Jedno Capability opisuje jedną spójną zdolność; nie może być ogólnym workiem na funkcje, komponenty ani integracje. Ma własną wartość biznesową, miary skuteczności, ryzyka, regulacje i ograniczenia.

Capability jest dokumentacją przyrostową: rozwijaj i aktualizuj istniejący artefakt wraz ze zmianami zdolności systemu, zachowując historię i odnośniki. Nie twórz nowego dokumentu dla każdej zmiany tej samej zdolności.

System może korzystać z Capability innych domen lub systemów, np. Loans, Documents, Payments albo Customer. W takim przypadku dokument wskazuje zależność i sposób jej wykorzystania, ale nie przypisuje sobie cudzej odpowiedzialności. Granica odpowiedzialności zewnętrznej domeny jest doprecyzowana w sekcji „Poza zakresem”.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- projektujesz architekturę systemu i ustalasz jego konkretne zdolności
- chcesz określić, co system dostarcza w granicach własnej domeny
- potrzebujesz powiązać zdolność z referencjami do wymagań i API, miarami lub regulacjami
- zmiana albo nowe Capability może oznaczać nowy zakres wymagań lub zmian w systemie

**Nie używaj gdy:**
- opisujesz krok po kroku scenariusz użytkownika lub systemu → rozważ `use-case` / `technical-use-case`, jeśli wnoszą wartość
- opisujesz kontrakt pojedynczego endpointu → użyj `api-endpoint`
- opisujesz detale połączenia z systemem zewnętrznym → użyj `integration`
- definiujesz wymagania jakościowe systemu (SLA/SLO, security) → użyj `non-functional-requirements` i powiąż je z Capability
- dokumentujesz cudzą zdolność domenową → odwołaj się do Capability właściciela domeny; nie przejmuj jej odpowiedzialności
- opisujesz szeroki, niespójny zestaw funkcji → rozbij go na odrębne Capability

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jaka jest jedna konkretna czynność lub wartość, którą system dostarcza
- Do jakiej domeny należy Capability i kto jest właścicielem tej odpowiedzialności
- Jak odróżnić tę Capability od innych zdolności systemu; nazwa i zakres muszą być granularne
- Jakie wymagania wynikają z Capability oraz które API ją realizują — wskaż do nich odnośniki, bez powielania ich treści w Capability
- Jakie dane, API, moduły lub Capability innych domen są potrzebne do jej działania; opisz wpływ ich niedostępności w ryzykach i ograniczeniach oraz wskaż odnośniki do dokumentacji właściciela
- Jak zależność od dostępności innego modułu/systemu wpływa na działanie tej Capability
- Jakie twarde regulacje, wytyczne lub wymagania compliance wpływają na zachowanie systemu
- Jakimi miarami i progami można ocenić skuteczność zdolności
- Jakie są jej własne ryzyka, ograniczenia i granice odpowiedzialności
- Capability powstaje podczas projektowania architektury systemu i jest dokumentowane przyrostowo; aktualizuj istniejący artefakt, gdy zmienia się zdolność, jej granice lub powiązania
- Capability opisuje zachowanie, **nie** implementację i nie jest kopią kodu (inwariancja I7)
- Jedna capability = jeden plik (inwariancja I3)

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: CAP-{numer}
title: "Capability: {Nazwa zdolności}"
status: draft
type: capability
component: {nazwa-komponentu}
source-spec-ids: []       # opcjonalne — istniejące źródła wymagań lub kontekstu; BFS nie jest wymagany
related-doc-ids:          # opcjonalne — referencje do wymagań, API, NFR, integracji i zależnych Capability
  - API-{numer}
  - NFR-{numer}
  - CAP-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji
Wybierz wariant opisany w sekcji „Warianty”. Capability rozwijaj przyrostowo w tym samym artefakcie. W wymaganych sekcjach, dla których brakuje danych, wskaż lukę, ownera i wymagany krok weryfikacji; nie wymyślaj danych. Wymagania i API wykazuj jako referencje w metadanych i generowanej sekcji „Powiązane dokumenty”, bez odrębnych sekcji ani kopiowania ich treści.
```markdown
# Capability: {Nazwa zdolności}

## Opis
Krótko i konkretnie opisz, co system robi w ramach tej zdolności, dla kogo i jaki obserwowalny rezultat dostarcza. Opis musi wskazywać jedną granularną zdolność; nie opisuj implementacji ani listy niespójnych funkcji.

## Wartość biznesowa
Opisz wartość dostarczaną przez Capability, jej odbiorcę oraz problem lub potrzebę, którą zaspokaja. Wartość powinna być możliwa do oceny miarami wskazanymi niżej.

## Zakres odpowiedzialności (in-scope)
Wskaż odpowiedzialność systemu i jego domeny. Zakres musi być spójny z pojedynczą Capability.
- {Odpowiedzialność 1}
- {Odpowiedzialność 2}

## Poza zakresem (out-of-scope)
Wskaż elementy istotne dla pełnego obrazu, ale realizowane poza zakresem tej Capability — przez inną Capability, domenę lub system. Dla każdej odpowiedzialności realizowanej poza opisywaną Capability podaj system oraz odpowiedzialną jednostkę i jej ownera, również gdy jest to inna Capability tego samego systemu. Szczegółowy kontrakt i odpowiedzialność pozostają po stronie właściciela; wskaż do nich referencję, jeśli jest dostępna. Nieznane dane oznacz jako lukę z ownerem i krokiem weryfikacji.

| Element poza zakresem / odpowiedzialność          | System lub Capability właściciela | Odpowiedzialna jednostka / owner | Referencja do kontraktu lub dokumentacji właściciela |
| ------------------------------------------------- | --------------------------------- | -------------------------------- | ---------------------------------------------------- |
| {odpowiedzialność realizowana poza tą Capability} | {system i/lub ID Capability}      | {jednostka oraz owner}           | {ID lub link; jeśli brak — luka do uzupełnienia}     |

Jeżeli nie zidentyfikowano elementów poza zakresem, wpisz „Brak” i wskaż, kto potwierdził tę granicę odpowiedzialności.

## Regulacje
Wskaż twarde regulacje, dyrektywy, wytyczne lub wymagania compliance, z których wynikają ograniczenia albo zachowania systemu. Pozwól prześledzić wpływ zmiany regulacji na Capability.

| Identyfikator i źródło regulacji | Wymaganie lub artykuł | Wpływ na działanie systemu / Capability | Właściciel interpretacji | Sposób monitorowania zmian  |
| -------------------------------- | --------------------- | --------------------------------------- | ------------------------ | --------------------------- |
| {nazwa, identyfikator, link}     | {konkretny zapis}     | {wpływ}                                 | {rola/obszar}            | {źródło lub cykl przeglądu} |

Jeżeli nie zidentyfikowano regulacji, wpisz „Nie zidentyfikowano” i oznacz, kto oraz kiedy powinien to potwierdzić. Nie zakładaj braku obowiązków bez weryfikacji.

## Miary i kryteria skuteczności
Zdefiniuj własne, mierzalne kryteria skuteczności tej Capability. Jeśli próg nie został jeszcze uzgodniony, oznacz go jako lukę do decyzji ownera.

| Miara     | Definicja i jednostka | Wartość bazowa             | Oczekiwany próg          | Źródło pomiaru / częstotliwość | Owner        |
| --------- | --------------------- | -------------------------- | ------------------------ | ------------------------------ | ------------ |
| {KPI/SLA} | {co i jak mierzymy}   | {wartość albo brak danych} | {próg albo do ustalenia} | {metryka/raport i cykl}        | {rola/osoba} |

## Ryzyka i ograniczenia
Wskaż ryzyka i ograniczenia dotyczące tej Capability, w tym skutki niedostępności zależności oraz ograniczenia regulacyjne lub domenowe. Nie duplikuj ogólnych ryzyk systemowych bez wskazania wpływu na tę zdolność.

| Ryzyko lub ograniczenie | Prawdopodobieństwo / warunek | Wpływ na Capability | Mitygacja / zachowanie systemu         | Owner        |
| ----------------------- | ---------------------------- | ------------------- | -------------------------------------- | ------------ |
| {opis}                  | {ocena lub warunek}          | {skutek}            | {kontrola, fallback albo do ustalenia} | {rola/osoba} |

## Historia zmian
| Źródło         | Autor             | Data          | Wydanie           | Opis                              |
| -------------- | ----------------- | ------------- | ----------------- | --------------------------------- |
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty
Capability jest dokumentacją przyrostową — rozwijaj istniejący artefakt w miarę przybywania wiedzy i zmian odpowiedzialności; nie twórz nowego dokumentu dla każdej zmiany tej samej zdolności. W obu wariantach zachowaj sekcję `Historia zmian`. Źródłowe specyfikacje i BFS wskazuj w `source-spec-ids`, a dokumenty wymagań wynikowych, API oraz inne powiązane artefakty — w `related-doc-ids`. Hook renderuje je w sekcjach „Specyfikacje źródłowe” i „Powiązane dokumenty”. Nie twórz dla nich odrębnych sekcji ani nie duplikuj ich treści.

**Wariant minimalny** — obowiązkowe sekcje treści: Opis, Wartość biznesowa, Zakres odpowiedzialności (in-scope) oraz Poza zakresem (out-of-scope). W „Poza zakresem” określ system i odpowiedzialną jednostkę/ownera dla każdej odpowiedzialności realizowanej poza opisywaną Capability, również w przypadku innej Capability tego samego systemu. Szczegółowy kontrakt pozostaje u właściciela; podaj jego referencję, jeśli jest dostępna. Nieznanego właściciela lub brak dokumentacji oznacz jako lukę z ownerem i krokiem weryfikacji. Utrzymuj metadane powiązań oraz historię zmian.

**Wariant pełny (zalecany)** — zawiera wszystkie sekcje wariantu minimalnego oraz Regulacje, Miary i kryteria skuteczności i Ryzyka i ograniczenia. Uzupełnij je w zakresie, w jakim wnoszą istotną wiedzę ponad kod. Wpływ zależności zewnętrznych opisz jako ryzyko lub ograniczenie, a ich szczegółowy kontrakt referuj — nie odtwarzaj go w Capability. Referencje do dokumentów wymagań i API nadal utrzymuj wyłącznie przez metadane.

Sekcje „Powiązane dokumenty” i „Specyfikacje źródłowe” są renderowane automatycznie na podstawie metadanych, jeśli zdefiniowano odpowiednie identyfikatory. Nie wpisuj ich ręcznie w treści artefaktu.

---

## 7. Powiązany prompt generujący
Użyj prompta `.github/prompts/create-capability.prompt.md`, aby utworzyć draft Capability na podstawie opisu, dokumentacji źródłowej lub kodu.
