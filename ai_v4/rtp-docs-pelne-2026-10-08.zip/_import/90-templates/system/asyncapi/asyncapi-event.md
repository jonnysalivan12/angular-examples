---
doc-id: TPL-QUE
title: "Template: AsyncApi - publikacja eventu"
status: active
tags:
  - standard
  - template
⟦?r⟧elated-doc-ids: [TPL-CAP, TPL-FLOW, TPL-INT, TPL-UC, TPL-TUC]
---

# Template: AsyncApi - publikacja eventu

## 1. Jakiego artefaktu to szablon?
Ten szablon opisuje **kontrakt eventu publikowanego asynchronicznie przez system za pośrednictwem brokera wiadomości** (Kafka topic, RabbitMQ exchange). Jeden plik = jeden obszar logiczny komunikacji (jeden lub kilka tematycznie powiązanych kanałów i operacji).

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- opisujesz event publikowany asynchronicznie przez system do jednego lub wielu konsumentów
- chcesz udokumentować kontrakt payload, headers i semantykę dostarczenia

**Nie używaj gdy:**
- opisujesz integrację synchroniczną REST/SOAP — użyj `api-endpoint`
- opisujesz integrację z zewnętrznym systemem — użyj `integration`
- opisujesz logikę przetwarzania po odbiorze komunikatu — użyj `flow` lub `workflow-step`
- opisujesz decyzję lub proces publikacji danego eventu — użyj `TUC`, `UC` lub `BFS`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jaki system produkuje event i jaki go konsumuje (producer / consumer)
- Jak są zdefiniowane kanały i operacje — adres kanału (topic / exchange / routing key) oraz kierunek operacji (`send` / `receive`)
- Jaka jest struktura komunikatu (payload) — pola biznesowe przesyłane w sekcji `payload`; to właśnie ten model należy opisać w sekcji **Specyfikacja schematu**
- Jaka jest konwencja nazewnicza komunikatu — nazwa komunikatu jest określana przez standard CAIT; należy ją znać przed wypełnianiem sekcji kontraktu
- Na jakiej platformie brokerowej działa komunikacja (Kafka — topic, RabbitMQ — exchange z routing direct/fanout/topic)
- Czy istnieje już dokument nadrzędny (BFS, UC, TUC) opisujący kontekst biznesowy
- Braki oznaczaj jawnie przez `> Założenie:` zamiast zgadywania

---

## 4. Front matter (obowiązkowe pola)
```json
---
doc-id: QUE-{numer}
title: "QUE - publikacja eventu"
status: draft
type: event
component: {nazwa-komponentu}
source-spec-ids:          # opcjonalne — dokument nadrzędny
  - {BFS-xxx|UC-xxx|TUC-xxx}
related-doc-ids:          # opcjonalne — dokumenty powiązane
  - {CAP-xxx}
owner: {Imię Nazwisko}    # opcjonalne
broker: {kafka|rabbitmq|inne}     # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

Konwencja nazwy pliku: `kebab-case`, angielski. Przykłady: `asyncapi-overdraft-renewal.md`, `asyncapi-loan-origination.md`.

---

## 5. Struktura sekcji
````markdown
# AsyncAPI: {Nazwa obszaru}

## Informacje podstawowe
| Właściwość | Wartość |
|------------|---------|
| **Nazwa eventu** | `{NazwaKomunikatu}` |
| **Wersja eventu** | v{N} |
| **System producenta** | {NazwaSystemu} |
| **Address kanału** | `{topic / exchange / routing-key}` |
| **Format** | JSON / AVRO (Schema Registry) |
| **Producent** | {Komponent lub proces publikujący} |
| **Konsument(ci)** | {Domena lub system odbierający} <!-- OPCJONALNIE --> |

## Cel i zakres
Krótki opis: co event sygnalizuje, kto go produkuje i po jakim zdarzeniu biznesowym.

## Kontekst biznesowy
Opis decyzji lub procesu, który ten event wspiera. Wskazanie dokumentu nadrzędnego (TUC/UC/BFS), jeżeli istnieje.

### Przepływ danych
<!-- wstaw diagram sequenceDiagram — patrz wzorzec poniżej -->
````

Wzorzec diagramu przepływu (zastąp uczestników nazwami swoich systemów):
```mermaid
%%{init: {'sequence': {'mirrorActors': false}}}%%
sequenceDiagram
    participant P as {Producent}
    participant B as {Broker — Kafka topic / RabbitMQ exchange}
    participant C as {Konsument}
    P->>B: Publikacja eventu {NazwaKomunikatu}
    B->>C: Dostarczenie eventu
```

````markdown
## Header komunikatu
Nagłówki powinny być zgodne z wytycznymi architektonicznymi dla AsyncAPI 3.0 (sekcja Messages):
- [Wytyczne uzupełniania dokumentacji AsyncAPI 3.0 - Architektura IT - Confluence](https://orsite.centrala.bzwbk/spaces/AIT/pages/557266666/Wytyczne+uzupe%C5%82niania+dokumentacji+AsyncAPI+3.0)

| Pole | Przyklad | Cel |
|------|----------|-----|
| `correlationId` | `{uuid}` | Śledzenie end-to-end |
| `messageId` | `{uuid}` | Idempotencja i deduplikacja |
| `ce_id` | `{uuid}` | CloudEvents — identyfikator zdarzenia |
| `ce_source` | `{system-name}` | CloudEvents — system źródłowy |
| `ce_time` | `2026-01-01T00:00:00Z` | CloudEvents — czas publikacji (RFC3339 UTC) |
| `content-type` | `application/avro` | Format payloadu |

## Specyfikacja schematu

### Atrybut: `{nazwaAtrybutu}`
| Właściwość | Wartość |
|------------|---------|
| Typ | `{string \| integer \| boolean \| ...}` |
| Obligatoryjny | TAK / NIE |
| Wartości / Format | `{enum-wartosci lub format, np. date-time}` |
| **Opis** | Opis biznesowy atrybutu |

> Założenie: [jawne braki lub założenia dotyczące schematu]

### Przykład payloadu
```json
{
  "eventId": "{uuid}",
  "eventType": "{NazwaKomunikatu}",
  "eventVersion": "v{N}",
  "occurredAt": "2026-01-01T00:00:00Z",
  "producerSystem": "{NazwaSystemu}",
  "correlationId": "{uuid}",
  "messageId": "{uuid}",
  "payload": {
    "{nazwaAtrybutu1}": "{wartoscPrzykladowa1}",
    "{nazwaAtrybutu2}": "{wartoscPrzykladowa2}",
    "{nazwaAtrybutu3}": "{wartoscPrzykladowa3}"
  }
}
```

## Charakterystyka dostarczenia <!-- OPCJONALNIE -->
| Właściwość | Wartość | Opis |
|------------|---------|------|
| **Gwarancja dostarczenia** | at-least-once / exactly-once / at-most-once | Semantyka dostarczenia wiadomości przez brokera. `at-least-once` — wiadomość dotrze co najmniej raz (duplikaty możliwe); `exactly-once` — dokładnie raz (wymaga transakcji lub idempotentnego producenta); `at-most-once` — co najwyżej raz (utrata możliwa). |
| **Idempotencja konsumenta** | wymagana / nie wymagana | Czy konsument musi obsługiwać powtórne dostarczenie tej samej wiadomości bez efektów ubocznych. Wymagana zawsze przy `at-least-once`. |
| **Kolejność wiadomości** | gwarantowana / nie gwarantowana | Czy wiadomości w ramach kanału (topic / exchange) są dostarczane w kolejności publikacji. W Kafce kolejność jest gwarantowana w obrębie partycji. |
| **Klucz partycji** | {pole lub „nie dotyczy"} | Pole payloadu lub nagłówka używane jako klucz partycji Kafki. Determinuje, do której partycji trafi wiadomość — wpływa na kolejność i lokalność danych. |
| **Retencja** | {np. 7 dni / „nie dotyczy"} | Czas przechowywania wiadomości na brokerze po dostarczeniu. Istotne dla scenariuszy replay i audytu. |
| **DLQ** | {nazwa DLQ lub „nie dotyczy"} | Dead Letter Queue — kolejka lub topic, do którego trafiają wiadomości niemożliwe do przetworzenia po wyczerpaniu prób ponowienia. |

## Powiązanie z przepływem end-to-end
- **Poprzedni krok**: [{TUC lub UC triggujący publikację}]({sciezka-wzgledna}.md)
- **Bieżący krok**: dokument opisuje kontrakt publikowanego eventu po stronie producenta.
- **Kolejny krok po stronie konsumenta**: {ścieżka do artefaktu konsumenta lub opis lokalizacji}

## Powiązane dokumenty
- **JIRA**: [{STORY-ID} — {tytuł}](https://jira.example.com/browse/{STORY-ID})

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krotki sens zmiany dla odbiorcy` |
````

---

## 6. Warianty
Brak osobnych wariantów plików — ten szablon jest broker-agnostic. Specyfikę brokera (konwencje Kafka, RabbitMQ) dokumentuj w sekcji **Runtime i technologia** oraz **Model kanałów i operacji** wewnątrz dokumentu.

### Wariant alternatywny: plik AsyncAPI wygenerowany z EA
Plik AsyncAPI można wygenerować bezpośrednio z Enterprise Architect przy użyciu wtyczki generującej specyfikację AsyncAPI. Wymaga to zdefiniowania w EA całej kolejki (kanałów, operacji, wiadomości), nie tylko struktury wiadomości. W takim przypadku niniejszy szablon służy jako dokumentacja uzupełniająca (kontekst biznesowy, headers, przykłady) — nie zastępuje wygenerowanego pliku JSON.

---

## 7. Powiązany prompt generujący
Brak dedykowanego prompta. Specyfikacje AsyncAPI można wygenerować promptami ogólnymi `generate-spec-from-jira` lub `generate-spec-from-description`.
