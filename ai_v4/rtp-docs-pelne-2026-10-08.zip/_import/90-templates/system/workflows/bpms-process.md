---
doc-id: TPL-BPMS
title: "Template: Proces BPMS"
status: active
tags:
  - standard
  - template
  - bpms
  - ⟦?w⟧orkflow
related-doc-ids: [TPL-WF, TPL-CAP, TPL-FLOW, TPL-API]
examples-ids: [EX-BPMS-001]
---

# Template: Proces BPMS

## 1. Jakiego artefaktu to szablon?

Proces BPMS opisuje **działanie i orkiestrację systemu zarządzania procesami biznesowymi**. Dokumentuje przebieg procesu oraz działanie każdego kroku w zakresie potrzebnym do zrozumienia całości. BPMN jest notacją diagramu procesu, a nie nazwą opisywanego systemu ani artefaktu. Dokument nie powiela pełnych kontraktów API, współdzielonych Capability ani ekranów; odsyła do ich specyfikacji. Osobny `workflow-step` (SPEC-WF) jest opcjonalnym rozwinięciem kroku o złożonej logice, której nie da się czytelnie opisać bezpośrednio w specyfikacji procesu.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- proces jest wykonywany przez system BPMS (np. Camunda), a jego diagram jest modelowany w BPMN
- potrzebujesz mapy „co po czym" i „kto co robi" dla procesu wielokrokowego
- BPMN jest właściwym artefaktem wiodącym dla opisu orkiestracji, a odrębny Use Case lub Technical Use Case nie wnosi potrzebnej perspektywy celu użytkownika, wymagań ani triggera systemowego

**Nie używaj gdy:**
- opisujesz przepływ poza systemem BPMS → użyj `flow`
- opisujesz scenariusz z perspektywy użytkownika → użyj `use-case`
- opisujesz automatyczny scenariusz systemowy lub jego trigger, a orkiestracja BPMS nie jest głównym celem → rozważ `technical-use-case`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?

- W którym systemie BPMS proces jest uruchomiony i kto go inicjuje
- **Proces = sterowanie, nie logika** — mapa mówi „co po czym" i „kto to robi", nie „jak to robi"
- **Silnik BPMN jest jedynym source of truth dla diagramu** — nie duplikuj go w żadnej notacji (Mermaid, ASCII); dwa źródła to gwarancja dryfu (inwariancja I1)
- Max 15 tasków na diagramie — większe procesy dziel na subprocesy jako osobne pliki (inwariancja I3)
- Każdy task procesu musi mieć opis działania w sekcji „Taski procesu”. Sam fakt, że element jest taskiem BPMN, nie uzasadnia tworzenia osobnego SPEC-WF.
- User Task wskazuje powiązany Screen, gdy proces BPMS jest artefaktem wiodącym opisującym interakcję; gdy tę interakcję opisuje Use Case, odnośnik do Screen znajduje się w Use Case i nie jest powtarzany w procesie BPMS.
- Osobny SPEC-WF twórz wyłącznie wtedy, gdy wewnętrzny przepływ pojedynczego kroku jest bardzo złożony; jego opis działania lub odnośnik do SPEC-WF umieść w sekcji „Taski procesu”.
- Wersjonowanie: `process-version` i sekcja diagramu są opcjonalne dopóki diagram BPMN nie powstał (przepływ spec-first). Od chwili, gdy diagram istnieje i jest osadzony w kodzie, każda zmiana procesu w silniku → aktualizacja `process-version` (tag/commit pliku BPMN XML), opisów kroków i sekcji subprocesów

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: BPMS-{NNN}
title: "Proces BPMS: {Nazwa procesu}"
status: draft
type: bpms-process
process-version: "1.0"    # opcjonalne do czasu powstania diagramu; obowiązkowe gdy diagram już istnieje
source-spec-ids: []       # opcjonalne — JIRA / BFS
related-doc-ids: []       # opcjonalne — UC/TUC, SPEC-WF, API, integracje, Capability, procesy
owner: {Imię Nazwisko}    # opcjonalne
---
```

`doc-id` musi być unikalny w całym repozytorium. Format: `BPMS-{NNN}`, np. `BPMS-001`.

Konwencja nazwy pliku: nazwa odpowiada identyfikatorowi procesu w systemie BPMS, np. `bpms-decyzja-wstepna.md`. Podprocesy jako osobne pliki: `bpms-decyzja-wstepna-ocena-ryzyka.md`.

`process-version` wiąże specyfikację z konkretną wersją pliku BPMN XML w silniku (tag lub hash commita). W przepływie spec-first (specyfikacja powstaje przed diagramem) pole pozostaje puste — nie ma jeszcze diagramu, który można powiązać. Od chwili gdy diagram istnieje i jest osadzony w kodzie, `process-version` staje się obowiązkowe, a zmiana procesu bez jego aktualizacji jest błędem.

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

```markdown
# Proces BPMS: {Nazwa procesu}

## Cel procesu

Jedno zdanie: jaki cel biznesowy realizuje ten proces i co jest jego efektem (output).

## Kontekst

- **System**: {nazwa systemu}
- **System BPMS**: {nazwa systemu, np. Camunda}
- **Inicjator**: {aktor / zdarzenie inicjujące}
- **Zakres**: {etapy procesu, które obejmuje ten diagram}

## Diagram procesu

Sekcja opcjonalna w przepływie spec-first — wypełnij dopiero gdy diagram BPMN powstanie. Dopóki diagram nie istnieje, pozostaw adnotację `> Założenie: diagram powstanie na etapie developmentu — do uzupełnienia`.

Silnik BPMN jest jedynym source of truth dla diagramu — nie duplikujemy go w notacji Mermaid.

| Zasób                         | Lokalizacja                                                               |
| ----------------------------- | ------------------------------------------------------------------------- |
| BPMN XML (wersjonowany)       | `bpmn/{bpmn-model-name}.bpmn` w tym samym repozytorium lub w repo silnika |
| Widok w silniku               | [{URL do Camundy / innego silnika BPMN}]({url})                           |
| Eksport PNG/SVG (opcjonalnie) | `bpmn/{bpmn-model-name}.svg` — commitowany przy każdej istotnej zmianie   |

Jeśli repozytorium BPMN XML jest zewnętrzne — podaj wersję/tag pliku BPMN powiązaną z tą specyfikacją (np. `v1.2.0` lub hash commita) i uzupełnij `process-version`.

## Taski procesu

Wymień wszystkie taski w kolejności wynikającej z procesu BPMN. Każdy task musi mieć zdefiniowany opis działania kroku wystarczający do zrozumienia jego roli w przebiegu procesu. Opis może zawierać warunki, istotne dane lub rezultat; kontraktów API, współdzielonych Capability ani ekranów nie duplikuj — podaj ich identyfikatory i odnośniki.

| ID tasku (BPMN) | Typ          | Nazwa         | Opis działania kroku                                                                                                            |
| --------------- | ------------ | ------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| task-001        | User Task    | {Nazwa tasku} | {Co wykonuje użytkownik i jaki rezultat uzyskuje; gdy BPMS jest artefaktem wiodącym, wskaż powiązany Screen jako `{{SCR-001}}`} |
| task-002        | Service Task | {Nazwa tasku} | {Opis działania systemu i rezultatu kroku albo odnośnik do `{{SPEC-WF-001}}`, jeśli logika jest złożona}                        |

Opis działania kroku w tabeli jest obowiązkowy dla każdego tasku. Jeśli wewnętrzna logika tasku jest bardzo złożona i wymaga osobnego dokumentu, można ją rozwinąć w SPEC-WF. W takim przypadku w kolumnie „Opis działania kroku” nie powielaj opisu logiki — wskaż SPEC-WF, który realizuje dany krok, np. `{{SPEC-WF-001}}`. Sam SPEC-WF jest opcjonalny; nie twórz go wyłącznie dlatego, że element występuje jako task BPMN.

> Założenie: jeśli działania tasku nie da się jeszcze ustalić, oznacz brak w jego komórce jako `> Założenie: opis działania kroku — do uzupełnienia` i uzupełnij przed zatwierdzeniem specyfikacji.

## Bramki i warunki

| Bramka       | Rodzaj          | Warunki                                                                   |
| ------------ | --------------- | ------------------------------------------------------------------------- |
| GW1: {Nazwa} | Exclusive (XOR) | `tak` gdy {warunek A}; `nie` gdy {warunek B}                              |
| GW2: {Nazwa} | Inclusive (OR)  | ścieżka A gdy {warunek A}; ścieżka B gdy {warunek B} (możliwe obie naraz) |
| GW3: {Nazwa} | Parallel (AND)  | wszystkie ścieżki uruchamiane równolegle — bez warunków                   |

Kolumna **Rodzaj** określa typ bramki BPMN. Najczęściej stosowane:
- **Exclusive (XOR)** — wybiera dokładnie jedną ścieżkę (pierwszy spełniony warunek).
- **Inclusive (OR)** — może uruchomić jedną lub wiele ścieżek jednocześnie (wszystkie spełnione warunki).
- **Parallel (AND)** — uruchamia wszystkie ścieżki równolegle, bez warunków (rozdzielenie i synchronizacja).

## Zdarzenia graniczne (Boundary Events)

Opcjonalne — wypełnij jeśli proces używa zdarzeń granicznych (timeout, error, escalation).

| Task     | Typ zdarzenia | Obsługa                    |
| -------- | ------------- | -------------------------- |
| task-001 | Timeout (48h) | Przejście do tasku {nazwa} |

## Subprocesy

Opcjonalne — jeśli proces zawiera subprocesy.

| Subproces          | Opis        | Plik dokumentacji |
| ------------------ | ----------- | ----------------- |
| {Nazwa subprocesu} | Krótki opis | `{{BPMS-002}}`    |

## Historia zmian

| Źródło         | Autor             | Data          | Wydanie           | Opis                              |
| -------------- | ----------------- | ------------- | ----------------- | --------------------------------- |
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

Powiązania (SPEC-WF, capability, poprzedni/następny proces) utrzymuj przez `related-doc-ids` oraz odnośniki inline `{{DOC-ID}}` — nie przez ścieżki. Hook wylicza tytuł, typ i poprawną ścieżkę docelowego dokumentu. Sekcje „Specyfikacje źródłowe” i „Powiązane dokumenty” są renderowane na podstawie `source-spec-ids` oraz `related-doc-ids`; nie wpisuj ich ręcznie w treści.

---

## 6. Wybór artefaktu wiodącego

Nie wszystkie procesy wymagają BPMS Process, Use Case, Technical Use Case i Flow jednocześnie. Dla każdego przebiegu wybierz jeden artefakt wiodący, który opisuje jego kolejność działań. Pozostałe artefakty dodawaj tylko wtedy, gdy wnoszą odrębną perspektywę lub kontrakt. Nie utrzymuj równoległych, konkurencyjnych opisów tych samych kroków.

| Pytanie                                                                                                          | Artefakt wiodący   |
| ---------------------------------------------------------------------------------------------------------------- | ------------------ |
| Czy opisujemy cel i interakcję konkretnego użytkownika?                                                          | Use Case           |
| Czy opisujemy automatyczny scenariusz systemowy i jego trigger, a nie orkiestrację BPMS?                         | Technical Use Case |
| Czy opisujemy orkiestrację realizowaną przez system BPMS?                                                        | Proces BPMS        |
| Czy przebieg nie jest orkiestracją BPMN ani scenariuszem UC/TUC, ale wymaga opisu sekwencji między uczestnikami? | Flow               |

### Wariant A — Proces BPMS jako artefakt wiodący

Stosuj, gdy orkiestracja BPMN jest wystarczającym i preferowanym opisem przebiegu, a Use Case lub Technical Use Case nie wnosi potrzebnej perspektywy. Proces BPMS opisuje kolejność kroków, bramki, wykonawców i rezultaty. Screen linkuj przy odpowiednim User Task. API i Integration linkuj przy krokach, które z nich korzystają. Capability określa odpowiedzialność i granice domeny, bez powielania przebiegu.

### Wariant B — Use Case lub Technical Use Case jako artefakt wiodący

Stosuj, gdy potrzebny jest opis celu i obserwowalnego przebiegu użytkownika (Use Case) albo triggera i zachowania systemowego (Technical Use Case), np. dla wymagań, akceptacji lub testów. Jeśli przebieg jest również orkiestracją BPMS, ten dokument opisuje orkiestrację i kroki systemowe bez kopiowania scenariusza UC/TUC. Screen linkuj z Use Case opisującego interakcję; nie powtarzaj tego odnośnika w procesie BPMS. Przy krokach BPMS referuj odpowiednie API, Integration lub Capability.

W obu wariantach Flow stosuj tylko do odrębnego przepływu nieopisanego przez BPMN ani UC/TUC. Aktorów można wskazać w kontekście i krokach; osobny artefakt Actor twórz, gdy katalog ról ma wartość samodzielną lub jest współdzielony.

Relacje między artefaktami utrzymuj przez `related-doc-ids` i odnośniki inline `{{DOC-ID}}`. Relacje nie uzasadniają kopiowania treści ani tworzenia dodatkowego artefaktu opisującego te same kroki.

## 7. Warianty procesu

| Wariant               | Kiedy stosować                                                       |
| --------------------- | -------------------------------------------------------------------- |
| Pełny proces          | Domyślny — cały przepływ end-to-end                                  |
| Subproces             | Etap zbyt złożony, by zmieścić się w 15 taskach na diagramie głównym |
| Proces obsługi błędów | Dedykowany przepływ dla sytuacji wyjątkowych (error boundary)        |

---

## 8. Workflow pracy z BPMN XML

### Lokalizacja pliku BPMN

BPMN XML procesu jest przechowywany w repozytorium dokumentacji obok SPEC:

```text
docs/project/system/workflows/bpmn/{bpmn-model-name}.bpmn
docs/project/system/workflows/bpmn/{bpmn-model-name}.svg  (opcjonalnie — eksport widoku)
```

### Cykl życia procesu (perspektywa analityka)

#### Projektowanie

1. Analityk tworzy BPMN XML w katalogu `docs/project/system/workflows/bpmn/` używając Camunda Modeler lub innego narzędzia BPMN.
2. Wypełnia SPEC procesu (ten dokument) — kontekst, taski wraz z opisem działania, bramki, zdarzenia i subprocesy.
3. Definiuje opis działania każdego tasku w sekcji „Taski procesu”; tworzy SPEC-WF tylko dla kroku o bardzo złożonym wewnętrznym przepływie, bez duplikowania tam jego szczegółowego opisu.
4. Commituje do repozytorium SPEC i BPMN XML razem oraz powiązane SPEC-WF, jeśli są potrzebne.

#### Zmiany procesu

- Wersjonowanie (`process-version`) zaczyna obowiązywać od momentu, gdy diagram BPMN istnieje. Wcześniej (spec-first) pole pozostaje puste.
- Każda zmiana diagramu BPMN → aktualizacja BPMN XML + SPEC + `process-version` w front matter.
- BPMN XML w docs to wersja projektowa (intencja biznesowa). Developer przenosi go do repo z kodem i rozbudowuje o szczegóły implementacyjne.

### Model źródeł prawdy

| Lokalizacja                           | Zawartość                                    | Właściciel  |
| ------------------------------------- | -------------------------------------------- | ----------- |
| `docs/project/system/workflows/bpmn/` | Struktura procesu — intencja biznesowa       | Analityk    |
| `code-repo/src/.../processes/`        | Proces + implementacja (delegaty, listenery) | Developer   |
| Camunda (runtime)                     | Deployed proces                              | Silnik BPMN |

W przypadku dryfu między docs a kodem — kod jest źródłem prawdy implementacyjnej, docs jest źródłem prawdy intencji biznesowej. Przy rozbieżnościach analityk weryfikuje zgodność z wymaganiami i aktualizuje SPEC.

---

## 9. Powiązany prompt generujący

> Założenie: prompt `generate-bpms-process-spec` nie został jeszcze utworzony — do zdefiniowania.
