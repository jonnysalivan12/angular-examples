---
doc-id: TPL-WF
title: "Template: Specyfikacja kroku Workflow (SPEC-WF)"
status: active
tags:
  - standard
  - template
  - bpmn
  - workflow
  - workflow-step
related-doc-ids: [TPL-BPMS, TPL-API, TPL-CAP, TPL-INT]
examples-ids: [EX-WF-001]
---

# Template: Specyfikacja kroku Workflow (SPEC-WF)

## 1. Jakiego artefaktu to szablon?

SPEC-WF jest **opcjonalnym, szczegółowym rozwinięciem logiki pojedynczego tasku** w procesie realizowanym przez BPMS — opisuje m.in. zmienne procesowe, reguły, wywoływane zasoby i obsługę błędów. Stosuj go tylko wtedy, gdy wewnętrzny przepływ tasku jest na tyle złożony, że nie da się go czytelnie opisać w specyfikacji procesu BPMS. Skrócony opis każdego kroku pozostaje w `bpms-process`. SPEC-WF nie opisuje mapy procesu, nie zawiera kontraktów API i nie redefiniuje logiki Capability. Jeden szczegółowo opisany task BPMN = jeden plik SPEC-WF (inwariancja I3).

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- wewnętrzny przepływ konkretnego tasku (User Task / Service Task) jest bardzo złożony i wymaga szczegółowego opisu ponad skrót ujęty w `bpms-process`
- potrzebujesz zadeklarować zmienne procesowe, reguły i scenariusze błędów kroku

**Nie używaj gdy:**
- opisujesz mapę całego procesu w systemie BPMS → użyj `bpms-process`
- task jest prosty i jego cel, warunki, działanie oraz rezultat można zrozumieć z opisu kroku w `bpms-process`; sam typ tasku BPMN nie uzasadnia osobnego SPEC-WF
- opisujesz kontrakt API → użyj `api`
- opisujesz reużywalną logikę biznesową → użyj `capability`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?

- Do którego procesu BPMN i tasku należy krok (id tasku w silniku)
- Typ tasku — wartość MUSI pochodzić z listy typów BPMN 2.0, nie twórz własnych: `User Task`, `Service Task`, `Script Task`, `Business Rule Task`, `Send Task`, `Receive Task`, `Manual Task`, `Call Activity`
- Konsekwencje typu dla tabeli Wywoływane zasoby: **User Task** → wiersz `UI` obowiązkowy; **Service Task / Send Task / Receive Task** → wiersz `API` lub `Integracja` obowiązkowy; **Business Rule Task** → wiersz `Capability` (reguły / DMN)
- Jakie zmienne procesowe task odczytuje i zapisuje do kontekstu procesu
- Reguły kroku sformułowane deterministycznie („jeśli X, to Y")

Granica odpowiedzialności — co SPEC-WF opisuje, a co jest gdzie indziej:

| SPEC-WF opisuje                                   | SPEC-WF NIE opisuje (link do właściwego miejsca)                                 |
| ------------------------------------------------- | -------------------------------------------------------------------------------- |
| Jak task używa API w tym procesie                 | Kontrakt API — to jest w **SPEC-API**                                            |
| Jak task wywołuje capability i co z wynikiem robi | Logika capability — to jest w **capability.md**                                  |
| Zmienne procesowe wchodzące/wychodzące z tasku    | Schemat danych domenowych — to jest w **modelu danych**                          |
| Reguły specyficzne dla tego kroku w tym procesie  | Reguły globalne systemu — to jest w **capability.md** lub **SPEC funkcjonalnym** |

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: SPEC-WF-{NNN}
title: "Workflow SPEC: {Nazwa tasku z BPMN}"
status: draft
type: workflow-step
bpms-process-id: BPMS-{NNN}
bpmn-task-id: {task-id-w-silniku-bpmn}
task-type: user-task | service-task | script-task | business-rule-task | send-task | receive-task | manual-task | call-activity
source-spec-ids:          # opcjonalne — JIRA
  - {JIRA-ID}
related-doc-ids:          # proces BPMS, poprzedni/następny task, API, UI
  - SPEC-WF-{NNN-poprzedni}
  - SPEC-WF-{NNN-nastepny}
owner: {Imię Nazwisko}    # opcjonalne
---
```

`doc-id` musi być unikalny w całym repozytorium. Format: `SPEC-WF-{NNN}`, np. `SPEC-WF-001`.

Konwencja nazwy pliku: `spec-wf-{nnn}.md` (np. `spec-wf-001.md`), gdzie `{nnn}` to numer porządkowy.

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

```markdown
# Workflow SPEC: {Nazwa tasku z BPMN}

## Kontekst

| Pole               | Wartość                                                                                                              |
| ------------------ | -------------------------------------------------------------------------------------------------------------------- |
| **Proces BPMS**    | [BPMS-{NNN}](../bpms-{process-name}.md)                                                                              |
| **Etap procesu**   | {Nazwa etapu, np. „Decyzja wstępna"}                                                                                 |
| **Typ tasku**      | User Task / Service Task / Script Task / Business Rule Task / Send Task / Receive Task / Manual Task / Call Activity |
| **Aktor / Serwis** | {Kto/co wykonuje ten task — rola użytkownika lub nazwa serwisu}                                                      |
| **JIRA**           | [{STORY-ID}](https://jira.example.com/browse/{STORY-ID})                                                             |

## Cel tasku

Jedno-dwa zdania: jaki konkretny efekt biznesowy ma ten task i co jest jego wyjściem (output).

## Warunki wstępne

- Poprzedni task `{nazwa}` zakończony ze statusem `{status}`
- Encja `{NazwaObiektu}` jest w stanie `{stan}`
- Wymagane dane: `{lista pól}`

## Wywoływane zasoby

Deklarujesz z czego korzysta ten task — SPEC-WF nie duplikuje kontraktów, referuje do właściwych SPEC.

| Typ            | Identyfikator | Opis powiązania                     |
| -------------- | ------------- | ----------------------------------- |
| **API**        | {{API-NNN}}   | {Co task robi z tym API}            |
| **Capability** | {{CAP-NNN}}   | {Jak task korzysta z tej zdolności} |
| **Integracja** | {{INT-NNN}}   | {Opcjonalne — zewnętrzny system}    |
| **UI**         | {{SCR-NNN}}   | {Tylko dla User Task — ekran}       |

Kontrakt API jest wyłącznie w SPEC-API. Logika capability wyłącznie w capability.md.

## Zmienne procesowe

### Wejście (odczytywane z kontekstu procesu)

| Zmienna procesowa | Typ    | Źródło (poprzedni task)                 | Opis         |
| ----------------- | ------ | --------------------------------------- | ------------ |
| `{nazwaZmiennej}` | String | {{SPEC-WF-NNN}}                         | {Co zawiera} |

### Wyjście (zapisywane do kontekstu procesu)

| Zmienna procesowa | Typ    | Konsument (następny task / bramka)                      | Opis                      |
| ----------------- | ------ | ------------------------------------------------------- | ------------------------- |
| `{nazwaZmiennej}` | String | bramka GW-{X} / {{SPEC-WF-NNN}}                         | {Co zawiera po wykonaniu} |

## Reguły i logika

Najważniejsza sekcja. Reguły formułuj deterministycznie („jeśli X, to Y"). Gdy mają rozgałęzienia — wstaw diagram flowchart Mermaid.

1. {Reguła 1 — jednoznacznie sformułowana}
2. {Reguła 2}

## Scenariusze błędów

| ID  | Scenariusz błędu | Reakcja systemu  | Komunikat / status        |
| --- | ---------------- | ---------------- | ------------------------- |
| E1  | {Opis sytuacji}  | {Co robi system} | `{KOD_BLEDU}` / `{treść}` |

## Obsługa zdarzeń granicznych (Boundary Events)

Opcjonalne — wypełnij jeśli task ma zdarzenia graniczne w BPMN.

| Zdarzenie | Warunek                          | Obsługa                          |
| --------- | -------------------------------- | -------------------------------- |
| Timeout   | Po {X} godzinach bez zakończenia | {Akcja — eskalacja / error flow} |

## Efekty uboczne

Opcjonalne — zmiany stanu obiektów domenowych, notyfikacje.

- Encja `{NazwaObiektu}` zmienia stan z `{stan A}` na `{stan B}`

## Acceptance Criteria

**AC-01**: Happy path
    Given {warunek wstępny}
    When  {akcja / zdarzenie}
    Then  {oczekiwany efekt}

## Powiązane dokumenty

- **Proces BPMS**: {{BPMS-NNN}}
- **Poprzedni task**: {{SPEC-WF-NNN}}
- **Następny task**: {{SPEC-WF-NNN}}
- **API SPEC**: {{API-NNN}} *(jeśli wywołuje API)*
- **JIRA**: [{STORY-ID}](https://jira.example.com/browse/{STORY-ID})

## Historia zmian

| Źródło         | Autor             | Data          | Wydanie           | Opis                              |
| -------------- | ----------------- | ------------- | ----------------- | --------------------------------- |
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

Powiązania (proces BPMS, poprzedni/następny task, API, UI) utrzymuj przez `related-doc-ids` oraz odnośniki inline `{{DOC-ID}}` — nie przez ścieżki.

---

## 6. Warianty

| Wariant            | Kiedy stosować                                                                    |
| ------------------ | --------------------------------------------------------------------------------- |
| User Task          | Krok wymagający akcji użytkownika — powiązanie z SPEC-UI obowiązkowe              |
| Service Task       | Automatyczny krok — serwis wykonuje logikę bez udziału użytkownika                |
| Script Task        | Zadanie skryptowe — opis skryptu / reguły transformacji wykonywanej w silniku     |
| Business Rule Task | Wywołanie reguł biznesowych / tabeli decyzyjnej (DMN) — np. scoring, kwalifikacja |
| Send Task          | Wysłanie komunikatu do innego uczestnika lub systemu                              |
| Receive Task       | Oczekiwanie na komunikat przychodzący — proces wstrzymany do momentu odbioru      |
| Manual Task        | Czynność wykonywana przez człowieka poza systemem — nieorkiestrowana przez silnik |
| Call Activity      | Task wywołujący subproces BPMN — powiązanie z dokumentacją subprocesu obowiązkowe |

---

## 7. Powiązany prompt generujący

> Założenie: prompt `generate-workflow-step-spec` nie został jeszcze utworzony — do zdefiniowania.
