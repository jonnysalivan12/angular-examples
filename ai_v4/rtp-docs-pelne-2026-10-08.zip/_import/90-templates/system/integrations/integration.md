---
doc-id: TPL-INT
title: "Template: Integracja"
status: active
tags:
  - standard
  - template
---

# Template: Integracja

## 1. Jakiego artefaktu to szablon?

Opis integracji z zewnętrznym systemem — cel, protokół, operacje, obsługa błędów.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- system konsumuje operacje zewnętrznego systemu (REST / SOAP / gRPC / JMS)

**Nie używaj gdy:**
- opisujesz własny endpoint API komponentu → użyj `api-endpoint`
- opisujesz zdolność biznesową (co system robi i dlaczego) → użyj `capability`
- opisujesz sekwencję kroków procesu → użyj `flow`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?

- Protokół, właściciela i endpoint zewnętrznego systemu (oraz link do API Catalog, jeśli istnieje)
- Konsumowane operacje: format żądania i odpowiedzi (tylko pola istotne dla nas)
- Warunek wywołania integracji
- Sposób obsługi błędów (404, 5xx, timeout)
- Integrację opisujemy z **perspektywy konsumenta**, nie kopiując pełnej specyfikacji dostawcy
- Jedna integracja (lub operacja) = jeden plik (inwariancja I3)

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: INT-{numer}
title: "Integracja: {Nazwa systemu} — {Operacja}"
status: draft
type: integration
component: {nazwa-komponentu}
related-doc-ids:          # opcjonalne — capability, API
  - CAP-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

Konwencja nazwy pliku: `{system-name}.md`. Jeśli jeden system ma kilka konsumowanych operacji — osobny plik per operacja: `{system}-{operation}.md`.

---

## 5. Struktura sekcji

```markdown
# Integracja: {Nazwa systemu} — {Operacja}

## Cel

Jedno-dwa zdania: po co integrujemy się z tym systemem.

## Protokół

- **Typ:** REST / SOAP / gRPC / JMS
- **Właściciel:** Area / Tribe / Squad
- **Endpoint:** ścieżka
- **API Catalog:** link (jeśli istnieje)

## Operacje konsumowane

### {Nazwa operacji}

**Żądanie:**

| Pole | Źródło | Opis |
|------|--------|------|
| ... | parametr / stała / nagłówek | ... |

**Odpowiedź:**

Opis konsumowanych pól — tylko tych, które NAS interesują. Nie kopiuj pełnej specyfikacji dostawcy.

## Warunek wywołania

Kiedy integracja jest uruchamiana.

## Obsługa błędów

| Scenariusz | Zachowanie |
|-----------|-----------|
| 404 | ... |
| 5xx / timeout | ... |

## Diagram

<!-- Diagram sekwencji Mermaid — wywołanie i warianty odpowiedzi. -->

## Historia zmian

| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty

Sekcja „Protokół” wygląda inaczej dla różnych typów (REST / SOAP / gRPC / JMS) — dostosuj pola do faktycznego protokołu. Gdy jeden system udostępnia wiele operacji, każda operacja trafia do osobnego pliku.

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Integrację można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
