---
doc-id: TPL-NFR
title: "Template: Non-Functional Requirements"
status: active
tags:
  - standard
  - templa⟦?te⟧
  ⟦?- ⟧system
related-doc-ids: [TPL-BFS, TPL-CAP, TPL-UC, TPL-TUC, TPL-API, TPL-INT]
examples-ids: [EX-NFR-001]
---

# Template: Non-Functional Requirements

## 1. Jakiego artefaktu to szablon?

NFR (Non-Functional Requirements) opisuje **wymagania jakościowe systemu**: jak szybko, jak bezpiecznie, jak niezawodnie i jak operowalnie ma działać rozwiązanie.

To dokument nadrzędny dla ograniczeń niefunkcjonalnych, do którego referują BFS, Capability, UC, TUC, API i Integracje. NFR nie duplikuje treści tych dokumentów — zbiera wymagania jakościowe w jednym miejscu i pozwala je referować po identyfikatorze.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- definiujesz bazowy zestaw wymagań jakościowych na etapie VISION
- definiujesz lub aktualizujesz wymagania jakościowe dla komponentu lub procesu
- chcesz mieć jedno źródło prawdy dla SLA/SLO, bezpieczeństwa, dostępności i monitoringu
- potrzebujesz mapowania NFR do artefaktów funkcjonalnych i technicznych

**Nie używaj gdy:**
- opisujesz przebieg scenariusza użytkownika lub systemu → użyj `use-case` / `technical-use-case`
- opisujesz kontrakt pojedynczego endpointu bez wymagań przekrojowych → użyj `api-endpoint`
- opisujesz zdolność biznesową komponentu → użyj `capability` (capability alokuje NFR do komponentu)

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?

- że bazowy zestaw NFR powstaje na etapie VISION i jest uszczegóławiany w kolejnych etapach
- jaki jest kontekst biznesowy i krytyczność procesu
- jakie są oczekiwane poziomy jakości (SLA/SLO)
- jakie wymagania regulacyjne i bezpieczeństwa obowiązują
- jakie metryki są mierzalne i kto odpowiada za ich utrzymanie

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: NFR-{numer}                 # tożsamość dokumentu; obszar opcjonalny (NFR-payments-001)
title: "NFR: {Nazwa obszaru}"
status: draft
type: non-functional-requirements
component: {nazwa-komponentu}       # pomiń, jeśli system nie ma podziału na komponenty
source-spec-ids: [BFS-{numer}]      # dokument źródłowy (np. wymagania z BFS)
related-doc-ids: [CAP-{numer}]      # powiązane capability/UC/TUC/API/integracje
owner: {Imię Nazwisko}              # opcjonalne
---
```

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

Identyfikatory pojedynczych wymagań wewnątrz dokumentu (`NFR-PERF-01`, `NFR-SEC-01`, …) są lokalnymi ID wierszy macierzy — referują je inne dokumenty, ale nie są `doc-id`.

---

## 5. Struktura sekcji

```markdown
# NFR: {Nazwa obszaru}

| Pole            | Wartość                        |
| --------------- | ------------------------------ |
| **Zakres**      | [system / component / process] |
| **Właściciel**  | [zespół / rola]                |
| **Krytyczność** | [wysoka / średnia / niska]     |

---

## Cel i kontekst

Krótki opis: po co definiujemy NFR i jakie ryzyka redukujemy.

## Macierz wymagań niefunkcjonalnych

| NFR-ID       | Atrybut jakości | Metryka               | Próg docelowy | Metoda pomiaru | Środowisko | Priorytet | Owner         |
| ------------ | --------------- | --------------------- | ------------- | -------------- | ---------- | --------- | ------------- |
| NFR-PERF-01  | Performance     | p95 latency           | <= 300 ms     | APM dashboard  | PROD       | Must      | Platform Team |
| NFR-AVAIL-01 | Availability    | Uptime miesięczny     | >= 99.9%      | Monitoring SLI | PROD       | Must      | SRE           |
| NFR-SEC-01   | Security        | Czas rotacji sekretów | <= 90 dni     | Audyt CI/CD    | ALL        | Must      | Security      |

## Katalog NFR wg kategorii

### Performance

- [NFR-PERF-01] {Opis}

### Availability i Reliability

- [NFR-AVAIL-01] {Opis}

### Security i Compliance

- [NFR-SEC-01] {Opis}

### Observability i Auditability

- [NFR-OBS-01] {Opis}

### Operability i Maintainability

- [NFR-OPS-01] {Opis}

### Continuity (RTO/RPO)

- [NFR-DR-01] {Opis}

## Traceability do artefaktów

| NFR-ID      | Capability    | UC      | TUC      | API      | Integracja |
| ----------- | ------------- | ------- | -------- | -------- | ---------- |
| NFR-PERF-01 | CAP-{numer}   | UC-{numer} | TUC-{numer} | API-{numer} | INT-{numer} |

## Weryfikacja i monitoring

| NFR-ID      | Jak weryfikujemy przed release | Jak monitorujemy po release | Alert threshold |
| ----------- | ------------------------------ | --------------------------- | --------------- |
| NFR-PERF-01 | Test wydajnościowy             | Dashboard p95               | > 300 ms        |

## Wyjątki / Waivery

| NFR-ID      | Powód wyjątku         | Akceptujący | Data wygaśnięcia |
| ----------- | --------------------- | ----------- | ---------------- |
| NFR-SEC-01 | Ograniczenie dostawcy | CISO        | YYYY-MM-DD       |

## Historia zmian

| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty

**NFR systemowy** — `scope: system`; wymagania przekrojowe dla wielu komponentów.

**NFR komponentowy** — `scope: component`; wyłącznie wymagania przypisane do jednego komponentu.

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. NFR można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
