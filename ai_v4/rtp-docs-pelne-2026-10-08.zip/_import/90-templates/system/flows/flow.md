---
doc-id: TPL-FLOW
title: "Template: Przepływ (Flow)"
status: active
tags:
  - standard
  - template
related-⟦?doc-ids:⟧ [TPL-ACT]
---

# Template: Przepływ (Flow)

## 1. Jakiego artefaktu to szablon?

Flow opisuje **przepływ biznesowy lub techniczny** — sekwencję kroków, warunki i warianty (happy path, error handling). Pokazuje, jak proces przebiega między uczestnikami, bez schodzenia do implementacji.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- opisujesz sekwencję kroków procesu biznesowego lub technicznego
- chcesz pokazać przebieg między komponentami z wariantami (happy path / błędy)

**Nie używaj gdy:**
- opisujesz pojedynczą aktywność z diagramu → użyj `activity`
- opisujesz scenariusz z perspektywy użytkownika → użyj `use-case`
- opisujesz zdolność biznesową komponentu → użyj `capability`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jakie warunki muszą być spełnione przed uruchomieniem przepływu
- Jakie kroki składają się na przebieg i którzy uczestnicy biorą w nim udział
- Które aktywności wymagają osobnej specyfikacji (`activity`) i linku z diagramu
- Happy path i error handling opisuj jako osobne pliki (ułatwia nawigację i review)
- Diagram powinien mieć max 10-15 uczestników/kroków — większe dziel na subdiagramy
- Opisuj zachowanie systemu, nie implementację (nazwy klas) — inwariancja I7

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: FLOW-{numer}
title: "Przepływ: {Nazwa} — {wariant}"
status: draft
type: flow
component: {nazwa-komponentu}
related-doc-ids:          # opcjonalne — activity, API, integracje
  - ACT-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```

Konwencja nazwy pliku: `{operacja}-{wariant}.md` (np. `get-offers-happy-path.md`, `get-offers-error-handling.md`).

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

```markdown
# Przepływ: {Nazwa} — {wariant}

## Warunki wstępne
Lista warunków, które muszą być spełnione przed uruchomieniem przepływu.

## Diagram
<!-- Opcjonalne — diagram powinien być spójny z opisem kroków (jeden wynika z drugiego); pomiń sekcję przy prostym flow, którego zobrazowanie nie wnosi dodatkowej wartości. -->
Dobór diagramu zależy od specyficznego przypadku. Do decyzji osoby tworzącej flow, czy każda aktywność wymagająca osobnej specyfikacji powinna mieć link bezpośrednio w diagramie Mermaid (np. `click E "./{activity-name}.md" "Przejdź do opisu aktywności"`).

## Opis flow
Lista kroków wykonywanych przez flow:
1. Krok 1
   - Szczegóły w ... <!-- link do specyfikacji, integracji, innego flow itd. -->
   - aktywność wymagająca osobnej specyfikacji powinna zawierać czytelny tytuł ("activity title")

## Scenariusze błędów
<!-- Opcjonalne — dla wariantu error handling -->
| Scenariusz | Zachowanie |
|-----------|-----------|
| ... | ... |

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty

**Happy path** — przebieg podstawowy bez błędów; pomiń sekcję „Scenariusze błędów".

**Error handling** — osobny plik skupiony na wariantach błędnych; wypełnij „Scenariusze błędów".

Oba warianty jako **osobne pliki** (zasada I3) — ułatwia nawigację i review.

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Flow można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
