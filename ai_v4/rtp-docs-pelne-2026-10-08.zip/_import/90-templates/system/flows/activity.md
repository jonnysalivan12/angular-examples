---
doc-id: TPL-ACT
title: "Template: Opis aktywności (Activity)"
status: active
tags:
  - standard
  - template
related-doc-ids: [TPL-FLOW]
---

# Template: Opis aktywności (Activity)

## 1. Jakiego artefaktu to szablon?

Activity opisuje **jedną aktywność** wynikającą z diagramu aktywności w przepływie (`flow`) — jej logikę biznesową, wejście/wyjście, reguły i scenariusze błędów. Jeden plik = jedna aktywność.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- uszczegóławiasz pojedynczą aktywność wskazaną w diagramie przepływu (`flow`)
- musisz opisać logikę biznesową, wejście/wyjście i reguły jednej aktywności

**Nie używaj gdy:**
- opisujesz cały przepływ (sekwencję kroków) → użyj `flow`
- opisujesz scenariusz z perspektywy użytkownika → użyj `use-case`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Którego przepływu (`flow`) ta aktywność jest częścią
- Jakie dane wejściowe i wyjściowe przekazuje
- Jakie warunki uruchomienia i reguły biznesowe jej dotyczą
- Jedna aktywność = jeden plik (inwariancja I3)
- Opisuj semantykę biznesową, nie implementację techniczną (inwariancja I7)
- Nie duplikuj OpenAPI / Swagger — opisuj to, co nie wynika z kontraktu
- Braki oznaczaj jawnie: `> Założenie: ...`

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: ACT-{numer}
title: "Aktywność: {Nazwa aktywności}"
status: draft
type: activity
component: {nazwa-komponentu}
source-spec-ids:          # opcjonalne — przepływ nadrzędny
  - FLOW-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```

Konwencja nazwy pliku: `{activity-name}.md` w `kebab-case` (np. `fetch-individual-offers.md`).

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

```markdown
# Aktywność: {Nazwa aktywności}

## Cel
Jedno zdanie: jaki efekt biznesowy realizuje ta aktywność i po co istnieje.

## Opis akcji
Opis aktywności zawierający logikę biznesową oraz istotne reguły i decyzje.

## Wejście / wyjście
- Dane wejściowe wymagane do wykonania aktywności
- Dane wyjściowe przekazywane do kolejnych kroków

## Warunki i reguły
- Warunki uruchomienia aktywności
- Reguły biznesowe i ograniczenia

## Scenariusze błędów
| Scenariusz | Zachowanie |
|-----------|-----------|
| ... | ... |

## Zależności
Przepływ, którego częścią jest aktywność, oraz powiązane artefakty.

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty

Brak wariantów — aktywność ma jednolitą strukturę. Sekcję „Scenariusze błędów" wypełnij, gdy aktywność ma nietrywialne przypadki odchyleń; w przeciwnym razie oznacz „Nie dotyczy".

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Aktywność można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
