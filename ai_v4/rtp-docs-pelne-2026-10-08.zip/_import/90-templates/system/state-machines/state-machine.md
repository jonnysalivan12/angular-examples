---
doc-id: TPL-STM
title: "Template: Maszyna stanów"
status: active
tags:
  - standard
  - template
---

# Templ⟦?ate: M⟧aszyna stanów

## 1. Jakiego artefaktu to szablon?

Maszyna stanów opisuje **cykl życia obiektu lub procesu** — dozwolone stany, przejścia między nimi i warunki ich wyzwalania. Pokazuje, jak obiekt przechodzi od stanu początkowego do stanów terminalnych (sukces, błąd, rezygnacja).

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- modelujesz cykl życia obiektu/procesu z wieloma stanami i przejściami
- chcesz jednoznacznie zdefiniować stany terminalne i warunki przejść

**Nie używaj gdy:**
- opisujesz sekwencję kroków procesu (przebieg) → użyj `flow`
- opisujesz scenariusz z perspektywy użytkownika → użyj `use-case`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?

- Jaki obiekt/proces ma cykl życia i jaki jest jego stan początkowy
- Jakie są wszystkie stany (pośrednie i końcowe) oraz które są terminalne
- Jakie zdarzenia/warunki wyzwalają każde przejście
- Które przejścia są główną ścieżką (MAIN), a które alternatywą (ALTERNATIVE) lub błędem (ERROR)
- Braki oznaczaj jawnie: `> Założenie: ...`

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: STM-{numer}
title: "Maszyna stanów: {Nazwa procesu}"
status: draft
type: state-machine
component: {nazwa-komponentu}
owner: {Imię Nazwisko}    # opcjonalne
---
```

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

````markdown
# Maszyna stanów: {Nazwa procesu}

> Założenie: Dokument opisuje maszynę stanów procesu [PROCESS_NAME]. Uzupełnij tę sekcję opisem procesu i jego celu.

Krótki opis diagramu maszyny stanów — co reprezentuje i jakie są główne przepływy.

## Warunki wstępne

- [Warunek wstępny 1 — opisz warunki konieczne do wejścia w stan początkowy]
- [Warunek wstępny 2]
- [Warunek wstępny N]

> Usuń te linie i dodaj rzeczywiste warunki wstępne dla Twojego procesu.

## Diagram maszyny stanów

> Założenie: Istnieje opcja dodania diagramu z EA. Należy stworzyć folder assets, w którym powinien zostać umiejscowiony diagram z odpowiednią nazwą, następnie może zostać umiejscowiony zamiast diagramu mermaid.

Obraz przedstawia referencyjny diagram stanu dla przepływu procesu [PROCESS_NAME].

Diagram Mermaid na podstawie tabel `Słownik statusów` oraz `Stany procesowe (ObjectFlow)`:

```mermaid
stateDiagram-v2
[*] --> S_START
state "[START_STATE_ID]. [START_STATE_NAME]" as S_START
state "[STATE_2_ID]. [STATE_2_NAME]" as S_STATE2
state "[STATE_N_ID]. [STATE_N_NAME]" as S_STATE_N
state "END: [END_STATE_1_ID]. [END_STATE_1_NAME]" as S_END1
state "END: [END_STATE_2_ID]. [END_STATE_2_NAME]" as S_END2
state "END: [END_STATE_N_ID]. [END_STATE_N_NAME]" as S_END_N
S_START --> S_STATE2
S_START --> S_END1
S_STATE2 --> S_STATE_N
S_STATE2 --> S_END2
S_STATE_N --> S_END_N
S_END1 --> [*]
S_END2 --> [*]
S_END_N --> [*]
```

> Zastąp wszystkie stany oraz przejścia realnymi wartościami z Twojego procesu. Format stanu: `S_ALIAS` (alias w mermaid), a w nazwie stanu `[ID]. [NAME]` (jak w tabelach poniżej).

## Stany — opis

### Słownik statusów

| Kod statusu | Status | Opis | Status końcowy |
|---|---|---|---|
| `[ID]` | `[STATE_NAME]` | [Opis statusu] | NIE |
| `[END_ID]` | `[END_STATE_NAME]` | [Opis statusu końcowego] | TAK |
| `[ID_N]` | `[STATE_NAME_N]` | [Opis statusu] | NIE |

> Założenie: Tabela zawiera wszystkie statusy procesu (zarówno pośrednie, jak i końcowe). Kolumna `Status końcowy` przyjmuje wartości wyłącznie `TAK` lub `NIE` i jest jedynym źródłem identyfikacji stanów terminalnych.

### Stany procesowe (ObjectFlow)

Jeden wiersz = jedno przejście między stanami.

| Stan (z) | Stan (do) | Opis przejścia | Flow |
|---|---|---|---|
| `[ID]. [STATE_NAME]` | `[NEXT_ID]. [NEXT_STATE_NAME]` | [Co wyzwala to przejście] | MAIN |
| `[ID]. [STATE_NAME]` | `[END_ID]. [END_STATE_NAME]` | [Co wyzwala to przejście] | ALTERNATIVE |
| `[ID]. [STATE_NAME]` | `[END_ID]. [END_STATE_NAME]` | [Co wyzwala to przejście] | ERROR |

> Założenie: Tabela zawiera wszystkie przejścia procesu. Kolumna `Flow` przyjmuje wartości: `MAIN` (główna ścieżka sukcesu), `ALTERNATIVE` (akceptowalne odgałęzienie, np. rezygnacja, ręczna obsługa), `ERROR` (błąd techniczny lub decyzja negatywna). Stany końcowe identyfikuj wyłącznie przez tabelę `Słownik statusów` (`Status końcowy = TAK`). Usuń przykładowe wiersze i dodaj przejścia dla swojego procesu.

## Kluczowe elementy

- **Główna ścieżka sukcesu:** [Opisz główną ścieżkę — od stanu początkowego przez stany pośrednie do stanu końcowego sukcesu] Np. `S_START` → `S_STATE2` → `S_STATE_N` → `S_END_SUCCESS`.
- **Przejścia alternatywne:** [Opisz alternatywne ścieżki — np. błędy, rezygnacje, odrzucenia]
- **Przeterminowanie / timeout:** [Jeśli proces ma mechanizm timeout, opisz, z których stanów jest możliwy i do jakich stanów prowadzi]
- **Odrzucenia / rezygnacje:** [Opisz, z których etapów klient/system może zrezygnować lub odrzucić proces]

> Uzupełnij te punkty informacjami specyficznymi dla Twojego procesu.

## Scenariusze błędów

| Scenariusz | Stan | Zachowanie |
|------------|------|------------|
| [Nazwa scenariusza błędu] | `[STATE_ID]` | [Opis — skąd można wejść, jak się kończy] |
| [Nazwa scenariusza błędu] | `[STATE_ID]` | [Opis — skąd można wejść, jak się kończy] |
| [Nazwa scenariusza błędu] | `[STATE_ID]` | [Opis — skąd można wejść, jak się kończy] |

> Założenie: Tabela zawiera tylko wyjątkowe scenariusze, które prowadzą do stanów końcowych niezaplanowanych. Usuń te linie i dodaj rzeczywiste scenariusze błędów dla Twojego procesu.

## Historia zmian

| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
````

---

## 6. Warianty

**Diagram z EA** — gdy istnieje wyeksportowany diagram stanu, umieść go w `assets/` i użyj zamiast diagramu Mermaid (zachowaj tabele stanów i przejść).

**Diagram Mermaid (domyślny)** — generowany z tabel `Słownik statusów` i `Stany procesowe (ObjectFlow)`.

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Maszynę stanów można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
