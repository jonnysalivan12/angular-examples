---
doc-id: TPL-NAV
title: "Template: Mapa nawigacyjna ekranów"
status: active
tags:
  - standard
  - template
related-doc-ids: [TPL-SCR]
---

# Template: Mapa nawigacyjna ekranów

## 1. Jakiego artefaktu to szablon?

Mapa nawigacyjna przedstawia **przejścia między ekranami w ramach jednego procesu użytkownika** — happy path i ścieżki błędowe. Spina ekrany (`screen`) w jeden obraz przepływu nawigacji.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- chcesz pokazać przejścia użytkownika między ekranami jednego procesu
- musisz zilustrować ścieżki alternatywne i błędowe nawigacji

**Nie używaj gdy:**
- opisujesz pojedynczy ekran i jego sekcje → użyj `screen`
- opisujesz przepływ danych/logiki między komponentami → użyj `flow`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jakie ekrany i jaki wariant procesu obejmuje mapa
- Jakie są główne przejścia i przejścia terminalne oraz warunki ich uruchomienia
- Używaj `flowchart TD` dla prostych przepływów ekranowych; ogranicz diagram do kluczowych ekranów i decyzji
- Każdy ekran z diagramu powinien mieć odwołanie w tabeli „Odniesienia do ekranów"
- Braki oznaczaj jawnie przez `> Założenie:` zamiast zgadywania

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: NAV-{numer}
title: "Mapa nawigacyjna ekranów: {Nazwa procesu}"
status: draft
type: navigation-map
component: {nazwa-komponentu}
related-doc-ids:                # opcjonalne — ekrany objęte mapą
  - SCR-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```

Konwencja: jeden proces = jedna mapa nawigacyjna.

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

````markdown
# Mapa nawigacyjna ekranów: {Nazwa procesu}

## Warunki wstępne
- Zakres mapy (jakie ekrany i jaki wariant procesu obejmuje).
- Założenia dotyczące kompletności opisu ekranów.

> Założenie: [wstaw jawne założenia, jeśli część ekranów lub przejść nie jest jeszcze opisana]

## Diagram nawigacji
```mermaid
flowchart TD
    START["Ekran startowy"]
    STEP2["Ekran pośredni"]
    STEP3["Ekran końcowy"]
    ERROR["Ekran błędu"]
    EXIT["Wyjście poza flow"]
    START -->|Akcja użytkownika| STEP2
    STEP2 -->|Dalej| STEP3
    STEP2 -->|Wstecz| START
    START -. błąd techniczny .-> ERROR
    STEP2 -. błąd techniczny .-> ERROR
    ERROR -->|CTA wyjścia| EXIT
```

## Kluczowe elementy nawigacji
- Opisz główne przejścia użytkownika między ekranami.
- Wskaż przejścia terminalne i warunki ich uruchomienia.
- Oznacz miejsca, gdzie dokumentacja jest niekompletna.

## Odniesienia do ekranów
| Ekran | Rola w mapie | Dokument |
|---|---|---|
| {Nazwa ekranu 1} | {Rola} | {ścieżka-do-ekranu-1} |
| {Nazwa ekranu 2} | {Rola} | {ścieżka-do-ekranu-2} |

## Scenariusze błędów
| Scenariusz | Zachowanie |
|---|---|
| {Nazwa scenariusza} | {Przejście / reakcja UI} |

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
````

---

## 6. Warianty

Brak wariantów — mapa ma jednolitą strukturę. Dla procesów wieloetapowych dziel diagram na obszary (np. onboarding, weryfikacja, finalizacja), utrzymując jeden plik mapy.

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Mapę nawigacyjną można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
