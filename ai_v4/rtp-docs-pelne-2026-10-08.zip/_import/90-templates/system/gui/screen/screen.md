---
doc-id: TPL-SCR
title: "Template: Ekran"
status: active
tags:
  - standard
  - template
related-doc-ids: [TPL-SCRSEC, TPL-NAV]
---

# Template: Ekran

## 1. Jakiego artefaktu to szablon?

Ekran opisuje **pojedynczy ekran procesu użytkownika** — jego cel, podział na sekcje, kolejność wyświetlania i nawigację do sąsiednich kroków. Spina sekcje (`screen-section`) w jeden widok i osadza go w mapie nawigacyjnej (`navigation-map`).

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- opisujesz jeden ekran (krok) w procesie użytkownika
- chcesz pokazać podział ekranu na sekcje i nawigację między krokami

**Nie używaj gdy:**
- uszczegóławiasz pojedynczą sekcję z polami → użyj `screen-section`
- opisujesz przejścia między wieloma ekranami → użyj `navigation-map`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?

- Którym krokiem procesu jest ekran (numer kroku, ekran poprzedni/następny)
- Jakie sekcje składają się na ekran i w jakiej kolejności
- Jakie warunki decydują o wyświetleniu poszczególnych sekcji
- Jak działa nawigacja (przyciski, akcje dodatkowe)
- Braki oznaczaj jawnie: `> Założenie: ...`

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: SCR-{numer}
title: "Ekran {Nazwa produktu}: Krok {X} z {Y} — {Nazwa kroku}"
status: draft
type: screen
component: {nazwa-komponentu}
step: {numer-kroku}
source-spec-ids: []        # np. [SCRSEC-001]
related-doc-ids: []        # np. [NAV-001]
owner: {Imię Nazwisko}     # opcjonalne
---
```

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

```markdown
# Ekran {Nazwa produktu}: Krok {X} z {Y} — {Nazwa kroku}

## Opis ekranu

{Krótki opis celu i kontekstu ekranu.}

**Cel ekranu:**
- {Cel 1}
- {Cel 2}
- {Cel 3}

**Link do Figmy:**

{Link do figmy}

## Mapa sekcji na ekranie

![{Nazwa ekranu} - ekran]
![{Nazwa ekranu} - podział sekcji]

Kolejność sekcji na ekranie (od góry do dołu):
1. [{Sekcja 0}]
2. [{Sekcja 1}]
3. [{Sekcja 2}]
4. [{Sekcja 3}]

## Struktura ekranu

Ekran podzielony jest na następujące sekcje:

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|-----------|--------|------|----------------------|
| **0** | **[{Sekcja 0}]** | {Opis sekcji 0} | {np. Zawsze / warunek biznesowy} |
| **1** | **[{Sekcja 1}]** | {Opis sekcji 1} | {np. Zawsze / warunek biznesowy} |
| **2** | **[{Sekcja 2}]** | {Opis sekcji 2} | {np. Zawsze / warunek biznesowy} |
| **3** | **[{Sekcja 3}]** | {Opis sekcji 3} | {np. Zawsze / warunek biznesowy} |

## Kolejne ekrany

> Założenie: Lista kolejnych ekranów do uzupełnienia po potwierdzeniu pełnego flowu.

| Numer | Nazwa | Link | Status |
|-------|-------|------|--------|
| Krok {X-1} | {Nazwa poprzedniego kroku} | {link lub -} | {status} |
| Krok {X}   | {Nazwa bieżącego kroku} (bieżący) | [{screen-name}.md] | W opracowaniu |
| Krok {X+1} | {Nazwa kolejnego kroku} | {link lub -} | {status} |

## Nawigacja

- **Przycisk poprzedni**: {Opis zachowania}
- **Przycisk "Dalej"**: {Opis zachowania}
- **Linki/akcje dodatkowe**: {Opis zachowania lub Nie dotyczy}

## Historia zmian

| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty

Brak wariantów — ekran ma jednolitą strukturę. Liczbę sekcji w tabeli „Struktura ekranu” dopasuj do rzeczywistego podziału; sekcje opisz osobno wg szablonu `screen-section`.

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Ekran można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
