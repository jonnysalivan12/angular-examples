---
doc-id: TPL-SCRSEC
title: "Template: Sekcja ekranu"
status: active
tags:
  - standard
  - template
related-d⟦?oc-ids:⟧ [TPL-SCR]
---

# Template: Sekcja ekranu

## 1. Jakiego artefaktu to szablon?

Sekcja ekranu opisuje **jeden wydzielony fragment ekranu** — jego pola, źródła danych, walidacje, reguły biznesowe i zachowania. Jest podrzędna wobec ekranu (`screen`) i pozwala opisać złożone pola bez przeciążania specyfikacji całego ekranu.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- uszczegóławiasz wydzieloną sekcję ekranu z wieloma polami i regułami
- musisz opisać atrybuty pól (źródło danych, walidacja, WCAG, analityka)

**Nie używaj gdy:**
- opisujesz cały ekran i jego strukturę sekcji → użyj `screen`
- opisujesz nawigację między ekranami → użyj `navigation-map`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Do którego ekranu (`screen`) sekcja należy
- Jakie pola/elementy zawiera sekcja i jakie mają źródła danych
- Jakie walidacje, uprawnienia i zachowania dotyczą pól
- Jakie reguły biznesowe rządzą sekcją
- Braki oznaczaj jawnie: `> Założenie: ...`

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: SCRSEC-{numer}
title: "Sekcja ekranu: {Nazwa sekcji}"
status: draft
type: screen-section
component: {nazwa-komponentu}
source-spec-ids:                # ekran nadrzędny
  - SCR-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

````markdown
# Sekcja ekranu: {Nazwa sekcji}

## Opis sekcji
{Krótki opis celu i kontekstu sekcji — co prezentuje lub umożliwia użytkownikowi. Maksymalnie 3-4 zdania.}

## Pola sekcji

### Pole: {Nazwa pola / elementu}
| Atrybut | Wartość |
|---------|---------|
| **Typ pola** | {np. Pole numeryczne / Input text / Select / Checkbox / Tekst stały / Przycisk / Link} |
| **Etykieta** | "{Etykieta widoczna dla użytkownika}" |
| **Wartość domyślna** | {np. „-", „Nie dotyczy", konkretna wartość domyślna} |
| **Wartość przykładowa** | `{przykładowa wartość}` |
| **Źródło danych** | {np. API: GET /endpoint, autouzupełnienie, dane statyczne, wybór użytkownika} |
| **Miejsce utrwalenia** | {np. payload Kroku 2, baza danych, local/session storage} |
| **Edytowalność** | Tak / Nie |
| **Wymagalność** | Tak / Nie |
| **Uprawnienia** | {np. rola użytkownika, zakres uprawnień, warunek dostępu} |
| **Walidacja** | {Opis reguł walidacji lub „-" jeśli brak} |
| **Zachowanie** | {Opis zachowania pola: autouzupełnienie, efekty, zależności od innych pól} |
| **Tooltip** | {Treść tooltip lub „brak"} |
| **WCAG** | `{atrybut aria lub element HTML, np. aria-label="..."}` |
| **Analityka zdarzeń (opcjonalnie)** | Event: `{nazwa_eventu}`, atrybuty: `{ klucz: "wartość" }` |
| **Referencja komponentu UI (opcjonalnie)** | `{nazwa-komponentu / URL / brak}` |

<!-- Powiel powyższy blok ### Pole dla każdego kolejnego elementu sekcji -->

## Reguły biznesowe
1. **{Nazwa reguły}**: {Opis reguły}
2. **{Nazwa reguły}**: {Opis reguły}

> Założenie: {Założenie wymagające potwierdzenia z zespołem / product ownerem}

## Zachowania specjalne
<!-- Opcjonalna sekcja — wypełnij jeśli sekcja ma niestandardowe stany lub interakcje -->

### {Stan lub scenariusz}
```code
{Opis zachowania w pseudokodzie lub zdaniach}
```

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
````

---

## 6. Warianty

Brak wariantów — sekcja ma jednolitą strukturę. Sekcję „Zachowania specjalne" wypełnij tylko gdy sekcja ma niestandardowe stany lub interakcje; w przeciwnym razie pomiń ją.

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Sekcję ekranu można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
