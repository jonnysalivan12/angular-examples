---
doc-id: TPL-API
title: "Template: API Endpoint"
status: active
tags:
  - standard
  - template
related-doc-i⟦?ds:⟧ ⟦?[⟧TPL-CAP, TPL-FLOW, TPL-INT, TPL-UC, TPL-TUC]
---

# Template: API Endpoint

## 1. Jakiego artefaktu to szablon?
Opis jednego endpointu API — cel, parametry, zachowanie, model odpowiedzi.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- dokumentujesz pojedynczy endpoint API: jak go wywołać i jak się zachowuje

**Nie używaj gdy:**
- opisujesz zdolność biznesową (co system robi i dlaczego) → użyj `capability`
- opisujesz integrację z zewnętrznym systemem → użyj `integration`
- opisujesz sekwencję kroków procesu → użyj `flow`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Metodę i ścieżkę endpointu oraz jego cel biznesowy
- Parametry wejściowe (źródło: query / header / path / body) i wymagalność
- Reguły walidacji pól (wymagane, długość, format, zakresy, zależności warunkowe)
- Kody błędów HTTP i komunikaty walidacji zwracane systemem
- Sposób autentykacji (JWT Bearer / publiczny / wymagana rola)
- Strukturę odpowiedzi i semantykę biznesową pól (nie tylko typy techniczne)
- Od jakich integracji i serwisów endpoint zależy
- Endpoint opisujemy ponad to, co wynika z OpenAPI/Swagger (inwariancja I7); jeden endpoint = jeden plik (inwariancja I3)

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: API-{numer}
title: "API: {METHOD} /{resource}"
status: draft
type: api
component: {nazwa-komponentu}
related-doc-ids:          # opcjonalne — capability, flow, integracje
  - CAP-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

Konwencja nazwy pliku: `{method}-{resource}.md` (np. `get-offers.md`, `post-reset-prelimit.md`). Konsekwentnie w ramach komponentu.

---

## 5. Struktura sekcji
```markdown
# API: {METHOD} /{resource}

## Cel
Jedno zdanie: co endpoint robi z perspektywy biznesowej.

## Parametry wejściowe
| Parametr | Typ | Wymagany | Źródło | Opis |
|----------|-----|----------|--------|------|
| `param` | String | Tak | query / header / path / body | Opis |

## Walidacja pól wejściowych
| Parametr | Reguła walidacji | Kod błędu | Komunikat |
|----------|-----------------|----------|---------|
| `param` | Wymagany, min. 3 znaki | 400 | "Field 'param' is required and must be at least 3 characters" |

**Uwagi:**
- Wymień **wszystkie reguły** (format, zakresy, długość, zależności warunkowe)
- Wskaż **kod HTTP** (400, 422, 409, 500 itp.) <!--OPCJONALNIE-->
- Komunikat powinien być taki, jaki zwraca system (API) <!--OPCJONALNIE-->
- Walidacja warunkowa — opisz w kolumnie lub sekcji Zachowanie
- Jeśli brak walidacji poza wymagalnością pól, wpisz: "Nie dotyczy (wymagalność opisana w sekcji Parametry wejściowe)".

## Złożone parametry wejściowe
<!-- sekcja opcjonalna-->
**Użyj gdy:**
- posiadasz pola zawierające złożenie wielu informacji
- Przykład: zaszyfrowane pole token w nagłówku, które składa się z cif, nik, caseId, caseStatus

## Autentykacja
JWT Bearer / publiczny / rola wymagana.

## Zachowanie
<!-- poniższe sub-sekcje są opcjonalne. W przypadku skomplikowanego przebiegu usługi możemy tu wstawić link do flow, integracji itp -->

### Scenariusz: {happy path}
Opis zachowania systemu.

### Scenariusz: {edge case}
Opis edge case'u.

## Model odpowiedzi
<!-- Opcjonalne — tylko gdy odpowiedź ma nietrywialną strukturę.
     Diagram Mermaid classDiagram + tabela pól z semantyką biznesową.
     NIE kopiuj OpenAPI spec 1:1. -->

## Struktura odpowiedzi błędnej
<!-- Sekcja opcjonalna; opcjonalnie tabelarycznie lub na diagramie rozpisana struktura JSON odpowiedzi przy błędnym przebiegu usługi -->

## Zależności
Lista integracji i serwisów, od których zależy endpoint.

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | <!-- krótki opis sensu zmiany dla odbiorcy, np. "Dostosowanie endpointu do wymogu SCA" --> |
```

---

## 6. Warianty
Brak wariantów strukturalnych.

**Sekcje opcjonalne:**
- Model odpowiedzi — tylko gdy odpowiedź ma nietrywialną strukturę (diagram `classDiagram` + tabela pól z semantyką biznesową).
- Złożone parametry wejściowe - tylko, gdy dane pole ma złożoną, najczęściej szyfrowaną strukturę - np token zawierający kontekst klienta, wniosku...
- Struktura odpowiedzi błędnej - tylko jeśli mamy założony format odpowiedzi przy błędnym przebiegu usługi
- Scenariusz: {happy path} - występuje w przypadku prostego przebiegu usługi. Alternatywnie można tu dać link do flow, integracji itd
- Scenariusz: {edge case} - występuje w przypadku prostego przebiegu usługi. Alternatywnie można tu dać link do flow, integracji itd

---

## 7. Powiązany prompt generujący
Brak dedykowanego prompta. Endpoint można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
