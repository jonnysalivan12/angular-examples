---
doc-id: TPL-LDM
title: "Template: LDM (Logical Data Model) — indeks"
status: active
tags:
  - standard
  - t⟦?emplate⟧
  - data-model
related-doc-ids: [TPL-DDM, TPL-ENT]
---

# Template: LDM (Logical Data Model) — indeks

## 1. Jakiego artefaktu to szablon?

LDM opisuje **model logiczny danych** dla jednego obszaru: obiekty logiczne, ich atrybuty, relacje i typy logiczne. To pomost między domeną (DDM) a interfejsami (API, integracje) — **bez schodzenia do modelu fizycznego**.

Ten szablon dotyczy **pliku indeksu** LDM: diagram ER, lista encji, słowniki, mapowanie DDM→LDM. Szczegóły każdej encji opisuje osobny plik wg szablonu encji.

LDM odpowiada na pytanie: **„Jak dane są ustrukturyzowane logicznie i jak łączą się ze sobą?"**

LDM jest **nadrzędny względem konsumentów**: API i integracje referują do encji/atrybutów LDM (przez `ENT-*`), a LDM nie wymienia miejsc swojego użycia.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- masz DDM i chcesz zamodelować strukturę logiczną pojęć
- potrzebujesz wspólnego, nadrzędnego modelu danych, do którego referują API/integracje
- chcesz pokazać relacje i typy logiczne atrybutów

**Nie używaj gdy:**
- modelujesz znaczenie i reguły domeny → użyj DDM
- opisujesz fizyczną bazę (typy kolumn, indeksy, migracje) → poza zakresem analizy
- chcesz udokumentować jak konkretne API używa danych → opisz to w SPEC API, referując do `ENT-*`

---

## 3. Co analityk musi wiedzieć zanim zacznie wypełniać?
- Który DDM jest źródłem pojęć (mapowanie DDM→LDM)
- Jakie obiekty logiczne wynikają z pojęć domenowych i jakie mają atrybuty
- Jakie relacje (i ich liczność) zachodzą między obiektami
- Jakie typy logiczne i słowniki zewnętrzne stosują atrybuty

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: LDM-{numer}
title: "LDM: {Nazwa obszaru logicznego}"
status: draft
type: ldm
component: {nazwa-komponentu}         # pomiń, jeśli system nie ma podziału na komponenty
source-spec-ids:          # DDM źródłowy
  - DDM-{numer}
source: "{źródło — np. EA CaseRepository, eksport XML}"
owner: {Imię Nazwisko}    # opcjonalne
---
```

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji

<!-- Każda sekcja zawiera komentarz dlaczego istnieje.
     Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem. -->

````markdown
# LDM: {Nazwa obszaru logicznego}

| Pole          | Wartość                                |
|---------------|----------------------------------------|
| **ID**        | LDM-{obszar}                           |
| **Źródło DDM**| [DDM-{obszar} — link względny]         |
| **Wersja**    | [np. 4.0]                              |
| **Źródło**    | [np. EA CaseRepository — eksport XML]  |

---

## Cel i zakres
<!-- dlaczego: czytelnik wie, jakie struktury logiczne model obejmuje i dla jakiego obszaru. -->

Jedno-trzy zdania: jakie struktury logiczne model opisuje i z jakiego DDM wynika.

## Źródło (DDM)
<!-- dlaczego: traceability do źródła, nie do konsumentów.
     LDM referuje DDM; API/integracje referują do LDM, nie odwrotnie. -->

- **DDM:** [DDM-{obszar} — źródło pojęć i reguł](ddm-{obszar}.md)

## Mapowanie DDM → LDM
<!-- dlaczego: wiąże znaczenie (DDM) ze strukturą (LDM).
     Tu „ląduje" mapowanie warstwy domenowej na logiczną — LDM jest pochodną DDM. -->

| Pojęcie domenowe (DDM) | Obiekt logiczny (LDM) | Uzasadnienie |
|------------------------|-----------------------|--------------|
| DOM-{Nazwa}            | ENT-{Nazwa}           | ...          |

## Diagram ER
<!-- dlaczego: jeden rzut oka na encje, atrybuty i relacje.
     Diagram pokazuje encje, atrybuty z typami logicznymi i relacje (z licznością).
     Bez kluczy PK/FK — te należą do modelu fizycznego; tożsamość encji opisz w komentarzu atrybutu. -->

```mermaid
erDiagram
    ENCJA_A {
        integer id "Identyfikator encji"
        string kolumna "Opis pola"
        datetime createdAt "Data utworzenia"
    }
    ENCJA_B {
        integer id "Identyfikator encji"
        string kolumna "Opis pola"
    }
    ENCJA_A }o--|| ENCJA_B : "należy do"
```

<!-- Notacja liczebności Mermaid erDiagram:
     ||--||  dokładnie jeden do dokładnie jednego
     ||--o|  dokładnie jeden do zera lub jednego
     ||--o{  dokładnie jeden do zera lub wielu
     ||--|{  dokładnie jeden do jednego lub wielu
     o{--||  zero lub wiele do dokładnie jednego -->

## Encje
<!-- dlaczego: lista encji z ID (ENT-*) i linkami do plików szczegółowych.
     ENT-* jest stabilnym identyfikatorem, po którym referują API i inne SPEC. -->

| ID         | Encja                          | Alias (biznesowy) | Opis              | Szczegóły                          |
|------------|--------------------------------|-------------------|-------------------|------------------------------------|
| ENT-EncjaA | [ENCJA_A](entities/encja-a.md) | Nazwa biznesowa   | Krótki opis encji | [encja-a.md](entities/encja-a.md)|

## Kluczowe relacje
<!-- dlaczego: relacje i kardynalność na poziomie modelu, niezależnie od kodu. -->

| Encja źródłowa | Liczebność | Encja docelowa | Opis relacji           |
|----------------|------------|----------------|------------------------|
| ENCJA_A        | 0..* do 1  | ENCJA_B        | Wiele A należy do jednej B |

## Słowniki zewnętrzne
<!-- dlaczego: wskazuje kody/enumy spoza modelu i ich źródło. -->

| Słownik       | Używany w     | Źródło / ścieżka            |
|---------------|---------------|-----------------------------|
| NazwaSłownika | ENCJA.kolumna | Opis i/lub link do słownika |

## Reguły walidacyjne i spójność
<!-- dlaczego: walidacje obejmujące wiele encji (cross-entity), wynikające z reguł DDM.
     Referuj reguły domenowe (RD-*) zamiast je duplikować. -->

| ID     | Reguła | Powiązanie z DDM | Kryterium |
|--------|--------|------------------|-----------|
| RW-001 | ...    | RD-001           | ...       |

## Zakres poza dokumentem
<!-- dlaczego: jawne granice chronią przed schodzeniem do warstwy fizycznej i duplikacją. -->

LDM **nie** opisuje:
- znaczenia i reguł domeny → [DDM](../../functional/data-models/ddm.md)
- kluczy fizycznych (PK/FK), tabel/kolumn/indeksów i migracji
- szczegółów ORM/frameworka
- konsumentów modelu (które API/integracje używają danych — to one referują do LDM)
````

---

## 6. Zasady wypełniania

### Typy logiczne — słownik

W modelu logicznym **nie używamy typów fizycznych** (`VARCHAR(255)`, `BIGINT`, `TIMESTAMP WITH TIME ZONE`). Stosujemy typy logiczne z poniższej tabeli:

| Typ logiczny                  | Opis                                | Typowe mapowania fizyczne          |
|-------------------------------|-------------------------------------|------------------------------------|
| `String`                      | Dane tekstowe                       | String, varchar, char, text        |
| `Integer`                     | Liczba bez części dziesiętnej       | Integer, int, long, bigint         |
| `Decimal`                     | Liczba z częścią dziesiętną         | Decimal, numeric, float, double    |
| `Date`                        | Data kalendarzowa (bez czasu)       | Date                               |
| `DateTime`                    | Data wraz z godziną                 | DateTime, LocalDateTime, Timestamp |
| `Boolean`                     | Prawda / Fałsz                      | Boolean, bit                       |
| `UUID`                        | Unikalny klucz globalny             | UUID, GUID                         |
| `Dictionary [DictionaryName]` | Wartość z zewnętrznego słownika     | Enum, FK do tabeli słownikowej     |
| `Enum`                        | Zamknięty, statyczny zbiór wartości | Enum z literałami                  |

### Czego nie umieszczać
- Kluczy fizycznych (PK/FK) i relacji wyrażonych po kluczach
- Typów i struktur fizycznych (`VARCHAR`, `BIGINT`, indeksy, partycje, DDL)
- Implementacyjnych nazw klas/metod/adnotacji ORM
- Listy konsumentów (API, integracje, ekrany) — referencje idą do LDM, nie z LDM
- Kopii kontraktów OpenAPI/AsyncAPI

### Sposób pracy
1. Weź DDM jako źródło pojęć i reguł.
2. Wypełnij mapowanie DDM→LDM (`DOM-*` → `ENT-*`).
3. Narysuj diagram ER i wypisz encje z ID `ENT-*`.
4. Dla każdej encji utwórz plik wg szablonu encji.
5. Uzupełnij relacje, słowniki i reguły walidacyjne (referuj `RD-*` z DDM).

## Historia zmian

| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Model logiczny można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
