---
doc-id: TPL-ENT
title: "Template: LDM (Logical Data Model) — encja"
status: active
tags:
  - standard
  - ⟦?template⟧
  - data-model
related-doc-ids: [TPL-LDM, TPL-DDM]
---

# Template: LDM (Logical Data Model) — encja

## 1. Jakiego artefaktu to szablon?

Ten szablon dotyczy **pliku pojedynczej encji** w modelu logicznym: pełna lista atrybutów, powiązania i reguły biznesowe. Jeden plik = jedna encja LDM.

Encja jest podrzędna wobec indeksu LDM i realizuje jedno lub więcej pojęć z DDM.

---

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**
- uszczegóławiasz encję wymienioną w indeksie LDM (`ENT-*`)
- musisz opisać atrybuty, typy logiczne i reguły zapisu/odczytu

**Nie używaj gdy:**
- opisujesz cały obszar (diagram ER, lista encji, słowniki) → użyj indeksu LDM
- opisujesz znaczenie pojęcia → użyj DDM

---

## 3. Co analityk musi wiedzieć zanim zacznie wypełniać?
- Które pojęcie domenowe (`DOM-*`) ta encja realizuje
- Jakie atrybuty ma encja i jakie typy logiczne stosują (słownik typów w [indeksie LDM](ldm.md#typy-logiczne-sownik))
- Który atrybut (lub atrybuty) stanowi tożsamość encji — identyfikuje jej instancję
- Jaka jest wymagalność atrybutów wynikająca z modelu logicznego (nie z walidacji aplikacyjnej)

---

## 4. Front matter (obowiązkowe pola)

```yaml
---
doc-id: ENT-{numer}
title: "Encja: {NazwaEncji}"
status: draft
type: ldm-entity
source-spec-ids:          # indeks LDM nadrzędny
  - LDM-{numer}
related-doc-ids:          # opcjonalne — pojęcia domenowe realizowane
  - DDM-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```

**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

Konwencja nazwy pliku: `kebab-case`, angielski, bez przedrostka `t_` i sufiksu `_table`. Przykłady: `cases.md`, `case-data.md`, `loan-application.md`.

---

## 5. Struktura sekcji

<!-- Każda sekcja zawiera komentarz dlaczego istnieje.
     Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem. -->

````markdown
# Encja: {NazwaEncji}

**ID:** ENT-{NazwaEncji}
**Alias biznesowy:** {Polska nazwa / opis biznesowy}
**Realizuje pojęcie (DDM):** [DOM-{Pojęcie}](../ddm-{obszar}.md)

## Opis
<!-- dlaczego: czytelnik wie, czego dotyczą dane i jaką rolę encja pełni w domenie.
     Wskaż momenty zapisu, jeśli są istotne (np. „pole zapisywane przy inicjalizacji"). -->

Jeden-trzy akapity: czego dotyczą dane tej encji i jaka jest jej rola.

## Atrybuty
<!-- dlaczego: kontrakt logiczny danych. Typy logiczne (nie fizyczne).
     Kolumny: Nazwa | Alias | Typ logiczny | Wymagalność | Identyfikator | Opis.
     Identyfikator: „Tak", jeśli atrybut współtworzy tożsamość encji, w przeciwnym razie „—". -->

| Nazwa         | Alias           | Typ logiczny             | Wymagalność | Identyfikator | Opis                 |
|---------------|-----------------|--------------------------|-------------|---------------|----------------------|
| `id`          | Id encji        | `Integer`                | Wymagany    | Tak           | Tożsamość encji      |
| `kolumna`     | Biznesowa nazwa | `String`                 | Opcjonalny  | —             | Opis pola            |
| `statusField` | Status          | `Dictionary [StatusDic]` | Wymagany    | —             | Wartości ze słownika |

## Typy wyliczeniowe
<!-- dlaczego: dokumentuje zamknięte zbiory wartości atrybutów typu Enum.
     Usuń sekcję, jeśli encja nie ma typów Enum. -->

### {NazwaEnum}

| Wartość | Opis |
|---------|------|
| `A`     | ...  |
| `B`     | ...  |

## Powiązania
<!-- dlaczego: relacje do innych encji z licznością (bez kluczy fizycznych). -->

| Relacja | Encja docelowa         | Liczebność (ta → cel) | Opis                   |
|---------|------------------------|-----------------------|------------------------|
| posiada | [{EncjaB}](encja-b.md) | 1 do 0..*             | Opis biznesowy relacji |

## Reguły biznesowe
<!-- dlaczego: nietrywialna logika zapisu/odczytu specyficzna dla encji.
     Reguły domenowe całego obszaru trzymaj w DDM (RD-*) i referuj, nie duplikuj. -->

- **RB-001:** Opis reguły.

## Uwagi
<!-- dlaczego: jawne odnotowanie braków/rozbieżności względem modelu źródłowego.
     Nie wymyślaj wartości — oznacz „(nie zmodelowano)". -->

> Uwaga: [opis znanych braków lub rozbieżności w modelu]
````

---

## 6. Zasady wypełniania

### Typy logiczne
Stosuj typy logiczne ze słownika w [indeksie LDM](ldm.md#typy-logiczne-sownik). Nie wpisuj typów fizycznych (`VARCHAR`, `BIGINT`).

### Identyfikator (tożsamość)
W kolumnie `Identyfikator` oznacz „Tak" atrybut(y), które jednoznacznie identyfikują instancję encji — po tym referują do niej inne SPEC. To pojęcie logiczne (tożsamość), nie fizyczny klucz główny. Nie modeluj kluczy obcych ani markerów PK/FK — powiązania między encjami wyrażaj wyłącznie w sekcji „Powiązania" przez liczność.

### Wymagalność
- **Wymagany** — atrybut musi mieć wartość, żeby instancja encji była poprawna.
- **Opcjonalny** — atrybut może pozostać pusty.

Wymagalność wynika z modelu logicznego, nie z walidacji aplikacyjnej.

### Braki w modelu źródłowym
Jeśli atrybut lub relacja nie są jawnie zmodelowane, zostaw komórkę pustą lub wpisz `(nie zmodelowano)`. Nie wymyślaj wartości.

### Czego nie umieszczać
- Kluczy fizycznych (PK/FK) i referencji po kluczach — powiązania wyrażaj licznością
- Szczegółów fizycznych: długości pól, precyzji, indeksów, partycji
- Implementacyjnych nazw klas, metod, adnotacji ORM/JPA
- Wartości domyślnych zależnych od środowiska lub konfiguracji
- Referencji do konsumentów (które API/integracje czytają/zapisują pole)

## Historia zmian

| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |

---

## 7. Powiązany prompt generujący

Brak dedykowanego prompta. Encję można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
