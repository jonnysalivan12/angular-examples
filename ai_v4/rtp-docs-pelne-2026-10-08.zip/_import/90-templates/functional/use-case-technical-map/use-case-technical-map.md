---
doc-id: TPL-UCMAP
title: "Template: Use Case + Technical Use Case Map"
status: active
tags:
  - standard
  - ⟦?t⟧emplate
related-doc-ids: [TPL-UC, TPL-TUC]
---

# Template: Use Case + Technical Use Case Map

## 1. Jakiego artefaktu to szablon?
Ten szablon opisuje **mapę relacji między Use Case i Technical Use Case** w jednym diagramie.

Artefakt odpowiada na pytanie: **jak łączą się scenariusze użytkownika i scenariusze systemowe** przez relacje `<<include>>`, `<<extend>>` i `<<exclude>>` oraz przez aktorów.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- chcesz pokazać pełny obraz procesu: co inicjuje użytkownik i co wykonuje system automatycznie
- potrzebujesz jednego diagramu pokazującego zależności UC i TUC
- chcesz jasno zdefiniować relacje `include`, `extend`, `exclude`

**Nie używaj gdy:**
- opisujesz pojedynczy scenariusz użytkownika bez relacji do innych przypadków → użyj `use-case.md`
- opisujesz wyłącznie automatyczny przebieg systemowy → użyj `technical-use-case.md`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jakie UC i TUC wchodzą w zakres procesu
- Które relacje są obowiązkowe (`include`), opcjonalne (`extend`) i wykluczające (`exclude`)
- Kto jest aktorem dla UC (osoba) i kto jest aktorem dla TUC (system/scheduler)
- Jakie artefakty szczegółowe istnieją i do których plików należy linkować

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: UCMAP-{numer}
title: "Use Case Technical Map: {Nazwa procesu}"
status: draft
type: use-case-technical-map
component: {nazwa-komponentu}
related-doc-ids:          # UC i TUC objęte mapą
  - UC-{numer}
  - TUC-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji
````markdown
# Use Case Technical Map: {Nazwa procesu}
| Pole                  | Wartość                    |
| --------------------- | -------------------------- |
| **Aktorzy biznesowi** | [np. Klient, Doradca]      |
| **Aktorzy systemowi** | [np. Scheduler, Event Bus] |
| **Wersja diagramu**   | [1.0]                      |

---

## Cel
Jedno-dwa zdania: jaki zakres procesu pokazuje mapa i dlaczego relacje między UC i TUC są istotne.

## Legenda relacji
| Relacja       | Znaczenie praktyczne                                                                       |
| ------------- | ------------------------------------------------------------------------------------------ |
| `<<include>>` | Krok obowiązkowy, zawsze wykonywany jako część bazowego przypadku                          |
| `<<extend>>`  | Krok opcjonalny/warunkowy, uruchamiany tylko przy spełnionym warunku                       |
| `<<exclude>>` | Wzajemne wykluczenie wariantów (nie jest to standard UML; używane jako notacja pomocnicza) |

## Diagram relacji UC i TUC
```mermaid
flowchart LR
    %% Aktorzy
    A1["Aktor: Użytkownik"]
    A2["Aktor: System Scheduler"]
    %% Use Case
    UC1(("UC-01\nZłożenie dyspozycji"))
    UC2(("UC-02\nWalidacja danych"))
    UC3(("UC-03\nKorekta danych"))
    %% Technical Use Case
    TUC1(("TUC-01\nJob nocny przetwarzania"))
    TUC2(("TUC-02\nRetry nieudanych rekordów"))
    TUC3(("TUC-03\nArchiwizacja wsadu"))
    %% Aktor -> przypadki użycia
    A1 --> UC1
    A2 --> TUC1
    %% Relacje między UC i TUC
    UC1 -. "<<include>>" .-> UC2
    UC3 -. "<<extend>>" .-> UC1
    UC2 -. "<<include>>" .-> TUC1
    TUC2 -. "<<include>>" .-> TUC1
    TUC3 -. "<<exclude>>" .-> TUC2
    classDef actor fill:#ECEFF1,stroke:#455A64,color:#263238;
    classDef uc fill:#E3F2FD,stroke:#1565C0,color:#0D47A1;
    classDef tuc fill:#E8F5E9,stroke:#2E7D32,color:#1B5E20;
    class A1,A2 actor;
    class UC1,UC2,UC3 uc;
    class TUC1,TUC2,TUC3 tuc;
```

## Opis relacji
| Źródło | Relacja       | Cel    | Uzasadnienie                                               |
| ------ | ------------- | ------ | ---------------------------------------------------------- |
| UC-01  | `<<include>>` | UC-02  | Walidacja danych jest obowiązkowa dla scenariusza bazowego |
| UC-03  | `<<extend>>`  | UC-01  | Korekta uruchamia się tylko warunkowo                      |
| UC-02  | `<<include>>` | TUC-01 | Po walidacji system zawsze uruchamia job przetwarzania     |
| TUC-03 | `<<exclude>>` | TUC-02 | Archiwizacja i retry nie mogą działać jednocześnie         |

## Powiązanie z artefaktami szczegółowymi
| Element                | Szablon szczegółów      | Link                                             |
| ---------------------- | ----------------------- | ------------------------------------------------ |
| UC-01, UC-02, UC-03    | `use-case.md`           | [UC-01](../use-cases/uc-01-nazwa.md)             |
| TUC-01, TUC-02, TUC-03 | `technical-use-case.md` | [TUC-01](../technical-use-cases/tuc-01-nazwa.md) |

## Otwarte pytania
> Założenie: Uzupełnij pytania, jeśli relacje `extend/include/exclude` nie są jeszcze potwierdzone przez analityka biznesowego i technicznego.

## Historia zmian
| Źródło         | Autor             | Data          | Wydanie           | Opis                              |
| -------------- | ----------------- | ------------- | ----------------- | --------------------------------- |
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
````

---

## 6. Warianty
**Wariant lekki** - gdy mapa zawiera do 5 przypadków:
- Zachowaj tylko sekcje: Cel, Diagram, Opis relacji, Powiązanie z artefaktami

**Wariant rozbudowany** - gdy mapa obejmuje wiele domen:
- Podziel diagram na obszary (np. onboarding, przetwarzanie, archiwizacja)
- Utrzymaj jeden plik mapy i linki do wielu UC/TUC

---

## 7. Powiązany prompt generujący
Brak dedykowanego prompta. Mapę można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
