---
doc-id: TPL-ACTOR
title: "Template: Actors"
status: active
tags:
  - standard
  - template
  - actors
related-doc-ids: [TPL-BFS]
---

# Template: Actors

## 1. Jakiego artefaktu to szablon?
Actors opisuje aktorów systemu (użytkowników oraz role systemowe): ich role, odpowiedzialności, uprawnienia oraz zależności między nimi. Dokument stanowi bazę aktorów współdzieloną przez use-case'y i technical-use-case'y, aby zachować spójność nazewnictwa i opisów.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- chcesz zbudować zbiór użytkowników systemu (z uwzględnieniem ich ról i nazw) na potrzeby reużywalności w procesach
- chcesz wskazać zależności między użytkownikami, w tym dziedziczenie uprawnień (hierarchię)
- chcesz opisać hierarchię ról w sposób jawny i jednoznaczny
- przygotowujesz use-case/technical-use-case i chcesz uniknąć niespójnych nazw aktorów
- potrzebujesz rozdzielić role biznesowe od ról systemowych i technicznych
- chcesz jednoznacznie powiązać role w procesie z artefaktami systemowymi (np. capability, API, integracje, flow)

**Nie używaj gdy:**
- opisujesz szczegółowy przebieg jednego scenariusza krok po kroku -> użyj `use-case`
- dokumentujesz relacje między przypadkami użycia

## Reguły modelowania aktorów
<!-- DLACZEGO: wymusza jednolity sposób opisu aktorów między zespołami i dokumentami. -->
- Jeden aktor = jedna nazwa kanoniczna i jedno ID.
- Rola opisuje odpowiedzialność biznesową, nie stanowisko organizacyjne.
- Nazwa aktora opisuje rolę w procesie (co robi), a nie etat lub nazwę stanowiska.
- Aktor systemowy to rola techniczna inicjująca lub realizująca kroki bez interwencji człowieka.
- Gdy rola ma różne poziomy uprawnień, opisz je jako jeden aktor + warianty uprawnień.
- Gdy występuje dziedziczenie uprawnień, pokaż hierarchię jawnie w tabeli aktorów i diagramie relacji.

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jaki jest system docelowy i granica opisu (jeden system, wiele procesów)
- Jaki jest wsad źródłowy do przygotowania specyfikacji (np. BFS, UC/TUC, diagram procesu, VISION, prompt, warsztat)
- Jakie role (biznesowe, systemowe) realnie uczestniczą w procesach objętych zakresem
- Jakie są granice odpowiedzialności i uprawnień aktorów
- Które przypadki użycia są inicjowane przez poszczególnych aktorów
- Czy występuje dziedziczenie uprawnień; jeśli tak, hierarchia musi być pokazana jawnie w strukturze opisu i na diagramie relacji
- Jakie nazwy są kanoniczne i jakie aliasy historyczne należy zachować w słowniku nazw

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: ACTOR-{numer}
title: "Actors: {Nazwa procesu}"
status: draft
type: actor
component: {nazwa-komponentu}
source-spec-ids:          # opcjonalne — dokument nadrzedny
  - BFS-{numer}
related-doc-ids:          # opcjonalne — dokumenty powiazane
  - TUC-{numer}
  - UC-{numer}
  - CAP-{numer}
  - API-{numer}
  - INT-{numer}
  - FLOW-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type -> folder`.
Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji
Sekcja ma pokazać dwie rzeczy:
- kanoniczną bazę aktorów dla jednego procesu (kto jest aktorem i jaka jest jego odpowiedzialność)
- mapowanie aktorów do scenariuszy (w jakich UC/TUC i w jakiej roli uczestniczą)

Powiązania ze scenariuszami są wymagane, ale przez artefakty procesowe (np. UC/TUC/BFS/FLOW), a nie przez opisywanie pełnego przebiegu procesu krok po kroku.

````markdown
# Actors: {Nazwa procesu}

## Kontekst biznesowy
1-2 zdania: dla jakiego procesu powstał dokument oraz kto korzysta z tej bazy aktorów.

## Cel
<!-- DLACZEGO: jednoznacznie definiuje po co powstał opis aktorów i jak ma być używany przez zespół. -->
Jedno-dwa zdania: jaki problem porządkuje opis aktorów i jaki jest jego zakres.

Przykład: "Dokument porządkuje nazwy i odpowiedzialności aktorów dla procesu spłaty/nadpłaty kredytu, aby wszystkie UC/TUC używały jednego, spójnego słownika ról. Zakres obejmuje aktorów biorących udział w procesie wcześniejszej spłaty kredytu gotówkowego."

## Zakres
<!-- DLACZEGO: ogranicza interpretacje i zapobiega mieszaniu aktorów z wielu, niezależnych procesów. -->

### W zakresie
- [Obszar 1]
- [Obszar 2]

Przykład:
- Obsługa manualna dyspozycjci skierowana do IBIS

## Klasyfikacja aktorów
<!-- DLACZEGO: wspólna klasyfikacja pozwala od razu odróżnić role biznesowe i systemowe. -->
| Typ aktora | Definicja lokalna | Kryterium kwalifikacji |
|------------|-------------------|------------------------|
| Biznesowy  | <Opis>            | <Kiedy uznajemy rolę za biznesową> |
| Systemowy  | <Opis>            | <Kiedy uznajemy rolę za systemową> |

## Przykład minimalny (BBC)
<!-- DLACZEGO: pokazuje na prostym przykładzie jak odróżnić role procesowe od komponentów technicznych. -->
| Typ aktora | Rola | Przykład | Powiązane artefakty |
|------------|------|----------|----------------------|
| Biznesowy  | Klient wnioskujący o kredyt | Klient zalogowany w bankowości elektronicznej, posiadający NIK | UC, BFS |
| Systemowy  | Frontend procesu | Frontend procesu BBC inicjujący wywołania (`clientId: FE-BBC`) | UC, API, FLOW |
| Systemowy  | Backend procesu | Backend procesu BBC realizujący logikę biznesową (`clientId: BE-BBC`) | TUC, CAP, API, INT |

## Aktorzy
<!-- DLACZEGO: kanoniczna lista aktorów z ID umożliwia spójne referencje z UC, map i flow. -->
| Typ aktora | Rola | Przykład | Powiązane artefakty |
|------------|------|----------|----------------------|
| Biznesowy/Systemowy | <Nazwa roli aktora> | <Opis odpowiedzialności i kontekstu użycia> | <UC-XX, TUC-YY, CAP-01, API-01> |
| Biznesowy/Systemowy | <Nazwa roli aktora> | <Opis odpowiedzialności i kontekstu użycia> | <UC-XX, TUC-YY, INT-01, FLOW-01> |

## Mapa udziału aktorów w procesach
<!-- DLACZEGO: przy wielu procesach i wielu aktorach pokazuje jednoznacznie, kto bierze udzial w danym procesie. -->
Użycie:
- Sekcja obowiązkowa, gdy dokument obejmuje więcej niż jeden proces/scenariusz.
- Sekcja opcjonalna, gdy dokument dotyczy jednego procesu i mapowanie jest oczywiste w tabeli Aktorzy.

| ID aktora | P1: UC/TUC-01 | P2: UC/TUC-02 | P3: UC/TUC-03 | P4: UC/TUC-04 |
|-----------|----------------|----------------|----------------|----------------|
| ACTOR-01  | Inicjuje       | Uczestniczy    | -              | -              |
| ACTOR-02  | -              | Uczestniczy    | Uczestniczy    | -              |
| ACTOR-03  | Uczestniczy    | -              | Uczestniczy    | Uczestniczy    |
| ACTOR-04  | -              | -              | Uczestniczy    | -              |
| ACTOR-05  | -              | -              | -              | Uczestniczy    |

Legenda:
- Inicjuje: aktor uruchamia proces/scenariusz.
- Uczestniczy: aktor bierze udział w wykonaniu procesu.
- -: aktor nie bierze udziału.

## Słownik nazw i aliasów
<!-- DLACZEGO: ogranicza chaos nazewniczy (synonimy, nazwy historyczne, skróty) i pomaga unikać duplikatów. -->
| Nazwa kanoniczna | Alias / nazwa historyczna |
|------------------|---------------------------|
| <Nazwa aktora>   | <Alias>                   |

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |

---

## 6. Warianty

### Aktorzy per proces
- obejmuje aktorów jednego procesu end-to-end
- zwykle referowany z jednego BFS i 1..N UC/TUC oraz opcjonalnie CAP/API/INT/FLOW
- stosuj tylko wtedy, gdy nie ma potrzeby utrzymania wspólnej bazy aktorów dla wielu procesów

### Aktorzy per system
- obejmuje aktorów wspólnych dla wielu procesów w jednym komponencie
- może być referowany przez wiele BFS/UC/TUC/CAP/API/INT/FLOW
- to wariant preferowany dla zachowania spójności nazewniczej i opisowej między procesami

---

## 7. Powiązany prompt generujący
Brak dedykowanego prompta. Actors można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
