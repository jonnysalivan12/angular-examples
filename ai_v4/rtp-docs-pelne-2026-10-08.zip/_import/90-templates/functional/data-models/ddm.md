---
doc-id: TPL-DDM
title: "Template: DDM (Domain Data Model)"
status: active
tags:
  - standard
  - template
  - data-model
related-doc-ids: [TPL-LDM]
---

# Template: DDM (Domain Data Model)

## 1. Jakiego artefaktu to szablon?
DDM opisuje **model domenowy danych** dla jednego obszaru: pojęcia biznesowe, ich znaczenie, reguły i relacje. To poziom analityczny, niezależny od implementacji, struktury bazy i kontraktów API.

DDM odpowiada na pytanie: **„Co te dane znaczą w domenie i jakimi regułami się rządzą?"** — nie jak są przechowywane ani przez kogo używane.

DDM jest **nadrzędny i niezależny od konsumentów**. Nie wymienia miejsc użycia (API, integracje, ekrany) — to one referują do modelu. DDM jest źródłem dla modelu logicznego (LDM), który mapuje pojęcia domenowe na obiekty logiczne.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- modelujesz język domeny: pojęcia, ich definicje, reguły i inwarianty biznesowe
- opisujesz znaczenie danych całego przypadku (case), np. Case, Loans, CurrentAccounts
- chcesz mieć jedno źródło prawdy dla pojęć, do którego referują LDM, API i inne SPEC

**Nie używaj gdy:**
- opisujesz strukturę logiczną (atrybuty, relacje) → użyj LDM
- opisujesz fizyczną bazę (tabele, kolumny, indeksy, migracje) → to nie jest dokumentowane na poziomie analizy
- opisujesz kontrakt API lub przepływ → użyj szablonów `api-endpoint.md` / `flow.md`

---

## 3. Co analityk musi wiedzieć zanim zacznie wypełniać?
- Jaki obszar domenowy modelujesz i gdzie są jego granice
- Jakie jest źródło domeny w górę: model w Enterprise Architect (CaseRepository), Jira, polityki biznesowe
- Które pojęcia wymagają jednoznacznej definicji (żeby uniknąć wieloznaczności w LDM i API)
- Jakie reguły i inwarianty rządzą danymi — czyli warunki zawsze prawdziwe w domenie, niezależne od implementacji (np. „każda sprawa ma co najmniej jednego klienta", „`sourceCaseId` jest unikalny", „kwota nie może być ujemna")

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: DDM-{numer}
title: "DDM: {Nazwa obszaru domenowego}"
status: draft
type: ddm
component: {nazwa-komponentu}        # pomiń, jeśli system nie ma podziału na komponenty
source-model: "{nazwa i wersja modelu źródłowego — np. EA CaseRepository / Case v4.0}"
owner: {Imię Nazwisko}               # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`.
Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

Konwencja nazwy pliku: jeden obszar domenowy = jeden plik DDM (np. `ddm-case.md`, `ddm-loans.md`).

---

## 5. Struktura sekcji
<!-- Każda sekcja zawiera komentarz dlaczego istnieje.
     Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem. -->
````markdown
# DDM: {Nazwa obszaru domenowego}
| Pole              | Wartość                                      |
|-------------------|----------------------------------------------|
| **Obszar**        | [np. Case / Loans / CurrentAccounts]         |
| **Źródło domeny** | [model EA / CaseRepository — nazwa i wersja] |

---

## Cel i zakres
<!-- dlaczego: punkt wejścia — czytelnik wie co model opisuje i gdzie są granice domeny.
     Bez tego nie wiadomo, które pojęcia należą do tego obszaru, a które nie. -->

Jedno-trzy zdania: jaki obszar domenowy model opisuje i jakie granice obejmuje.

## Źródła wymagań (w górę)
<!-- dlaczego: utrzymuje traceability do źródła, nie do konsumentów.
     Model referuje swoje źródła; konsumenci (API, integracje) referują do modelu, nie odwrotnie. -->
- **CaseRepository / EA:** [nazwa modelu źródłowego, wersja, link/ścieżka]
- **Jira:** [epiki/story/bugi wpływające na model]
- **Polityki / regulacje:** [jeśli dotyczy]

## Słownik pojęć domenowych
<!-- dlaczego: jednoznaczne znaczenie pojęć — fundament dla LDM i API.
     Każde pojęcie dostaje stabilne ID (DOM-*), po którym referują inne SPEC. -->

| ID         | Pojęcie | Definicja biznesowa | Synonimy | Właściciel pojęcia |
|------------|---------|---------------------|----------|--------------------|
| DOM-{Nazwa}| ...     | ...                 | ...      | ...                |

## Encje i Value Objects
<!-- dlaczego: rozróżnia byty z tożsamością (encje) od bytów bez tożsamości (VO).
     To decyduje o agregatach i o tym, jak LDM zamodeluje obiekty. -->

| ID          | Element | Typ (Encja / VO) | Tożsamość | Odpowiedzialność |
|-------------|---------|------------------|-----------|------------------|
| DOM-{Nazwa} | ...     | ...              | ...       | ...              |

## Relacje i agregaty
<!-- dlaczego: pokazuje granice spójności (agregaty) i powiązania między pojęciami.
     Opisuj zachowanie/znaczenie -->

Opis relacji i granic agregatów. Opcjonalnie diagram pojęć:
```mermaid
classDiagram
    class Case {
        +tożsamość
    }
    class CaseData
    Case "1" --> "0..1" CaseData : posiada
```

## Reguły i inwarianty domenowe
<!-- dlaczego: reguły, które są zawsze prawdą w domenie, niezależnie od implementacji.
     Stabilne ID (RD-*) pozwala referować je z LDM, API i testów. -->

| ID     | Reguła / inwariant | Kryterium walidacji |
|--------|--------------------|---------------------|
| RD-001 | ...                | ...                 |

## Zakres poza dokumentem
<!-- dlaczego: jawne granice chronią przed rozjazdem warstw i duplikacją. -->
DDM **nie** opisuje:
- struktury logicznej (atrybuty, typy) — to opisuje model logiczny (LDM) tego obszaru
- konsumentów modelu (które API/integracje używają danych — to one referują do modelu)

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
````

---

## 6. Zasady wypełniania

### Czego nie umieszczać
- Atrybutów, kluczy, typów logicznych — to warstwa LDM
- Typów i struktur fizycznych (`VARCHAR`, indeksy, migracje)
- Listy konsumentów (API, integracje, ekrany) — model jest nadrzędny, referencje idą do niego
- Kodu 1:1 i kontraktów OpenAPI/AsyncAPI

### Sposób pracy
1. Zacznij od źródła w górę: model EA (CaseRepository), Jira, rozmowy domenowe.
2. Zdefiniuj pojęcia i nadaj im ID `DOM-*`.
3. Rozróżnij encje i VO, ustal agregaty.
4. Spisz reguły i inwarianty `RD-*`.
5. Pojęcia i reguły z DDM są źródłem dla modelu logicznego (LDM) — to LDM mapuje je na obiekty logiczne.

---

## 7. Powiązany prompt generujący
Brak dedykowanego prompta. DDM można wygenerować promptami ogólnymi `generate-spec-from-code`, `generate-spec-from-jira` lub `generate-spec-from-description`.
