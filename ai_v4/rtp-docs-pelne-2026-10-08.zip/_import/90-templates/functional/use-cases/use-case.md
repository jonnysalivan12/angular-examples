---
doc-id: TPL-UC
title: "Template: Use Case"
status: active
tags:
  - standard
  - template
related-doc-ids: ⟦?[⟧TPL-BFS, TPL-CAP, TPL-NFR, TPL-FLOW, TPL-INT]
---

# Template: Use Case

## 1. Jakiego artefaktu to szablon?
Use Case opisuje **scenariusz działania użytkownika** — co chce osiągnąć, jak to robi krok po kroku i co może pójść nie tak. To artefakt uszczegóławiający wymagania z dokumentu BFS/SPEC dla konkretnej interakcji użytkownika.

Use Case odpowiada na pytanie: **„Co użytkownik robi i czego oczekuje?"** — nie jak system to realizuje.

Use Case jest **podrzędny wobec BFS (Business Functional Spec)**: powinien wskazywać, które wymagania `REQ-*` i reguły `RB-*` z BFS realizuje.

Use Case referuje do Capabilities i GUI w kontekście użytkownika, który działa na ekranie.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- opisujesz działanie z perspektywy użytkownika (klienta, doradcy, pracownika)
- uszczegóławiasz wymagania `REQ-*` i reguły `RB-*` opisane wcześniej w BFS/SPEC
- chcesz opisać scenariusz z krokami, warunkami i sytuacjami wyjątkowymi

**Nie używaj gdy:**
- opisujesz scenariusz uruchamiany automatycznie przez system (bez udziału użytkownika) → użyj szablonu `technical-use-case`
- opisujesz zdolność biznesową systemu (co system robi i dlaczego), nie scenariusz użytkownika → użyj szablonu `capability`
- dokumentujesz integrację z zewnętrznym systemem → użyj szablonu `integration`
- opisujesz sam przepływ danych między komponentami → użyj szablonu `flow`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Kim jest główny aktor i jakie ma cele
- Przez jakie kanały korzysta z funkcji (aplikacja, oddział, infolinia)
- Jakie warunki muszą być spełnione, żeby akcja była możliwa
- Co jest punktem końcowym — jak wygląda sukces z perspektywy użytkownika
- Który BFS/SPEC jest dokumentem nadrzędnym i jakie `REQ-*`/`RB-*` dotyczą tego scenariusza

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: UC-{numer}
title: "Use Case: {Nazwa scenariusza}"
status: draft
type: use-case
component: {nazwa-komponentu}
source-spec-ids:          # BFS nadrzędny
  - BFS-{numer}
related-doc-ids:          # opcjonalne — capability, GUI
  - CAP-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`. Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji
<!-- Każda sekcja poniżej zawiera komentarz DLACZEGO istnieje.
     Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem. -->
````markdown
# Use Case: {Nazwa scenariusza}
<!-- Tabela nagłówkowa — szybki przegląd bez czytania całego dokumentu.
     Autor, priorytet i status są w front matter — nie duplikuj ich tutaj. -->
| Pole             | Wartość                                         |
|------------------|-------------------------------------------------|
| **Aktor główny** | [np. Klient / Doradca / Pracownik oddziału]     |
| **Kanały**       | [np. Aplikacja mobilna / Oddział / Infolinia]   |
| **BFS / SPEC**   | [SPEC-XXX — link względny do dokumentu nadrzędnego] |
| **Powiązane REQ**| [REQ-01, REQ-04]                                |
| **Powiązane RB** | [RB-01, RB-03]                                  |
| **Makiety**      | [link do GUI SPEC/UI SPEC - [screen.md], [screen-section.md]]        |

---

## Powiązanie z BFS (wymagania nadrzędne)
<!-- DLACZEGO: utrzymuje traceability między BFS i UC.
     Każdy UC musi mapować się do konkretnych REQ i RB zamiast duplikować wymagania. -->

| Typ | ID z BFS | Jak UC to realizuje |
|-----|----------|---------------------|
| REQ | REQ-01   | [krótko: które kroki pokrywają wymaganie] |
| REQ | REQ-04   | [krótko: gdzie w przebiegu jest wymaganie] |
| RB  | RB-03    | [krótko: jak reguła wpływa na przebieg] |

## Cel
<!-- DLACZEGO: punkt wejścia dla każdego czytelnika — biznes, tech, tester.
     Bez tego nikt nie wie po co istnieje ten dokument. -->

Jedno-dwa zdania: co użytkownik chce osiągnąć i jaką korzyść przynosi ta funkcja.

## Aktorzy
<!-- DLACZEGO: określa kto jest właścicielem scenariusza i kto uczestniczy.
     Pomaga przypisać odpowiedzialności i prawa dostępu. -->

Kto bierze udział w tym scenariuszu — opisz rolą, nie stanowiskiem technicznym. (np. Klient indywidualny, Doradca bankowy, Pracownik back-office)

## Kiedy można to zrobić
<!-- DLACZEGO: definiuje warunki brzegowe — co musi być prawdą PRZED akcją.
     To jest podstawa do testów regresji i reguł walidacji. -->
- [ ] [np. Użytkownik jest zalogowany]
- [ ] [np. Użytkownik posiada aktywny produkt X]
- [ ] [np. Nie minął termin ważności operacji]

## Kroki — co się dzieje po kolei
<!-- DLACZEGO: serce Use Case — opisuje przebieg z perspektywy użytkownika.
     Każdy krok to jedna obserwowalna akcja lub reakcja systemu. -->

Każdy krok: kto wykonuje akcję i co widzi / dostaje w odpowiedzi.
1. Użytkownik [wykonuje akcję] — widzi [efekt]
2. Użytkownik [podejmuje decyzję]
3. System potwierdza [co użytkownik widzi na końcu]

## Co może pójść inaczej
<!-- DLACZEGO: scenariusze alternatywne — użytkownik zmienia zdanie lub robi coś innego.
     Bez nich dokument opisuje tylko „szczęśliwą ścieżkę" i jest niekompletny. -->

### A1: Użytkownik rezygnuje
1. Użytkownik wybiera „Anuluj" / zamyka ekran
2. Nic nie zostaje zapisane — użytkownik wraca do poprzedniego miejsca

### A2: [Inna decyzja użytkownika]
1. [Trigger — co robi użytkownik inaczej]
2. [Co się dzieje w efekcie]
3. Wraca do kroku [X] lub kończy operację

## Co może pójść nie tak
<!-- DLACZEGO: sytuacje błędne z perspektywy użytkownika — co widzi i co może zrobić.
     Bez tej sekcji testerzy nie wiedzą jakie komunikaty i zachowania weryfikować. -->

### E1: [Nazwa sytuacji — np. „Brak dostępu do funkcji"]
1. Użytkownik próbuje wykonać operację
2. Widzi komunikat: _„[treść komunikatu dla użytkownika]"_
3. Może [spróbować ponownie / skontaktować się z doradcą / wrócić do poprzedniego ekranu]

### E2: [Kolejna sytuacja błędna]
> _(dodaj E3, E4... według potrzeb)_

## Reguły biznesowe
<!-- DLACZEGO: zasady i ograniczenia, które nie wynikają z kroków, ale wpływają na ich realizację.
     To najcenniejsza wiedza analityka — tu jest logika biznesowa. -->

| ID RB | Zasada                                                        | Źródło w BFS |
|-------|---------------------------------------------------------------|--------------|
| RB-01 | [np. Użytkownik może wykonać max X operacji dziennie]         | [RB-01]      |
| RB-02 | [np. Kwota transakcji nie może przekroczyć X PLN]             | [RB-02]      |
| RB-03 | [np. Funkcja niedostępna poza godzinami X-Y]                  | [RB-03]      |

## Ograniczenia NFR (referencje)
<!-- DLACZEGO: ograniczenia jakościowe mające wpływ na ten scenariusz referujemy po ID.
     Szczegóły metryk i progów utrzymywane są w dokumencie NFR (related-doc-ids). -->

| NFR-ID      | Ograniczenie w UC                                   |
|-------------|-----------------------------------------------------|
| NFR-PERF-01 | [np. potwierdzenie operacji w czasie <= X]          |
| NFR-SEC-01  | [np. krok wymaga uwierzytelnienia dwuskładnikowego] |

## Kryteria akceptacji
<!-- DLACZEGO: sprawdzalne warunki gotowości — pomost między wymaganiami a testami.
     Format „Kiedy / wtedy" jest bezpośrednio używany przez QA. -->
- [ ] Kiedy użytkownik pomyślnie zakończy kroki 1-N, widzi potwierdzenie operacji (`REQ-01`)
- [ ] Kiedy użytkownik anuluje (A1), żadne dane nie zostają zmienione (`REQ-04`)
- [ ] Kiedy wystąpi sytuacja E1, użytkownik widzi zrozumiały komunikat z instrukcją co zrobić (`RB-03`)

## Diagram
<!-- DLACZEGO: opcjonalny, ale pomaga przy złożonych przepływach z wieloma rozgałęzieniami.
     Nie zastępuje tekstu — uzupełnia go. Max 15 kroków na diagramie. -->

> Opcjonalny — dodaj gdy przebieg ma więcej niż jedno rozgałęzienie decyzyjne.
```mermaid
flowchart TD
    START(["Użytkownik\nrozpoczyna"]) --> K1
    K1["1. Użytkownik: [akcja]"] --> D1
    D1{"2. Decyzja użytkownika"}
    D1 -->|"Anuluje [A1]"| A1["Operacja anulowana\nPowrót do poprzedniego ekranu"]
    A1 --> END_CANCEL(["Anulowano"])
    D1 -->|"Kontynuuje"| K3
    K3["3. Użytkownik: [kolejna akcja]"] --> W1
    W1{"Czy dane są poprawne?"}
    W1 -->|"Nie [E1]"| E1["Komunikat błędu\nUżytkownik poprawia dane"]
    E1 --> K3
    W1 -->|"Tak"| KN["N. Potwierdzenie operacji\ndla użytkownika"]
    KN --> END_OK(["Sukces"])
    style START fill:#1565C0,color:#fff
    style END_OK fill:#2E7D32,color:#fff
    style END_CANCEL fill:#E65100,color:#fff
```

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
````

---

## 6. Warianty
**Use Case uproszczony** — gdy scenariusz ma tylko jeden przepływ bez rozgałęzień:
- Pomiń sekcję „Diagram"
- Sekcje „Co może pójść inaczej" i „Co może pójść nie tak" wypełnij jako „Nie dotyczy" z uzasadnieniem

**Use Case po BFS (zalecany)** — gdy BFS już istnieje:
- Obowiązkowo wypełnij sekcję „Powiązanie z BFS (wymagania nadrzędne)"
- Wpisz referencje do `REQ-*` i `RB-*` z dokumentu nadrzędnego
- Nie duplikuj pełnych treści wymagań z BFS, tylko mapuj i uszczegóławiaj przebieg

**Use Case złożony** — gdy wiele aktorów lub wielu kanałów:
- Rozbij na osobne pliki (jeden UC na aktor/kanał) — zasada I3
- Połącz powiązane artefakty przez `related-doc-ids` w front matter (link generuje hook)

---

## 7. Powiązany prompt generujący
Agent `@requirements-collector` przeprowadza przez zbieranie wymagań krok po kroku i generuje plik wg tej struktury.

> Uruchom: wpisz `@requirements-collector` w Copilot Chat.
