---
doc-id: TPL-TUC
title: "Template: Technical Use Case"
status: active
tags:
  - standard
  - template
related-doc-ids: [TPL-UC, TPL-CAP, TPL-NFR, TPL-FLOW, TPL-INT]
---

# Template: Technical Use Case

## 1. Jakiego artefaktu to szablon?
Technical Use Case opisuje **scenariusz działania systemu bez udziału użytkownika jako osoby** — jak uruchamia się funkcjonalność, co dzieje się krok po kroku i co może pójść nie tak.

Technical Use Case odpowiada na pytanie: **"Co system wykonuje automatycznie i jakiego efektu oczekujemy?"**

Technical Use Case jest **podrzędny wobec BFS (Business Functional Spec)**: powinien wskazywać, które wymagania `REQ-*` i reguły `RB-*` z BFS realizuje.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- opisujesz funkcjonalność uruchamianą automatycznie przez system (np. cron, scheduler, job nocny, retry)
- uszczegóławiasz wymagania `REQ-*` i reguły `RB-*` opisane wcześniej w BFS/SPEC
- chcesz opisać warunki uruchomienia, przebieg i sytuacje wyjątkowe procesu systemowego

**Nie używaj gdy:**
- opisujesz działanie z perspektywy użytkownika końcowego → użyj szablonu `use-case`
- opisujesz zdolność biznesową systemu (co system robi i dlaczego) → użyj szablonu `capability`
- dokumentujesz integrację z zewnętrznym systemem → użyj szablonu `integration`
- opisujesz sam przepływ danych między komponentami → użyj szablonu `flow`

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jaki komponent/system uruchamia scenariusz
- Jaki jest trigger uruchomienia (czasowy, zdarzeniowy, harmonogram)
- Jakie warunki muszą być spełnione, żeby proces wystartował
- Co jest punktem końcowym i jak wygląda sukces
- Który BFS/SPEC jest dokumentem nadrzędnym i jakie `REQ-*`/`RB-*` dotyczą tego scenariusza

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: TUC-{numer}
title: "Technical Use Case: {Nazwa scenariusza technicznego}"
status: draft
type: technical-use-case
component: {nazwa-komponentu}
source-spec-ids:          # BFS nadrzędny
  - BFS-{numer}
related-doc-ids:          # opcjonalne — capability, NFR
  - CAP-{numer}
owner: {Imię Nazwisko}    # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`.
Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji
<!-- Każda sekcja poniżej zawiera komentarz DLACZEGO istnieje.
     Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem. -->
````markdown
# Technical Use Case: {Nazwa scenariusza technicznego}
<!-- Tabela nagłówkowa — szybki przegląd bez czytania całego dokumentu.
     Autor, priorytet i status są w front matter — nie duplikuj ich tutaj. -->
| Pole              | Wartość                                              |
| ----------------- | ---------------------------------------------------- |
| **Aktor**         | [System]                                             |
| **Trigger**       | [np. cron 02:00 / event / harmonogram]               |
| **BFS / SPEC**    | [SPEC-XXX - link względny do dokumentu nadrzędnego] |
| **Powiązane REQ** | [REQ-01, REQ-04]                                     |
| **Powiązane RB**  | [RB-01, RB-03]                                       |

---

## Powiązanie z BFS (wymagania nadrzędne)
<!-- DLACZEGO: utrzymuje traceability między BFS i TUC.
     Każdy TUC musi mapować się do konkretnych REQ i RB zamiast duplikować wymagania. -->

| Typ | ID z BFS | Jak TUC to realizuje                       |
| --- | -------- | ------------------------------------------ |
| REQ | REQ-01   | [krótko: które kroki pokrywają wymaganie]  |
| REQ | REQ-04   | [krótko: gdzie w przebiegu jest wymaganie] |
| RB  | RB-03    | [krótko: jak reguła wpływa na przebieg]    |

## Cel
<!-- DLACZEGO: punkt wejścia dla każdego czytelnika — biznes, tech, tester.
     Bez tego nikt nie wie po co istnieje ten dokument. -->

Jedno-dwa zdania: co system ma wykonać automatycznie i jaki efekt biznesowy/techniczny ma zostać osiągnięty.

## Aktor
<!-- DLACZEGO: jasno definiuje, że wykonawcą scenariusza jest system.
     Eliminuje mieszanie z procesami wykonywanymi przez użytkownika jako osobę. -->

Jedynym aktorem jest system/komponent uruchamiający proces.

## Kiedy można to zrobić
<!-- DLACZEGO: definiuje warunki brzegowe — co musi być prawdą PRZED uruchomieniem procesu.
     To jest podstawa do testów i walidacji automatyzacji. -->
- [ ] [np. Aktywny harmonogram i okno czasowe]
- [ ] [np. Dostępne dane wejściowe]
- [ ] [np. Wymagane zależności systemowe są dostępne]

## Kroki — co dzieje się po kolei
<!-- DLACZEGO: serce Technical Use Case — opisuje przebieg automatycznej funkcjonalności.
     Każdy krok to jedna obserwowalna akcja wykonywana przez system. -->

Każdy krok: jaką akcję wykonuje system i jaki jest oczekiwany efekt.
1. System uruchamia [zadanie/proces]
2. System weryfikuje [warunek/dane]
3. System kończy [czynność] i zapisuje rezultat

## Co może pójść inaczej
<!-- DLACZEGO: scenariusze alternatywne — przebieg odbiega od planu, ale pozostaje kontrolowany.
     Bez nich dokument opisuje tylko „szczęśliwą ścieżkę" i jest niekompletny. -->

### A1: Przerwanie działań
1. Trigger nie występuje lub zostaje odroczony
2. System nie uruchamia procesu
3. Kolejna próba następuje w następnym cyklu

### A2: [Inny wariant przebiegu]
1. [Trigger — co zmienia przebieg]
2. [Co się dzieje w efekcie]
3. Powrót do kroku [X] lub zamknięcie procesu

## Co może pójść nie tak
<!-- DLACZEGO: sytuacje błędne z perspektywy operacyjnej — co się dzieje i jaka jest reakcja.
     Bez tej sekcji zespół nie wie, jak postępować przy odchyleniach. -->

### E1: [Nazwa sytuacji — np. „Brak wymaganych zasobów"]
1. System próbuje wykonać krok
2. Warunek nie jest spełniony
3. System uruchamia politykę błędu (retry/eskalacja/stop)

### E2: [Kolejna sytuacja błędna]
> _(dodaj E3, E4... według potrzeb)_

## Reguły biznesowe
<!-- DLACZEGO: zasady i ograniczenia, które nie wynikają bezpośrednio z kroków,
     ale wpływają na ich realizację. -->

| ID TUC | Zasada                                      | Źródło w BFS |
| ------ | ------------------------------------------- | ------------ |
| RB-01  | [np. Proces musi uruchomić się w oknie X-Y] | [RB-01]      |
| RB-02  | [np. Maksymalna liczba retry wynosi X]      | [RB-02]      |
| RB-03  | [np. Maksymalny czas realizacji wynosi X]   | [RB-03]      |

## Ograniczenia NFR (referencje)
<!-- DLACZEGO: ograniczenia jakościowe mające wpływ na ten scenariusz referujemy po ID.
     Szczegóły metryk i progów utrzymywane są w dokumencie NFR (related-doc-ids). -->

| NFR-ID      | Ograniczenie w TUC                              |
| ----------- | ----------------------------------------------- |
| NFR-PERF-01 | [np. czas przetworzenia batcha <= X]            |
| NFR-AVAIL-01 | [np. proces odporny na restart węzła]          |

## Kryteria akceptacji
<!-- DLACZEGO: sprawdzalne warunki gotowości — pomost między wymaganiami a testami/checklistą.
     Format „Kiedy / wtedy" ułatwia walidację scenariusza. -->
- [ ] Kiedy wszystkie kroki 1-N zostaną wykonane, wtedy rezultat scenariusza jest osiągnięty (`REQ-01`)
- [ ] Kiedy uruchomi się wariant A1, wtedy proces zostaje zakończony bez skutków ubocznych (`REQ-04`)
- [ ] Kiedy wystąpi sytuacja E1, wtedy system uruchamia właściwą procedurę reakcji (`RB-03`)

## Diagram
<!-- DLACZEGO: opcjonalny, ale pomaga przy złożonych przebiegach z rozgałęzieniami.
     Nie zastępuje tekstu — uzupełnia go. Max 15 kroków na diagramie. -->

> Opcjonalny - dodaj gdy przebieg ma więcej niż jedno rozgałęzienie decyzyjne.
```mermaid
flowchart TD
    START(["Start scenariusza"]) --> K1
    K1["1. System: uruchamia proces"] --> D1
    D1{"2. Czy warunek jest spełniony?"}
    D1 -->|"Nie [E1]"| E1["Procedura obejścia / eskalacja"]
    E1 --> END_ERR(["Zatrzymano"])
    D1 -->|"Tak"| K3
    K3["3. System: wykonuje kolejne kroki"] --> KN
    KN["N. System: zapisuje rezultat"] --> END_OK(["Zakończono"])
    style START fill:#1565C0,color:#fff
    style END_OK fill:#2E7D32,color:#fff
    style END_ERR fill:#E65100,color:#fff
```

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
````

---

## 6. Warianty
**Technical Use Case uproszczony** — gdy scenariusz ma jeden przepływ bez rozgałęzień:
- Pomiń sekcję „Diagram"
- Sekcje „Co może pójść inaczej" i „Co może pójść nie tak" wypełnij jako „Nie dotyczy" z uzasadnieniem

**Technical Use Case po BFS (zalecany)** — gdy BFS już istnieje:
- Obowiązkowo wypełnij sekcję „Powiązanie z BFS (wymagania nadrzędne)"
- Wpisz referencje do `REQ-*` i `RB-*` z dokumentu nadrzędnego
- Nie duplikuj pełnych treści wymagań z BFS, tylko mapuj i uszczegóławiaj przebieg

**Technical Use Case złożony** — gdy wiele triggerów lub wiele wariantów systemowych:
- Rozbij na osobne pliki (jeden TUC na wariant) — zasada I3
- Połącz powiązane pliki przez `related-doc-ids` w front matter (link generuje hook)

---

## 7. Powiązany prompt generujący
Agent `@requirements-collector` może pomóc zebrać wymagania i wygenerować pierwszy szkic pliku wg tej struktury.
