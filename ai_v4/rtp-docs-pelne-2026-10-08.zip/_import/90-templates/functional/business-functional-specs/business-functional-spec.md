---
doc-id: TPL-BFS
title: "Template: Business Functional Spec"
status: active
tags:
  - standard
  - template
⟦BRAK: koniec 1. linii ekranowej po „- template” (miejsce na maks. ok. 10 znaków) zasłonięty licznikiem ✓139 w IMG_3341; może być pusty albo zawierać kolejny tag⟧
related-doc-ids: [TPL-UC, TPL-NFR, TPL-ADR]
---

# Template: Business Functional Spec

## 1. Jakiego artefaktu to szablon?
Specyfikacja Funkcjonalna Biznesowa (BFS) opisuje **wymagania funkcjonalne i reguły biznesowe dla jednego procesu biznesowego** — co proces musi robić, jakich zasad przestrzegać i w jakim kontekście biznesowym działa.

BFS odpowiada na pytanie: **„Co proces musi robić i dlaczego?"** — jest dokumentem nadrzędnym wobec Use Case'ów, które uszczegółowiają poszczególne wymagania.

---

## 2. Kiedy analityk powinien go użyć?
**Użyj gdy:**
- startujesz projekt i potrzebujesz skatalogować jego wymagania
- chcesz zebrać reguły biznesowe w jednym miejscu przed rozbiciem na UC
- grupujesz wymagania biznesowe, reguły biznesowe, wymagania prawne, UX (WCAG) i compliance oraz odwołania do kontekstu dziedzinowego i wspólnego słownika pojęć używanych w procesie

**Nie używaj gdy:**
- opisujesz szczegółowy scenariusz z perspektywy użytkownika → użyj `use-case`
  (UC uszczegóławiają wymagania REQ z tego dokumentu)
- dokumentujesz decyzję architektoniczną → użyj `adr`
  (ADR zapisuje decyzje wynikające z wymagań w BFS)

---

## 3. Co analityk MUSI wiedzieć zanim zacznie wypełniać?
- Jaki jest cel biznesowy procesu i kontekst jego powstania/ rozwoju
- Co jest **w zakresie** projektu, a co jawnie **poza zakresem**
- Kto jest właścicielem biznesowym (interesariusz, Product Owner)
- Jakie pojęcia domenowe wymagają definicji (żeby uniknąć wieloznaczności)

---

## 4. Front matter (obowiązkowe pola)
```yaml
---
doc-id: BFS-{numer}
title: "Specyfikacja funkcjonalna: {Nazwa procesu}"
status: draft
type: business-functional-spec
component: {nazwa-komponentu}
owner: {Imię Nazwisko}    # opcjonalne
---
```
**Lokalizacja docelowa:** folder docelowy specu wynika z pola `type`, zgodnie z mapą taksonomii `type → folder`.
Patrz zasada „Metadane i linkowanie” (`00-principles/metadata-and-linking.md`).

---

## 5. Struktura sekcji
<!-- Każda sekcja poniżej zawiera komentarz DLACZEGO istnieje.
     Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem. -->
```markdown
# Specyfikacja funkcjonalna: {Nazwa procesu}
<!-- Tabela nagłówkowa — szybki podgląd kluczowych metadanych bez czytania całości. -->
| Pole                  | Wartość                                        |
|-----------------------|------------------------------------------------|
| **Proces**            | [nazwa procesu]                                |
| **Właściciel bizn.**  | [Product Owner / interesariusz]                |

---

## Kontekst biznesowy
<!-- DLACZEGO:  bez tego czytelnik nie wie skąd pochodzi wymaganie i czy jest aktualne.
     Opisz problem biznesowy, który ten komponent rozwiązuje — nie opis techniczny. -->

Jedno-trzy zdania: jaki problem biznesowy ten komponent rozwiązuje i w jakim kontekście działa.

## Cel
<!-- DLACZEGO: jasno określa mierzalny efekt dostarczenia procesu.
     Pozwala weryfikować czy wymagania są spójne z celem. -->

Co ma być możliwe PO wdrożeniu tego procesu, czego nie było możliwe wcześniej.

## Zakres
<!-- DLACZEGO: zapobiega scope creep i unika niejasności co jest a co nie jest w dokumencie.
     Kolumna „Poza zakresem" jest równie ważna jak „W zakresie". -->

### W zakresie
- [Funkcjonalność / obszar 1]
- [Funkcjonalność / obszar 2]

### Poza zakresem
- [Co NIE należy do tego procesu — z krótkim uzasadnieniem]

## Wymagania funkcjonalne
<!-- DLACZEGO: kanoniczna lista tego co system MUSI robić — podstawa do testów i odbioru.
     Każde wymaganie ma identyfikator, żeby można je linkować z UC, AC, ticketami. -->

| ID     | Wymaganie                                              | Priorytet     | Powiązany UC / Jira     |
|--------|--------------------------------------------------------|---------------|-------------------------|
| REQ-01 | Proces musi [co robić]                                 | Must Have     | [UC-XXX / STORY-XXX]    |
| REQ-02 | Proces powinien [co robić]                             | Should Have   | [UC-XXX / STORY-XXX]    |
| REQ-03 | Proces może [co robić]                                 | Could Have    | —                       |

> Założenie: priorytety wg MoSCoW. Jeśli projekt stosuje inną skalę — dostosuj.

## Reguły biznesowe
<!-- DLACZEGO: reguły to najcenniejsza wiedza analityka — tu jest logika i ograniczenia biznesowe.
     Identyfikatory RB pozwalają linkować reguły z UC  bez duplikowania treści. -->

| ID   | Reguła                                                        | Źródło / Uzasadnienie         |
|------|---------------------------------------------------------------|-------------------------------|
| RB-01 | [np. Wartość X nie może przekroczyć limitu Y]                 | [Regulacja / decyzja bizn.]   |
| RB-02 | [np. Operacja A dostępna tylko dla roli Z]                    | [Polityka / AC epiki]         |
| RB-03 | [np. W przypadku warunku A, system stosuje logikę B]          | [Opis domenowy]               |

## Wymagania niefunkcjonalne (referencje)
<!-- DLACZEGO: NFR mające wpływ na proces biznesowy referujemy po ID, bez duplikowania.
     Szczegóły metryk i progów utrzymywane są w dokumencie NFR (related-doc-ids). -->

| NFR-ID      | Kategoria   | Wpływ na proces                       |
|-------------|-------------|---------------------------------------|
| NFR-PERF-01 | Performance | [np. czas realizacji kroku procesu]   |
| NFR-AVAIL-01 | Availability | [np. dostępność procesu w godzinach X] |

## Słownik pojęć
<!-- DLACZEGO: ujednoznacznia terminy domenowe — jeden termin = jedna definicja w całym projekcie.
     Bez tego każdy rozumie pojęcia inaczej, co prowadzi do błędów w implementacji. -->

| Pojęcie         | Definicja                                                  |
|-----------------|------------------------------------------------------------|
| [Termin 1]      | [Precyzyjna definicja w kontekście tego procesu]           |
| [Termin 2]      | [Precyzyjna definicja w kontekście tego procesu]           |

## Założenia i otwarte pytania
<!-- DLACZEGO: jawne założenia chronią analityka — jeśli coś jest niepewne, musi być widoczne.
     Otwarte pytania blokują implementację — powinny być zamykane z datą i osobą odpowiedzialną. -->

### Założenia
> Założenie: [treść założenia — co przyjęto bez potwierdzenia]

### Otwarte pytania
| # | Pytanie                          | Właściciel       | Termin     | Status    |
|---|----------------------------------|------------------|------------|-----------|
| 1 | [Co jest niejasne / do ustalenia]| [Imię Nazwisko]  | YYYY-MM-DD | Otwarte   |

## Historia zmian
| Źródło | Autor | Data | Wydanie | Opis |
|--------|-------|------|---------|------|
| `link do jira` | `imie i nazwisko` | `data zapisu` | `link do jira PW` | `krótki sens zmiany dla odbiorcy` |
```

---

## 6. Warianty
**BFS dla nowego procesu** — brak istniejących UC:
- Pozostaw `related-doc-ids` puste — dokument powstaje przed UC
- Użyj tabeli Wymagań jako backlog do rozbicia na UC w kolejnym kroku

**BFS dla istniejącego procesu** (retro-dokumentacja):
- Zacznij od sekcji „Reguły biznesowe" — reguły są w kodzie, trzeba je wydobyć
- Sekcję „Słownik pojęć" wypełnij na podstawie nazw z istniejących UC i kodu

---

## 7. Powiązany prompt generujący
Prompt `.github/prompts/create-business-functional-spec.prompt.md` generuje BFS na podstawie:
- epiki / impaktu z Jiry,
- strony Confluence,
- pliku z GitLab,
- lub opisu słownego analityka.

> Uruchom: wpisz `/create-business-functional-spec` w Copilot Chat.
