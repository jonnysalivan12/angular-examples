# Decyzje: przejęcie ustaleń z docs-standards

Plik zbiera decyzje o tym, które ustalenia z firmowego standardu `docs-standards` przejmujemy do standardu `rtp-docs`. Decyzje zapadły 2026-10-07 i 2026-10-08.

Materiał źródłowy leży w tym folderze:

| Ścieżka | Zawartość |
|---|---|
| `90-templates/` | 22 szablony z `docs-standards/docs/standard/90-templates`, przepisane ze zdjęć |
| `00-principles/metadata-and-linking.md` | zasady metadanych i linkowania z `docs-standards` |
| `porownanie/` | porównanie ich szablonów z naszymi, jeden plik na typ, z ponumerowanymi różnicami |

Odwołanie „actor 3” oznacza punkt 3 w pliku `porownanie/actor.md`.

## Decyzje ogólne

1. **Metadane.** Zostaje nasz model: pole `relations` z wpisami o nazwanym typie, pole `description` i nasze walidatory. Nie przejmujemy pól `type`, `component`, `source-spec-ids`, `related-doc-ids` i `examples-ids` ani odnośników `{{DOC-ID}}`.
2. **Struktura folderów.** Zmieniamy układ szablonów i układ dokumentów projektu. Dokumenty projektu trafią do folderów według typu, jak w ich mapie typ → folder. Ta część czeka na treść pliku `hooks/spec_taxonomy.yml`.
3. **Podział szablonu.** Zostaje podział na `guide.md` (opis typu) i `template.md` (szablon do skopiowania).
4. **Lista typów.**
   - Typ `bpmn-process` z prefiksem `BPMN` zmienia nazwę na `bpms-process` z prefiksem `BPMS`.
   - Zostaje typ `convention` z prefiksem `CONV`, którego nie ma w ich standardzie.
   - Dochodzi typ `adr` z prefiksem `ADR`, czyli zapis decyzji architektonicznej.
5. **Statusy i sekcje stałe.** Zostają nasze statusy `draft | active`. Nie dodajemy sekcji „Historia zmian” ani sekcji z promptami generującymi.
6. **Układ folderu szablonów.** Przejmujemy ich drzewo `90-templates` do poziomu pliku. W miejsce pliku `X.md` powstaje folder `X/` z plikami `template.md` i `guide.md`, na przykład `standards/templates/system/apis/api-endpoint/template.md`. Nazwy folderów pochodzą z ich drzewa.
7. **Miejsce typu `convention`.** Szablon trafia do `standards/templates/system/conventions/`.

## Tematy wspólne

Każdy temat rozstrzyga jedną decyzją te same różnice w wielu typach. Wszystkie rekomendacje zostały przyjęte.

### T1. Sprzeczności z naszym grafem

Ich szablony każą wymieniać dokumenty, które wskazują dany dokument, używać krótkich identyfikatorów (`REQ-01` zamiast `BFS-001.REQ-01`), linkować ścieżką do pliku zamiast identyfikatorem, podawać aktora nazwą zamiast wiersza `ROLE` i używać prefiksów wierszy `RB`, `RW` i `E` w typach, do których nie należą.

**Decyzja:** odrzucamy wszystkie takie punkty, bo zostaje nasz model relacji.

Punkty: actor 1, 2, 3, 6; business-functional-spec 1, 2; ddm 1; use-case 2, 3, 4, 5, 6; technical-use-case 2, 3, 4, 5; use-case-technical-map 1, 2, 3; api 9; event 3, 12; capability 4 (ID w tabeli „Poza zakresem”), 10, 11; ldm 1, 3, 13 oraz odnośnik do `entities/` z ldm 2; ldm-entity 1, 2, 3, 5, 13; activity 9, 10; flow 4, 7; navigation-map 5; screen 3, 5; screen-section 4, 5, 12; non-functional-requirements 1, 2, 5; bpms-process 3, 4, 6, 8, 10; workflow-step 2, 3, 4, 5, 6, 7, 8, 11.

### T2. Nasze sekcje dla grafu

Nasze szablony mają miejsca, z których wynikają relacje: pole `Zdolność`, sekcje `Encje`, `Ograniczenia NFR` i `Odbierane`, odwołania do konwencji `CONV` oraz kolumny `Ekran`, `Sekcja` i `Wywołanie` w tabelach kroków. Ich szablony tych miejsc nie mają.

**Decyzja:** zostają nasze sekcje i kolumny.

Punkty: ddm 11; use-case 1, 12; technical-use-case 1, 10; api 1, 5, 8, 10; event 5, 11 oraz wiersz `Zdolność publikująca` z event 2; capability 8, 9; ldm 11; flow 2, 6; screen-section 6; integration 1, 2, 3, 4; non-functional-requirements 7; state-machine 1; bpms-process 11.

### T3. Przedrostek typu w tytule

Ich tytuły mają przedrostek typu, na przykład `# API: {METHOD} /{resource}` albo `# Capability: {Nazwa zdolności}`.

**Decyzja:** nie przejmujemy. Tytuł zostaje samą nazwą.

Punkty: actor 11; business-functional-spec 11; ddm 12; use-case 19 (przedrostek); technical-use-case 17 (przedrostek); api 14; capability 15; ldm 14; ldm-entity 14; activity 1; flow 1 (przedrostek); navigation-map 1; screen-section 1; integration 13; non-functional-requirements 15; state-machine 11; bpms-process 19; workflow-step 21.

### T4. Komentarze z uzasadnieniem sekcji

Ich szablony mają przy każdej sekcji komentarz `<!-- DLACZEGO: … -->`. U nas komentarz HTML w szablonie oznacza regułę sekcji (`standards/templates/_00-meta.md`).

**Decyzja:** uzasadnienia sekcji przenosimy do `guide.md`. Szablon nie dostaje tych komentarzy.

Punkty: actor 12; business-functional-spec 12; ddm 13; use-case 20; technical-use-case 18; ldm 7 (komentarze); ldm-entity 7 (komentarze).

### T5. Zasada „Nie dotyczy”

Ich szablony mówią: „Wypełnij wszystkie sekcje — jeśli sekcja nie dotyczy, napisz „Nie dotyczy" z uzasadnieniem.”

**Decyzja:** przyjmujemy jako zasadę wspólną dla wszystkich typów. Sekcja, której nie da się wypełnić, dostaje wpis „Nie dotyczy” z uzasadnieniem. Sekcję, którą pomija wariant opisany w `guide.md`, nadal można pominąć.

Punkty: business-functional-spec 5; ddm 4; use-case 11; technical-use-case 9; ldm 7 (zasada); ldm-entity 7 (zasada); activity 8; api 4 (zapis pustej sekcji walidacji).

### T6. Znacznik `> Założenie:` dla braków

Ich szablony i opisy każą oznaczać braki danych blokiem `> Założenie: …` zamiast zgadywać.

**Decyzja:** przyjmujemy jako jedną zasadę wspólną, zapisaną w `_00-meta.md`, a nie osobno w każdym typie.

Punkty: event 7; capability 12; ldm-entity 10; activity 13; navigation-map 8; screen 6; screen-section 10; use-case-technical-map 6; state-machine 6; bpms-process 14.

### T7. Gotowe przykłady w treści szablonu

Ich szablony mają wpisane przykłady, na przykład wypełniony wariant `A1`, tabelę aktorów z procesu BBC, gotowy tekst sekcji albo pełny przykładowy diagram.

**Decyzja:** nie przejmujemy. Szablon ma pola do wypełnienia, a przykłady leżą w `standards/examples`. Konwencje zapisu, które ich przykłady pokazują, omawiamy osobno przy typie.

Punkty: actor 5; ddm 7; use-case 13; technical-use-case 11; use-case-technical-map 4; ldm 6.

### T8. Scenariusze błędów jako tabela

Ich szablony zapisują scenariusze błędów tabelą `| Scenariusz | Zachowanie |`. U nas w kilku typach ta sekcja jest wolnym tekstem.

**Decyzja:** przyjmujemy tabelę wszędzie tam, gdzie mamy wolny tekst. W kroku SPEC-WF tabela nie dostaje identyfikatorów `E1`, bo prefiks `E` należy do UC i TUC.

Punkty: activity 7; flow 8; navigation-map 7; state-machine 4 (sama tabela); workflow-step 13.

### T9. Pytania przygotowawcze w opisie typu

Ich sekcja „Co analityk MUSI wiedzieć” to lista pytań do zadania przed pisaniem. Nasza ta sama sekcja zawiera reguły zapisu.

**Decyzja:** dodajemy ich pytania do `guide.md` jako osobną listę i zostawiamy nasze reguły.

Punkty: actor 13; business-functional-spec 13; ddm 10; use-case 18; technical-use-case 16; api 12; event 18; non-functional-requirements 14.

### T10. Odesłania w „Nie używaj gdy”

Ich listy „Nie używaj gdy” odsyłają do innych typów niż nasze.

**Decyzja:** dodajemy te odesłania, które wskazują typ istniejący u nas i nie łamią T1. Nasze odesłania zostają. Odesłanie do `adr` też wchodzi, bo typ `adr` dochodzi.

Punkty: actor 14; business-functional-spec 3; ddm 9; use-case 17; technical-use-case 15; api 13; event 16; capability 14; ldm 12; activity 12; flow 11; navigation-map 10; screen-section 13; integration 12; non-functional-requirements 13; state-machine 10; bpms-process 15; workflow-step 20.

### T11. Odnośniki do zgłoszeń Jira w treści

Ich szablony podają zgłoszenia Jira w treści, na przykład w BFS, DDM, QUE i SPEC-WF.

**Decyzja:** nie przejmujemy, tak jak sekcji „Historia zmian”.

Punkty: business-functional-spec 1 (Jira); ddm 3; event 13 (Jira); workflow-step 12.

## Zmiany modelu

### M1. CAP, czyli zdolność

**Decyzja:** przyjmujemy ich definicję. Zdolność to konkretna, mierzalna umiejętność systemu, oprogramowania, urządzenia lub organizacji do wykonania określonego zadania lub osiągnięcia celu. Dotychczas CAP opisywał zakres odpowiedzialności całego komponentu.

Punkty: capability 1, 2, 3, 4 (forma tabeli), 5, 6, 7, 13.

Szczegóły ustalone 2026-10-08:

1. **Nowa definicja w opisach.** Definicję wpisujemy do `guide.md` typu, do tabeli typów w `methodology.md`, do komentarza typów w `relation-matrix.yaml` i w miejsce zdania „Komponenty opisują dokumenty zdolności CAP” w `methodology.md`, sekcja 5.
2. **Reguły z ich szablonu.** Jedna zdolność to jedna spójna umiejętność, a nie zbiór funkcji, komponentów ani integracji. CAP mówi, co system potrafi, a nie jak to robi. Szeroki, niespójny zestaw funkcji rozbija się na kilka CAP. Zdolność rozwija się w tym samym pliku, bez nowego dokumentu przy każdej zmianie.
3. **Opis i wartość.** Sekcję „Cel biznesowy” zastępują dwie: „Opis” (co zdolność robi, dla kogo i jaki daje rezultat) oraz „Wartość biznesowa” (wartość, odbiorca, problem, który rozwiązuje).
4. **Zakres.** „Zakres odpowiedzialności” to lista. Nagłówki zostają bez angielskich dopisków `(in-scope)` i `(out-of-scope)`.
5. **Tabele.** Przejmujemy cztery ich tabele:
   - „Poza zakresem”: element, system lub zdolność właściciela, właściciel, odnośnik do dokumentacji właściciela. Zgodnie z T1 zdolność, także z tego samego systemu, podaje się nazwą, bez ID, bo matryca nie ma trójki CAP–CAP.
   - „Regulacje” jako nowa sekcja: regulacja i źródło, wymaganie lub artykuł, wpływ na zdolność, właściciel interpretacji, sposób monitorowania zmian.
   - „Miary i kryteria skuteczności”: miara, definicja i jednostka, wartość bazowa, oczekiwany próg, źródło pomiaru, właściciel.
   - „Ryzyka i ograniczenia”: ryzyko, prawdopodobieństwo lub warunek, wpływ, mitygacja, właściciel. Obejmuje skutki niedostępności zależności.
6. **Miary a NFR.** Tabela miar zawiera tylko miary biznesowe zdolności. Progi SLA i inne progi jakości zostają w NFR, a CAP wskazuje je w sekcji „Ograniczenia NFR”.
7. **Warianty.** Minimalny: Opis, Wartość biznesowa, Zakres odpowiedzialności, Poza zakresem. Pełny, zalecany: do tego Zdarzenia i kontrakty domenowe (odbierane), Regulacje, Miary i kryteria skuteczności, Ograniczenia NFR, Ryzyka i ograniczenia.

Kolejność sekcji w szablonie: Opis, Wartość biznesowa, Zakres odpowiedzialności, Poza zakresem, Zdarzenia i kontrakty domenowe, Regulacje, Miary i kryteria skuteczności, Ograniczenia NFR, Ryzyka i ograniczenia.

Folder dokumentów zależny od zdolności (`methodology.md`, sekcja 11) rozstrzyga M4.

### M2. SPEC-WF, czyli specyfikacja kroku procesu

**Decyzja:** SPEC-WF opisuje tylko złożony krok. Mały krok nie dostaje osobnego pliku. Dokument BPMS dostaje nowy typ wiersza dla kroków procesu.

Punkty: bpms-process 1, 2, 5; workflow-step 1.

Szczegóły ustalone 2026-10-08:

1. **Wiersz zadania.** Każde zadanie procesu, małe i złożone, jest wierszem `STEP` w tabeli „Zadania procesu” dokumentu BPMS. Inne dokumenty wskazują je pełnym ID, na przykład `BPMS-001.STEP-01`. Wiersze stoją w kolejności z diagramu BPMN, a numer usuniętego wiersza nie wraca do obiegu.
2. **Tabela zadań.** Kolumny: `ID`, `W silniku`, `Typ`, `Nazwa`, `Rola`, `Wywołanie`, `Opis działania`, `SPEC-WF`. Opis działania jest obowiązkowy dla każdego zadania. Zadanie złożone ma w kolumnie `SPEC-WF` identyfikator pliku, a jego wywołania opisuje SPEC-WF, więc proces ich nie powtarza.
3. **Cechy zadania w BPMS.** ID zadania w silniku, typ zadania i rola leżą zawsze w tabeli procesu. SPEC-WF opisuje tylko wnętrze kroku i traci pola `task-type` oraz „Aktor / serwis”.
4. **Relacje małego zadania.** Kolumna `Rola` tworzy wpis `BPMS involves ROLE`, a kolumna `Wywołanie` wpisy `BPMS consumes API`, `INT` albo `QUE`, tak jak tabela kroków w FLOW i UC.
5. **Wskazania zadania.** Zadanie małe wskazuje się wierszem `STEP`, a złożone plikiem SPEC-WF:
   - API, które przypisuje, odkłada albo kończy zadanie użytkownika: `API consumes BPMS-001.STEP-02` albo `API consumes SPEC-WF-007`;
   - SPEC-WF, który czyta zmienną zapisaną przez inne zadanie: `SPEC-WF-007 consumes BPMS-001.STEP-01` albo `SPEC-WF-007 consumes SPEC-WF-003`.
6. **Kryteria akceptacji** zostają tylko w SPEC-WF (`SPEC-WF contains AC`).
7. **Kryterium zadania złożonego.** Zadanie dostaje SPEC-WF, gdy spełnia którykolwiek warunek:
   - ma logikę decyzyjną typu „jeśli X, to Y”;
   - woła więcej niż jeden zasób (API, INT, QUE);
   - ma własną obsługę błędów albo zdarzeń granicznych, inną niż opisana w procesie;
   - potrzebuje kryteriów akceptacji;
   - jego opis działania nie mieści się w 2–3 zdaniach.

Zmiany w matrycy relacji, które z tego wynikają:

| Zmiana | Trójka |
|---|---|
| dochodzi | `BPMS contains STEP` (1:N) |
| dochodzi | `BPMS consumes API`, `BPMS consumes INT`, `BPMS consumes QUE` (N:N) |
| dochodzi | `BPMS involves ROLE` (N:N) |
| dochodzi | `API consumes STEP` (N:N) |
| dochodzi | `SPEC-WF consumes STEP` (N:N) |
| odpada | `SPEC-WF involves ROLE` |
| zostaje | `BPMS contains SPEC-WF`, `API consumes SPEC-WF`, `SPEC-WF consumes SPEC-WF`, `SPEC-WF consumes API`, `INT`, `QUE`, `SPEC-WF contains AC` |

Do omówienia przy typach zostaje lista wartości kolumny `Typ` (workflow-step 9: u nich osiem typów zadań z BPMN 2.0, u nas cztery).

### M3. QUE, czyli zdarzenie

**Decyzja:** QUE działa jak API, tylko asynchronicznie. Jeden plik opisuje jedno zdarzenie, tak jak jeden plik API opisuje jeden punkt końcowy. Ich model „jeden plik na obszar komunikacji” odrzucamy.

Punkty: event 1, 15.

### M4. Nazwy plików i układ dokumentów projektu

Ich szablony nazywają pliki opisowo, na przykład `get-offers.md`, `ddm-case.md` albo `asyncapi-overdraft-renewal.md`. U nas plik ma nazwę równą doc-id małymi literami, na przykład `api-001.md`.

Punkty: ddm 2; api 11; event 19; ldm-entity 12; activity 14; flow 12; integration 7; bpms-process 16.

Ustalone 2026-10-08 na podstawie odczytu `hooks/spec_taxonomy.yml` (plik `hooks/spec_taxonomy.yml` w tym folderze, linie 1–14 oryginału nieznane):

1. **Folder główny.** Dokumenty projektu leżą w `project/` w głównym folderze repozytorium, obok `standards/`.
2. **Folder typu.** Folder dokumentu wynika z typu według ich mapy: `project/functional/…`, `project/system/…`, `project/architecture/…`. Typ `convention` dostaje `project/system/conventions`. Aktywności leżą razem z przepływami w `system/flows`, encje razem z LDM w `system/data-models`, DDM w `functional/data-models`.
3. **Podfoldery.** Pod folderem typu wolno założyć jeden poziom dowolnego grupowania, na przykład po procesie albo domenie. Narzędzia ignorują podfolder, bo grupowanie liczą z relacji. Mapy nawigacji (`gui/navigation-maps`) nie mają podfolderów. Ekran leży w `system/gui/screens/{ekran}/`, jego sekcje w `system/gui/screens/{ekran}/ui-specs/`, a sekcje wspólne dla kilku ekranów w `system/gui/screens/_shared/ui-specs/`; obrazy sekcji w `ui-specs/assets/` (ustalone 2026-10-08, po etapach 0–6). Proces BPMS leży w `system/workflows/{proces}/`, a jego kroki w `system/workflows/{proces}/steps/`; folder `{proces}` nazywa się tak jak plik procesu bez rozszerzenia.
4. **Nazwy plików.** Nazwy są opisowe, jak u nich, a nie od doc-id. Doc-id zostaje w nagłówku pliku i nadal jest kluczem relacji. Wzorzec: tytuł dokumentu małymi literami, bez polskich znaków, słowa połączone myślnikiem, bez prefiksu typu, na przykład `walidacja-danych-klienta.md`, `pobranie-ofert.md`. Encja bierze nazwę z doc-id: `ENT-Disposition` to `disposition.md`. Walidator formy sprawdza zapis nazwy (małe litery, cyfry i myślniki) i to, czy nazwa jest jedyna w folderze. Zmiana tytułu zmienia nazwę pliku; relacje tego nie zauważają, bo opierają się na doc-id.
5. **Pliki pomocnicze.** Makiety i pliki diagramów leżą w `assets/` obok dokumentu i nazywają się tak jak plik dokumentu, nie od doc-id. To zmienia zapis w decyzjach stm 8 i bpms 18: `assets/{nazwa-pliku}.svg` i `assets/{nazwa-pliku}.bpmn`.
6. **Co odpada.** Sekcja 11 `methodology.md`: układ `processes/` i `shared/`, reguły „do którego procesu należy dokument”, folder ekranu z `sections/` i `shared/`, folder przepływu, folder domeny `DDM-001/`. Zasada „plik ma nazwę równą doc-id”.
7. **Narzędzia do zmiany.** `validate-form` (kody FORM-05 i FORM-06: nazwa pliku i folder), `docs-workbench` (grupy z folderów `processes/` i `shared/` zastępuje grupowanie z relacji), `knowledge-index` (ścieżki w wynikach), `_00-meta.md`, przykłady w `standards/examples` do przeniesienia w nowy układ.

## Decyzje typ po typie

### actor

Ustalone 2026-10-08:
- **actor 4.** Zostają nasze kolumny tabeli „Aktorzy”: `| ID | Nazwa kanoniczna | Klasa | Odpowiedzialność | Uprawnienia | Dziedziczy po |`.
- **actor 7.** Różne poziomy uprawnień zapisuje się jako osobne role z kolumną „Dziedziczy po”. Guide dostaje tę regułę jawnie, z uzasadnieniem: każdy poziom ma własne ID, które może wskazać scenariusz.
- **actor 8.** Tabela „Klasyfikacja aktorów” dostaje kolumnę „Definicja lokalna”: `| Klasa | Definicja lokalna | Kryterium kwalifikacji |`.
- **actor 9.** Zostaje podsekcja „Poza zakresem”.
- **actor 10.** „Słownik nazw i aliasów” ma jeden alias w wierszu i kolumnę „Alias / nazwa historyczna”: `| Nazwa kanoniczna | Alias / nazwa historyczna |`.
- **Usterka 2.** Z guide znikają słowa „i na diagramie relacji”. Dziedziczenie pokazuje tylko kolumna „Dziedziczy po”.

### business-functional-spec

Ustalone 2026-10-08:
- **bfs 4.** Zostaje skala `Must / Should / Could / Won't`, jedna dla całego projektu.
- **bfs 6.** Sekcja „Wymagania niefunkcjonalne” zostaje listą `- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}: {czego dotyczy w procesie}`.
- **bfs 7.** Pole wymagania ma postać `{Proces musi / powinien / może …}`. Guide wyjaśnia, że czasownik odpowiada priorytetowi: musi to Must, powinien to Should, może to Could.
- **bfs 8.** „Słownik pojęć” jest tabelą `| Pojęcie | Definicja |`.
- **bfs 9.** „Założenia i otwarte pytania” mają podsekcje `### Założenia` i `### Otwarte pytania`, a tabela pytań ma kolumnę numeru: `| # | Pytanie | Właściciel | Termin | Status |`.
- **bfs 10.** Pole „Poza zakresem” ma postać `{Czego proces nie obejmuje i dlaczego}`.
- **bfs 14.** Wariant „BFS dla istniejącego procesu” dostaje zdanie, że słownik pojęć wypełnia się na podstawie nazw z istniejących UC i kodu.

### ddm

Ustalone 2026-10-08:
- **ddm 5.** „Słownik pojęć domenowych” dostaje kolumnę „Pojęcie” z pełną nazwą: `| ID | Pojęcie | Definicja | Synonimy | Właściciel pojęcia |`. Guide dostaje zasadę: ID `DOM-{Nazwa}` powstaje z nazwy pojęcia bez polskich znaków i spacji, na przykład „Pełnomocnictwo” daje `DOM-Pelnomocnictwo`.
- **ddm 6.** Zostaje tabela „Encje i Value Objects” z kolumną „Pojęcie” zawierającą samo ID.
- **ddm 8.** Guide dostaje zdanie, że DDM nie zawiera typów fizycznych (`VARCHAR`, indeksy, migracje) ani kopii kodu i kontraktów OpenAPI i AsyncAPI.
- **ddm 12.** Zostaje nagłówek `## Źródła wymagań w górę`.

### use-case

Ustalone 2026-10-08:
- **uc 7.** Sekcja „Ograniczenia NFR” zostaje listą, ale z opisem: `- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}: {jak ogranicza scenariusz}`.
- **uc 8.** Kryterium akceptacji kończy się pełnym ID wymagania albo reguły: `- Kiedy {sytuacja}, wtedy {oczekiwany wynik}. (BFS-{nnn}.REQ-{nn})`. Bez pól wyboru `- [ ]`.
- **uc 9.** Guide: ostatnie wiersze tabeli każdej sytuacji błędnej `E` podają komunikat, który widzi użytkownik, i co może zrobić dalej.
- **uc 10.** Guide: ostatni wiersz tabeli każdego wariantu `A` mówi, do którego kroku wraca przebieg albo że kończy operację.
- **uc 14.** Pole kroku ma postać `{Kto robi co i co widzi w odpowiedzi}`.
- **uc 15.** Komentarz przy diagramie i guide: diagram dodaje się, gdy przebieg ma więcej niż jedno rozgałęzienie decyzyjne; najwyżej 15 kroków. Bez przykładowego diagramu (T7).
- **uc 16 i usterka 4.** UC bez BFS jest dozwolony, bo zespół może nie prowadzić BFS. „Po BFS” przestaje być wariantem. Do sekcji 3 guide trafia reguła: jeśli zespół prowadzi BFS, UC wskazuje co najmniej jedno wymaganie albo regułę BFS i nie kopiuje ich treści, tylko opisuje przebieg; jeśli nie, sekcja „Powiązanie z BFS” i pola `BFS`, `Powiązane REQ` i `Powiązane RB` dostają „Nie dotyczy” (T5). Zostają warianty „Uproszczony” i „Złożony”. Zdanie z `methodology.md`, sekcja 11, o folderze UC bez BFS odpada razem z układem folderów według procesu (M4).
- **uc 19.** Zostają nasze nagłówki: `## Powiązanie z BFS`, `## Kroki`, `### A1. …`, `### E1. …`. Wzorzec w `scripts/lib/templates.js:39` rozpoznaje wiersz tylko z kropką albo spacją po numerze, więc `A1:` zepsułby wykrywanie wariantów.

### technical-use-case

Ustalone 2026-10-08. Punkty tuc 6, 7, 8, 12, 13 i 17 dostają te same decyzje co odpowiednio uc 7, 8, 10, 15, 16 i 19, z tą różnicą, że ostatni wiersz wariantu mówi o powrocie do kroku albo zamknięciu procesu.
- **tuc 14.** Wariant „Złożony” stosuje się także przy kilku wyzwalaczach: jeden TUC na wyzwalacz, bo pole „Trigger” tworzy relację do zdarzenia uruchamiającego scenariusz. Warianty zestawia mapa `use-case-technical-map`.

### use-case-technical-map

Ustalone 2026-10-08:
- **ucmap 4.** Zostaje nagłówek `## Diagram`.
- **ucmap 5.** Zostaje zapis `include`, `extend`, `exclude` bez nawiasów stereotypu i kolumna legendy „Znaczenie”.
- **ucmap 7.** Wariant „Rozbudowany” dostaje warunek: „gdy mapa obejmuje kilka obszarów; diagram podzielony na obszary, jeden plik mapy”. Bez przykładów obszarów.

### api

Ustalone 2026-10-08:
- **api 2.** „Parametry wejściowe” dostają kolumnę „Opis”: `| Parametr | Typ | Wymagany | Źródło | Opis |`. Komentarz o nagłówkach z konwencji zostaje.
- **api 3.** „Walidacja pól wejściowych” dostaje kolumnę „Parametr” na początku: `| Parametr | Reguła | Kod błędu HTTP | Komunikat zwracany przez system |`.
- **api 4.** Guide: tabela walidacji wymienia wszystkie reguły (format, zakresy, długość, zależności warunkowe), a walidację warunkową opisuje się w kolumnie „Reguła” albo w sekcji „Zachowanie”. Kod HTTP i komunikat zostają obowiązkowe.
- **api 6.** `### Przebieg podstawowy` zostaje obowiązkowy, z listą wskazań FLOW, BPMS i SPEC-WF (T2). `### Przypadek brzegowy` zostaje jako nagłówek, jest opcjonalny, a jego treść to lista `- {nazwa przypadku}: {zachowanie}`, więc mieści kilka przypadków.
- **api 7.** „Model odpowiedzi” dostaje warunek: wypełnia się, gdy struktura odpowiedzi jest nietrywialna. „Struktura odpowiedzi błędnej” zostaje obowiązkowa. Sekcje opcjonalne: „Złożone parametry wejściowe”, „Model odpowiedzi”, „Przypadek brzegowy”.

### event

Ustalone 2026-10-08:
- **event 2.** Bez wierszy `Producent` i `Konsument(ci)`. Listę odbiorców liczy graf z wpisów `consumes QUE` (M3).
- **event 4.** Zostaje osobna sekcja `## Przepływ danych` z pustym diagramem.
- **event 6.** Zostaje jedna tabela atrybutów w „Specyfikacja schematu”.
- **event 8.** „Przykład ładunku” zostaje z `{}`. Guide: przykład pokazuje ładunek zdarzenia, bez pól koperty opisanych w konwencji.
- **event 9.** „Charakterystyka dostarczenia” zostaje obowiązkowa. Nieznaną wartość oznacza `> Założenie:` (T6).
- **event 10.** Komórki tabeli dostają dozwolone wartości jako podpowiedzi: gwarancja `at-least-once / exactly-once / at-most-once`, idempotencja `wymagana / nie wymagana`. Guide: idempotencja konsumenta jest wymagana zawsze przy `at-least-once`. Bez kolumny „Opis”, nazwy wierszy zostają nasze.
- **event 14.** Bez reguły o sekcjach „Runtime i technologia” i „Model kanałów i operacji”.
- **event 17.** Bez odwołania do standardu CAIT. Guide: nazwę zdarzenia ustala konwencja nazewnictwa, jeśli projekt ją ma, wskazana wpisem `applies CONV`.
- **Usterka 1.** Sekcja „Powiązane dokumenty” znika z szablonów `event`, `bpms-process` i `workflow-step`. Listę powiązań liczy graf. Przykłady w `standards/examples` tracą tę sekcję.

### ldm

Ustalone 2026-10-08:
- **ldm 2.** Sekcja „Encje” jest tabelą `| Encja | Opis |` z jednym zdaniem opisu. Bez aliasu, bo stoi w nagłówku encji.
- **ldm 4.** Sekcja „Kluczowe relacje” jest tabelą `| Encja źródłowa | Liczebność | Encja docelowa | Opis relacji |`.
- **ldm 5.** Sekcja „Słowniki zewnętrzne” jest tabelą `| Słownik | Używany w | Źródło |`.
- **ldm 8.** Komentarz przy diagramie ER dostaje legendę notacji liczebności Mermaid. Bez przykładowego diagramu i bez reguły o tożsamości w komentarzu atrybutu.
- **ldm 9.** Guide dostaje tabelę typów logicznych `| Typ logiczny | Opis | Typowe mapowania fizyczne |` w miejsce zdania z listą typów.
- **ldm 10.** Lista „Czego nie umieszczać” w guide dostaje punkt o kopiach kontraktów OpenAPI i AsyncAPI.

### ldm-entity

Ustalone 2026-10-08:
- **ent 4.** Zostaje tabela `| Pole | Wartość |` pod tytułem.
- **ent 6.** „Typy wyliczeniowe” mają podsekcję `### {NazwaEnum}` na każdy typ z tabelą `| Wartość | Opis |`. Sekcja jest opcjonalna (komentarz w szablonie), encja bez typów wyliczeniowych ją pomija.
- **ent 8.** Zostają wartości `tak / nie` i `Tak / Nie`. Guide: wymagalność wynika z modelu logicznego, nie z walidacji aplikacyjnej.
- **ent 9.** Guide encji nie powtarza listy „Czego nie umieszczać”, tylko odsyła do guide LDM. Lista w guide LDM dostaje pozycje: precyzja, partycje, adnotacje JPA.
- **ent 11.** Guide: w „Opis” wskazuje się momenty zapisu, jeśli są istotne, na przykład pole zapisywane przy inicjalizacji.

### activity

Ustalone 2026-10-08:
- **act 2.** Zostaje nagłówek `## Wejście i wyjście`.
- **act 3.** Zostaje tabela `| Kierunek | Dane | Opis |`.
- **act 4.** Pole „Cel” ma postać `{Jedno zdanie: jaki efekt daje aktywność i po co istnieje}`.
- **act 5.** Zostaje „Opis akcji” krok po kroku; reguły tylko w „Warunki i reguły”.
- **act 6.** „Warunki i reguły” dzielą się na dwie listy: „Warunki uruchomienia” i „Reguły i ograniczenia”.
- **act 11.** Zostaje reguła: osobny plik dostaje tylko logika ze złożonym algorytmem albo używana przez kilka przepływów.

### flow

Ustalone 2026-10-08:
- **flow 1.** Guide: plik obsługi błędów ma w tytule dopisek „: obsługa błędów”, plik podstawowy nie ma dopisku.
- **flow 3.** Diagram jest opcjonalny przy prostym przepływie (komentarz w szablonie). Guide: diagram musi zgadzać się z tabelą kroków. Mermaid i limit 10–15 kroków zostają.
- **flow 5.** Zostaje nagłówek `## Opis przepływu`, bo `docs-workbench` czyta tabelę po tej nazwie.
- **flow 9.** „Scenariusze błędów” są obowiązkowe, chyba że obsługę błędów opisuje osobny plik wariantu; wtedy plik podstawowy pomija sekcję.
- **flow 10.** Zostaje odesłanie procesu w silniku Workflow do `bpms-process`.

### navigation-map

Ustalone 2026-10-08:
- **nav 2.** Komentarz w szablonie i guide dostają konwencję krawędzi: akcja użytkownika to strzałka z etykietą (`-->|Dalej|`), błąd techniczny to linia przerywana (`-. błąd techniczny .->`). Bez przykładowego diagramu.
- **nav 3.** Diagram pokazuje wszystkie ekrany procesu, bo `docs-workbench` rysuje z niego mapę nawigacji.
- **nav 4.** „Kluczowe elementy nawigacji” to lista: „Główne przejścia” i „Przejścia końcowe i ich warunki”. Luki oznacza `> Założenie:` (T6).
- **nav 6.** Zostaje zamknięta lista `startowy / pośredni / końcowy / błędu`.
- **nav 9.** Guide, bez wariantu: duży diagram dzieli się na obszary (`subgraph`), plik zostaje jeden.

### screen

Ustalone 2026-10-08:
- **scr 1.** „Opis ekranu” dostaje akapit `{Krótki opis celu i kontekstu ekranu}` przed listą.
- **scr 2.** „Mapa sekcji na ekranie” to dwa obrazy całego ekranu: zwykły i z zaznaczonym podziałem na sekcje. Obrazy pojedynczych sekcji należą do SCRSEC. Bez listy sekcji.
- **scr 4.** Numeracja sekcji zostaje od 1.
- **scr 7.** Zostaje „Przycisk wstecz”; ostatni punkt nazywa się „Odnośniki i akcje dodatkowe”.

### screen-section

Ustalone 2026-10-08:
- **sec 2.** Pole „Opis sekcji” ma postać `{Co sekcja pokazuje i do czego służy, 3–4 zdania}`.
- **sec 3.** Blok pola nazywa się `### {Nazwa pola albo elementu}`, bez przedrostka „Pole:”.
- **sec 7.** Atrybut nazywa się `WCAG`, wartość `{atrybut aria albo element HTML}`.
- **sec 8.** Atrybut analityki ma zapis `Zdarzenie: {nazwa}, atrybuty: {klucz: wartość}`.
- **sec 9.** „Reguły biznesowe” to lista `1. **{Nazwa reguły}**: {Opis}`. Numery nie są identyfikatorami w grafie.
- **sec 11.** „Zachowania specjalne” mają podsekcje `### {Stan albo scenariusz}`. Sekcja zostaje opcjonalna.

### integration

Ustalone 2026-10-08:
- **int 5.** Zostaje tabela odpowiedzi `| Pole | Opis |`.
- **int 6.** Zostają cztery stałe wiersze tabeli „Protokół”. Guide pozwala dopisać wiersze właściwe dla protokołu, na przykład WSDL przy SOAP albo nazwę kolejki przy JMS. Do sprawdzenia przy wdrożeniu: czy `validate-form` dopuszcza dodatkowe wiersze w tabeli „Pole | Wartość”.
- **int 8.** Zostaje nagłówek `## Operacja`.
- **int 9.** Zostają osobne wiersze `5xx` i „Przekroczenie czasu”.
- **int 10.** Zostaje nagłówek `## Diagram sekwencji`; komentarz mówi, że diagram pokazuje wywołanie i warianty odpowiedzi.
- **int 11.** Komórka „Źródło” w tabeli żądania dostaje podpowiedź `parametr / stała / nagłówek`.

### non-functional-requirements

Ustalone 2026-10-08:
- **nfr 3.** Macierz dostaje kolumny „Środowisko” i „Priorytet”: `| ID | Atrybut jakości | Metryka | Próg docelowy | Metoda pomiaru | Środowisko | Priorytet |`. Bez kolumny „Owner”.
- **nfr 4.** Wpisy katalogu mają postać `- NFRT-{KATEGORIA}-{nn}: {Opis}`.
- **nfr 6.** Pole „Właściciel” pod tytułem zmienia nazwę na „Zespół odpowiedzialny” z wartością `{zespół albo rola}`. `owner` w nagłówku pliku to nadal osoba odpowiedzialna za dokument.
- **nfr 8 i usterka 3.** Zakres przyjmuje tylko `system / component`. Wymagania jakościowe procesu zapisuje BFS w sekcji „Wymagania niefunkcjonalne”. „Użyj gdy” dostaje zdanie o jednym źródle prawdy dla SLA/SLO, bezpieczeństwa, dostępności i monitoringu.
- **nfr 9.** Zostaje kod kategorii `CONT`.
- **nfr 10.** „Krytyczność” przyjmuje `wysoka / średnia / niska`.
- **nfr 11.** Pole „Cel i kontekst” ma postać `{Po co są wymagania jakościowe, czego dotyczą i jakie ryzyka ograniczają}`.
- **nfr 12.** Zostają nasze nazwy sekcji i kolumn.

### state-machine

Ustalone 2026-10-08:
- **stm 2.** Zostają kolumny `| Kod | Status | Opis | Czy końcowy |`. Guide: tabela wymienia wszystkie statusy, a kolumna „Czy końcowy” jest jedynym źródłem stanów końcowych, także dla diagramu.
- **stm 3.** Zostają kolumny `| Stan z | Stan do | Opis przejścia | Typ przepływu |`. Guide: jeden wiersz to jedno przejście, tabela zawiera wszystkie przejścia, stan zapisuje się jako `{Kod}. {Status}`. Definicje: `MAIN` to główna ścieżka sukcesu, `ALTERNATIVE` to akceptowalne odgałęzienie (np. rezygnacja, ręczna obsługa), `ERROR` to błąd techniczny albo decyzja negatywna.
- **stm 4.** „Scenariusze błędów” to tabela `| Scenariusz | Stan | Zachowanie |`, tylko dla scenariuszy prowadzących do niezaplanowanych stanów końcowych.
- **stm 5.** Komentarz w szablonie: etykiety stanów na diagramie to `{Kod}. {Status}` jak w tabelach; stan końcowy prowadzi do `[*]`. Bez szkieletu i bez przedrostka `END:`.
- **stm 7.** Po tabeli pod tytułem jest pole `{Co reprezentuje maszyna stanów, 1–2 zdania}`.
- **stm 8.** Guide: tabele stanów i przejść są obowiązkowe także przy diagramie z EA; plik diagramu leży w `assets/` i nazywa się od doc-id, np. `stm-001.svg`.
- **stm 9.** Zostaje nagłówek `### Stany procesowe`.

### bpms-process

Ustalone 2026-10-08:
- **bpms 7.** Specyfikację można pisać przed diagramem. Do powstania diagramu sekcja „Diagram procesu” ma znacznik `> Założenie: diagram powstanie …` (T6), a `process-version` jest puste. Od chwili powstania diagramu każda zmiana procesu podnosi `process-version`. Do sprawdzenia przy wdrożeniu: jak `validate-form` traktuje puste pole.
- **bpms 12.** „Bramki i warunki” to tabela `| Bramka | Rodzaj | Warunki |` z oznaczeniami `GW1: {Nazwa}` i rodzajami `Exclusive (XOR)`, `Inclusive (OR)`, `Parallel (AND)`. Opisy rodzajów trafiają do guide. Numery `GW` nie są identyfikatorami w grafie.
- **bpms 13.** „Zdarzenia graniczne” to opcjonalna tabela `| Zadanie | Typ zdarzenia | Obsługa |`, gdzie „Zadanie” to wiersz `STEP-{nn}`.
- **bpms 17.** Guide: programista przenosi BPMN XML do repozytorium kodu i rozbudowuje go o szczegóły implementacyjne; przy rozbieżności analityk sprawdza zgodność z wymaganiami i aktualizuje specyfikację.
- **bpms 18.** Tabela „Diagram procesu” podaje wzorce `assets/{doc-id}.bpmn` i `assets/{doc-id}.svg`; eksport PNG/SVG jest opcjonalny. Kolumna zostaje „Odnośnik”.

### workflow-step

Ustalone 2026-10-08:
- **wf 9.** Kolumna „Typ” w tabeli „Zadania procesu” (BPMS) przyjmuje zamkniętą listę ośmiu typów z BPMN 2.0: `user-task`, `service-task`, `script-task`, `business-rule-task`, `send-task`, `receive-task`, `manual-task`, `call-activity`. Guide procesu opisuje krótko każdy typ. Warianty w guide SPEC-WF zostają tylko dla `user-task` i `call-activity`.
- **wf 14.** „Obsługa zdarzeń granicznych” to opcjonalna tabela `| Zdarzenie | Warunek | Obsługa |`.
- **wf 15.** Bez pola „Etap procesu”.
- **wf 16.** Bez pola „Typ tasku”. Sekcja „Kontekst” znika z SPEC-WF, bo po M2 nie ma w niej żadnego pola.
- **wf 17.** Guide: reguły z rozgałęzieniami można pokazać opcjonalnym diagramem `flowchart`.
- **wf 18.** „Efekty uboczne” są opcjonalne.
- **wf 19.** Kryterium akceptacji zostaje nagłówkiem, z nazwą po kropce: `### AC-01. {Nazwa kryterium}`, a pod nim lista Given, When, Then.

Wymaganie dla narzędzi (docs-workbench): grupowanie po BFS zostaje jedną z opcji grupowania. Po M4 grupa musi wynikać z wpisów `realizes` do wierszy BFS, a nie z folderu. UC bez BFS w tym grupowaniu nie widać i to jest zamierzone.

## Typ adr

Ustalone 2026-10-08:

1. **Szablon.** Ich szablon przechodzi do naszego formatu: `standards/templates/architecture/decision-records/adr/template.md` i `guide.md`. Nagłówek pliku: `doc-id: ADR-{nnn}`, `title`, `description`, `status`, `owner`, `relations`. Bez pól `type` i `component`, bez sekcji „Historia zmian” i bez promptu (decyzje 1 i 5). Numeracja trzycyfrowa, sekwencyjna.
2. **Sekcje szablonu.** Kontekst, Opcje, Decyzja, Konsekwencje. Sekcja „Opcje” ma podsekcję na każdą opcję: `### A. {Nazwa opcji}` z listą zalet i wad; opcji jest co najmniej dwie, a wybraną oznacza dopisek „(wybrana)”. Sekcja „Status” z ich szablonu odpada, bo status stoi w nagłówku pliku. Guide dostaje ich sekcje 1–3 i 6 w naszym układzie.
3. **Statusy.** `draft` to decyzja proponowana, `active` przyjęta, `deprecated` wycofana albo zastąpiona. Status `deprecated` ma tylko typ ADR; pozostałe typy zostają przy `draft | active`. Wycofanej decyzji nie usuwa się z repozytorium.
4. **Relacje.** ADR nie ma powiązań z innymi typami i żaden inny typ nie wskazuje ADR. ADR to dokumentacja informacyjna. Jedyna relacja to nowa `supersedes` między dwoma ADR: nowa decyzja wskazuje decyzję, którą zastępuje (`ADR-002 supersedes ADR-001`), a stara dostaje status `deprecated`. To, czym stara decyzja została zastąpiona, pokazuje graf z wpisu nowej decyzji; w treści starej można podać nową tytułem, bez ID (`methodology.md`, sekcja 7).
5. **Matryca relacji.** Lista `relation_types` dostaje `supersedes` z opisem „Dokument zastępuje wcześniejszą wersję decyzji”. Nowa trójka: `ADR supersedes ADR` z liczebnością `1:N` (jedna nowa decyzja może zastąpić kilka starych, każdą starą zastępuje jedna nowa). Walidatory czytają listę rodzajów relacji z matrycy (`scripts/lib/matrix.js`), więc nowy rodzaj nie wymaga zmian w ich kodzie.
6. **Walidator.** Reguła REL-07 „brak połączenia z grafem” (`scripts/validate-relations.js`, `checkConnectivity`) zgłosiłaby każdy ADR jako wyspę. Dokumenty typu ADR są z tej reguły wyłączone.
7. **docs-workbench.** ADR dostaje osobny zgrupowany widok: lista decyzji ze statusami i łańcuchem zastąpień. Potrzebna nowa warstwa i kolor dla typu. Zmiana z 2026-10-08, po etapach 0–6: decyzje leżą też na Mapie w warstwie Architektura, z liniami `supersedes` między decyzjami; do Zasięgu i Implementacji nie trafiają, bo wzorce zapytań nie mają ADR.
8. **knowledge-index.** Bez wzorców zapytań dla ADR. `describe_node` działa jak dla innych typów.
9. **Folder i nazwa pliku.** `project/architecture/decision-records/`, nazwa pliku ze skrótu tytułu (M4).

## Usterki w naszym standardzie

Porównanie pokazało miejsca, które trzeba poprawić u nas niezależnie od ich szablonów:
1. Sekcja „Powiązane dokumenty” w szablonach `event` i `bpmn-process` nie mówi, co w niej wpisać. Według matrycy relacji identyfikator innego dokumentu byłby tam często błędem (event 13, bpms-process 9). Rozstrzygnięte w „Decyzje typ po typie”, `event`: sekcja znika z trzech szablonów.
2. Opis `actor` każe pokazać dziedziczenie ról na diagramie relacji, ale szablon nie ma sekcji na ten diagram (actor 4, uwaga). Rozstrzygnięte w „Decyzje typ po typie”, `actor`.
3. Tabela pod tytułem w `non-functional-requirements` dopuszcza zakres `process`, a warianty opisują tylko `system` i `component` (non-functional-requirements 8). Rozstrzygnięte w „Decyzje typ po typie”, `non-functional-requirements`: zakres `process` odpada.
4. Opisy `use-case` i `technical-use-case` nazywają wariant „Po BFS” zalecanym, czyli dopuszczają scenariusz bez BFS. Według `methodology.md`, sekcja 11, scenariusz bez wpisu `realizes` do wymagania BFS nie ma folderu procesu (use-case 16, technical-use-case 13). Rozstrzygnięte w „Decyzje typ po typie”, `use-case`: scenariusz bez BFS jest dozwolony.

## Uwagi o materiale źródłowym

- W ich `actors.md` blok przykładu otwiera się czterema grawisami i nigdy się nie zamyka (zdjęcie IMG_3340).
- Na zdjęciach nie było plików `90-templates/_meta-template.md`, `90-templates/index.md` ani `hooks/spec_taxonomy.yml`.

## Otwarte sprawy

Brak. Wdrożenie wszystkich decyzji z tego pliku (szablony, `_00-meta.md`, `methodology.md`, matryca relacji, skrypty, `docs-workbench` i przykłady w `standards/examples`) opisuje `plan-wdrozenia.md`: etapy 0–6 z dziennikiem wykonania, 2026-10-08.

## Punkty do omówienia typ po typie

Wszystkie punkty z raportów w `porownanie/` są rozstrzygnięte: przez tematy wspólne, zmiany modelu albo sekcję „Decyzje typ po typie”.
