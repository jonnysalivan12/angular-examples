# Nazwy plików przykładów po M4

Propozycja nazw i miejsc dla 128 dokumentów w `standards/examples`, do akceptacji przed przeniesieniem (etap 3 planu). Ścieżka jest względna do `standards/examples/`. Nazwa to skrót tytułu po polsku; encje biorą nazwę z doc-id. Skrypt przenoszący czyta tabele z tego pliku, więc zmiana nazwy w tabeli wystarczy.

Podfoldery grupujące (jeden dozwolony poziom) są użyte tam, gdzie pokazują regułę: API i integracje według procesu (`dyspozycje`, `reklamacje`, `rachunki`), modele logiczne i encje według domeny (`dyspozycje`, `rachunki`). Pozostałe typy leżą wprost w folderze typu.

## functional

| doc-id | Tytuł | Nowa ścieżka |
|---|---|---|
| ACTOR-001 | Aktorzy systemu bankowości detalicznej | functional/actors/aktorzy-bankowosci-detalicznej.md |
| BFS-001 | Obsługa dyspozycji | functional/business-functional-specs/obsluga-dyspozycji.md |
| BFS-002 | Reklamacje dyspozycji | functional/business-functional-specs/reklamacje-dyspozycji.md |
| BFS-003 | Otwarcie rachunku | functional/business-functional-specs/otwarcie-rachunku.md |
| DDM-001 | Domena dyspozycji | functional/data-models/domena-dyspozycji.md |
| DDM-002 | Domena rachunków | functional/data-models/domena-rachunkow.md |
| UC-001 | Złożenie dyspozycji | functional/use-cases/zlozenie-dyspozycji.md |
| UC-002 | Korekta dyspozycji | functional/use-cases/korekta-dyspozycji.md |
| UC-003 | Zgłoszenie reklamacji przez klienta | functional/use-cases/zgloszenie-reklamacji-przez-klienta.md |
| UC-004 | Rozpatrzenie reklamacji | functional/use-cases/rozpatrzenie-reklamacji.md |
| UC-005 | Podgląd dyspozycji | functional/use-cases/podglad-dyspozycji.md |
| UC-006 | Zgłoszenie reklamacji w oddziale | functional/use-cases/zgloszenie-reklamacji-w-oddziale.md |
| UC-010 | Wniosek o rachunek | functional/use-cases/wniosek-o-rachunek.md |
| UC-011 | Ręczna weryfikacja tożsamości | functional/use-cases/reczna-weryfikacja-tozsamosci.md |
| TUC-001 | Nocne rozliczenie dyspozycji | functional/technical-use-cases/nocne-rozliczenie-dyspozycji.md |
| TUC-002 | Ponowienie nieudanych rozliczeń | functional/technical-use-cases/ponowienie-nieudanych-rozliczen.md |
| TUC-003 | Wypłata rekompensaty | functional/technical-use-cases/wyplata-rekompensaty.md |
| TUC-010 | Aktywacja rachunku | functional/technical-use-cases/aktywacja-rachunku.md |
| UCMAP-001 | Mapa scenariuszy dyspozycji i reklamacji | functional/use-case-technical-map/scenariusze-dyspozycji-i-reklamacji.md |
| UCMAP-002 | Mapa scenariuszy rozliczenia dyspozycji | functional/use-case-technical-map/scenariusze-rozliczenia-dyspozycji.md |

## system: zdolności, kontrakty, konwencje, NFR

| doc-id | Tytuł | Nowa ścieżka |
|---|---|---|
| CAP-001 | Przyjmowanie dyspozycji | system/capabilities/przyjmowanie-dyspozycji.md |
| CAP-002 | Walidacja danych klienta | system/capabilities/walidacja-danych-klienta.md |
| CAP-003 | Rozliczanie dyspozycji | system/capabilities/rozliczanie-dyspozycji.md |
| CAP-004 | Obsługa reklamacji | system/capabilities/obsluga-reklamacji.md |
| CAP-010 | Zakładanie rachunku | system/capabilities/zakladanie-rachunku.md |
| CAP-011 | Weryfikacja tożsamości | system/capabilities/weryfikacja-tozsamosci.md |
| API-001 | POST /dispositions | system/apis/dyspozycje/zlozenie-dyspozycji.md |
| API-002 | PATCH /dispositions/{id}/items/{itemId} | system/apis/dyspozycje/zmiana-pozycji-dyspozycji.md |
| API-005 | GET /dispositions | system/apis/dyspozycje/lista-dyspozycji.md |
| API-006 | POST /settlement-runs | system/apis/dyspozycje/uruchomienie-rozliczenia.md |
| API-003 | POST /clients/validate | system/apis/reklamacje/walidacja-klienta.md |
| API-004 | POST /complaints | system/apis/reklamacje/zgloszenie-reklamacji.md |
| API-007 | GET /complaints/{id} | system/apis/reklamacje/szczegoly-reklamacji.md |
| API-008 | POST /complaints/{id}/decision | system/apis/reklamacje/decyzja-w-sprawie-reklamacji.md |
| API-015 | POST /complaints/{id}/assignment | system/apis/reklamacje/przypisanie-reklamacji.md |
| API-009 | GET /addresses/suggestions | system/apis/rachunki/podpowiedzi-adresu.md |
| API-010 | POST /account-applications | system/apis/rachunki/zlozenie-wniosku-o-rachunek.md |
| API-011 | POST /identity-verifications | system/apis/rachunki/uruchomienie-weryfikacji-tozsamosci.md |
| API-012 | GET /identity-verifications/{id} | system/apis/rachunki/szczegoly-weryfikacji-tozsamosci.md |
| API-013 | POST /accounts | system/apis/rachunki/otwarcie-rachunku.md |
| API-014 | POST /account-applications/{id}/manual-verification/decision | system/apis/rachunki/decyzja-recznej-weryfikacji.md |
| API-016 | POST /account-applications/{id}/manual-verification/assignment | system/apis/rachunki/przypisanie-recznej-weryfikacji.md |
| API-017 | DELETE /account-applications/{id}/manual-verification/assignment | system/apis/rachunki/odlozenie-recznej-weryfikacji.md |
| INT-001 | System limitów: sprawdzenie limitu | system/integrations/dyspozycje/sprawdzenie-limitu.md |
| INT-002 | Księga główna: księgowanie dyspozycji | system/integrations/dyspozycje/ksiegowanie-dyspozycji.md |
| INT-004 | System płatności: zlecenie przelewu | system/integrations/reklamacje/zlecenie-przelewu.md |
| INT-005 | Bramka e-mail: wysłanie wiadomości | system/integrations/reklamacje/wyslanie-wiadomosci-email.md |
| INT-003 | Słownik adresów: wyszukiwanie adresu | system/integrations/rachunki/wyszukiwanie-adresu.md |
| INT-010 | Rejestr PESEL: weryfikacja numeru | system/integrations/rachunki/weryfikacja-pesel.md |
| INT-011 | System centralny: aktywacja rachunku | system/integrations/rachunki/aktywacja-rachunku.md |
| INT-012 | Lista sankcyjna: sprawdzenie osoby | system/integrations/rachunki/sprawdzenie-listy-sankcyjnej.md |
| QUE-001 | DispositionAccepted | system/asyncapi/dyspozycja-przyjeta.md |
| QUE-003 | ComplaintResolved | system/asyncapi/reklamacja-uznana.md |
| QUE-010 | AccountOpened | system/asyncapi/rachunek-otwarty.md |
| CONV-001 | Model odpowiedzi błędnej API | system/conventions/model-odpowiedzi-blednej-api.md |
| CONV-002 | Autentykacja API | system/conventions/autentykacja-api.md |
| CONV-003 | Ponawianie wywołań integracji | system/conventions/ponawianie-wywolan-integracji.md |
| CONV-004 | Nagłówki komunikatów | system/conventions/naglowki-komunikatow.md |
| NFR-001 | Wymagania jakościowe systemu | system/non-functional-requirements/wymagania-jakosciowe-systemu.md |
| NFR-002 | Bezpieczeństwo weryfikacji tożsamości | system/non-functional-requirements/bezpieczenstwo-weryfikacji-tozsamosci.md |

## system: przepływy, procesy, maszyny stanów

| doc-id | Tytuł | Nowa ścieżka |
|---|---|---|
| FLOW-001 | Przyjęcie dyspozycji — przebieg podstawowy | system/flows/przyjecie-dyspozycji.md |
| FLOW-002 | Przyjęcie dyspozycji — obsługa błędów | system/flows/przyjecie-dyspozycji-obsluga-bledow.md |
| FLOW-010 | Automatyczna weryfikacja tożsamości — przebieg podstawowy | system/flows/automatyczna-weryfikacja-tozsamosci.md |
| ACT-001 | Walidacja wejścia dyspozycji | system/flows/walidacja-wejscia-dyspozycji.md |
| ACT-002 | Zapis dyspozycji | system/flows/zapis-dyspozycji.md |
| ACT-003 | Odrzucenie dyspozycji | system/flows/odrzucenie-dyspozycji.md |
| ACT-010 | Ocena zgodności danych tożsamości | system/flows/ocena-zgodnosci-danych-tozsamosci.md |
| BPMS-001 | Rozliczenie dyspozycji | system/workflows/rozliczenie-dyspozycji/rozliczenie-dyspozycji.md |
| SPEC-WF-001 | Pobranie dyspozycji do rozliczenia | system/workflows/rozliczenie-dyspozycji/steps/pobranie-dyspozycji-do-rozliczenia.md |
| SPEC-WF-002 | Księgowanie pozycji | system/workflows/rozliczenie-dyspozycji/steps/ksiegowanie-pozycji.md |
| SPEC-WF-003 | Zamknięcie dnia rozliczeniowego | system/workflows/rozliczenie-dyspozycji/steps/zamkniecie-dnia-rozliczeniowego.md |
| BPMS-002 | Obsługa reklamacji | system/workflows/obsluga-reklamacji/obsluga-reklamacji.md |
| SPEC-WF-004 | Rejestracja reklamacji w procesie | system/workflows/obsluga-reklamacji/steps/rejestracja-reklamacji.md |
| SPEC-WF-005 | Rozpatrzenie reklamacji | system/workflows/obsluga-reklamacji/steps/rozpatrzenie-reklamacji.md |
| SPEC-WF-006 | Wyliczenie rekompensaty | system/workflows/obsluga-reklamacji/steps/wyliczenie-rekompensaty.md |
| SPEC-WF-007 | Publikacja decyzji reklamacyjnej | system/workflows/obsluga-reklamacji/steps/publikacja-decyzji-reklamacyjnej.md |
| SPEC-WF-008 | Wywołanie korekty rozliczenia | system/workflows/obsluga-reklamacji/steps/wywolanie-korekty-rozliczenia.md |
| BPMS-003 | Korekta rozliczenia po reklamacji | system/workflows/korekta-rozliczenia/korekta-rozliczenia.md |
| SPEC-WF-009 | Korekta księgowania dyspozycji | system/workflows/korekta-rozliczenia/steps/korekta-ksiegowania-dyspozycji.md |
| BPMS-004 | Eskalacja przeterminowanej reklamacji | system/workflows/eskalacja-reklamacji/eskalacja-reklamacji.md |
| SPEC-WF-010 | Powiadomienie kierownika o eskalacji | system/workflows/eskalacja-reklamacji/steps/powiadomienie-kierownika.md |
| BPMS-010 | Otwarcie rachunku | system/workflows/otwarcie-rachunku/otwarcie-rachunku.md |
| SPEC-WF-011 | Automatyczna weryfikacja tożsamości | system/workflows/otwarcie-rachunku/steps/automatyczna-weryfikacja-tozsamosci.md |
| SPEC-WF-012 | Ręczna weryfikacja tożsamości | system/workflows/otwarcie-rachunku/steps/reczna-weryfikacja-tozsamosci.md |
| SPEC-WF-013 | Otwarcie rachunku w systemie | system/workflows/otwarcie-rachunku/steps/otwarcie-rachunku-w-systemie.md |
| SPEC-WF-014 | Publikacja otwarcia rachunku | system/workflows/otwarcie-rachunku/steps/publikacja-otwarcia-rachunku.md |
| SPEC-WF-015 | Odrzucenie wniosku o rachunek | system/workflows/otwarcie-rachunku/steps/odrzucenie-wniosku.md |
| STM-001 | Cykl życia dyspozycji | system/state-machines/cykl-zycia-dyspozycji.md |
| STM-002 | Cykl życia reklamacji | system/state-machines/cykl-zycia-reklamacji.md |
| STM-003 | Cykl życia przebiegu rozliczenia | system/state-machines/cykl-zycia-przebiegu-rozliczenia.md |
| STM-004 | Cykl życia pozycji dyspozycji | system/state-machines/cykl-zycia-pozycji-dyspozycji.md |
| STM-010 | Cykl życia rachunku | system/state-machines/cykl-zycia-rachunku.md |
| STM-014 | Cykl życia lokaty | system/state-machines/cykl-zycia-lokaty.md |

## system: dane i ekrany

| doc-id | Tytuł | Nowa ścieżka |
|---|---|---|
| LDM-001 | Model logiczny dyspozycji | system/data-models/dyspozycje/model-logiczny-dyspozycji.md |
| ENT-Client | Klient | system/data-models/dyspozycje/client.md |
| ENT-Complaint | Reklamacja | system/data-models/dyspozycje/complaint.md |
| ENT-Disposition | Dyspozycja | system/data-models/dyspozycje/disposition.md |
| ENT-DispositionItem | Pozycja dyspozycji | system/data-models/dyspozycje/dispositionitem.md |
| ENT-StatusDict | Słownik statusów | system/data-models/dyspozycje/statusdict.md |
| LDM-002 | Model logiczny rachunków | system/data-models/rachunki/model-logiczny-rachunkow.md |
| LDM-003 | Model hurtowni rachunków | system/data-models/rachunki/model-hurtowni-rachunkow.md |
| ENT-Account | Rachunek | system/data-models/rachunki/account.md |
| ENT-AccountSnapshot | Stan dzienny rachunku | system/data-models/rachunki/accountsnapshot.md |
| ENT-Consent | Zgoda | system/data-models/rachunki/consent.md |
| ENT-Deposit | Lokata terminowa | system/data-models/rachunki/deposit.md |
| ENT-Product | Produkt | system/data-models/rachunki/product.md |
| SCR-001 | Ekran Dyspozycja: Krok 1 z 2 — Dane i pozycje | system/gui/screen/dyspozycja-dane-i-pozycje.md |
| SCR-002 | Ekran Dyspozycja: Krok 2 z 2 — Podsumowanie | system/gui/screen/dyspozycja-podsumowanie.md |
| SCR-003 | Ekran Korekta dyspozycji: Krok 1 z 2 — Edycja pozycji | system/gui/screen/korekta-dyspozycji-edycja-pozycji.md |
| SCR-004 | Ekran Reklamacja: Krok 1 z 1 — Zgłoszenie reklamacji | system/gui/screen/zgloszenie-reklamacji.md |
| SCR-005 | Ekran Reklamacje zaplecze: Krok 1 z 1 — Rozpatrzenie reklamacji | system/gui/screen/rozpatrzenie-reklamacji.md |
| SCR-010 | Ekran Konto: Krok 1 z 2 — Dane i produkt | system/gui/screen/konto-dane-i-produkt.md |
| SCR-011 | Ekran Konto: Krok 2 z 2 — Zgody i wysłanie | system/gui/screen/konto-zgody-i-wyslanie.md |
| SCR-012 | Ekran Weryfikacja zaplecze: Krok 1 z 1 — Weryfikacja tożsamości | system/gui/screen/weryfikacja-tozsamosci.md |
| SCRSEC-001 | Dane klienta | system/gui/screen/ui-spec/dane-klienta.md |
| SCRSEC-002 | Pozycje dyspozycji | system/gui/screen/ui-spec/pozycje-dyspozycji.md |
| SCRSEC-003 | Podsumowanie kwot | system/gui/screen/ui-spec/podsumowanie-kwot.md |
| SCRSEC-004 | Historia statusów | system/gui/screen/ui-spec/historia-statusow.md |
| SCRSEC-005 | Wybór dyspozycji | system/gui/screen/ui-spec/wybor-dyspozycji.md |
| SCRSEC-006 | Opis reklamacji | system/gui/screen/ui-spec/opis-reklamacji.md |
| SCRSEC-007 | Decyzja w sprawie reklamacji | system/gui/screen/ui-spec/decyzja-w-sprawie-reklamacji.md |
| SCRSEC-010 | Dane osobowe | system/gui/screen/ui-spec/dane-osobowe.md |
| SCRSEC-011 | Wybór produktu | system/gui/screen/ui-spec/wybor-produktu.md |
| SCRSEC-012 | Zgody | system/gui/screen/ui-spec/zgody.md |
| SCRSEC-013 | Dokument tożsamości | system/gui/screen/ui-spec/dokument-tozsamosci.md |
| NAV-001 | Obsługa dyspozycji: mapa nawigacyjna | system/gui/navigation-map/obsluga-dyspozycji.md |
| NAV-002 | Reklamacje dyspozycji: mapa nawigacyjna | system/gui/navigation-map/reklamacje-dyspozycji.md |
| NAV-010 | Otwarcie rachunku: mapa nawigacyjna | system/gui/navigation-map/otwarcie-rachunku.md |
