'use strict';

// Edycja dokumentów z interfejsu Warsztatu: spis szablonów typów, odczyt
// pliku Markdown do edytora i zapis. To jedyne miejsce, w którym serwer
// zapisuje w folderze dokumentacji. Zapis dotyczy wyłącznie pliku .md
// wskazanego w żądaniu, który leży w tym folderze.

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { REPO_ROOT } = require('../../../scripts/knowledge-index/sync');
const { DOC_FORMATS } = require('../../../scripts/lib/ids');
const { loadFolders } = require('../../../scripts/lib/folders');
const { TEMPLATES_DIR, loadTemplates } = require('../../../scripts/lib/templates');
const { layerOf } = require('./layers');

// Nazwa nowego pliku i nowego folderu według folders.yaml: małe litery,
// cyfry i myślniki; folder może mieć też podkreślenie (_shared).
const FILE_NAME = /^[a-z0-9]+(-[a-z0-9]+)*\.md$/;
const FOLDER_NAME = /^[a-z0-9_-]+$/;

const hashText = text => crypto.createHash('sha1').update(text).digest('hex');
const fail = (status, error, extra = {}) => ({ status, body: { error, ...extra } });
const repoPath = file => path.relative(REPO_ROOT, file).split(path.sep).join('/');

// Szablony typów ze standards/templates: nazwa typu (ostatni segment
// ścieżki z _00-meta.md), grupa i opis „Kiedy używać” ze spisu treści,
// folder dokumentów z folders.yaml i treść template.md do skopiowania.
function listTemplates() {
  const folders = loadFolders();
  const info = new Map();
  let group = null;
  for (const line of fs.readFileSync(path.join(TEMPLATES_DIR, '_00-meta.md'), 'utf8').split(/\r?\n/)) {
    const heading = /^###\s+(.+?)\s*$/.exec(line);
    if (heading) { group = heading[1]; continue; }
    const cells = line.split('|').slice(1, -1).map(cell => cell.trim());
    if (cells.length === 4 && /^`.+`$/.test(cells[0])) info.set(cells[2], { group, description: cells[3] });
  }
  return [...loadTemplates().values()].map(template => ({
    type: template.prefix, name: path.basename(template.folder), layer: layerOf(template.prefix),
    group: info.get(template.prefix)?.group || null, description: info.get(template.prefix)?.description || null,
    folder: folders.get(template.prefix)?.folder || null, subfolders: folders.get(template.prefix)?.subfolders || 'one',
    // Typ z numerem w doc-id (UC-001) dostaje w edytorze kolejny wolny numer; ENT ma nazwę.
    numbered: DOC_FORMATS[template.prefix] === '-\\d+',
    content: fs.readFileSync(template.file, 'utf8').replace(/^﻿/, ''),
  }));
}

// Plik Markdown ze ścieżki względem folderu repozytorium (jak `path`
// dokumentu w API), który leży w folderze dokumentacji. Zwraca pełną ścieżkę
// albo odpowiedź z błędem.
function resolveMarkdown(rootDir, requested) {
  const file = path.resolve(REPO_ROOT, String(requested || '').replace(/\\/g, '/'));
  const root = path.resolve(REPO_ROOT, rootDir);
  if (file !== root && !file.startsWith(root + path.sep)) return fail(400, 'Ścieżka leży poza folderem dokumentacji.');
  if (path.extname(file).toLowerCase() !== '.md') return fail(400, 'Edytować można tylko plik Markdown (.md).');
  return { file, root };
}

// Treść pliku do edytora ze skrótem treści; zapis sprawdza ten skrót.
function readText(rootDir, requested) {
  const resolved = resolveMarkdown(rootDir, requested);
  if (resolved.status) return resolved;
  const { file } = resolved;
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return fail(404, 'Nie ma takiego pliku w folderze dokumentacji.');
  const content = fs.readFileSync(file, 'utf8');
  return { path: repoPath(file), content, hash: hashText(content), size: Buffer.byteLength(content) };
}

// Zapis pliku. Nowy plik (create) nie może istnieć, a jego nazwa i nowe
// foldery trzymają zapis z folders.yaml. Istniejący plik jest zapisywany
// tylko wtedy, gdy baseHash zgadza się ze skrótem treści na dysku, czyli
// plik nie zmienił się od wczytania do edytora; zapis zachowuje końce linii
// i BOM pliku. Edytor przysyła treść z końcami linii LF.
function writeText(rootDir, { path: requested, content, baseHash, create }) {
  if (typeof content !== 'string') return fail(400, 'Treść (content) musi być tekstem.');
  const resolved = resolveMarkdown(rootDir, requested);
  if (resolved.status) return resolved;
  const { file, root } = resolved;
  const exists = fs.existsSync(file);
  if (create) {
    if (exists) return fail(409, 'Plik już istnieje. Wybierz inną nazwę.');
    const segments = path.relative(root, file).split(path.sep);
    if (!FILE_NAME.test(segments[segments.length - 1])) return fail(400, 'Nazwa pliku: małe litery, cyfry i myślniki, rozszerzenie .md.');
    const badFolder = segments.slice(0, -1).find(segment => !FOLDER_NAME.test(segment));
    if (badFolder) return fail(400, `Nazwa folderu „${badFolder}”: dozwolone są małe litery, cyfry, myślniki i podkreślenia.`);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, content.replace(/\r\n?/g, '\n'));
  } else {
    if (!exists || fs.statSync(file).isDirectory()) return fail(404, 'Nie ma takiego pliku w folderze dokumentacji.');
    const current = fs.readFileSync(file, 'utf8');
    if (baseHash && hashText(current) !== baseHash) {
      return fail(409, 'Plik zmienił się na dysku od wczytania do edytora. Wczytaj go ponownie i nanieś zmiany jeszcze raz.', { stale: true, hash: hashText(current) });
    }
    let text = content.replace(/\r\n?/g, '\n');
    if (current.includes('\r\n')) text = text.replace(/\n/g, '\r\n');
    if (current.startsWith('﻿') && !text.startsWith('﻿')) text = `﻿${text}`;
    fs.writeFileSync(file, text);
  }
  const saved = fs.readFileSync(file, 'utf8');
  return { path: repoPath(file), hash: hashText(saved), size: Buffer.byteLength(saved), created: Boolean(create) };
}

module.exports = { listTemplates, readText, writeText, hashText };
