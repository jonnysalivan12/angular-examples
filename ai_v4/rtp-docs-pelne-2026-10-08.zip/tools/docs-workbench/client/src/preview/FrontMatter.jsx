import { useState } from 'react';
import { plural } from '../components/TopBar';

// Front matter zwinięty do jednej linii z liczbą relacji (null: bez liczby);
// przycisk rozwija YAML z numerami linii pliku. Używany w podglądzie pliku
// na płótnie trybu Pliki i w edytorze.
export default function FrontMatter({ yaml, relations }) {
  const [open, setOpen] = useState(false);
  if (yaml === null) return null;
  return (
    <div className="fm-box">
      <div className="fm-line">
        <span className="m">---</span>
        <span>front matter{relations !== null ? ` · ${relations} ${plural(relations, 'relacja', 'relacje', 'relacji')}` : ''}</span>
        <button type="button" className="linkish" style={{ marginLeft: 'auto', color: 'var(--color-accent)' }} onClick={() => setOpen(value => !value)}>
          {open ? 'zwiń YAML' : 'rozwiń YAML'}
        </button>
      </div>
      {open && (
        <pre className="fm-yaml">
          {yaml.split(/\r?\n/).map((text, index) => <div key={index} className="fm-row"><span className="ln">{index + 2}</span>{text || ' '}</div>)}
        </pre>
      )}
    </div>
  );
}
