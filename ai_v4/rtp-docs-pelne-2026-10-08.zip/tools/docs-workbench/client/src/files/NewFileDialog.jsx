import { useEffect, useState } from 'react';
import { api, useData } from '../state/data';
import { TypeTag } from '../components/common';
import { Modal } from '../preview/FilePreview';
import { closeEditor, startNewFile } from './editor';
import { fitsFolder, nextDocId, withDocId } from './newFile';

// Pierwszy krok nowego dokumentu (menu folderu w drzewie trybu Pliki): wybór
// typu. Lista ma tylko typy, które według folders.yaml leżą w klikniętym
// folderze; folder bez typów pokazuje foldery typów poniżej. Po wyborze
// otwiera się edytor z treścią szablonu i kolejnym wolnym doc-id.
export default function NewFileDialog({ dir }) {
  const { graph } = useData();
  const [state, setState] = useState({ templates: null, error: null });

  useEffect(() => {
    let cancelled = false;
    api('/api/templates')
      .then(data => { if (!cancelled) setState({ templates: data.templates, error: null }); })
      .catch(error => { if (!cancelled) setState({ templates: null, error: error.message }); });
    return () => { cancelled = true; };
  }, []);

  const choose = template => startNewFile({ dir, template, content: withDocId(template.content, nextDocId(graph.documents, template)) });
  const templates = state.templates || [];
  const fitting = templates.filter(template => fitsFolder(dir, template));
  // Foldery typów pod klikniętym folderem: podpowiedź, gdy nic tu nie leży.
  const below = [...templates
    .filter(template => template.folder && template.folder.startsWith(`${dir}/`))
    .reduce((map, template) => map.set(template.folder, [...(map.get(template.folder) || []), template.type]), new Map())];
  const onKeyDown = event => {
    if (event.key !== 'Escape') return;
    event.stopPropagation();
    closeEditor();
  };

  return (
    <Modal label="Nowy dokument" onClose={closeEditor} width={760} className="editor-modal" onKeyDown={onKeyDown}>
      <div className="preview-head">
        <span style={{ fontSize: 14, fontWeight: 500 }}>Nowy dokument</span>
        <span className="m mu" style={{ fontSize: 11 }}>{graph.root}/{dir}</span>
        <div className="acts" style={{ marginLeft: 'auto' }}>
          <button type="button" className="btn btn-ghost" onClick={closeEditor}>Zamknij <span className="sk">Esc</span></button>
        </div>
      </div>
      <div className="dialog-body">
        {state.error && <div className="preview-note" style={{ color: 'var(--t-error)', padding: 0 }}>{state.error}</div>}
        {!state.templates && !state.error && <div className="preview-note" style={{ padding: 0 }}>Wczytywanie szablonów…</div>}
        {state.templates && fitting.length === 0 && (
          <div className="mu" style={{ fontSize: 12, lineHeight: 1.5 }}>
            Według folders.yaml żaden typ dokumentu nie leży w folderze <span className="m">{dir}</span>.
            {below.length > 0 && (
              <>
                {' '}Foldery typów poniżej:
                <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>
                  {below.map(([folder, types]) => <li key={folder}><span className="m">{folder}</span> · {types.join(', ')}</li>)}
                </ul>
              </>
            )}
          </div>
        )}
        {fitting.length > 0 && <TypeList title={`Typy dokumentów folderu ${dir}`} templates={fitting} onChoose={choose} autoFocus />}
      </div>
    </Modal>
  );
}

// Lista typów w grupach ze spisu treści szablonów (Wymagania, Scenariusze…).
function TypeList({ title, templates, onChoose, autoFocus }) {
  const names = [...new Set(templates.map(template => template.group || 'Inne'))];
  return (
    <div>
      <div className="k">{title}</div>
      {names.map((name, groupIndex) => (
        <div key={name}>
          <div className="type-group">{name}</div>
          {templates.filter(template => (template.group || 'Inne') === name).map((template, index) => (
            <button key={template.type} type="button" className="type-row" autoFocus={autoFocus && groupIndex === 0 && index === 0}
              title={`Szablon ${template.name}`} onClick={() => onChoose(template)}>
              <TypeTag type={template.type} layer={template.layer} />
              <span className="type-text">
                <span>{template.name}</span>
                <span className="mu">{template.description}</span>
              </span>
              <span className="m mu type-folder">{template.folder}</span>
            </button>
          ))}
        </div>
      ))}
    </div>
  );
}
