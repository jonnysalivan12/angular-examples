import { useEffect, useMemo, useRef, useState } from 'react';
import NavigatedViewer from 'bpmn-js/lib/NavigatedViewer';
import 'bpmn-js/dist/assets/diagram-js.css';
import 'bpmn-js/dist/assets/bpmn-js.css';
import { useData } from '../state/data';
import { navigate } from '../state/route';
import useNode, { vscodeLink } from '../state/useNode';
import { NodeActions } from '../components/NodeDetails';
import { Status, TypeTag, layerText, relPath } from '../components/common';
import FrontMatter from '../preview/FrontMatter';
import MarkdownView from '../preview/MarkdownView';
import { splitFrontMatter } from '../preview/markdown';
import { fileUrl } from '../workflow/model';
import { openEditor } from './editor';
import { useTree } from './useTree';
import { extensionOf, fileKind, findFile, formatSize } from './model';

// Płótno trybu Pliki: podgląd pliku wybranego w drzewie z panelu po lewej
// (files/FilesTree.jsx). Dokument z indeksu ma nagłówek i działania węzła
// jak w inspektorze (z przyciskiem Edytuj, który otwiera edytor w oknie);
// plik pomocniczy ma obraz, diagram BPMN albo tekst.

const toast = message => window.dispatchEvent(new CustomEvent('workbench:toast', { detail: message }));
const copy = text => navigator.clipboard?.writeText(text).then(() => toast(`Skopiowano ${text}`), () => toast('Nie udało się skopiować'));
const dirOf = filePath => (filePath.includes('/') ? filePath.slice(0, filePath.lastIndexOf('/')) : '');

export default function FilesCanvas({ params }) {
  const { data, error } = useTree();
  const tree = data?.tree;
  const file = useMemo(() => (tree && params.plik ? findFile(tree, params.plik) : null), [tree, params.plik]);
  if (error && !tree) return <div className="cv"><div className="cv-note" style={{ color: 'var(--t-error)' }}>{error}</div></div>;
  if (!tree) return <div className="cv"><div className="cv-note">Wczytywanie drzewa plików…</div></div>;
  return (
    <div className="cv files-cv">
      <PreviewPane file={file} root={data.root} missing={Boolean(params.plik) && !file} />
    </div>
  );
}

function PreviewPane({ file, root, missing }) {
  if (missing) return <div className="files-preview"><div className="cv-note">Nie ma takiego pliku w folderze dokumentacji.</div></div>;
  if (!file) return <div className="files-preview"><div className="cv-note">Kliknij plik w drzewie w panelu po lewej, żeby zobaczyć jego treść.</div></div>;
  const kind = fileKind(file.name);
  const repoPath = `${root}/${file.path}`;
  // Klucz wymusza nowy podgląd po zmianie pliku (stan rozmiaru obrazu, XML).
  if (file.docId) return <DocView key={file.path} file={file} root={root} />;
  if (kind === 'markdown') return <MarkdownFileView key={file.path} file={file} root={root} repoPath={repoPath} />;
  if (kind === 'image') return <ImageView key={file.path} file={file} root={root} repoPath={repoPath} />;
  if (kind === 'bpmn') return <BpmnView key={file.path} file={file} root={root} repoPath={repoPath} />;
  if (kind === 'text') return <TextView key={file.path} file={file} root={root} repoPath={repoPath} />;
  return (
    <div className="files-preview">
      <FileHead file={file} root={root} kind="plik" />
      <div className="files-body"><div className="preview-note">Podgląd tego rodzaju pliku nie jest dostępny. Otwórz plik w VS Code.</div></div>
    </div>
  );
}

// Nagłówek podglądu pliku pomocniczego: nazwa, ścieżka, rozmiar, VS Code.
function FileHead({ file, root, kind, info = null, actions = null }) {
  const { meta } = useData();
  const dir = dirOf(file.path);
  const link = vscodeLink(meta, { path: dir ? `${root}/${dir}` : root, fileName: file.name });
  return (
    <div className="files-head">
      <span className="chip mu">{kind}</span>
      <span style={{ fontSize: 14, fontWeight: 500 }}>{file.name}</span>
      <span className="m mu" style={{ fontSize: 11 }}>{file.path}</span>
      <span className="mu" style={{ fontSize: 11 }}>{formatSize(file.size)}{info ? ` · ${info}` : ''}</span>
      <div className="acts" style={{ marginLeft: 'auto' }}>
        {actions}
        {link && <a className="btn btn-primary" href={link}>Otwórz w VS Code</a>}
        <button type="button" className="btn btn-ghost" onClick={() => copy(`${root}/${file.path}`)}>Kopiuj ścieżkę</button>
      </div>
    </div>
  );
}

// Treść pliku tekstowego z /api/file; pobierana ponownie po zmianie danych.
function useFileText(repoPath) {
  const { graph } = useData();
  const [state, setState] = useState({ path: null, text: null, error: null });
  useEffect(() => {
    let cancelled = false;
    fetch(fileUrl(repoPath))
      .then(async response => {
        if (!response.ok) throw new Error(`plik nie jest dostępny (${response.status})`);
        return response.text();
      })
      .then(text => { if (!cancelled) setState({ path: repoPath, text, error: null }); })
      .catch(error => { if (!cancelled) setState({ path: repoPath, text: null, error: error.message }); });
    return () => { cancelled = true; };
  }, [repoPath, graph?.version]);
  return state.path === repoPath ? state : { path: repoPath, text: null, error: null };
}

// Dokument z indeksu: nagłówek jak w inspektorze, działania węzła i treść.
function DocView({ file, root }) {
  const { nodeInfo, graph } = useData();
  const { node, error } = useNode(file.docId);
  const { yaml, body, bodyLine } = useMemo(() => splitFrontMatter(node?.content), [node?.content]);
  if (error) return <div className="files-preview"><FileHead file={file} root={root} kind="md" /><div className="files-body"><div className="preview-note">{file.docId}: {error}</div></div></div>;
  if (!node) return <div className="files-preview"><FileHead file={file} root={root} kind="md" /><div className="files-body"><div className="preview-note">Wczytywanie {file.docId}…</div></div></div>;
  const layer = nodeInfo(node.docId)?.layer || node.layer;
  return (
    <div className="files-preview">
      <div className="files-head">
        <TypeTag type={nodeInfo(node.docId)?.type || node.type} layer={layer} />
        <span className="m" style={{ fontSize: 13, fontWeight: 500, color: layerText(layer) }}>{node.docId}</span>
        <span style={{ fontSize: 14, fontWeight: 500 }}>{node.title}</span>
        <Status status={node.status} />
        {node.owner && <span className="mu" style={{ fontSize: 12 }}>{node.owner}</span>}
        <span className="m mu" style={{ fontSize: 11 }}>{relPath(node, graph)} · {formatSize(file.size)}</span>
        <div style={{ marginLeft: 'auto' }}>
          <NodeActions node={node} onCopy={copy} extra={<button type="button" className="btn btn-ghost" onClick={() => navigate({ podglad: '1' }, { replace: true })}>Podgląd w oknie <span className="sk">Space</span></button>} />
        </div>
      </div>
      <div className="files-body">
        <div className="preview-content">
          <FrontMatter yaml={yaml} relations={node.outgoing.length} />
          <MarkdownView body={body} bodyLine={bodyLine} docId={node.docId} />
        </div>
      </div>
    </div>
  );
}

// Plik Markdown spoza indeksu (bez doc-id): treść bez ID w nagłówku.
function MarkdownFileView({ file, root, repoPath }) {
  const { text, error } = useFileText(repoPath);
  const { yaml, body, bodyLine } = useMemo(() => splitFrontMatter(text), [text]);
  return (
    <div className="files-preview">
      <FileHead file={file} root={root} kind="md" info="bez doc-id"
        actions={<button type="button" className="btn btn-secondary" onClick={() => openEditor({ repoPath })}>Edytuj</button>} />
      <div className="files-body">
        {error && <div className="preview-note">{error}</div>}
        {text !== null && (
          <div className="preview-content">
            <FrontMatter yaml={yaml} relations={null} />
            <MarkdownView body={body} bodyLine={bodyLine} docId={null} />
          </div>
        )}
      </div>
    </div>
  );
}

function ImageView({ file, root, repoPath }) {
  const [natural, setNatural] = useState(false);
  const [size, setSize] = useState(null);
  return (
    <div className="files-preview">
      <FileHead file={file} root={root} kind={extensionOf(file.name)} info={size}
        actions={<button type="button" className="btn btn-secondary" onClick={() => setNatural(value => !value)}>{natural ? 'Dopasuj do okna' : 'Rozmiar naturalny'}</button>} />
      <div className="files-body is-image">
        <img src={fileUrl(repoPath)} alt={file.name} className={natural ? 'is-natural' : ''} onClick={() => setNatural(value => !value)}
          onLoad={event => setSize(`${event.currentTarget.naturalWidth} × ${event.currentTarget.naturalHeight} px`)} />
      </div>
    </div>
  );
}

// Diagram BPMN z pliku XML (bpmn-js, tylko do odczytu) albo sam XML.
function BpmnView({ file, root, repoPath }) {
  const { text, error } = useFileText(repoPath);
  const [xmlShown, setXmlShown] = useState(false);
  const [importError, setImportError] = useState(null);
  const container = useRef(null);
  useEffect(() => {
    if (text === null || xmlShown || !container.current) return undefined;
    let cancelled = false;
    const styles = getComputedStyle(container.current);
    const viewer = new NavigatedViewer({
      container: container.current,
      bpmnRenderer: {
        defaultFillColor: styles.getPropertyValue('--color-surface').trim() || '#ffffff',
        defaultStrokeColor: styles.getPropertyValue('--color-text').trim() || '#1f2130',
        defaultLabelColor: styles.getPropertyValue('--color-text').trim() || '#1f2130',
      },
    });
    viewer.importXML(text)
      .then(() => { if (!cancelled) viewer.get('canvas').zoom('fit-viewport', 'auto'); })
      .catch(reason => { if (!cancelled) setImportError(reason.message || String(reason)); });
    return () => { cancelled = true; viewer.destroy(); };
  }, [text, xmlShown]);
  return (
    <div className="files-preview">
      <FileHead file={file} root={root} kind="bpmn"
        actions={<button type="button" className="btn btn-secondary" onClick={() => setXmlShown(value => !value)}>{xmlShown ? 'Diagram' : 'XML'}</button>} />
      {xmlShown
        ? <div className="files-body">{error ? <div className="preview-note">{error}</div> : <pre className="files-text">{text}</pre>}</div>
        : (
          <div className="files-body is-bpmn">
            <div className="files-bpmn" ref={container} />
            {(error || importError) && <div className="cv-note" style={{ color: 'var(--t-error)' }}>Nie udało się wczytać diagramu BPMN: {error || importError}</div>}
          </div>
        )}
    </div>
  );
}

function TextView({ file, root, repoPath }) {
  const { text, error } = useFileText(repoPath);
  return (
    <div className="files-preview">
      <FileHead file={file} root={root} kind={extensionOf(file.name)} />
      <div className="files-body">
        {error && <div className="preview-note">{error}</div>}
        {text !== null && <pre className="files-text">{text}</pre>}
      </div>
    </div>
  );
}
