import { useEffect, useState } from 'react';
import { api, useData } from '../state/data';

// Drzewo plików z /api/tree. Serwer liczy je przy każdym żądaniu, więc hook
// pobiera je przy wejściu w tryb i po każdej zmianie wersji danych; do tego
// czasu pokazuje ostatnie znane drzewo.
let last = null;

export function useTree() {
  const { graph } = useData();
  const version = graph?.version ?? null;
  const [state, setState] = useState(() => ({ data: last, error: null }));

  useEffect(() => {
    if (version === null) return undefined;
    let cancelled = false;
    api('/api/tree')
      .then(data => { last = data; if (!cancelled) setState({ data, error: null }); })
      .catch(error => { if (!cancelled) setState({ data: last, error: error.message }); });
    return () => { cancelled = true; };
  }, [version]);

  return state;
}
