import { useSyncExternalStore } from 'react';

// Stan edytora pliku Markdown (jeden dla całej aplikacji, poza adresem, bo
// niezapisanej treści nie da się odtworzyć z adresu):
//   choose  okno wyboru typu nowego dokumentu w folderze dir (względem
//           folderu dokumentacji),
//   new     edytor nowego dokumentu z treścią szablonu; plik powstaje przy
//           pierwszym zapisie,
//   edit    edytor istniejącego pliku ze ścieżką względem folderu repozytorium.
// App rysuje okno (files/EditorHost.jsx); id rośnie z każdym otwarciem, żeby
// nowe otwarcie zaczynało od świeżego stanu.

let state = null;
let counter = 0;
const listeners = new Set();
const emit = () => listeners.forEach(listener => listener());
const open = next => { state = { ...next, id: ++counter }; emit(); };

export const openNewFileDialog = dir => open({ kind: 'choose', dir });
export const startNewFile = ({ dir, template, content }) => open({ kind: 'new', dir, template, content });
export const openEditor = ({ repoPath, docId = null, type = null }) => open({ kind: 'edit', repoPath, docId, type });

export function closeEditor() {
  if (!state) return;
  state = null;
  emit();
}

export const useEditorState = () => useSyncExternalStore(listener => { listeners.add(listener); return () => listeners.delete(listener); }, () => state);
