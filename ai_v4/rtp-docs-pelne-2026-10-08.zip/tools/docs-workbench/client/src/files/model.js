import { listParam } from '../state/route';

// Model trybu Pliki: które foldery są rozwinięte, które pliki pasują do
// filtra i jaki podgląd ma plik. Drzewo przychodzi z /api/tree: folder ma
// children, documents (pliki z ID) i files (wszystkie pliki, także w
// podfolderach), plik ma path względem folderu dokumentacji, size i docId.

// Foldery rozwinięte domyślnie: warstwa (functional) i folder typu
// (functional/use-cases). Folder procesu albo ekranu rozwija klik.
export const DEFAULT_DEPTH = 2;
export const folderDepth = folder => folder.split('/').length;

export function allFolders(tree) {
  const out = [];
  (function walk(node) {
    for (const child of node.children) if (child.kind === 'dir') { out.push(child.path); walk(child); }
  })(tree);
  return out;
}

// Foldery nadrzędne pliku: „a/b/c.md” daje „a” i „a/b”.
export function ancestors(filePath) {
  const parts = filePath.split('/').slice(0, -1);
  return parts.map((_, index) => parts.slice(0, index + 1).join('/'));
}

// Rozwinięte foldery z adresu (otwarte: lista albo „brak”), domyślnie do
// DEFAULT_DEPTH; foldery nad wybranym plikiem są zawsze rozwinięte.
export function expandedSet(tree, params) {
  let base;
  if (params.otwarte === 'brak') base = new Set();
  else if (params.otwarte) base = new Set(listParam(params.otwarte));
  else base = new Set(allFolders(tree).filter(folder => folderDepth(folder) <= DEFAULT_DEPTH));
  for (const folder of ancestors(params.plik || '')) base.add(folder);
  return base;
}

export function findFile(tree, filePath) {
  for (const child of tree.children) {
    if (child.kind === 'file' && child.path === filePath) return child;
    if (child.kind === 'dir' && filePath.startsWith(`${child.path}/`)) return findFile(child, filePath);
  }
  return null;
}

// Rodzaj podglądu według rozszerzenia; pozostałe pliki tylko do otwarcia w VS Code.
const KINDS = {
  md: 'markdown',
  png: 'image', jpg: 'image', jpeg: 'image', gif: 'image', webp: 'image', svg: 'image',
  bpmn: 'bpmn',
  txt: 'text', yaml: 'text', yml: 'text', json: 'text', csv: 'text',
};
export const extensionOf = name => (name.includes('.') ? name.slice(name.lastIndexOf('.') + 1).toLowerCase() : '');
export const fileKind = name => KINDS[extensionOf(name)] || 'other';

// Drzewo po filtrze: plik pasuje nazwą, ID dokumentu albo tytułem; folder
// zostaje, gdy ma pasujący plik albo sam pasuje nazwą. Liczby documents
// i files folderu zostają z pełnego drzewa.
export function filterTree(tree, phrase, onlyDocs, docIndex) {
  const needle = phrase.trim().toLowerCase();
  const matches = file => {
    if (!needle) return true;
    const doc = file.docId ? docIndex.get(file.docId) : null;
    return file.name.toLowerCase().includes(needle)
      || (file.docId || '').toLowerCase().includes(needle)
      || (doc?.title || '').toLowerCase().includes(needle);
  };
  const walk = node => {
    const children = [];
    for (const child of node.children) {
      if (child.kind === 'dir') {
        const sub = walk(child);
        if (sub.children.length || (needle && child.name.toLowerCase().includes(needle))) children.push(sub);
      } else if ((!onlyDocs || child.docId) && matches(child)) {
        children.push(child);
      }
    }
    return { ...node, children };
  };
  return walk(tree);
}

export const formatSize = bytes => (bytes < 1024 ? `${bytes} B`
  : bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(bytes < 10240 ? 1 : 0)} KB`
    : `${(bytes / 1024 / 1024).toFixed(1)} MB`);
