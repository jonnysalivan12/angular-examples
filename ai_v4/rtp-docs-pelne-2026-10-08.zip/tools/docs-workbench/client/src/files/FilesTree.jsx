import { useEffect, useMemo, useRef } from 'react';
import { useData } from '../state/data';
import { navigate } from '../state/route';
import { TypeTag, layerText } from '../components/common';
import { openFolderMenu, openNodeMenu } from '../components/NodeMenu';
import { plural } from '../components/TopBar';
import { useTree } from './useTree';
import { expandedSet, extensionOf, filterTree } from './model';

// Drzewo folderu dokumentacji w panelu po lewej (tryb Pliki). Dokument
// (plik z indeksu) ma ID i typ: klik zaznacza go też w inspektorze, dwuklik
// otwiera podgląd w oknie, prawy klik menu węzła. Klik w otwarty plik zamyka
// jego podgląd (zaznaczenie w inspektorze zostaje); zwinięcie folderu, w którym
// leży otwarty plik, też zamyka podgląd. Prawy klik na folderze otwiera menu
// folderu (nowy dokument z szablonu). Rozwinięte foldery (otwarte) i wybrany
// plik (plik) są w adresie.
export default function FilesTree({ params }) {
  const { docIndex } = useData();
  const { data, error } = useTree();
  const tree = data?.tree;
  const phrase = params.fraza || '';
  const onlyDocs = params.pliki === 'dokumenty';
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const expanded = useMemo(() => (tree ? expandedSet(tree, params) : new Set()), [tree, params.otwarte, params.plik]);
  const shown = useMemo(() => (tree ? filterTree(tree, phrase, onlyDocs, docIndex) : null), [tree, phrase, onlyDocs, docIndex]);

  const toggle = folder => {
    const next = new Set(expanded);
    const closing = next.has(folder);
    if (closing) next.delete(folder); else next.add(folder);
    // Foldery nad otwartym plikiem są zawsze rozwinięte (expandedSet), więc
    // zwinięcie folderu z otwartym plikiem zamyka też podgląd tego pliku.
    const closesFile = closing && Boolean(params.plik) && params.plik.startsWith(`${folder}/`);
    navigate({ otwarte: next.size ? [...next].sort().join(',') : 'brak', ...(closesFile ? { plik: undefined } : {}) }, { replace: true });
  };
  const pick = (item, event) => {
    // Drugi klik dwukliku (detail 2) nie zamyka podglądu, bo dwuklik otwiera okno.
    if (event?.detail > 1) return;
    if (params.plik === item.path) { navigate({ plik: undefined }, { replace: true }); return; }
    navigate({ plik: item.path, ...(item.docId ? { sel: item.docId } : {}), podglad: undefined }, { replace: true });
  };

  return (
    <div className="files-tree-section">
      <div className="k"><span>Drzewo</span>{data && <b>{data.root}</b>}</div>
      {error && !tree && <div className="mu" style={{ fontSize: 11.5, color: 'var(--t-error)' }}>{error}</div>}
      {!tree && !error && <div className="mu" style={{ fontSize: 11.5 }}>Wczytywanie drzewa plików…</div>}
      {shown && <TreePane tree={shown} expanded={expanded} filtering={phrase.trim().length > 0} selected={params.plik} onToggle={toggle} onPick={pick} />}
    </div>
  );
}

function TreePane({ tree, expanded, filtering, selected, onToggle, onPick }) {
  const ref = useRef(null);
  useEffect(() => {
    ref.current?.querySelector('.files-row.is-active')?.scrollIntoView({ block: 'nearest' });
  }, [selected]);

  // Strzałki: góra i dół przechodzą między wierszami, prawo rozwija folder, lewo zwija.
  const onKeyDown = event => {
    if (!['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    const rows = [...ref.current.querySelectorAll('.files-row')];
    const index = rows.indexOf(document.activeElement);
    if (index === -1) return;
    event.preventDefault();
    const row = rows[index];
    if (event.key === 'ArrowDown') rows[Math.min(index + 1, rows.length - 1)].focus();
    else if (event.key === 'ArrowUp') rows[Math.max(index - 1, 0)].focus();
    else if (row.dataset.dir !== undefined) {
      const open = row.getAttribute('aria-expanded') === 'true';
      if ((event.key === 'ArrowRight' && !open) || (event.key === 'ArrowLeft' && open)) onToggle(row.dataset.dir);
    }
  };

  return (
    <div className="files-tree" ref={ref} onKeyDown={onKeyDown} aria-label="Drzewo plików">
      {tree.children.length === 0 && <div className="mu" style={{ padding: '6px 8px', fontSize: 11.5 }}>Żaden plik nie pasuje do filtra.</div>}
      {tree.children.map(child => (
        <TreeNode key={child.path} node={child} depth={0} expanded={expanded} filtering={filtering} selected={selected} onToggle={onToggle} onPick={onPick} />
      ))}
    </div>
  );
}

function TreeNode({ node, depth, expanded, filtering, selected, onToggle, onPick }) {
  const { docIndex } = useData();
  const indent = { paddingLeft: 4 + depth * 12 };
  if (node.kind === 'dir') {
    // Przy filtrze każdy folder z wynikiem jest rozwinięty.
    const open = filtering || expanded.has(node.path);
    return (
      <div>
        <button type="button" className="files-row is-dir" style={indent} aria-expanded={open} data-dir={node.path} title={node.path}
          onClick={() => onToggle(node.path)} onContextMenu={event => openFolderMenu(event, node.path)}>
          <span className="chev">{open ? '▾' : '▸'}</span>
          <span className="name">{node.name}</span>
          {node.documents > 0 && <span className="cnt" title={`${node.documents} ${plural(node.documents, 'dokument', 'dokumenty', 'dokumentów')}`}>{node.documents}</span>}
        </button>
        {open && node.children.map(child => (
          <TreeNode key={child.path} node={child} depth={depth + 1} expanded={expanded} filtering={filtering} selected={selected} onToggle={onToggle} onPick={onPick} />
        ))}
      </div>
    );
  }
  const doc = node.docId ? docIndex.get(node.docId) : null;
  return (
    <button type="button" className={`files-row ${selected === node.path ? 'is-active' : ''}`} style={indent} title={doc ? `${doc.id} · ${doc.title}` : node.path}
      onClick={event => onPick(node, event)}
      onDoubleClick={() => node.docId && navigate({ plik: node.path, sel: node.docId, podglad: '1' }, { replace: true })}
      onContextMenu={event => node.docId && openNodeMenu(event, node.docId)}>
      <span className="chev" />
      {doc ? <TypeTag type={doc.type} layer={doc.layer} /> : <span className="chip mu">{extensionOf(node.name) || 'plik'}</span>}
      <span className="name">{node.name}</span>
      {doc && <span className="cnt" style={{ color: layerText(doc.layer) }}>{doc.id}</span>}
    </button>
  );
}
