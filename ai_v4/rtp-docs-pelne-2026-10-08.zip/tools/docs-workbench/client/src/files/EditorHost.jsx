import { useData } from '../state/data';
import { useEditorState } from './editor';
import EditorModal from './EditorModal';
import NewFileDialog from './NewFileDialog';

// Okno edytora albo wyboru typu nowego dokumentu, zależnie od stanu
// w files/editor.js. Klucz z id wymusza świeży stan przy każdym otwarciu.
export default function EditorHost() {
  const editor = useEditorState();
  const { graph } = useData();
  if (!editor || !graph) return null;
  if (editor.kind === 'choose') return <NewFileDialog key={editor.id} dir={editor.dir} />;
  return <EditorModal key={editor.id} editor={editor} />;
}
