import { useEffect, useMemo, useRef, useState } from 'react';
import { useData } from '../state/data';
import { navigate } from '../state/route';
import { TypeTag, layerText } from '../components/common';
import { Modal } from '../preview/FilePreview';
import FrontMatter from '../preview/FrontMatter';
import MarkdownView from '../preview/MarkdownView';
import { splitFrontMatter } from '../preview/markdown';
import { closeEditor } from './editor';
import { FILE_STEM, docIdOf, targetDir } from './newFile';

// Edytor pliku Markdown w oknie nad płótnem: tekst po lewej, podgląd po
// prawej (jak w oknie podglądu, odświeżany w trakcie pisania). Istniejący
// plik przychodzi z /api/edit ze skrótem treści; zapis ze skrótem innym niż
// na dysku jest odrzucany, bo plik zmienił się poza Warsztatem. Nowy plik
// (z menu folderu) ma treść szablonu i dostaje nazwę w nagłówku; powstaje
// na dysku przy pierwszym zapisie, a potem edytor pracuje na nim jak na
// istniejącym. Ctrl+S zapisuje, Esc zamyka (z pytaniem, gdy są zmiany).

const PREVIEW_KEY = 'workbench.editor.preview';
const toast = message => window.dispatchEvent(new CustomEvent('workbench:toast', { detail: message }));
const storedPreview = () => { try { return localStorage.getItem(PREVIEW_KEY) !== '0'; } catch { return true; } };
const baseName = repoPath => repoPath.slice(repoPath.lastIndexOf('/') + 1);

async function request(path, body) {
  const response = await fetch(path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined);
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

export default function EditorModal({ editor }) {
  const { graph, docIndex, nodeInfo } = useData();
  const isNew = editor.kind === 'new';
  // file: plik na dysku ze skrótem treści z chwili wczytania albo zapisu; null dla nowego, jeszcze niezapisanego.
  const [file, setFile] = useState(null);
  const [text, setText] = useState(isNew ? editor.content : '');
  // savedText: treść z dysku; null, dopóki nowy plik nie powstał albo istniejący się nie wczytał.
  const [savedText, setSavedText] = useState(null);
  const [name, setName] = useState('');
  const [loadError, setLoadError] = useState(null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [previewOn, setPreviewOn] = useState(storedPreview);
  const [previewText, setPreviewText] = useState(text);
  const textRef = useRef(null);

  // Wczytanie z dysku: przy otwarciu istniejącego pliku i na żądanie po
  // odrzuconym zapisie (także pliku utworzonego w tym oknie).
  const load = async () => {
    const result = await request(`/api/edit?path=${encodeURIComponent(file?.repoPath || editor.repoPath)}`);
    if (!result.ok) {
      const message = result.data.error || `Błąd serwera (${result.status})`;
      if (savedText === null) setLoadError(message); else setError({ message, stale: false });
      return;
    }
    setFile({ repoPath: result.data.path, hash: result.data.hash });
    setText(result.data.content);
    setPreviewText(result.data.content);
    setSavedText(result.data.content);
    setError(null);
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (!isNew) load(); }, [editor.id]);

  // Podgląd odświeża się chwilę po ostatnim znaku.
  useEffect(() => {
    const timer = setTimeout(() => setPreviewText(text), 150);
    return () => clearTimeout(timer);
  }, [text]);
  useEffect(() => {
    try { localStorage.setItem(PREVIEW_KEY, previewOn ? '1' : '0'); } catch { /* brak dostępu do localStorage */ }
  }, [previewOn]);
  // Istniejący plik: fokus w tekście po wczytaniu. Nowy: fokus w polu nazwy (autoFocus).
  useEffect(() => {
    if (!isNew && savedText !== null) requestAnimationFrame(() => textRef.current?.focus());
  }, [isNew, savedText]);

  const dirty = savedText === null ? true : text !== savedText;
  // Zamknięcie karty z niezapisanymi zmianami pyta, jak edytor tekstu.
  useEffect(() => {
    if (!dirty || loadError) return undefined;
    const onBeforeUnload = event => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [dirty, loadError]);

  const stem = name.trim();
  const newDir = isNew && !file ? targetDir(editor.dir, editor.template, FILE_STEM.test(stem) ? stem : '') : null;
  const newPath = newDir !== null ? `${graph.root}/${newDir}/${stem || '{nazwa-pliku}'}.md` : null;
  const nameValid = FILE_STEM.test(stem);
  const canSave = !busy && !loadError && (file ? dirty : nameValid);

  const save = async () => {
    if (!canSave) return;
    setBusy(true);
    try {
      const body = file ? { path: file.repoPath, content: text, baseHash: file.hash } : { path: newPath, content: text, create: true };
      const result = await request('/api/edit', body);
      if (!result.ok) { setError({ message: result.data.error || `Błąd serwera (${result.status})`, stale: Boolean(result.data.stale) }); return; }
      const created = !file;
      setFile({ repoPath: result.data.path, hash: result.data.hash });
      setSavedText(text);
      setError(null);
      if (created) {
        const docId = docIdOf(text);
        navigate({ mode: 'files', plik: result.data.path.slice(graph.root.length + 1), ...(docId ? { sel: docId } : {}), podglad: undefined }, { replace: true });
        toast(`Utworzono ${result.data.path}`);
      } else {
        toast(`Zapisano ${baseName(result.data.path)}`);
      }
    } catch (reason) {
      setError({ message: reason.message, stale: false });
    } finally {
      setBusy(false);
    }
  };

  const close = () => {
    if (dirty && !loadError && !window.confirm('Odrzucić niezapisane zmiany?')) return;
    closeEditor();
  };

  const onKeyDown = event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') { event.preventDefault(); event.stopPropagation(); save(); return; }
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); }
  };
  // Tab w tekście wstawia dwie spacje, zamiast przenosić fokus.
  const onTextKeyDown = event => {
    if (event.key !== 'Tab' || event.shiftKey) return;
    event.preventDefault();
    const element = event.currentTarget;
    const { selectionStart, selectionEnd } = element;
    setText(`${text.slice(0, selectionStart)}  ${text.slice(selectionEnd)}`);
    requestAnimationFrame(() => element.setSelectionRange(selectionStart + 2, selectionStart + 2));
  };

  const { yaml, body, bodyLine } = useMemo(() => splitFrontMatter(previewText), [previewText]);
  const contentDocId = useMemo(() => docIdOf(previewText), [previewText]);
  const docId = editor.docId || contentDocId;
  const type = isNew ? editor.template.type : docIndex.get(editor.docId)?.type || editor.type;
  const layer = isNew ? editor.template.layer : nodeInfo(editor.docId)?.layer;
  const label = file ? `Edycja ${baseName(file.repoPath)}` : 'Nowy dokument';

  return (
    <Modal label={label} onClose={close} className="editor-modal" onKeyDown={onKeyDown}>
      <div className="preview-head">
        {type && <TypeTag type={type} layer={layer} />}
        {docId && <span className="m" style={{ fontSize: 13, fontWeight: 500, color: layerText(layer) }}>{docId}</span>}
        {file
          ? <span style={{ fontSize: 14, fontWeight: 500 }}>{baseName(file.repoPath)}</span>
          : (
            <label className="editor-name">
              <input className="sel" value={name} placeholder="nazwa-pliku" spellCheck={false} autoFocus aria-label="Nazwa pliku"
                onChange={event => setName(event.target.value)} onKeyDown={event => { if (event.key === 'Enter' && nameValid) textRef.current?.focus(); }} />
              <span className="mu">.md</span>
            </label>
          )}
        <span className="m mu" style={{ fontSize: 11 }}>{file ? file.repoPath : newPath}</span>
        <span className={`editor-state ${dirty ? 'is-dirty' : ''}`}>
          {!file ? (nameValid ? 'nowy plik, jeszcze niezapisany' : 'podaj nazwę: małe litery, cyfry i myślniki') : dirty ? 'niezapisane zmiany' : 'zapisano'}
        </span>
        <div className="acts" style={{ marginLeft: 'auto' }}>
          <button type="button" className="btn btn-ghost" onClick={() => setPreviewOn(value => !value)}>{previewOn ? 'Ukryj podgląd' : 'Podgląd'}</button>
          <button type="button" className="btn btn-primary" disabled={!canSave} onClick={save}>{busy ? 'Zapisywanie…' : 'Zapisz'} <span className="sk">Ctrl S</span></button>
          <button type="button" className="btn btn-ghost" onClick={close}>Zamknij <span className="sk">Esc</span></button>
        </div>
      </div>
      {error && (
        <div className="editor-error" role="alert">
          <span>{error.message}</span>
          {error.stale && <button type="button" className="btn btn-secondary" onClick={() => { if (window.confirm('Odrzucić własne zmiany i wczytać plik z dysku?')) load(); }}>Wczytaj z dysku</button>}
        </div>
      )}
      {loadError && <div className="preview-note" style={{ color: 'var(--t-error)' }}>{editor.repoPath}: {loadError}</div>}
      {!loadError && (
        <div className={`editor-body ${previewOn ? 'is-split' : ''}`}>
          <textarea ref={textRef} className="editor-text" value={text} spellCheck={false} aria-label="Treść pliku"
            disabled={!isNew && savedText === null} placeholder={!isNew && savedText === null ? 'Wczytywanie…' : ''}
            onChange={event => setText(event.target.value)} onKeyDown={onTextKeyDown} />
          {previewOn && (
            <div className="preview-scroll editor-preview">
              <div className="preview-content">
                <FrontMatter yaml={yaml} relations={null} />
                <MarkdownView body={body} bodyLine={bodyLine} docId={docIndex.has(docId) ? docId : null} />
              </div>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}
