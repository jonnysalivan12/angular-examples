// Nowy dokument z szablonu (menu folderu w drzewie trybu Pliki).

// Nazwa pliku bez rozszerzenia według folders.yaml: małe litery, cyfry i myślniki.
export const FILE_STEM = /^[a-z0-9]+(-[a-z0-9]+)*$/;

// Kolejny wolny doc-id typu: największy numer z indeksu plus jeden, z zerami
// do trzech cyfr (UC-009). Typ z nazwą w doc-id (ENT) zostaje z placeholderem.
export function nextDocId(documents, template) {
  if (!template.numbered) return null;
  const numbers = documents
    .filter(doc => doc.type === template.type)
    .map(doc => Number(doc.id.slice(template.type.length + 1)))
    .filter(Number.isFinite);
  const next = (numbers.length ? Math.max(...numbers) : 0) + 1;
  return `${template.type}-${String(next).padStart(3, '0')}`;
}

// Treść szablonu z wpisanym doc-id (linia doc-id: we front matter).
export const withDocId = (content, id) => (id ? content.replace(/^(doc-id:\s*).*$/m, (line, prefix) => `${prefix}${id}`) : content);

// doc-id z treści, gdy jest pełnym ID bez placeholdera w nawiasach klamrowych.
export function docIdOf(content) {
  const match = /^doc-id:\s*"?([^"\s#]+)"?/m.exec(content || '');
  if (!match || /[{}]/.test(match[1])) return null;
  return /^[A-Z][A-Z-]*-[\p{L}\p{N}]+$/u.test(match[1]) ? match[1] : null;
}

// Czy dokument typu może leżeć w folderze z drzewa (ścieżka względem folderu
// dokumentacji) według folders.yaml: w folderze typu albo w podfolderze, na
// który pozwala reguła subfolders (folder procesu i jego steps/, folder
// ekranu i jego ui-specs/, jeden podfolder o dowolnej nazwie).
export function fitsFolder(dir, template) {
  const { folder, subfolders } = template;
  if (!folder || !(dir === folder || dir.startsWith(`${folder}/`))) return false;
  const rest = dir === folder ? [] : dir.slice(folder.length + 1).split('/');
  switch (subfolders) {
    case 'none': return rest.length === 0;
    case 'steps': return rest.length === 1 || (rest.length === 2 && rest[1] === 'steps');
    case 'sections': return rest.length === 1 || (rest.length === 2 && rest[1] === 'ui-specs');
    default: return rest.length <= 1;
  }
}

// Folder nowego pliku: kliknięty folder (okno wyboru typu podaje tylko typy,
// które w nim leżą; folder typu z folders.yaml to zabezpieczenie dla innych
// wywołań). Reguła podfolderów typu dokłada podfolder:
//   process, screen  plik w podfolderze nazwanym jak plik (system/workflows/{nazwa}/),
//   steps            krok w podfolderze steps folderu procesu,
//   sections         sekcja w podfolderze ui-specs folderu ekranu.
export function targetDir(dir, template, stem) {
  const base = fitsFolder(dir, template) ? dir : template.folder || dir;
  const rule = template.subfolders;
  const inTypeFolder = base === template.folder;
  const childOfType = base.startsWith(`${template.folder}/`) && !base.slice(template.folder.length + 1).includes('/');
  if ((rule === 'process' || rule === 'screen') && inTypeFolder && stem) return `${base}/${stem}`;
  if (rule === 'steps' && childOfType && !base.endsWith('/steps')) return `${base}/steps`;
  if (rule === 'sections' && childOfType && !base.endsWith('/ui-specs')) return `${base}/ui-specs`;
  return base;
}
