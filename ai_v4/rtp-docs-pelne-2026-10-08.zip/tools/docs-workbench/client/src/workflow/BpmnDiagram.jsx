import { useEffect, useRef, useState } from 'react';
import NavigatedViewer from 'bpmn-js/lib/NavigatedViewer';
import 'bpmn-js/dist/assets/diagram-js.css';
import 'bpmn-js/dist/assets/bpmn-js.css';
import { navigate } from '../state/route';
import { fileUrl } from './model';

// Diagram BPMN z pliku XML (bpmn-js, tylko do odczytu: przesuwanie i zoom).
// Zadanie z tabeli „Zadania procesu” (kolumna „W silniku”) dostaje etykietę
// swojego kroku SPEC-WF albo wiersza STEP; klik w zadanie zaznacza krok
// albo wiersz, dwuklik otwiera podgląd.
export default function BpmnDiagram({ process, selectedId }) {
  const container = useRef(null);
  const viewerRef = useRef(null);
  const [error, setError] = useState(null);
  const tasks = process.tasks.filter(task => task.engineId);
  const nodeOf = task => task.spec || task.rowId || null;

  useEffect(() => {
    let cancelled = false;
    const styles = getComputedStyle(container.current);
    const viewer = new NavigatedViewer({
      container: container.current,
      bpmnRenderer: {
        defaultFillColor: styles.getPropertyValue('--color-surface').trim() || '#ffffff',
        defaultStrokeColor: styles.getPropertyValue('--color-text').trim() || '#1f2130',
        defaultLabelColor: styles.getPropertyValue('--color-text').trim() || '#1f2130',
      },
    });
    viewerRef.current = viewer;
    const nodeOfElement = elementId => nodeOf(tasks.find(task => task.engineId === elementId) || {});
    (async () => {
      const response = await fetch(fileUrl(process.bpmnXml.path));
      if (!response.ok) throw new Error(`plik ${process.bpmnXml.path} nie jest dostępny`);
      const xml = await response.text();
      if (cancelled) return;
      const { warnings } = await viewer.importXML(xml);
      if (warnings?.length) console.warn('BPMN: ostrzeżenia importu', warnings);
      const overlays = viewer.get('overlays');
      const registry = viewer.get('elementRegistry');
      for (const task of tasks) {
        const target = nodeOf(task);
        if (!target || !registry.get(task.engineId)) continue;
        const badge = document.createElement('button');
        badge.type = 'button';
        badge.className = 'bpmn-spec-badge';
        badge.textContent = task.spec || task.stepId;
        badge.addEventListener('click', event => { event.stopPropagation(); navigate({ sel: target }); });
        overlays.add(task.engineId, { position: { bottom: 10, left: -4 }, html: badge });
      }
      const events = viewer.get('eventBus');
      events.on('element.click', event => { const target = nodeOfElement(event.element.id); if (target) navigate({ sel: target }); });
      events.on('element.dblclick', event => { const target = nodeOfElement(event.element.id); if (target) navigate({ sel: target, podglad: '1' }); });
      viewer.get('canvas').zoom('fit-viewport', 'auto');
    })().catch(reason => { if (!cancelled) setError(reason.message || String(reason)); });
    return () => { cancelled = true; viewer.destroy(); viewerRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [process]);

  // Zaznaczony krok SPEC-WF albo wiersz STEP podświetla swoje zadanie.
  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewer) return;
    const canvas = viewer.get('canvas');
    const registry = viewer.get('elementRegistry');
    for (const task of tasks) {
      if (!registry.get(task.engineId)) continue;
      const target = nodeOf(task);
      if (target && (target === selectedId || task.spec === selectedId)) canvas.addMarker(task.engineId, 'is-selected-task');
      else canvas.removeMarker(task.engineId, 'is-selected-task');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId, process]);

  return (
    <>
      <div ref={container} className="wf-bpmn" />
      {error && <div className="cv-note" style={{ color: 'var(--t-error)' }}>Nie udało się wczytać diagramu BPMN: {error}</div>}
    </>
  );
}
