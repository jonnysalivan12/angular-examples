# Warsztat dokumentacji

Aplikacja działa lokalnie i pokazuje graf dokumentacji: mapę, katalog typu,
zasięg zmiany, przepływ danych między zdolnościami, drzewo plików, podgląd
pliku i wynik walidatorów. Aplikacja czyta pliki, a zapisuje tylko pliki
Markdown przez edytor.

| Plik lub folder | Zawartość |
|---|---|
| `server/` | Serwer API (Node.js, bez pakietów npm). |
| `client/` | Interfejs: React i Vite. Tokeny Nocturne w `client/src/styles/nocturne.css`, motywy i układ w `app.css`. |
| `dev.mjs` | Tryb deweloperski: serwer API i Vite naraz. |

## Uruchomienie aplikacji

Przed pierwszym uruchomieniem zainstaluj pakiety w folderze `tools/docs-workbench`:

```bash
npm install
```

Tryb deweloperski uruchamia serwer API na porcie 4180 i interfejs pod adresem
http://localhost:5173:

```bash
npm run dev
```

Wersja zbudowana: `npm run build` tworzy folder `dist/`, a `npm start` uruchamia
serwer, który udostępnia interfejs pod http://127.0.0.1:4180.

Interfejs zapisuje widok (tryb, zaznaczenie, koszyk, filtry) w adresie strony,
więc link otwiera ten sam widok. Motyw i szerokość paneli pamięta przeglądarka.

| Skrót | Działanie |
|---|---|
| `Ctrl K` | wyszukiwanie: najpierw dopasowanie w ID i na początku słowa tytułu, potem w opisie. `typ:API` albo samo `api` otwiera katalog typu |
| `1` `2` `3` `4` | tryb Mapa, Zasięg, Przepływ, Pliki |
| `Z` | dodaj zaznaczony węzeł do koszyka zasięgu |
| `I` | zapytanie `implementation` dla zaznaczonego węzła |
| `O` | otwórz plik zaznaczonego węzła w VS Code |
| `Space` | podgląd pliku zaznaczonego węzła w oknie nad płótnem. `Esc` albo klik obok okna zamyka |
| `E` | pokaż albo ukryj wiersze zaznaczonego dokumentu na Mapie |
| `F` | dopasuj widok do zaznaczenia (bez zaznaczenia: do całości) |
| `0` `+` `−` | zoom 100%, przybliż, oddal |

Prawy klik na węźle zaznacza go i otwiera menu z działaniami inspektora:
Podgląd pliku, Edytuj plik, Otwórz w VS Code, Zasięg, Dodaj do koszyka
zasięgu, Implementacja, Kopiuj ID. Menu działa na Mapie, w katalogu,
w Zasięgu, w Przepływie i w Plikach, także na chipie kontraktu na karcie
zdolności. Menu na grupie ma Rozwiń albo Zwiń grupę i Tylko ten proces. Menu
na folderze w drzewie plików ma Nowy dokument i Kopiuj ścieżkę. Menu obsługuje
strzałki, Enter, Esc i skróty z podpowiedzi.

Inspektor pokazuje relacje wychodzące (wpisy z pola `relations`), dokumenty
wskazujące węzeł, wiersze dokumentu z etykietą z treści i problemy walidacji
pliku. Etykietę wiersza aplikacja bierze z treści dokumentu: z reszty
nagłówka, w którym stoi ID wiersza (`### A1. Zapis szkicu`), z komórki kolumny
„Nazwa” w wierszu tabeli (tak mają zadania `STEP` w „Zadaniach procesu”) albo,
gdy tabela nie ma tej kolumny, z drugiej komórki wiersza (`| REQ-01 | … |`).
Podgląd pliku renderuje Markdown bez surowego HTML. Identyfikatory w treści są
linkami, a diagramy Mermaid rysują się w motywie aplikacji.

Tryb Zasięg liczy zapytanie `change_scope` albo `implementation` dla węzłów
z koszyka. `Z` dodaje do koszyka zaznaczony węzeł. Węzeł można też wyszukać
w sekcji Koszyk albo, gdy koszyk jest pusty, na środku płótna. Płótno układa
wynik w kolumny według liczby kroków od startu. Najechanie na plik w wyniku
podświetla jego ścieżkę. Strzałka biegnie od dokumentu, który ma wpis relacji,
do celu. Symulacja usunięcia pokazuje zasięg przed usunięciem, wpisy, których
cel przestanie istnieć, i węzły, które stracą połączenie z grafem. Wynik można
skopiować albo pobrać jako listę kontrolną Markdown.

Tryb Przepływ pokazuje zdolności CAP w kolumnach procesów i linie między nimi.
Linia zdarzenia wynika z wpisów `QUE realizes CAP` i `CAP consumes QUE`. Linia
wywołania powstaje, gdy dokument jednej zdolności korzysta z API albo INT
innej zdolności; krok SPEC-WF należy do zdolności swojego BPMS, a ekran SCR
i sekcja SCRSEC do zdolności scenariuszy, które je zawierają. Linia
niejednoznaczna powstaje, gdy wywołujący należy do kilku zdolności. Kilka linii
między tą samą parą zdolności leży obok siebie. Kliknięcie linii pokazuje
w inspektorze, z czego wynika kierunek, ładunek encji i innych korzystających.
Dwuklik na zdolności przechodzi na poziom kontraktów: kto korzysta z jej API,
INT i QUE oraz z czego one korzystają.

Przełącznik „Widok” w trybie Przepływ pokazuje też przepływ pracy (parametry
`widok` i `dok`). Dokument wybiera się w panelu po lewej:

| Widok | Co pokazuje | Skąd dane |
|---|---|---|
| Nawigacja ekranów (NAV) | ekrany SCR z makietą i sekcjami SCRSEC, wejścia, wyjścia, komunikaty i przejścia z podpisami, obszary | diagram Mermaid `flowchart` w dokumencie NAV; bez diagramu same ekrany z relacji `groups` |
| Przepływy i aktywności (FLOW) | warunki wstępne i kroki z aktywnością ACT i wywołaniem API, INT albo QUE | tabela „Opis przepływu” |
| Procesy BPMS i kroki | diagram z pliku BPMN XML (bpmn-js) z etykietą kroku SPEC-WF albo wiersza STEP przy zadaniu. Bez pliku: zadania STEP w kolejności z tabeli (typ, rola, wywołanie, opis działania małego zadania albo krok SPEC-WF złożonego) i zmienne przekazywane między zadaniami. W panelu: bramki, zdarzenia graniczne i uwagi do zadań | tabela „Diagram procesu” (plik szukany względem folderu dokumentu, folderu dokumentacji albo po nazwie), „Zadania procesu”, „Bramki i warunki”, „Zdarzenia graniczne”, kolumna „Źródło” wejścia kroków SPEC-WF (krok albo zadanie `BPMS-nnn.STEP-nn`) |
| Mapy scenariuszy (UCMAP) | aktorzy, obszary, UC i TUC z relacjami `include`, `extend`, `exclude`; najechanie na etykietę pokazuje uzasadnienie | diagram Mermaid i tabela „Opis relacji” |
| Decyzje architektoniczne (ADR) | wszystkie decyzje na jednym płótnie: ID, status, tytuł, wybrana opcja. Strzałka `supersedes` biegnie od nowej decyzji do zastąpionej, decyzja `deprecated` jest przekreślona. Panel pokazuje listę według statusu | front matter ADR, nagłówki opcji z dopiskiem „(wybrana)”, wpisy `supersedes` |

Makieta ekranu albo sekcji to obraz nazwany tak jak plik dokumentu:
`assets/zgloszenie-reklamacji.png` obok `zgloszenie-reklamacji.md`. Obraz może
też leżeć wprost obok pliku. Dozwolone są także obrazy `.svg`, `.jpg`
i `.webp`. Bez obrazu karta pokazuje oczekiwaną nazwę pliku. Decyzje
ADR leżą też na Mapie w warstwie Architektura, z liniami `supersedes` między
decyzjami. Do Zasięgu nie trafiają, bo wzorce zapytań nie mają ADR. Klik
w dokument na diagramie zaznacza go, dwuklik otwiera podgląd.

Tryb Pliki pokazuje w panelu po lewej drzewo folderu dokumentacji: foldery
z liczbą dokumentów, dokumenty z typem i ID oraz pliki pomocnicze (makiety,
diagramy). Klik w plik otwiera jego podgląd na płótnie. Dokument Markdown
pokazuje się z front matter i treścią, z działaniami węzła jak w inspektorze.
Klik w obraz przełącza rozmiar naturalny. Diagram BPMN rysuje bpmn-js,
z przełączeniem na XML. Inne pliki pokazują się jako tekst. Klik w otwarty
plik zamyka podgląd; to samo robi zwinięcie folderu, w którym ten plik leży.
Klik w dokument zaznacza go też w inspektorze, dwuklik otwiera podgląd
w oknie, a prawy klik otwiera menu węzła. Strzałki przechodzą po drzewie
i rozwijają foldery. W trybie Pliki inspektor ma przycisk „Pokaż w drzewie”:
zaznacza w drzewie plik zaznaczonego węzła, czyści filtr i pokazuje treść
pliku na płótnie. Nad drzewem są filtr po nazwie pliku, ID albo tytule,
przełącznik „Dokumenty” (ukrywa pliki pomocnicze) i przyciski, które
rozwijają albo zwijają wszystkie foldery. Domyślnie rozwinięte są foldery
warstw i typów. Rozwinięte foldery i wybrany plik są w adresie (`otwarte`,
`plik`).

Przycisk „Edytuj” otwiera plik Markdown w edytorze w oknie nad płótnem.
Przycisk jest w inspektorze, w oknie podglądu i na płótnie trybu Pliki; to
samo robi „Edytuj plik” w menu węzła. W edytorze tekst jest po lewej, a po
prawej podgląd odświeżany w trakcie pisania (przycisk „Podgląd” go chowa).
`Ctrl S` zapisuje, `Esc` zamyka; przy niezapisanych zmianach edytor pyta.
Zapis zachowuje końce linii pliku. Gdy plik zmienił się na dysku po wczytaniu
do edytora, edytor go nie nadpisuje: pokazuje błąd i przycisk
„Wczytaj z dysku”. Po zapisie serwer od razu synchronizuje indeks.

Prawy klik na folderze w drzewie i „Nowy dokument…” otwiera wybór typu. Lista
ma tylko typy, które według `folders.yaml` leżą w klikniętym folderze: w folderze
typu albo w podfolderze z reguły `subfolders` (folder procesu i jego `steps/`,
folder ekranu i jego `ui-specs/`, jeden podfolder). Folder bez typów pokazuje
foldery typów poniżej. Wybór typu otwiera edytor z treścią szablonu
`template.md` i kolejnym wolnym `doc-id`; ENT zostaje z tekstem zastępczym
w miejscu nazwy. Nazwa pliku (małe litery, cyfry i myślniki) jest w nagłówku
edytora. Reguła podfolderów typu dokłada podfolder: proces albo ekran nazwany
jak plik, `steps/` dla kroku, `ui-specs/` dla sekcji. Plik powstaje przy
pierwszym zapisie, a drzewo i inspektor pokazują go od razu.

Klik w problem walidacji (w inspektorze albo w ścieżce pliku w panelu
walidacji) otwiera podgląd pliku z tym problemem. Linia z problemem jest
podświetlona w treści albo w rozwiniętym YAML front matter. Nad treścią stoi
panel z komunikatem, podpowiedzią naprawy, przyciskiem
„Kopiuj prompt dla agenta” i linkiem do VS Code na tej linii. Prompt podaje plik i linię,
walidator, komunikat, fragment pliku wokół linii, zasady zmiany i polecenie,
którym agent sprawdza naprawę. Gdy plik ma kilka problemów, strzałki w panelu
przełączają między nimi, a przycisk „Kopiuj prompt dla wszystkich” kopiuje
jeden zbiorczy prompt. Zbiorczy prompt zawiera wszystkie problemy pliku
w kolejności linii, każdy z komunikatem i podpowiedzią, fragment pliku raz na
linię oraz polecenia wszystkich walidatorów, które te problemy zgłosiły. Ten
sam zbiorczy prompt kopiują: link „kopiuj prompt dla wszystkich” w sekcji
Walidacja inspektora, przycisk „Kopiuj prompt dla pliku” w panelu walidacji
(przy filtrze Dokument) i link „prompt dla pliku” w rozwiniętym problemie.
Prompt obejmuje wszystkie problemy pliku bez względu na filtry panelu.

Panel walidacji otwiera kliknięcie liczników w pasku górnym, a `Esc` go
zamyka. Panel pokazuje wynik `validate-relations.js`, `validate-form.js`
i `validate-consistency.js` z filtrami poziomu, dokumentu i walidatora. Przy
problemie stoi podpowiedź „Naprawa”. „Pokaż” przełącza na Mapę, rozwija grupę
dokumentu i wyśrodkowuje go. Ścieżka pliku otwiera VS Code na linii. Znaczniki
błędów i ostrzeżeń na Mapie można wyłączyć w panelu po lewej.

Po zapisie pliku serwer wysyła zdarzenie `change`, a interfejs pobiera dane od
nowa bez zmiany widoku: węzły, zaznaczenie i zoom zostają na miejscu.

Katalog typu to zakres „Typ dokumentu” na Mapie (albo `typ:API`
w wyszukiwaniu). Pokazuje wszystkie dokumenty wybranych typów jako graf albo
tabelę. Graf układa grupy w kolumnach według właściciela (na przykład CAP dla
API i LDM dla encji) albo według procesu. Przy grupowaniu „Status” kolumną
jest status, a przy „Typ” typ dokumentu, jak na tablicy kanban. Kolumny tabeli
wynikają z trójek matrycy relacji. „Używany przez” liczy dokumenty, które
wskazują dokument albo jego wiersz. Wpisu `LDM contains ENT` nie liczy, bo LDM
to indeks encji.

Grupy liczy serwer z relacji, nie z folderów, bo podfolder nie niesie
znaczenia (metodyka, sekcja 11). Grupowanie „Proces” przypisuje dokument do
BFS, do którego dokument dochodzi łańcuchem wpisów: UC i TUC przez `realizes`
do wiersza BFS; CAP przez scenariusze, które ją realizują; API, INT, QUE,
FLOW, BPMS i STM przez `realizes CAP`; SCR, SCRSEC, ACT i SPEC-WF przez
dokument, który je zawiera; NAV i UCMAP przez `groups`. Dokument z kilkoma
procesami trafia do grupy wspólnej (`BFS-001 + BFS-002`). Dokument bez drogi
do BFS (ACTOR, NFR, CONV, DDM, LDM, ENT, ADR, scenariusz bez wymagania) nie ma
procesu i nie jest widoczny w tym grupowaniu; panel po lewej podaje, ile
takich dokumentów jest. Grupowanie „Folder typu” bierze folder typu
z `standards/config/folders.yaml` (`system/apis`, `functional/use-cases`),
a „Warstwa” bierze warstwę z metodyki.

Na Mapie kółko myszy przybliża w miejscu kursora, a przeciąganie tła przesuwa
widok. Klik w tło zdejmuje zaznaczenie. Shift z przeciąganiem zaznacza ramką
i przybliża do zaznaczonych węzłów. Dwuklik na grupie ją rozwija albo zwija.
Przeciągnięte węzły zostają na miejscu do kliknięcia „Ułóż”. Minimapa pojawia
się powyżej 150%, a poniżej 25% widać tylko grupy. Przycisk „Auto” obok
„Dopasuj” jest domyślnie włączony i pamięta go przeglądarka. Dopasowuje widok
po zmianie zakresu, grupowania, warstw, relacji, gęstości i układu, gdy nowy
układ jest już policzony. Zaznaczenie, rozwinięcie wierszy i odświeżenie
danych nie przesuwają widoku. Linia między grupami ma 1,2–2,4 px grubości
zależnie od liczby relacji, a strzałki mają stały rozmiar.

Rozwinięta grupa układa dokumenty w kolumnach: Mapy, Ekrany (SCR, obok
SCRSEC), Scenariusze, Wymagania, Odpowiedzialność, Kontrakty, Przepływy (FLOW
i BPMS, obok ACT i SPEC-WF), Pojęcia i dane, Architektura. Kolejność kolumn
jest policzona na korpusie tak, żeby jak najwięcej relacji łączyło sąsiednie
kolumny. Architektura stoi na końcu, bo decyzje ADR mają linie tylko między
sobą. Listy w panelu (warstwy, relacje, typy i kolumny katalogu) mają
w nagłówku „zaznacz wszystko” albo „odznacz wszystko”. Liczby w panelu po
lewej są klikalne: liczba warstwy otwiera katalog jej typów, a liczba relacji
zostawia na płótnie tylko tę relację.

Domyślny układ Mapy to **warstwowy** (algorytm layered z elkjs, `map/layout.js`):
1. Algorytm układa każdą rozwiniętą ramkę osobno. Kolumny ramki są wymuszone.
   Kolejność kart w kolumnie algorytm wybiera tak, żeby linie jak najrzadziej
   się krzyżowały. Linie biegną pionowo i poziomo wokół kart.
2. Linie z dokumentów ramki do jednej grupy poza ramką tworzą **wiązkę**. Na
   brzegu ramki wiązka ma jeden port: prawy, gdy wpisy wychodzą z ramki, lewy,
   gdy przychodzą. Dalej biegnie jedna linia z liczbą relacji.
3. Algorytm układa ramki, grupy i wiązki razem, więc grupy stoją po tej
   stronie ramki, z którą się łączą.

Na korpusie przy rozwiniętej BFS-003 poprzedni układ dawał 129 przejść linii
przez obce karty i 201 przecięć. Układ warstwowy daje 0 przejść i 88 przecięć
przy wszystkich liniach, a w widoku domyślnym 6 przecięć.

**Linie** to trzy niezależne pola (parametr `linie`):
- **Grupujące**: linie między grupami i wiązki do grup, z liczbą relacji.
- **Relacje dokumentów**: każda relacja jest osobną linią (wiązki wtedy znikają).
- **Relacje po najechaniu**: najechana albo zaznaczona karta pokazuje swoje
  relacje z nazwami, a reszta przygasa.

Domyślnie włączone są Grupujące i Po najechaniu, a w sąsiedztwie wszystkie
trzy. „Tylko relacje” to same Relacje dokumentów. Linie karty w fokusie biegną
także przez port ramki do grupy i zastępują jej część wiązki. Zostaje wtedy
wiązka pozostałych dokumentów albo żadna. Przy grupowaniu według warstwy karty
grup pokazują nazwę warstwy bez klucza (`scr`, `data`). Wiązka bez wyliczonej
trasy (układ siłowy, kołowy, przeciągnięta ramka) nie ma strzałki.

**Sąsiedztwo węzła** liczy dokumenty w odległości 1–3 kroków od środka
(parametr `wezel`). Środek wybiera się wyszukiwarką na środku pustego płótna
albo w panelu po lewej, dwuklikiem na dokumencie albo z menu kontekstowego
(„Sąsiedztwo na Mapie”). Środek nie zależy od zaznaczenia: klik w tło zdejmuje
zaznaczenie, a sąsiedztwo zostaje.

Linia na Mapie i w Zasięgu kończy się w jednym z punktów połączenia na brzegu
karty dokumentu albo grupy. Karta dokumentu albo grupy ma trzy punkty na
górze, trzy na dole, jeden po lewej i jeden po prawej. Punkt jest widoczny
tylko na końcu linii. Trasa z układu warstwowego dochodzi do najbliższego
punktu na swoim brzegu. Linia bez trasy wybiera najkrótszą parę punktów
zwróconych do siebie. Karty jedna nad drugą (w jednej kolumnie) łączy łuk
z lewego boku do lewego boku, żeby linia nie szła przez karty pomiędzy.

Układ siłowy i kołowy zostały jako alternatywa. Oba układają się wokół węzła
zaznaczonego w chwili wyboru układu albo kliknięcia „Ułóż”; samo zaznaczenie
nie przestawia węzłów. Układają tylko grupy i ramki, a linie biegną od brzegu
do brzegu. Przeciągnięty węzeł traci trasy swoich linii do kliknięcia „Ułóż”.
Do tego czasu jego linie biegną od brzegu do brzegu.

## Uruchomienie samego serwera

Polecenie uruchom z głównego folderu repozytorium:

```bash
node tools/docs-workbench/server/index.js --root standards/examples
```

- `--root` to folder dokumentacji (wymagany).
- `--port` to port serwera; domyślnie 4180.
- `--db` to plik bazy indeksu; domyślnie `node_modules/.cache/docs-workbench.db`. Baza jest osobna od bazy serwera MCP knowledge-index, więc oba mogą indeksować różne foldery.

Serwer słucha tylko na `127.0.0.1`. Po zmianie pliku w folderze dokumentacji
albo w `standards/config` synchronizuje indeks. Gdy indeks naprawdę się
zmienił, serwer wysyła zdarzenie `change` pod `/api/events`. W folderze
dokumentacji serwer zapisuje tylko plik Markdown wskazany przez edytor
interfejsu (`POST /api/edit`). Zapis innego pliku albo pliku spoza folderu
odrzuca.

## API

| Adres | Zwraca |
|---|---|
| `GET /api/meta` | wersję danych, folder dokumentacji, główny folder repozytorium, gałąź git i nazwy zapytań |
| `GET /api/graph` | dokumenty z grupą (proces z relacji), folderem typu i warstwą, wiersze, relacje (z polem `exists`), grupy, liczby relacji między grupami |
| `GET /api/doc?id=UC-001` | opis węzła z knowledge-index (relacje wychodzące i przychodzące) oraz treść pliku |
| `GET /api/search?q=dysp&type=API&limit=20` | dokumenty z wyszukiwania knowledge-index |
| `POST /api/query` | dla treści `{ query, starts, simulateRemoval }` wynik zapytania; z `simulateRemoval` także `removal`: `broken` (wpisy, których cel przestanie istnieć) i `disconnected` (węzły, które stracą połączenie z grafem) |
| `GET /api/workflows` | widoki przepływu pracy: `navigation` (NAV), `flows` (FLOW), `processes` (BPMS, zadania STEP z typem, rolą, wywołaniami i krokiem SPEC-WF, bramki, zdarzenia graniczne), `scenarioMaps` (UCMAP), `decisions` (ADR ze statusem i łańcuchem `supersedes`) |
| `GET /api/flow` | zdolności z kontraktami i linie `event`, `call`, `ambiguous` z encjami |
| `GET /api/validation` | wynik trzech walidatorów (`--json`) w jednej liście |
| `GET /api/events` | strumień zdarzeń `hello` (z wersją danych), `change`, `sync-error` |
| `GET /api/file?path=…` | plik z folderu dokumentacji (obraz z treści dokumentu, makieta, plik `.bpmn`, tekst `.md`, `.txt`, `.yaml`, `.yml`, `.json`, `.csv`); ścieżka względem głównego folderu repozytorium, jak `path` dokumentu |
| `GET /api/tree` | drzewo folderu dokumentacji: foldery z liczbą dokumentów i plików, pliki z rozmiarem i ID dokumentu z indeksu; liczone przy każdym żądaniu |
| `GET /api/templates` | szablony typów ze `standards/templates`: typ, nazwa, warstwa, grupa i opis ze spisu treści, folder i reguła podfolderów z `folders.yaml`, treść `template.md` |
| `GET /api/edit?path=…` | treść pliku Markdown z folderu dokumentacji do edytora ze skrótem treści (`hash`) |
| `POST /api/edit` | `{ path, content, baseHash }` zapisuje istniejący plik (409 ze `stale`, gdy skrót treści na dysku jest inny niż `baseHash`); `{ path, content, create: true }` tworzy nowy plik (409, gdy istnieje; nazwa i foldery według `folders.yaml`); po zapisie synchronizuje indeks i wysyła `change` |

Zasięg zmiany liczy `scripts/lib/query.js`, a węzeł startowy jest pierwszą
pozycją wyniku.
