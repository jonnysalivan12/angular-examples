# Use Case + Technical Map (UCMAP)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Jeden diagram relacji między UC i TUC: powiązania `include`, `extend`
i `exclude` oraz aktorzy. Dokument odpowiada na pytanie, jak łączą się
scenariusze użytkownika ze scenariuszami systemowymi.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** pokazujesz pełny obraz procesu, czyli co inicjuje użytkownik,
a co system wykonuje automatycznie, i chcesz na jednym diagramie zdefiniować
relacje include, extend i exclude.

**Nie używaj gdy:**

- opisujesz jeden scenariusz → [use-case](../../use-cases/use-case/guide.md), [technical-use-case](../../technical-use-cases/technical-use-case/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Które UC i TUC wchodzą w zakres mapy?
- Które relacje są obowiązkowe (`include`), które warunkowe (`extend`), a które wykluczające (`exclude`)?
- Kto jest aktorem UC (osoba), a kto aktorem TUC (system, harmonogram)?
- Które scenariusze szczegółowe istnieją i mają trafić na mapę?

Reguły zapisu:

- `include` to krok obowiązkowy, `extend` to krok warunkowy, a `exclude` to wzajemne wykluczenie wariantów (ta relacja nie jest standardem UML). Relacje zapisujesz bez nawiasów stereotypu.
- Mapa zestawia scenariusze (`UCMAP-001 groups UC-001`) i opisuje ich powiązania include, extend i exclude. Mapa nie ma własnych wzorców zapytań. Zwraca ją zapytanie `change_scope` dla scenariusza i dla wymagania: dla `UC-001` wynik zawiera `UCMAP-001`.
- Aktorów na mapie podajesz nazwą. Matryca relacji nie ma trójki UCMAP z rolą, więc ID roli w treści mapy walidator zgłasza jako błąd.

## 4. Warianty

- **Lekki**: do 5 przypadków. Mapa ma tylko sekcje Cel, Diagram, Opis relacji i Powiązanie z artefaktami szczegółowymi.
- **Rozbudowany**: mapa obejmuje kilka obszarów. Diagram dzielisz na obszary, ale mapa zostaje jednym plikiem.
