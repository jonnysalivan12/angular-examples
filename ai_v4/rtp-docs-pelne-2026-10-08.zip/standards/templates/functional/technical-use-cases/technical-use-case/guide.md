# Technical Use Case (TUC)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Scenariusz, który system uruchamia automatycznie, bez udziału człowieka: jak
uruchamia się funkcja, co dzieje się krok po kroku i co może pójść nie tak.
Dokument odpowiada na pytanie „Co system wykonuje automatycznie i jakiego
efektu oczekujemy?”. Jest podrzędny wobec BFS.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz scenariusz działania systemu bez udziału użytkownika
(cron, harmonogram, zadanie nocne, ponowienie): warunki uruchomienia,
przebieg i sytuacje wyjątkowe.

**Nie używaj gdy:**

- w scenariuszu uczestniczy użytkownik → [use-case](../../use-cases/use-case/guide.md),
- opisujesz, co system potrafi, a nie przebieg scenariusza → [capability](../../../system/capabilities/capability/guide.md),
- dokumentujesz integrację z systemem zewnętrznym → [integration](../../../system/integrations/integration/guide.md),
- opisujesz przepływ danych między komponentami → [flow](../../../system/flows/flow/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Który komponent albo system uruchamia scenariusz?
- Co go wyzwala: czas, zdarzenie, harmonogram?
- Jakie warunki muszą być spełnione, żeby przebieg wystartował?
- Co jest punktem końcowym i jak wygląda sukces?
- Który BFS jest dokumentem nadrzędnym i które wymagania i reguły dotyczą scenariusza?

Reguły zapisu:

- Sekcje są takie same jak w UC. Tabela pod tytułem podaje aktora systemowego i pole „Trigger”: `cron 02:00`, zdarzenie albo harmonogram.
- Jeśli zespół prowadzi BFS, TUC wskazuje pełnym ID co najmniej jedno wymaganie albo regułę: `TUC-001 realizes BFS-001.REQ-04`. TUC nie kopiuje ich treści, tylko opisuje przebieg. Jeśli zespół nie prowadzi BFS, sekcja „Powiązanie z BFS” i pola „BFS”, „Powiązane REQ” i „Powiązane RB” dostają „Nie dotyczy”.
- Kroki opisują akcje systemu. Tabele kroków mają kolumnę „Wywołanie” z ID API, INT albo QUE.
- Pole „Trigger” może wskazać zdarzenie: `TUC-010 consumes QUE-010`. To pole tworzy relację do zdarzenia, które uruchamia scenariusz, więc jeden TUC ma jeden wyzwalacz.
- TUC nie ma ekranów.
- Ostatni wiersz tabeli wariantu mówi, do którego kroku wraca przebieg albo że proces się zamyka.
- Sytuacja błędna wskazuje politykę błędu: ponowienie, eskalację albo zatrzymanie.
- Rolę, progi NFR i zdolność zapisujesz tak jak w UC: `TUC-001 involves ACTOR-001.ROLE-03`. Przy każdym wierszu NFR piszesz, jak ogranicza scenariusz.
- Kryterium akceptacji kończy się pełnym ID wymagania albo reguły, które sprawdza: `(BFS-001.REQ-04)`.
- Diagram dodajesz, gdy przebieg ma więcej niż jedno rozgałęzienie decyzyjne. Diagram ma najwyżej 15 kroków.

Po co są sekcje:

- Tabela pod tytułem daje przegląd bez czytania całości. Autor i status stoją w nagłówku pliku.
- „Powiązanie z BFS” utrzymuje ślad od wymagania do scenariusza bez kopiowania wymagań.
- „Cel” to punkt wejścia dla biznesu, programisty i testera.
- „Aktorzy” mówi, że wykonawcą jest system, i nie pozwala mieszać scenariusza z pracą użytkownika.
- „Kiedy można to zrobić” to warunki, które muszą być prawdą przed uruchomieniem. Na nich opierają się testy automatyzacji.
- „Kroki” to przebieg automatycznej funkcji: jeden krok to jedna obserwowalna akcja systemu.
- „Co może pójść inaczej” opisuje warianty, w których przebieg odbiega od planu, ale zostaje pod kontrolą.
- „Co może pójść nie tak” mówi, co się dzieje przy błędzie i jaka jest reakcja. Bez tego zespół nie wie, jak postępować przy odchyleniach.
- „Reguły biznesowe” to zasady, które nie wynikają z kroków, a wpływają na ich wykonanie.
- „Ograniczenia NFR” wskazują progi jakości po ID. Metryki trzyma NFR.
- „Kryteria akceptacji” to sprawdzalne warunki gotowości w zapisie „kiedy, wtedy”.
- „Diagram” uzupełnia tekst przy rozgałęzieniach, nie zastępuje go.

## 4. Warianty

- **Uproszczony**: jeden przepływ bez rozgałęzień. Diagramu nie ma, a sekcje „Co może pójść inaczej” i „Co może pójść nie tak” dostają „Nie dotyczy” z uzasadnieniem.
- **Złożony**: kilka wyzwalaczy albo wiele wariantów systemowych. Piszesz jeden TUC na wyzwalacz albo wariant, bo pole „Trigger” tworzy relację do zdarzenia. Warianty zestawia mapa [use-case-technical-map](../../use-case-technical-map/use-case-technical-map/guide.md).
