# Use Case (UC)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Scenariusz działania użytkownika: co chce osiągnąć, jak to robi krok po kroku
i co może pójść nie tak. Dokument odpowiada na pytanie „Co użytkownik robi
i czego oczekuje?”. Nie opisuje, jak system to realizuje.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz scenariusz działania użytkownika z krokami, warunkami i sytuacjami wyjątkowymi.

**Nie używaj gdy:**

- scenariusz działa bez udziału użytkownika (cron, harmonogram, zadanie nocne) → [technical-use-case](../../technical-use-cases/technical-use-case/guide.md),
- zbierasz wymagania i reguły procesu → [business-functional-spec](../../business-functional-specs/business-functional-spec/guide.md),
- opisujesz, co system potrafi, a nie scenariusz użytkownika → [capability](../../../system/capabilities/capability/guide.md),
- dokumentujesz integrację z systemem zewnętrznym → [integration](../../../system/integrations/integration/guide.md),
- opisujesz przepływ danych między komponentami → [flow](../../../system/flows/flow/guide.md).

Powiązane szablony: [business-functional-spec](../../business-functional-specs/business-functional-spec/guide.md), [capability](../../../system/capabilities/capability/guide.md), [non-functional-requirements](../../../system/non-functional-requirements/non-functional-requirements/guide.md), [api-endpoint](../../../system/apis/api-endpoint/guide.md), [screen-section](../../../system/gui/screens/screen-section/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Kim jest aktor główny i jaki ma cel?
- Przez jakie kanały korzysta z funkcji: aplikacja, oddział, infolinia?
- Jakie warunki muszą być spełnione, żeby akcja była możliwa?
- Jak wygląda sukces z perspektywy użytkownika?
- Który BFS jest dokumentem nadrzędnym i które wymagania i reguły dotyczą scenariusza?

Reguły zapisu:

- Jeśli zespół prowadzi BFS, UC wskazuje pełnym ID co najmniej jedno wymaganie albo regułę: `UC-001 realizes BFS-001.REQ-01`, `BFS-001.RB-01`. UC nie kopiuje ich treści, tylko opisuje przebieg. Jeśli zespół nie prowadzi BFS, sekcja „Powiązanie z BFS” i pola „BFS”, „Powiązane REQ” i „Powiązane RB” dostają „Nie dotyczy”.
- Zdolność podajesz w polu „Zdolność” i wskazujesz wpisem `realizes`. Gdy zdolności jest kilka, każda dostaje osobny wpis: `UC-002 realizes CAP-001`, `CAP-002`.
- Krok ma postać „kto robi co i co widzi w odpowiedzi”.
- Tabele kroków (Kroki, warianty A, błędy E) mają kolumny „Ekran” i „Wywołanie”. Ekranowi odpowiada wpis `UC-001 contains SCR-001`, a wywołaniu wpis `UC-001 consumes API-001`. Ten sam ekran bywa wspólny dla kilku scenariuszy.
- Kolumna „Sekcja” jest opcjonalna. Wpisujesz w niej sekcję ekranu, gdy krok opisuje pracę użytkownika w jednej sekcji: `UC-010 contains SCRSEC-010`.
- W kolumnie „Wywołanie” podajesz API albo QUE. Scenariusz nie woła integracji INT wprost, tylko przez API, więc nie wymienia jej w treści.
- Gdy użytkownik w kroku przypisuje, odkłada albo kończy zadanie procesu, krok podaje w kolumnie „Wywołanie” API, które to robi: `UC-004 consumes API-015` przy otwarciu zadania i `API-008` przy zapisie decyzji. Samego zadania procesu scenariusz nie wymienia. Krok, który woła kilka API, podaje je w jednej komórce po przecinku.
- Krok, który publikuje albo odbiera zdarzenie, podaje QUE: `UC-001 consumes QUE-001`.
- Warianty `A1, A2…` i błędy `E1, E2…` to wiersze tego UC: `UC-001 contains A1`. Ostatni wiersz tabeli wariantu mówi, do którego kroku wraca przebieg albo że kończy operację. Ostatnie wiersze tabeli sytuacji błędnej podają komunikat, który widzi użytkownik, i co może zrobić dalej.
- Rolę wskazujesz pełnym ID: `UC-001 involves ACTOR-001.ROLE-01`.
- Progi jakości wskazujesz wierszem NFR. Przy każdym piszesz, jak ogranicza scenariusz. Wiersza NFR, który wskazuje już zdolność scenariusza, nie powtarzasz: `UC-013` podlega `NFR-001.NFRT-PERF-02` przez `CAP-014`.
- Kryterium akceptacji kończy się pełnym ID wymagania albo reguły, które sprawdza: `(BFS-001.REQ-01)`.
- Diagram dodajesz, gdy przebieg ma więcej niż jedno rozgałęzienie decyzyjne. Diagram ma najwyżej 15 kroków.

Po co są sekcje:

- Tabela pod tytułem daje przegląd bez czytania całości. Autor i status stoją w nagłówku pliku.
- „Powiązanie z BFS” utrzymuje ślad od wymagania do scenariusza bez kopiowania wymagań.
- „Cel” to punkt wejścia dla biznesu, programisty i testera.
- „Aktorzy” mówi, kto jest właścicielem scenariusza i kto w nim uczestniczy. Podajesz rolę, nie stanowisko.
- „Kiedy można to zrobić” to warunki, które muszą być prawdą przed akcją. Na nich opierają się testy regresji i reguły walidacji.
- „Kroki” to przebieg z perspektywy użytkownika: jeden krok to jedna obserwowalna akcja albo reakcja systemu.
- „Co może pójść inaczej” opisuje warianty, w których użytkownik robi coś innego. Bez nich dokument opisuje tylko szczęśliwą ścieżkę.
- „Co może pójść nie tak” mówi, co użytkownik widzi w sytuacji błędnej i co może zrobić. Bez tego tester nie wie, jakie komunikaty sprawdzać.
- „Reguły biznesowe” to zasady, które nie wynikają z kroków, a wpływają na ich wykonanie.
- „Ograniczenia NFR” wskazują progi jakości po ID. Metryki trzyma NFR.
- „Kryteria akceptacji” to sprawdzalne warunki gotowości w zapisie „kiedy, wtedy”. Testerzy używają ich wprost.
- „Diagram” uzupełnia tekst przy rozgałęzieniach, nie zastępuje go.

## 4. Warianty

- **Uproszczony**: jeden przepływ bez rozgałęzień. Diagramu nie ma, a sekcje „Co może pójść inaczej” i „Co może pójść nie tak” dostają „Nie dotyczy” z uzasadnieniem.
- **Złożony**: wielu aktorów albo wiele kanałów. Scenariusz rozbijasz na pliki: jeden UC na aktora albo kanał.
