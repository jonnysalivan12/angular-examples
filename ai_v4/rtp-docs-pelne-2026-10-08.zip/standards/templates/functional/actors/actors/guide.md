# Actor (ACTOR)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Wspólna baza aktorów systemu, czyli użytkowników i ról systemowych. Korzystają
z niej UC, TUC i procesy BPMS. Baza opisuje role, ich odpowiedzialności,
uprawnienia i zależności.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** zakładasz bazę aktorów systemu. Rolę nowego procesu dopisujesz do istniejącej bazy.

**Nie używaj gdy:**

- opisujesz kroki, które rola wykonuje → [use-case](../../use-cases/use-case/guide.md) albo [technical-use-case](../../technical-use-cases/technical-use-case/guide.md),
- zestawiasz powiązania między scenariuszami → [use-case-technical-map](../../use-case-technical-map/use-case-technical-map/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaki system opisujesz i gdzie leży granica opisu: jeden system czy wiele procesów?
- Z jakich materiałów bierzesz role: BFS, UC, TUC, diagram procesu, warsztat?
- Które role biznesowe i systemowe wykonują kroki w procesach objętych zakresem?
- Gdzie leżą granice odpowiedzialności i uprawnień poszczególnych ról?
- Które scenariusze uruchamia każda rola?
- Czy role dziedziczą uprawnienia po innych rolach?
- Które nazwy są kanoniczne, a które aliasy historyczne trzeba zachować w słowniku?

Reguły zapisu:

- Jeden aktor ma jedną nazwę kanoniczną i jedno ID.
- Rola opisuje, co aktor robi w procesie. Nie opisuje stanowiska ani etatu.
- Aktor systemowy wykonuje kroki bez udziału człowieka.
- Rola z kilkoma poziomami uprawnień to kilka ról. Każdy poziom dostaje własny wiersz z wypełnioną kolumną „Dziedziczy po”, bo scenariusz wskazuje poziom jego własnym ID.
- Dziedziczenie uprawnień pokazuje tylko kolumna „Dziedziczy po”.
- Role mają prefiks ROLE: `ACTOR-001 contains ROLE-01`. UC, TUC i BPMS wskazują rolę pełnym ID: `UC-001 involves ACTOR-001.ROLE-01`. Celem relacji jest zawsze rola, nigdy cały dokument ACTOR.
- Numeru ROLE nie używa się ponownie. Usunięty wiersz znika z dokumentu, a jego historię trzyma repozytorium.

Po co są sekcje:

- „Cel” mówi, po co powstała baza i jak zespół ma jej używać.
- „Zakres” wyznacza granice bazy i nie pozwala mieszać aktorów z niezależnych procesów.
- „Klasyfikacja aktorów” od razu odróżnia role biznesowe od systemowych. Kolumna „Definicja lokalna” mówi, kim jest aktor danej klasy w tym systemie.
- „Przykład minimalny” pokazuje na jednym aktorze, jak odróżnić rolę procesową od komponentu technicznego.
- „Aktorzy” to kanoniczna lista ról z ID. Scenariusze i procesy wskazują role z tej listy.
- „Słownik nazw i aliasów” zbiera w jednym miejscu synonimy, nazwy historyczne i skróty, po jednym aliasie w wierszu. Dzięki temu nie powstają duplikaty ról.

## 4. Warianty

Brak wariantów: jedna baza aktorów systemu, wspólna dla wszystkich procesów.
