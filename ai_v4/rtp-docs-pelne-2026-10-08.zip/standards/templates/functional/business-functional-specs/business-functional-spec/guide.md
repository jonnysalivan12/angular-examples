# Business Functional Spec (BFS)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Wymagania funkcjonalne i reguły biznesowe jednego procesu biznesowego.
Dokument odpowiada na pytanie „Co proces musi robić i dlaczego?”. Jest
nadrzędny wobec przypadków użycia, bo one uszczegóławiają jego wymagania.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**

- zaczynasz projekt i katalogujesz wymagania,
- zbierasz reguły biznesowe, zanim rozbijesz proces na przypadki użycia,
- grupujesz w jednym miejscu wymagania biznesowe, reguły, wymagania prawne, UX (WCAG), zgodność i wspólny słownik pojęć.

**Nie używaj gdy:**

- opisujesz szczegółowy scenariusz użytkownika → [use-case](../../use-cases/use-case/guide.md); UC uszczegóławia wymagania REQ z tego dokumentu,
- zapisujesz decyzję architektoniczną → [adr](../../../architecture/decision-records/adr/guide.md).

Powiązane szablony: [use-case](../../use-cases/use-case/guide.md), [non-functional-requirements](../../../system/non-functional-requirements/non-functional-requirements/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaki jest cel biznesowy procesu i skąd wziął się proces albo jego zmiana?
- Co jest w zakresie, a co jawnie poza zakresem?
- Kto jest właścicielem biznesowym: interesariusz, Product Owner?
- Które pojęcia domenowe trzeba zdefiniować, żeby uniknąć wieloznaczności?

Reguły zapisu:

- Jeden BFS opisuje jeden proces. Proces ma jeden start i jeden koniec, a koniec może mieć warianty. BFS nie dzieli się po iteracjach, ścieżkach ani komponentach (plik [methodology.md](../../../../methodology.md), sekcja 5).
- Wymagania `REQ-{nn}` i reguły `RB-{nn}` to wiersze. Inne dokumenty wskazują je pełnym ID: `UC-001 realizes BFS-001.REQ-01`. Celem relacji jest zawsze wiersz, nigdy cały dokument BFS.
- Wymaganie zaczyna się od „Proces musi”, „Proces powinien” albo „Proces może”. Czasownik odpowiada priorytetowi: musi to Must, powinien to Should, może to Could. Skala MoSCoW jest jedna dla całego projektu.
- BFS nie wymienia scenariuszy. Relację zapisuje UC albo TUC, który realizuje wymaganie: `TUC-017 realizes BFS-010.REQ-01`.
- Numeru REQ ani RB nie używa się ponownie. Usunięty wiersz znika z dokumentu, a jego historię trzyma repozytorium.
- Wymaganie niefunkcjonalne wskazujesz wierszem NFR: `BFS-001 constrained_by NFR-001.NFRT-PERF-01`. Sekcja „Wymagania niefunkcjonalne” mówi, które progi jakości dotyczą procesu. Metryki i wartości progów trzyma dokument NFR.
- Zmianę albo usunięcie wymagania zaczynasz od zapytania `change_scope` (plik [methodology.md](../../../../methodology.md), sekcja 6).

Po co są sekcje:

- Tabela pod tytułem pokazuje najważniejsze metadane bez czytania całości.
- „Kontekst biznesowy” mówi, skąd pochodzi wymaganie i czy jest aktualne. Opisuje problem biznesowy, a nie rozwiązanie techniczne.
- „Cel” określa mierzalny efekt wdrożenia procesu i pozwala sprawdzać, czy wymagania są z nim spójne.
- „Zakres” pilnuje, żeby zakres nie rósł bez kontroli. Podsekcja „Poza zakresem” jest równie ważna jak „W zakresie”.
- „Wymagania funkcjonalne” to kanoniczna lista tego, co proces musi robić. Na niej opierają się testy i odbiór. Każde wymaganie ma ID, żeby UC mógł je wskazać.
- „Reguły biznesowe” zbierają logikę i ograniczenia biznesowe. ID reguły pozwala wskazać ją z UC bez kopiowania treści.
- „Wymagania niefunkcjonalne” wskazują progi jakości po ID, bez powtarzania metryk z NFR.
- „Słownik pojęć” daje jednemu terminowi jedną definicję w całym projekcie.
- „Założenia i otwarte pytania” pokazują, co przyjęto bez potwierdzenia. Otwarte pytanie blokuje wdrożenie, więc ma właściciela i termin.

## 4. Warianty

- **BFS dla nowego procesu**: tabela wymagań to lista zaległości do rozbicia na przypadki użycia.
- **BFS dla istniejącego procesu** (dokumentacja wsteczna): zaczynasz od reguł biznesowych wydobytych z kodu. Słownik pojęć wypełniasz nazwami z istniejących UC i kodu.
