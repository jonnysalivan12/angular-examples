# Domain Data Model (DDM)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Model domenowy danych jednego obszaru: pojęcia biznesowe, ich znaczenie,
reguły i relacje. Dokument odpowiada na pytanie „Co te dane znaczą w domenie
i jakimi regułami się rządzą?”. Nie mówi, jak dane są przechowywane ani kto
ich używa.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** modelujesz język domeny, czyli pojęcia, definicje, reguły i inwarianty biznesowe, i chcesz mieć jedno źródło prawdy dla pojęć. Do tego źródła odwołują się LDM i kontrakty.

**Nie używaj gdy:**

- opisujesz strukturę logiczną danych → [ldm](../../../system/data-models/ldm/guide.md), [ldm-entity](../../../system/data-models/ldm-entity/guide.md),
- opisujesz kontrakt API → [api-endpoint](../../../system/apis/api-endpoint/guide.md),
- opisujesz przepływ → [flow](../../../system/flows/flow/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaki obszar domenowy modelujesz i gdzie są jego granice?
- Jakie jest źródło domeny w górę: model w Enterprise Architect, polityki biznesowe, regulacje?
- Które pojęcia wymagają jednoznacznej definicji, żeby LDM i API rozumiały je tak samo?
- Jakie reguły i inwarianty rządzą danymi, czyli które warunki są zawsze prawdziwe w domenie bez względu na implementację?

Reguły zapisu:

- Model jest na poziomie analitycznym: nie zależy od implementacji, struktury bazy ani kontraktów API.
- DDM jest nadrzędny wobec konsumentów i nie zależy od nich. To konsumenci wskazują model. DDM nie opisuje struktury logicznej ani konsumentów modelu.
- Jeden obszar domenowy to jeden DDM.
- Kolejność pracy: najpierw źródło w górę (model EA, rozmowy), potem pojęcia `DOM-*`, encje i Value Objects, agregaty, reguły `RD-*` i na końcu mapowanie do LDM.
- ID pojęcia `DOM-{Nazwa}` powstaje z nazwy pojęcia bez polskich znaków i spacji: „Pełnomocnictwo” daje `DOM-Pelnomocnictwo`. Pełna nazwa stoi w kolumnie „Pojęcie”.
- Pojęcia `DOM-{Nazwa}` i reguły `RD-{nnn}` to wiersze. Inne dokumenty wskazują je pełnym ID: `ENT-Disposition realizes DDM-001.DOM-Dyspozycja`. Celem relacji jest zawsze wiersz, nigdy cały dokument DDM.
- Numeru RD nie używa się ponownie. Usunięty wiersz znika z dokumentu, a jego historię trzyma repozytorium.
- Encja i maszyna stanów wskazują własne pojęcie. Brakujące pojęcie dopisujesz do DDM, zamiast wskazywać najbliższe.
- DDM nie zawiera: atrybutów, kluczy i typów logicznych (to warstwa LDM), typów fizycznych (`VARCHAR`, indeksy, migracje), listy konsumentów, kopii kodu ani kopii kontraktów OpenAPI i AsyncAPI.

Po co są sekcje:

- Tabela pod tytułem podaje obszar i źródło domeny bez czytania całości.
- „Cel i zakres” mówi, co model opisuje i gdzie są granice domeny. Bez tego nie wiadomo, które pojęcia należą do obszaru.
- „Źródła wymagań w górę” zapisuje, skąd pochodzi model. Ślad prowadzi do źródła, a nie do konsumentów.
- „Słownik pojęć domenowych” daje pojęciom jednoznaczne znaczenie i stabilne ID. Na nim opierają się LDM i API.
- „Encje i Value Objects” odróżnia byty z tożsamością od bytów bez tożsamości. To decyduje o agregatach i o tym, jak LDM zamodeluje obiekty.
- „Relacje i agregaty” pokazuje granice spójności i powiązania między pojęciami, ich zachowanie i znaczenie.
- „Reguły i inwarianty domenowe” zapisują warunki, które w domenie są zawsze prawdziwe. Każda reguła ma stabilne ID, które mogą wskazać LDM i testy.
- „Zakres poza dokumentem” wyznacza jawne granice, żeby warstwy się nie dublowały.

## 4. Warianty

Brak wariantów.
