---
doc-id: STM-{nnn}
title: "{Nazwa maszyny stanów}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
owner: "{Imię Nazwisko}"
relations:
  - type: realizes
    target: DDM-{nnn}.DOM-{Nazwa}              # Obiekt (pojęcie DDM)
  - type: realizes
    target: CAP-{nnn}                          # zdolność
---

# {Nazwa maszyny stanów}

| Pole | Wartość |
|---|---|
| Obiekt (pojęcie DDM) | DDM-{nnn}.DOM-{Nazwa} |
| Zdolność | CAP-{nnn} |

{Co reprezentuje maszyna stanów, 1–2 zdania}

## Warunki wstępne

{Co musi być spełnione, zanim obiekt wejdzie w cykl życia}

## Diagram maszyny stanów

<!-- Etykiety stanów to „{Kod}. {Status}” jak w tabelach; stan końcowy prowadzi do [*]. Diagram z EA leży w assets/{nazwa-pliku}.svg, a tabele stanów i przejść są wtedy nadal obowiązkowe. -->

```mermaid
stateDiagram-v2
```

## Stany — opis

### Słownik statusów

| Kod | Status | Opis | Czy końcowy |
|---|---|---|---|
| {Kod} | {Status} | {Opis} | tak / nie |

### Stany procesowe

| Stan z | Stan do | Opis przejścia | Typ przepływu |
|---|---|---|---|
| {Kod}. {Status} | {Kod}. {Status} | {Opis przejścia} | MAIN / ALTERNATIVE / ERROR |

## Kluczowe elementy

- Główna ścieżka sukcesu: {Opis}
- Przejścia alternatywne: {Opis}
- Przekroczenie czasu: {Opis}
- Odrzucenia i rezygnacje: {Opis}

## Scenariusze błędów

<!-- Tylko scenariusze, które prowadzą do niezaplanowanych stanów końcowych. -->

| Scenariusz | Stan | Zachowanie |
|---|---|---|
| {Scenariusz} | {Kod}. {Status} | {Zachowanie} |
