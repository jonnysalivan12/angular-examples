# Maszyna stanów (STM)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Cykl życia obiektu albo procesu: dozwolone stany, przejścia i warunki ich
wyzwalania, stany końcowe (sukces, błąd, rezygnacja). Jeden plik to jedna
maszyna. Jedno pojęcie może mieć kilka maszyn, np. stany rachunku i stany
umowy lokaty.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz cykl życia obiektu jako maszynę stanów.

**Nie używaj gdy:**

- opisujesz kroki procesu → [flow](../../flows/flow/guide.md), [bpms-process](../../workflows/bpms-process/guide.md),
- opisujesz scenariusz z perspektywy użytkownika → [use-case](../../../functional/use-cases/use-case/guide.md),
- opisujesz atrybuty obiektu, w tym listę wartości statusu bez przejść → [ldm-entity](../../data-models/ldm-entity/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Cykl życia którego pojęcia DDM opisujesz? A może opisujesz obiekt techniczny bez pojęcia?
- Jakie są wszystkie statusy obiektu i które z nich kończą cykl życia?
- Co wyzwala każde przejście: zdarzenie, decyzja, upływ czasu?
- Które scenariusze błędów kończą obiekt w stanie innym niż planowany?

Reguły zapisu:

- Pole „Obiekt (pojęcie DDM)” wskazuje pojęcie, którego cykl życia opisujesz: `STM-001 realizes DDM-001.DOM-Dyspozycja`. Maszyna techniczna, np. cykl życia przebiegu rozliczenia, ma w polu „—”.
- Zdolność podajesz w polu „Zdolność” i wskazujesz wpisem `realizes`: `STM-001 realizes CAP-003`.
- Pod tabelą stoi zdanie albo dwa o tym, co maszyna reprezentuje.
- „Słownik statusów” wymienia wszystkie statusy. Kolumna „Czy końcowy” jest jedynym źródłem stanów końcowych, także dla diagramu.
- „Stany procesowe” to tabela przejść: jeden wiersz to jedno przejście, a tabela zawiera wszystkie przejścia. Stan zapisujesz jako `{Kod}. {Status}`, np. `NOWA. Nowa`. Stan początkowy to `[*]`.
- Kolumna „Typ przepływu” ma jedną z wartości: `MAIN` to główna ścieżka sukcesu, `ALTERNATIVE` to akceptowalne odgałęzienie, np. rezygnacja albo ręczna obsługa, a `ERROR` to błąd techniczny albo decyzja negatywna.
- Diagram `stateDiagram-v2` powstaje z tabel: etykiety stanów to `{Kod}. {Status}` jak w tabelach, a stan końcowy prowadzi do `[*]`. Diagram nie zastępuje tabel.
- „Scenariusze błędów” to tabela z kolumnami scenariusz, stan i zachowanie. Wpisujesz do niej tylko scenariusze, które prowadzą do niezaplanowanych stanów końcowych. Odrzucone operacje bez zmiany stanu opisujesz w „Kluczowych elementach”.

## 4. Warianty

- **Diagram Mermaid** w treści dokumentu, generowany z tabel.
- **Diagram wyeksportowany z EA**: plik leży w `assets/` obok dokumentu i nazywa się jak plik dokumentu, np. `assets/cykl-zycia-rachunku.svg`. Sekcja diagramu osadza ten obraz. Tabele stanów i przejść pozostają obowiązkowe.
