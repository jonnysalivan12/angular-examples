---
doc-id: LDM-{nnn}
title: "{Nazwa modelu}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
source: "{np. eksport XML z EA}"
owner: "{Imię Nazwisko}"
relations:
  - type: realizes
    target: DDM-{nnn}.DOM-{Nazwa}              # realizowane pojęcie
  - type: contains
    target: ENT-{Nazwa}                        # encja modelu
---

# {Nazwa modelu}

| Pole | Wartość |
|---|---|
| ID | LDM-{nnn} |
| Źródło DDM | DDM-{nnn} |
| Wersja | {Wersja} |
| Źródło | {Źródło} |

## Cel i zakres

{Jaki obszar danych opisuje model i po co}

## Źródło (DDM)

{Model domenowy, z którego wynika model logiczny}

## Mapowanie DDM → LDM

| Pojęcie | Encja | Uzasadnienie |
|---|---|---|
| DDM-{nnn}.DOM-{Nazwa} | ENT-{Nazwa} | {Uzasadnienie} |

## Diagram ER

<!-- Bez kluczy PK/FK. Liczebność w notacji Mermaid, od strony lewej encji: || dokładnie jeden, |o zero albo jeden, }| jeden albo wiele, }o zero albo wiele; po prawej stronie odpowiednio ||, o|, |{ i o{. -->

```mermaid
erDiagram
```

## Encje

| Encja | Opis |
|---|---|
| ENT-{Nazwa} | {Jedno zdanie opisu} |

## Kluczowe relacje

| Encja źródłowa | Liczebność | Encja docelowa | Opis relacji |
|---|---|---|---|
| ENT-{Nazwa} | 1:N | ENT-{Nazwa} | {Opis relacji} |

## Słowniki zewnętrzne

| Słownik | Używany w | Źródło |
|---|---|---|
| {Słownik} | {Encja i atrybut} | {Źródło słownika} |

## Zakres poza dokumentem

{Czego model nie opisuje}
