# Model logiczny danych, Logical Data Model (LDM)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Model logiczny danych jednego obszaru: encje, atrybuty, relacje i typy
logiczne, niezależne od bazy danych. Model łączy domenę (DDM) z interfejsami.
Plik jest indeksem modelu. Szczegóły każdej encji leżą w osobnych plikach.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz logiczny model danych obszaru: encje, atrybuty, relacje.

**Nie używaj gdy:**

- opisujesz znaczenie pojęć domeny → [ddm](../../../functional/data-models/ddm/guide.md),
- opisujesz szczegóły jednej encji → [ldm-entity](../ldm-entity/guide.md),
- opisujesz cykl życia obiektu → [state-machine](../../state-machines/state-machine/guide.md),
- opisujesz, jak jedno API używa danych → [api-endpoint](../../apis/api-endpoint/guide.md), które wskazuje encje `ENT`.

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Z którego DDM wynika model i które jego pojęcia realizuje?
- Które pojęcia stają się encjami, a które atrybutami innych encji?
- Które encje są zawarte w innych, a które są osobnymi agregatami?
- Z jakich słowników spoza modelu korzystają atrybuty?

Typy logiczne atrybutów:

| Typ logiczny | Opis | Typowe mapowania fizyczne |
|---|---|---|
| String | Tekst, np. imię, tytuł przelewu | VARCHAR, TEXT |
| Integer | Liczba całkowita | INTEGER, BIGINT |
| Decimal | Liczba dziesiętna o stałej dokładności, np. kwota | DECIMAL, NUMERIC |
| Date | Data kalendarzowa bez czasu | DATE |
| DateTime | Data z czasem | TIMESTAMP, TIMESTAMP WITH TIME ZONE |
| Boolean | Prawda albo fałsz | BOOLEAN, BIT |
| UUID | Uniwersalny identyfikator | UUID, CHAR(36) |
| Dictionary[NazwaSłownika] | Wartość ze słownika spoza modelu | VARCHAR z kluczem obcym do tabeli słownika |
| Enum | Wartość z zamkniętej listy encji, opisanej w jej typach wyliczeniowych | VARCHAR, ENUM |

Mapowania fizyczne to wskazówka dla programisty. Model logiczny ich nie
zapisuje.

Czego nie umieszczać w modelu logicznym i w encjach:

- kluczy fizycznych i relacji po kluczach,
- typów i struktur fizycznych, np. VARCHAR(255), BIGINT, TIMESTAMP WITH TIME ZONE, precyzji liczb i partycji,
- nazw klas, adnotacji ORM i JPA,
- wartości domyślnych zależnych od środowiska,
- kopii kontraktów OpenAPI i AsyncAPI,
- referencji do konsumentów modelu.

Reguły zapisu:

- Kolejność pracy: zaczynasz od DDM jako źródła, mapujesz pojęcia DOM na encje ENT, rysujesz diagram ER, zakładasz plik na każdą encję, na końcu opisujesz relacje i słowniki.
- LDM wskazuje pojęcia, które realizuje. Wszystkie pochodzą z jednego DDM: `LDM-001 realizes DDM-001.DOM-Dyspozycja`. Jeden DDM może mieć kilka LDM.
- „Encje” to tabela z jednym zdaniem opisu na encję. Każdy wiersz tworzy wpis `LDM-001 contains ENT-Disposition`. Alias biznesowy stoi w nagłówku encji, więc tabela go nie powtarza. Encja należy do jednego LDM. Jej nazwa jest doc-id, unikalnym także między modelami: `ENT-Account` w systemie transakcyjnym, `ENT-AccountSnapshot` w hurtowni.
- „Kluczowe relacje” to tabela: encja źródłowa, liczebność, encja docelowa, opis relacji. Relację „zawiera” zapisuje encja nadrzędna wpisem `ENT contains ENT`. Model nie powtarza jej w `relations`. Encję z innego modelu podajesz nazwą, bez ID, bo model nie wskazuje encji, których nie zawiera ([methodology.md](../../../../methodology.md), sekcja 7).
- „Słowniki zewnętrzne” to tabela: słownik, encja i atrybut, które go używają, źródło słownika. Model bez słowników zewnętrznych ma w tabeli wiersz „Nie dotyczy” z uzasadnieniem.
- Diagram ER nie ma kluczy. Liczebność zapisujesz w notacji Mermaid; legenda stoi w komentarzu szablonu. Na diagramie używasz biznesowych nazw encji.
- Reguły walidacyjne RW leżą w encji, którą walidują ([ldm-entity](../ldm-entity/guide.md)).

Po co są sekcje:

- „Cel i zakres” mówi, jakie struktury logiczne model obejmuje i dla jakiego obszaru.
- „Źródło (DDM)” prowadzi do źródła pojęć, nie do konsumentów modelu. Kierunek jest jeden: LDM wskazuje DDM, a API i integracje wskazują encje modelu (ENT), nie odwrotnie.
- „Mapowanie DDM → LDM” wiąże znaczenie pojęć ze strukturą danych. Tu widać, że model logiczny wynika z domeny.
- „Diagram ER” pokazuje na jednym rysunku encje, atrybuty z typami logicznymi i relacje z liczebnością, bez kluczy fizycznych.
- „Encje” to lista encji ze stałymi ID `ENT-*`. Po tych ID wskazują je API i inne dokumenty.
- „Kluczowe relacje” zapisują relacje i liczebność na poziomie modelu, niezależnie od kodu.
- „Słowniki zewnętrzne” wskazują kody i wartości spoza modelu razem z ich źródłem.
- „Zakres poza dokumentem” wyznacza granice modelu. Dzięki nim model nie schodzi do warstwy fizycznej i nie dubluje innych warstw.

## 4. Warianty

Brak wariantów.
