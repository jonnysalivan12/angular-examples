# Encja modelu logicznego (ENT)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Pojedyncza encja modelu logicznego: pełna lista atrybutów, typy wyliczeniowe,
powiązania i reguły walidacyjne. Jeden plik to jedna encja. Encja jest
podrzędna wobec indeksu LDM i realizuje pojęcie z DDM.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz szczegółowo pojedynczą encję.

**Nie używaj gdy:**

- opisujesz indeks encji obszaru → [ldm](../ldm/guide.md),
- opisujesz znaczenie pojęcia → [ddm](../../../functional/data-models/ddm/guide.md),
- opisujesz przejścia między wartościami statusu → [state-machine](../../state-machines/state-machine/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Które pojęcie DDM encja realizuje i czy jest korzeniem agregatu?
- Które atrybuty współtworzą tożsamość encji?
- Kiedy powstają dane encji i które atrybuty są zapisywane później?
- Które reguły domenowe da się sprawdzić na danych tej jednej encji?

Reguły zapisu:

- doc-id encji to jej nazwa po angielsku, bez przedrostka `t_` i przyrostka `_table`: `ENT-{Nazwa}`. Nazwa jest unikalna w całej dokumentacji.
- „Opis” mówi, czym encja jest i do czego służy. Gdy ma to znaczenie, podaje też, kiedy powstają dane, np. atrybut zapisywany przy utworzeniu, a uzupełniany przy otwarciu.
- Tabela pod tytułem ma pole „Realizuje pojęcie (DDM)” z pojęciem, które encja realizuje: `ENT-Disposition realizes DDM-001.DOM-Dyspozycja`. Encja, która jest rodzajem pojęcia ogólnego, wskazuje to pojęcie ogólne: `ENT-Deposit realizes DDM-002.DOM-Rachunek`. Encja techniczna, np. `ENT-StatusDict`, nie wskazuje pojęcia.
- Typy logiczne i lista „Czego nie umieszczać” stoją w opisie modelu ([ldm](../ldm/guide.md), sekcja 3). Obowiązują także encję.
- Kolumna „Wymagalność” wynika z modelu logicznego. Atrybut jest wymagany wtedy, gdy encja bez niego nie istnieje, a nie dlatego, że sprawdza go formularz. Walidacja aplikacyjna leży w ekranach i regułach walidacyjnych.
- Kolumna „Identyfikator” ma „Tak” dla atrybutów, które współtworzą tożsamość. To pojęcie logiczne, nie klucz główny.
- „Typy wyliczeniowe” mają podsekcję `### {NazwaEnum}` na każdy typ, z tabelą wartości i opisów. Encja bez typów wyliczeniowych pomija sekcję. Wartości ze słownika spoza modelu nie są typem wyliczeniowym. Taki atrybut ma typ `Dictionary[NazwaSłownika]`.
- W sekcji „Powiązania” wartość „zawiera” w kolumnie relacji tworzy wpis w grafie: `ENT-Disposition contains ENT-DispositionItem`. Pozostałe powiązania nie tworzą relacji.
- „Reguły walidacyjne” numerują reguły RW: `ENT-Disposition contains RW-001`. Kolumna RD wskazuje regułę domenową, z której RW wynika. RW leży w encji, którą waliduje. Niezmiennik agregatu leży w korzeniu agregatu. Reguła między agregatami to RD w DDM albo RB w BFS.
- „Uwagi” wymieniają jawne braki: czego nie zmodelowano i dlaczego.

Po co są sekcje:

- „Opis” mówi, czego dotyczą dane i jaką rolę encja pełni w domenie.
- „Atrybuty” to logiczny kontrakt danych: typy logiczne, wymagalność i tożsamość, bez typów fizycznych.
- „Typy wyliczeniowe” dokumentują zamknięte zbiory wartości atrybutów typu Enum. Encja bez nich pomija sekcję.
- „Powiązania” zapisują relacje do innych encji z liczebnością, bez kluczy fizycznych.
- „Reguły walidacyjne” zbierają logikę zapisu właściwą tej encji. Reguły całego obszaru leżą w DDM jako RD; encja je wskazuje, a nie kopiuje.
- „Uwagi” zapisują wprost braki i rozbieżności wobec modelu źródłowego. Zamiast zgadywać wartość, opisujesz brak.

## 4. Warianty

Brak wariantów.
