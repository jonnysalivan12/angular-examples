# Krok Workflow (SPEC-WF)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Logika pojedynczego zadania złożonego w procesie BPMS: zmienne procesowe,
reguły, wywoływane zasoby, obsługa błędów, kryteria akceptacji. Jedno zadanie
złożone to jeden plik. Małe zadanie nie ma pliku. Opisuje je wiersz tabeli
„Zadania procesu” w dokumencie BPMS.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** zadanie procesu spełnia którykolwiek z warunków: ma logikę
decyzyjną typu „jeśli X, to Y”; woła więcej niż jeden zasób (API, INT, QUE);
ma własną obsługę błędów albo zdarzeń granicznych, inną niż opisana
w procesie; potrzebuje kryteriów akceptacji; jego opis działania nie mieści
się w 2–3 zdaniach.

**Nie używaj gdy:**

- opisujesz mapę całego procesu → [bpms-process](../bpms-process/guide.md),
- zadanie jest proste i jego cel, warunki, działanie i wynik mieszczą się w opisie działania w tabeli procesu,
- opisujesz kontrakt API → [api-endpoint](../../apis/api-endpoint/guide.md),
- opisujesz logikę zdolności albo reguły globalne → [capability](../../capabilities/capability/guide.md), [business-functional-spec](../../../functional/business-functional-specs/business-functional-spec/guide.md),
- opisujesz schemat danych domenowych → [ddm](../../../functional/data-models/ddm/guide.md), [ldm-entity](../../data-models/ldm-entity/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Do którego procesu i zadania należy krok?
- Jakiego typu BPMN 2.0 jest zadanie? Typ stoi w tabeli procesu.
- Jakie zmienne procesowe zadanie odczytuje i zapisuje?
- Jakie reguły rządzą krokiem? Zapisujesz je deterministycznie: „jeśli X, to Y”.

Granica odpowiedzialności:

| SPEC-WF opisuje | SPEC-WF nie opisuje |
|---|---|
| Jak zadanie używa API w tym procesie | Kontraktu API (w API) |
| Jak zadanie wywołuje zdolność i co robi z wynikiem | Logiki zdolności (w CAP) |
| Zmienne procesowe wchodzące i wychodzące | Schematu danych domenowych (w modelu danych) |
| Reguły specyficzne dla tego kroku | Reguł globalnych (w CAP albo BFS) |

Reguły zapisu:

- Krok należy do procesu, który go zawiera: `BPMS-001 contains SPEC-WF-001`. Identyfikator zadania w silniku, typ zadania i rola leżą w tabeli „Zadania procesu” tego procesu, nie w kroku. Krok nie ma pola typu ani sekcji kontekstu.
- „Wywoływane zasoby” wymieniają API, INT i QUE, które krok woła sam, w tym zdarzenie, które publikuje: `SPEC-WF-001 consumes API-005`. Zdolności nie wymieniasz. Wynika ona z wpisu `realizes` wołanego zasobu: `SPEC-WF-014 consumes QUE-010`, a `QUE-010 realizes CAP-010`. Krok, który niczego nie woła, ma w tabeli wiersz „—”.
- Zadanie `user-task` czeka na człowieka, który przypisuje, odkłada i kończy je tylko przez API. Relację zapisuje każde z tych API: `API-015 consumes SPEC-WF-005` przypisuje zadanie, a `API-008 consumes SPEC-WF-005` je kończy. Krok nie wymienia tych API ani ekranu, z którego człowiek je wywołuje.
- Tabela „Wejście” w sekcji „Zmienne procesowe” ma kolumnę „Źródło” z ID kroku albo zadania, które zmienną zapisało: `SPEC-WF-002 consumes SPEC-WF-001`, `SPEC-WF-009 consumes BPMS-003.STEP-01`.
- Krok `call-activity` odbiera też zmienne zapisane w podprocesie. Tabela „Wyjście” ma wtedy kolumnę „Źródło” z ID kroku podprocesu: `SPEC-WF-008 consumes SPEC-WF-009`. W pozostałych krokach tabela wyjścia nie ma tej kolumny, bo zmienną zapisuje sam krok.
- Reguły formułujesz deterministycznie: „jeśli X, to Y”. Reguły z rozgałęzieniami możesz dodatkowo pokazać diagramem flowchart.
- „Scenariusze błędów” to tabela z kolumnami scenariusz i zachowanie. Wiersze nie mają identyfikatorów E, bo prefiks E należy do UC i TUC.
- „Obsługa zdarzeń granicznych” i „Efekty uboczne” są opcjonalne.
- Kryteria akceptacji to wiersze kroku: `SPEC-WF-001 contains AC-01`. Nagłówek kryterium ma nazwę po kropce: `### AC-01. {Nazwa kryterium}`. Pod nagłówkiem stoi lista Given, When, Then.
- Krok nie ma sekcji powiązanych dokumentów. Listę powiązań wylicza graf.

## 4. Warianty

- **User Task**: zadanie człowieka. „Wywoływane zasoby” mają wiersz „—”. API, które przypisują, odkładają i kończą zadanie, wskazują krok.
- **Wywołanie podprocesu** (`call-activity`): tabela „Wejście” podaje zmienne przekazywane do podprocesu, a tabela „Wyjście” zmienne przepisywane z podprocesu, z kolumną „Źródło”.
