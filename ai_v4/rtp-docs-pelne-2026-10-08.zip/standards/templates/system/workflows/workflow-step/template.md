---
doc-id: SPEC-WF-{nnn}
title: "{Nazwa zadania}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
owner: "{Imię Nazwisko}"
relations:
  - type: consumes
    target: API-{nnn}                          # Wywoływane zasoby; także INT-{nnn}, QUE-{nnn}
  - type: consumes
    target: SPEC-WF-{nnn}                      # Źródło zmiennej wejściowej; także BPMS-{nnn}.STEP-{nn}; w call-activity także wyjściowej
  - type: contains
    target: AC-{nn}                            # własne kryterium akceptacji
---

# {Nazwa zadania}

## Cel zadania

{Co zadanie ma osiągnąć w procesie}

## Warunki wstępne

{Co musi być spełnione przed startem zadania}

## Wywoływane zasoby

<!-- Tylko zasoby, które krok woła sam. Krok, który niczego nie woła, np. user-task, ma jeden wiersz: „— | — | Zadanie nie woła zasobów”. -->

| Rodzaj | ID | Jak zadanie go używa |
|---|---|---|
| API | API-{nnn} | {Jak zadanie go używa} |
| Integracja | INT-{nnn} | {Jak zadanie go używa} |
| Zdarzenie | QUE-{nnn} | {Jak zadanie go używa} |

## Zmienne procesowe

### Wejście

| Zmienna | Typ | Źródło | Opis |
|---|---|---|---|
| {nazwa} | {Typ} | {Krok SPEC-WF-nnn albo zadanie BPMS-nnn.STEP-nn} | {Opis} |

### Wyjście

<!-- Kolumna „Źródło” opcjonalna: tylko w kroku call-activity, ID kroku podprocesu, który zmienną zapisał. -->

| Zmienna | Typ | Źródło | Opis |
|---|---|---|---|
| {Zmienna} | {Typ} | SPEC-WF-{nnn} | {Opis} |

## Reguły i logika

<!-- Reguły z rozgałęzieniami możesz dodatkowo pokazać diagramem flowchart. -->

- Jeśli {X}, to {Y}.

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| {Scenariusz} | {Zachowanie zadania} |

## Obsługa zdarzeń granicznych

<!-- Opcjonalnie: tylko gdy zadanie ma zdarzenia graniczne w BPMN. -->

| Zdarzenie | Warunek | Obsługa |
|---|---|---|
| {Zdarzenie} | {Warunek} | {Obsługa} |

## Efekty uboczne

<!-- Opcjonalnie: zmiany stanu obiektów domenowych, powiadomienia. -->

{Efekty uboczne}

## Kryteria akceptacji

### AC-01. {Nazwa kryterium}

- Given {stan}
- When {zdarzenie}
- Then {wynik}
