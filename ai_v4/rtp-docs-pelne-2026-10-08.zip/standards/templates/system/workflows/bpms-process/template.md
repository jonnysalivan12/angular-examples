---
doc-id: BPMS-{nnn}
title: "{Nazwa procesu}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
bpms-process-id: "{id procesu w silniku}"
process-version: ""                            # znacznik lub skrót zapisu pliku BPMN XML; puste do powstania diagramu
owner: "{Imię Nazwisko}"
relations:
  - type: realizes
    target: CAP-{nnn}                          # zdolność
  - type: contains
    target: STEP-{nn}                          # własne zadanie
  - type: contains
    target: SPEC-WF-{nnn}                      # plik zadania złożonego
  - type: involves
    target: ACTOR-{nnn}.ROLE-{nn}              # Rola
  - type: consumes
    target: API-{nnn}                          # Wywołanie; także INT-{nnn}, QUE-{nnn}
---

# {Nazwa procesu}

## Cel procesu

{Co proces ma osiągnąć i co jest jego wynikiem}

## Kontekst

| Pole | Wartość |
|---|---|
| System | {System} |
| Silnik BPMN | {Silnik BPMN} |
| Inicjator | {Inicjator, podany nazwą} |
| Zakres | {Zakres} |
| Zdolność | CAP-{nnn} |

## Diagram procesu

<!-- Do powstania diagramu sekcja ma wpis „> Założenie: diagram powstanie …”, a process-version jest puste. Silnik BPMN jest jedynym źródłem diagramu; nie powtarzasz go w Mermaid. -->

| Zasób | Odnośnik |
|---|---|
| BPMN XML | assets/{nazwa-pliku}.bpmn |
| Widok w silniku | {Odnośnik} |
| Eksport PNG/SVG | assets/{nazwa-pliku}.svg |

## Zadania procesu

<!-- Wiersze w kolejności z diagramu BPMN; numer usuniętego zadania nie wraca do obiegu. Zadanie złożone ma plik w kolumnie „SPEC-WF”, a jego wywołania opisuje ten plik, więc „Wywołanie” zostaje puste. -->

| ID | W silniku | Typ | Nazwa | Rola | Wywołanie | Opis działania | SPEC-WF |
|---|---|---|---|---|---|---|---|
| STEP-01 | {id zadania w silniku} | user-task / service-task / script-task / business-rule-task / send-task / receive-task / manual-task / call-activity | {Nazwa} | ACTOR-{nnn}.ROLE-{nn} | API-{nnn} | {Co zadanie robi i jaki daje wynik} | SPEC-WF-{nnn} |

## Bramki i warunki

| Bramka | Rodzaj | Warunki |
|---|---|---|
| GW1: {Nazwa} | Exclusive (XOR) / Inclusive (OR) / Parallel (AND) | {Warunki wyboru ścieżek} |

## Zdarzenia graniczne

<!-- Opcjonalnie: tylko gdy zadania mają zdarzenia graniczne. -->

| Zadanie | Typ zdarzenia | Obsługa |
|---|---|---|
| STEP-{nn} | {Typ zdarzenia} | {Obsługa} |

## Podprocesy

{Podprocesy wywoływane przez proces, podane nazwą}
