# Proces BPMS (BPMS)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Mapa procesu, który wykonuje silnik Workflow, a jego diagram jest zapisany
w BPMN: kolejność zadań, kto je wykonuje, bramki, zdarzenia graniczne
i podprocesy. Dokument opisuje działanie każdego zadania tylko w zakresie
potrzebnym do zrozumienia całości. Logika zadania złożonego trafia do pliku
SPEC-WF. BPMN to notacja diagramu, a nie nazwa systemu ani artefaktu.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** proces wykonuje silnik BPMS, np. Camunda, jego diagram jest
modelowany w BPMN i potrzebujesz mapy „co po czym” i „kto co robi”.

**Nie używaj gdy:**

- opisujesz logikę jednego zadania → [workflow-step](../workflow-step/guide.md),
- przepływ nie działa w silniku → [flow](../../flows/flow/guide.md),
- opisujesz scenariusz z perspektywy użytkownika → [use-case](../../../functional/use-cases/use-case/guide.md),
- opisujesz automatyczny scenariusz systemowy i jego wyzwalacz, a orkiestracja w silniku nie jest celem opisu → [technical-use-case](../../../functional/technical-use-cases/technical-use-case/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- W którym silniku proces działa i kto go inicjuje?
- Jakie zadania składają się na proces, w jakiej kolejności i jakiego typu BPMN 2.0?
- Które zadania wykonuje człowiek i w jakiej roli?
- Które zadania są na tyle złożone, że potrzebują pliku SPEC-WF?
- Jakie bramki i zdarzenia graniczne ma diagram?
- Czy diagram BPMN już istnieje, czy specyfikacja powstaje przed nim?

Reguły zapisu:

- Proces to sterowanie, nie logika: mapa mówi „co po czym” i „kto to robi”, nie „jak to robi”.
- Silnik BPMN jest jedynym źródłem prawdy dla diagramu. Nie duplikujesz go w Mermaid ani ASCII. Diagram ma najwyżej 15 zadań. Większy proces dzielisz na podprocesy w osobnych plikach.
- Każde zadanie procesu, małe i złożone, jest wierszem `STEP` w tabeli „Zadania procesu”: `BPMS-001 contains STEP-01`. Wiersze stoją w kolejności z diagramu, a numer usuniętego wiersza nie wraca do obiegu. Inne dokumenty wskazują zadanie pełnym ID: `BPMS-001.STEP-01`.
- Kolumna „W silniku” podaje identyfikator zadania w BPMN XML. Pole `bpms-process-id` podaje identyfikator procesu.
- Kolumna „Typ” przyjmuje osiem typów zadań BPMN 2.0: `user-task` (człowiek przypisuje, odkłada i kończy zadanie przez API), `service-task` (serwis wykonuje logikę), `script-task` (skrypt w silniku), `business-rule-task` (reguły biznesowe albo tabela decyzyjna DMN), `send-task` (wysłanie komunikatu), `receive-task` (oczekiwanie na komunikat), `manual-task` (czynność człowieka poza systemem, bez orkiestracji silnika), `call-activity` (wywołanie podprocesu).
- „Opis działania” jest obowiązkowy dla każdego zadania: co zadanie robi i jaki daje wynik, w 2–3 zdaniach.
- Kolumna „Rola” tworzy wpis `BPMS involves ROLE`: `BPMS-002 involves ACTOR-001.ROLE-02`. Rola zadania leży zawsze w tabeli procesu, także gdy zadanie ma plik SPEC-WF.
- Kolumna „Wywołanie” tworzy wpisy `BPMS consumes API`, `INT` albo `QUE` dla małych zadań: `BPMS-003 consumes API-007`. Zadanie złożone ma w kolumnie „SPEC-WF” identyfikator pliku. Jego wywołania opisuje ten plik, więc proces ich nie powtarza.
- Zadanie dostaje plik SPEC-WF, gdy spełnia którykolwiek z warunków: ma logikę decyzyjną typu „jeśli X, to Y”; woła więcej niż jeden zasób (API, INT, QUE); ma własną obsługę błędów albo zdarzeń granicznych, inną niż opisana w procesie; potrzebuje kryteriów akceptacji; jego opis działania nie mieści się w 2–3 zdaniach. Samo to, że element jest zadaniem BPMN, nie uzasadnia osobnego pliku.
- Zadanie `user-task` człowiek przypisuje, odkłada i kończy przez API. Każde z tych API wskazuje zadanie: małe wierszem (`API consumes BPMS-001.STEP-02`), złożone plikiem (`API-008 consumes SPEC-WF-005`). Kryteria akceptacji zostają tylko w SPEC-WF.
- Bramki zapisujesz w tabeli z oznaczeniem `GW1: {Nazwa}`. Rodzaj bramki: `Exclusive (XOR)` wybiera dokładnie jedną ścieżkę, tę z pierwszym spełnionym warunkiem; `Inclusive (OR)` uruchamia jedną albo wiele ścieżek, wszystkie ze spełnionym warunkiem; `Parallel (AND)` uruchamia wszystkie ścieżki równolegle, bez warunków. Numery GW nie są identyfikatorami w grafie. Proces bez bramek ma w tabeli jeden wiersz „—”.
- „Zdarzenia graniczne” to opcjonalna tabela. Kolumna „Zadanie” podaje wiersz `STEP-{nn}`.
- Specyfikację możesz pisać przed diagramem. Dopóki diagram nie powstanie, sekcja „Diagram procesu” ma wpis `> Założenie: diagram powstanie …`, a `process-version` jest puste. Gdy diagram już istnieje, każda zmiana procesu podnosi `process-version`.
- Plik BPMN XML i jego eksport leżą w `assets/` obok dokumentu i nazywają się jak plik dokumentu: `assets/rozliczenie-dyspozycji.bpmn`, `assets/rozliczenie-dyspozycji.svg`. Eksport PNG/SVG jest opcjonalny.
- Cykl życia procesu: analityk tworzy BPMN XML w narzędziu do modelowania, wypełnia specyfikację procesu i pliki SPEC-WF zadań złożonych, a potem zapisuje je razem. Programista przenosi BPMN XML do repozytorium kodu i rozbudowuje go o szczegóły implementacyjne. Gdy kod i dokumentacja się różnią, kod jest źródłem prawdy o implementacji, a dokumentacja źródłem intencji biznesowej. Analityk sprawdza wtedy zgodność z wymaganiami i aktualizuje specyfikację.
- Zdolność podajesz w polu „Zdolność” i wskazujesz wpisem `realizes`.
- Proces uruchamia API albo przepływ. Relację zapisuje ten dokument, który uruchamia proces: `API-006 consumes BPMS-001`. W polu „Inicjator” podajesz inicjatora nazwą, bez ID, bo dokument nie wymienia dokumentów, które go wskazują ([methodology.md](../../../../methodology.md), sekcja 7). Podprocesy i inne procesy też podajesz nazwą.

## 4. Warianty

- **Pełny proces**: cały przebieg od początku do końca.
- **Podproces**: etap zbyt złożony, by zmieścić się w 15 zadaniach diagramu głównego. Ma osobny plik, a proces główny wywołuje go przez `call-activity`.
- **Proces obsługi błędów**: osobny przebieg dla sytuacji wyjątkowych, np. uruchamiany z timera granicznego.
