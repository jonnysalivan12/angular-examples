---
doc-id: NFR-{nnn}
title: "{Nazwa}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
scope: system                                  # system | component
owner: "{Imię Nazwisko}"
relations:
  - type: contains
    target: NFRT-{KATEGORIA}-{nn}              # własny wiersz, np. NFRT-PERF-01
---

# {Nazwa}

| Pole | Wartość |
|---|---|
| Zakres | system / component |
| Zespół odpowiedzialny | {zespół albo rola} |
| Krytyczność | wysoka / średnia / niska |

## Cel i kontekst

{Po co są wymagania jakościowe, czego dotyczą i jakie ryzyka ograniczają}

## Macierz wymagań

| ID | Atrybut jakości | Metryka | Próg docelowy | Metoda pomiaru | Środowisko | Priorytet |
|---|---|---|---|---|---|---|
| NFRT-{KATEGORIA}-{nn} | {Atrybut jakości} | {Metryka} | {Próg docelowy} | {Metoda pomiaru} | {Środowisko} | Must / Should / Could / Won't |

## Katalog według kategorii

### Performance

- NFRT-PERF-{nn}: {Opis}

### Availability i Reliability

- NFRT-AVAIL-{nn}: {Opis}

### Security i Compliance

- NFRT-SEC-{nn}: {Opis}

### Observability i Auditability

- NFRT-OBS-{nn}: {Opis}

### Operability i Maintainability

- NFRT-OPS-{nn}: {Opis}

### Continuity (RTO/RPO)

- NFRT-CONT-{nn}: {Opis}

## Weryfikacja i monitorowanie

| ID | Przed wydaniem | Po wydaniu | Próg alertu |
|---|---|---|---|
| NFRT-{KATEGORIA}-{nn} | {Przed wydaniem} | {Po wydaniu} | {Próg alertu} |

## Wyjątki i odstępstwa

| ID | Powód | Akceptujący | Data wygaśnięcia |
|---|---|---|---|
| NFRT-{KATEGORIA}-{nn} | {Powód} | {Akceptujący} | {Data wygaśnięcia} |
