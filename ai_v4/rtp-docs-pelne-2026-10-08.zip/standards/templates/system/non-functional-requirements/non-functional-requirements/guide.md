# Non-Functional Requirements (NFR)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Wymagania jakościowe systemu albo komponentu: jak szybko, jak bezpiecznie,
jak niezawodnie i jak operacyjnie ma działać rozwiązanie. To dokument
nadrzędny dla ograniczeń niefunkcjonalnych. Do jego wierszy odwołują się BFS,
CAP, UC, TUC, API i INT.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**

- definiujesz bazowy zestaw wymagań jakościowych na etapie VISION,
- definiujesz albo aktualizujesz wymagania jakościowe systemu lub komponentu,
- chcesz mieć jedno źródło prawdy dla SLA, SLO, bezpieczeństwa, dostępności i monitoringu.

**Nie używaj gdy:**

- opisujesz wymaganie funkcjonalne albo próg jakościowy jednego procesu → [business-functional-spec](../../../functional/business-functional-specs/business-functional-spec/guide.md), sekcja „Wymagania niefunkcjonalne”,
- opisujesz przebieg scenariusza → [use-case](../../../functional/use-cases/use-case/guide.md), [technical-use-case](../../../functional/technical-use-cases/technical-use-case/guide.md),
- opisujesz kontrakt jednego punktu końcowego bez wymagań przekrojowych → [api-endpoint](../../apis/api-endpoint/guide.md),
- opisujesz, co system potrafi → [capability](../../capabilities/capability/guide.md); zdolność wskaże wiersze NFR, które ją ograniczają.

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaki jest kontekst biznesowy i krytyczność systemu albo komponentu?
- Jakich poziomów jakości (SLA, SLO) oczekuje biznes?
- Jakie wymagania regulacyjne i bezpieczeństwa obowiązują?
- Które metryki są mierzalne i kto odpowiada za ich utrzymanie?

Reguły zapisu:

- Bazowy zestaw wymagań powstaje na etapie VISION. Szczegóły uzupełniasz później.
- Zakres dokumentu to `system` albo `component`. Progi jakości jednego procesu zapisuje BFS w sekcji „Wymagania niefunkcjonalne” i wskazuje tam wiersze NFR.
- „Zespół odpowiedzialny” pod tytułem to zespół albo rola, która utrzymuje wymagania. Pole `owner` w nagłówku pliku to nadal osoba odpowiedzialna za dokument.
- Wiersze macierzy wymagań mają prefiks NFRT: `NFRT-PERF-01`. BFS, UC, TUC, CAP, API i INT wskazują wiersz pełnym ID: `API-001 constrained_by NFR-001.NFRT-PERF-01`. Celem relacji jest zawsze wiersz, nigdy cały dokument NFR.
- Kod kategorii odpowiada sekcji „Katalogu według kategorii”: PERF (Performance), AVAIL (Availability i Reliability), SEC (Security i Compliance), OBS (Observability i Auditability), OPS (Operability i Maintainability), CONT (Continuity). Numer liczysz osobno w każdej kategorii dokumentu. Przykład: po `NFRT-PERF-02` w `NFR-001` następny wiersz to `NFRT-PERF-03`.
- Wpis katalogu ma postać `- NFRT-{KATEGORIA}-{nn}: {Opis}`. Kategoria bez własnych wierszy dostaje zdanie, co w niej obowiązuje.
- Kolumny „Środowisko” i „Priorytet” macierzy mówią, gdzie próg obowiązuje i jak ważny jest w skali MoSCoW.
- Numer NFRT nie wraca do obiegu. Usunięty wiersz znika z dokumentu, a jego historię trzyma repozytorium.

## 4. Warianty

- **NFR systemowy**: `scope: system`. Wymagania przekrojowe dla wielu komponentów.
- **NFR komponentowy**: `scope: component`. Wymagania jednego komponentu, dodane do progów systemowych.
