# API Endpoint (API)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Dokument opisuje jeden punkt końcowy API: jego cel, parametry, zachowanie
i model odpowiedzi. Jeden punkt końcowy to jeden plik. Dokument zawiera to,
czego nie da się wyczytać z kontraktu OpenAPI (Swagger).

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** dokumentujesz jeden punkt końcowy API: jak go wywołać i jak się zachowuje.

**Nie używaj gdy:**

- opisujesz, co system potrafi, a nie kontrakt wywołania → [capability](../../capabilities/capability/guide.md),
- opisujesz połączenie z systemem zewnętrznym → [integration](../../integrations/integration/guide.md),
- opisujesz kontrakt zdarzenia w brokerze → [asyncapi-event](../../asyncapi/asyncapi-event/guide.md),
- opisujesz część przebiegu, która jest złożona albo wspólna dla kilku API → [flow](../../flows/flow/guide.md); API wskaże ten przepływ,
- opisujesz zasadę wspólną dla wielu kontraktów, np. model odpowiedzi błędnej → [convention](../../conventions/convention/guide.md); API wskaże tę konwencję.

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaką metodę i ścieżkę ma punkt końcowy i jaki jest jego cel biznesowy?
- Jakie są parametry wejściowe, skąd pochodzą (query, header, path, body) i które są wymagane?
- Jakie reguły walidacji obowiązują pola: wymagalność, długość, format, zakresy, zależności warunkowe?
- Jakie kody błędów HTTP i komunikaty walidacji zwraca system?
- Jak wygląda autentykacja: token, dostęp publiczny, wymagana rola?
- Jaką strukturę ma odpowiedź i co jej pola znaczą biznesowo, nie tylko technicznie?
- Od jakich integracji i serwisów zależy punkt końcowy?

Reguły zapisu:

- Nie kopiujesz kontraktu OpenAPI.
- Zdolność podajesz w polu „Zdolność” i wskazujesz wpisem `realizes`: `API-001 realizes CAP-001`.
- Tabela walidacji wymienia wszystkie reguły: format, zakresy, długość i zależności warunkowe. Walidację warunkową opisujesz w kolumnie „Reguła” albo w sekcji „Zachowanie”. Każda reguła ma kod HTTP i komunikat. Jeśli punkt końcowy nie ma reguł poza wymagalnością pól, w sekcji wpisujesz „Nie dotyczy (wymagalność opisana w Parametrach wejściowych)”.
- Sekcja „Encje” wymienia encje, które w żądaniu albo w odpowiedzi występują jako osobny byt: `API-001 consumes ENT-Disposition`, `ENT-StatusDict`. Encji zagnieżdżonej w innej encji nie wymieniasz, bo graf dochodzi do niej przez wpis `ENT contains ENT`. Przykład: `POST /dispositions` z pozycjami wewnątrz dyspozycji wskazuje tylko `ENT-Disposition`, a odpowiedź `{ disposition, dispositionItems }`, w której pozycje są osobnym bytem, wskazuje obie encje.
- Prosty przebieg opisujesz w „Przebiegu podstawowym” bez przepływu. Przepływ wydzielasz, gdy część przebiegu jest złożona albo wspólna dla kilku API.
- Sekcja „Przebieg podstawowy” wskazuje przepływy, które opisują część przebiegu, i procesy BPMS, które punkt końcowy uruchamia: `API-001 consumes FLOW-001`, `FLOW-002`, `API-006 consumes BPMS-001`. Jedno API może korzystać z kilku przepływów, a jeden przepływ może należeć do kilku API.
- Sekcja „Przebieg podstawowy” wskazuje też zadania użytkownika, które punkt końcowy przypisuje, odkłada albo kończy. Małe zadanie wskazujesz wierszem procesu: `API consumes BPMS-001.STEP-02`. Zadanie złożone wskazujesz plikiem kroku: `API-015 consumes SPEC-WF-005`. Człowiek przypisuje, odkłada i kończy zadanie tylko przez API, dlatego relację zapisuje API, a zadanie nie wymienia punktu końcowego.
- „Przypadek brzegowy” to lista: nazwa przypadku i zachowanie. Sekcja jest opcjonalna. Punkt końcowy bez przypadków brzegowych ją pomija.
- Sekcja „Zależności” wskazuje integracje, które punkt końcowy woła sam, poza przepływami: `API-003 consumes INT-010`. Wywołania zapisanego w przepływie nie powtarzasz. Przykład: FLOW-001 woła INT-001, więc API-001 nie wymienia INT-001.
- Punkt końcowy nie woła innego punktu końcowego. Gdy kilka API ma wspólną część przebiegu, opisuje ją jeden przepływ, a każde z tych API go wskazuje.
- „Model odpowiedzi” wypełniasz tylko wtedy, gdy struktura odpowiedzi jest nietrywialna. „Struktura odpowiedzi błędnej” jest obowiązkowa zawsze.
- Sekcja „Ograniczenia NFR” wskazuje wiersze NFR: `API-001 constrained_by NFR-001.NFRT-PERF-01`. Nie powtarzasz wiersza NFR, który ma już zdolność punktu końcowego. Przykład: `API-020` podlega `NFR-002.NFRT-SEC-02` przez `CAP-020`, więc sam tego wiersza nie wskazuje.
- Sekcje „Autentykacja” i „Struktura odpowiedzi błędnej” wskazują konwencję, która opisuje sposób autentykacji i model odpowiedzi błędnej: `API-009 applies CONV-001`. W tych sekcjach dopisujesz tylko to, co jest własne dla punktu końcowego: wymaganą rolę i jego kody błędów. Nagłówków opisanych w konwencji nie powtarzasz w „Parametrach wejściowych”.
- Punkt końcowy, który odstępuje od konwencji, nie wskazuje jej. Zamiast tego sam opisuje swoje zachowanie w tej sekcji.

## 4. Warianty

Brak wariantów. Sekcje opcjonalne: „Złożone parametry wejściowe”, „Model odpowiedzi”, „Przypadek brzegowy”.
