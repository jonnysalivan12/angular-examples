---
doc-id: NAV-{nnn}
title: "{Nazwa procesu}: mapa nawigacyjna"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
owner: "{Imię Nazwisko}"
relations:
  - type: groups
    target: SCR-{nnn}                          # ekran na mapie
---

# {Nazwa procesu}: mapa nawigacyjna

## Warunki wstępne

{Zakres mapy i założenia o kompletności}

## Diagram nawigacji

<!-- Wszystkie ekrany procesu: startowy, pośrednie, końcowy, ekran błędu, wejścia i wyjścia poza przepływ. Krawędzie: akcja użytkownika to strzałka z etykietą (-->|Dalej|), błąd techniczny to linia przerywana (-. błąd techniczny .->). Duży diagram dzielisz na obszary subgraph. -->

```mermaid
flowchart TD
```

## Kluczowe elementy nawigacji

- Główne przejścia: {Przejścia między ekranami na ścieżce podstawowej}
- Przejścia końcowe i ich warunki: {Jak przepływ się kończy i co o tym decyduje}

## Odniesienia do ekranów

| Ekran | Rola w mapie | Dokument |
|---|---|---|
| {Nazwa ekranu} | startowy / pośredni / końcowy / błędu | SCR-{nnn} |

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| {Scenariusz} | {Zachowanie nawigacji} |
