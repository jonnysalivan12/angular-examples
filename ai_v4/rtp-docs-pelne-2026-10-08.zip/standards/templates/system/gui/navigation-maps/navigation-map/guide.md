# Mapa nawigacyjna ekranów (NAV)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Mapa opisuje przejścia między ekranami jednego procesu: ścieżkę podstawową,
ścieżki błędne, wejścia i wyjścia poza przepływ. Jeden proces to jedna mapa.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz przejścia i połączenia między ekranami procesu.

**Nie używaj gdy:**

- opisujesz jeden ekran → [screen](../../screens/screen/guide.md),
- opisujesz kroki scenariusza użytkownika, a nie przejścia między ekranami → [use-case](../../../../functional/use-cases/use-case/guide.md),
- opisujesz przepływ danych albo logiki między komponentami → [flow](../../../flows/flow/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Które ekrany należą do procesu i który z nich jest startowy, a który końcowy?
- Skąd użytkownik wchodzi do przepływu i dokąd z niego wychodzi?
- Które przejścia wyzwala użytkownik, a które błąd techniczny?
- Czy proces ma osobny ekran błędu, czy błędy są komunikatami na ekranach?

Reguły zapisu:

- Diagram pokazuje wszystkie ekrany procesu, bo `docs-workbench` rysuje z niego mapę nawigacji. Każdy ekran z diagramu ma wpis w tabeli „Odniesienia do ekranów”: `NAV-001 groups SCR-001`.
- Krawędzie diagramu rysujesz tak: akcja użytkownika to strzałka z etykietą, np. `-->|Dalej|`, a błąd techniczny to linia przerywana, np. `-. błąd techniczny .->`. Wejścia i wyjścia poza przepływ to osobne węzły.
- Duży diagram dzielisz na obszary `subgraph`, np. ścieżkę klienta i ścieżkę pracownika. Plik zostaje jeden.
- „Kluczowe elementy nawigacji” to lista z dwóch punktów: „Główne przejścia” i „Przejścia końcowe i ich warunki”. Luki w wiedzy oznaczasz blokiem `> Założenie:` ([_00-meta.md](../../../../_00-meta.md)).
- Kolumna „Rola w mapie” ma wartość z zamkniętej listy: `startowy`, `pośredni`, `końcowy`, `błędu`. Ekran, który jest zarazem startowy i końcowy ścieżki, dostaje obie role w jednej komórce.
- „Scenariusze błędów” to tabela z kolumnami scenariusz i zachowanie nawigacji. Jeśli proces nie ma osobnych ekranów błędu, piszesz o tym zdaniem nad tabelą.
- Mapa zestawia ekrany i opisuje przejścia między nimi. Nie ma własnych wzorców zapytań. Zwraca ją zapytanie `change_scope` dla ekranu, scenariusza i wymagania. Przykład: dla `SCR-002` wynik to `UC-001` i `NAV-001`.

## 4. Warianty

Brak wariantów.
