# Ekran (SCR)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Pojedynczy ekran procesu użytkownika: cel, podział na sekcje, kolejność
wyświetlania, nawigacja do sąsiednich kroków. Dokument łączy sekcje ekranu
w całość i umiejscawia ekran w mapie nawigacyjnej.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz ekran z odnośnikami do makiet, z podziałem na sekcje.

**Nie używaj gdy:**

- opisujesz pola jednej sekcji → [screen-section](../screen-section/guide.md),
- opisujesz przejścia między ekranami procesu → [navigation-map](../../navigation-maps/navigation-map/guide.md),
- opisujesz kroki pracy użytkownika → [use-case](../../../../functional/use-cases/use-case/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Którym krokiem procesu jest ekran i jakie ma sąsiednie kroki?
- Z jakich sekcji ekran się składa i w jakiej kolejności je pokazuje?
- Które sekcje są warunkowe i co decyduje o ich wyświetleniu?
- Dokąd prowadzą przycisk wstecz, przycisk „Dalej” i akcje dodatkowe?

Reguły zapisu:

- Tytuł ma postać „Ekran {Nazwa produktu}: Krok {X} z {Y} — {Nazwa kroku}”.
- „Opis ekranu” zaczyna się akapitem o celu i kontekście ekranu: kto go używa i w którym miejscu procesu. Pod akapitem stoi lista z celami ekranu i odnośnikiem do makiety.
- „Mapa sekcji na ekranie” to dwa obrazy całego ekranu: zwykły i z zaznaczonym podziałem na sekcje. Obrazy leżą w folderze `assets/` obok dokumentu, czyli w folderze ekranu (`system/gui/screens/zgloszenie-reklamacji/assets/`). Nazywają się jak plik dokumentu: `assets/zgloszenie-reklamacji.png` i `assets/zgloszenie-reklamacji-sekcje.png`. Obraz pojedynczej sekcji należy do dokumentu tej sekcji.
- „Struktura ekranu” numeruje sekcje od 1 w kolejności wyświetlania i tworzy wpisy `SCR-001 contains SCRSEC-001`.
- „Nawigacja” ma trzy punkty: „Przycisk wstecz”, „Przycisk „Dalej”” i „Odnośniki i akcje dodatkowe”. Gdy przycisk ma na ekranie inną etykietę, np. „Zatwierdź”, piszesz o tym w punkcie.
- Ekran bywa wspólny dla kilku scenariuszy. Relację zapisuje scenariusz: `UC-001 contains SCR-001`. Krok procesu nie wskazuje ekranu, bo człowiek obsługuje ten krok przez API, a API wywołują kroki scenariusza.
- Ekran nie wskazuje innych ekranów, bo matryca relacji nie ma trójki SCR → SCR. Sąsiednie kroki opisujesz numerem i nazwą. Przejścia z ID ekranów opisuje mapa nawigacyjna.

## 4. Warianty

Brak wariantów.
