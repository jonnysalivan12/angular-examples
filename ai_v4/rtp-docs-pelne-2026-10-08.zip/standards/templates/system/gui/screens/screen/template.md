---
doc-id: SCR-{nnn}
title: "Ekran {Nazwa produktu}: Krok {X} z {Y} — {Nazwa kroku}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
step: "{X}"                                    # numer kroku
owner: "{Imię Nazwisko}"
relations:
  - type: contains
    target: SCRSEC-{nnn}                       # sekcja ekranu
---

# Ekran {Nazwa produktu}: Krok {X} z {Y} — {Nazwa kroku}

## Opis ekranu

{Krótki opis celu i kontekstu ekranu}

- Cele ekranu: {Cele}
- Figma: {Odnośnik}

## Mapa sekcji na ekranie

<!-- Dwa obrazy całego ekranu: zwykły i z zaznaczonym podziałem na sekcje. Obrazy pojedynczych sekcji należą do SCRSEC. -->

![{Nazwa ekranu}](assets/{nazwa-pliku}.png)

![Podział ekranu na sekcje](assets/{nazwa-pliku}-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-{nnn} | {Opis} | {Warunek} |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | {X-1} {Nazwa kroku} | {Status} |
| Bieżący | {X} {Nazwa kroku} | {Status} |
| Następny | {X+1} {Nazwa kroku} | {Status} |

## Nawigacja

- Przycisk wstecz: {Zachowanie}
- Przycisk „Dalej”: {Zachowanie}
- Odnośniki i akcje dodatkowe: {Opis}
