---
doc-id: SCRSEC-{nnn}
title: "{Nazwa sekcji}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
owner: "{Imię Nazwisko}"
relations:
  - type: consumes
    target: ENT-{Nazwa}                        # Źródło danych, Miejsce utrwalenia
  - type: consumes
    target: API-{nnn}                          # Zachowanie
---

# {Nazwa sekcji}

## Opis sekcji

{Co sekcja pokazuje i do czego służy, 3–4 zdania}

## Pola sekcji

<!-- Blok powielany dla każdego pola albo elementu. -->

### {Nazwa pola albo elementu}

| Atrybut | Wartość |
|---|---|
| Typ pola | {Typ pola} |
| Etykieta | {Etykieta} |
| Wartość domyślna | {Wartość domyślna} |
| Wartość przykładowa | {Wartość przykładowa} |
| Źródło danych | ENT-{Nazwa} |
| Miejsce utrwalenia | ENT-{Nazwa} |
| Edytowalność | tak / nie |
| Wymagalność | tak / nie |
| Uprawnienia | {Uprawnienia} |
| Walidacja | {Walidacja} |
| Zachowanie | {Opis}, API-{nnn} |
| Tooltip | {Tooltip} |
| WCAG | {atrybut aria albo element HTML} |
| Analityka zdarzeń (opcjonalnie) | Zdarzenie: {nazwa}, atrybuty: {klucz: wartość} |
| Referencja komponentu UI (opcjonalnie) | {Referencja komponentu UI} |

## Reguły biznesowe

1. **{Nazwa reguły}**: {Opis}

## Zachowania specjalne

<!-- Opcjonalnie: podsekcja na każdy stan albo scenariusz, prozą albo pseudokodem. -->

### {Stan albo scenariusz}

{Zachowanie sekcji w tym stanie albo scenariuszu}
