# Sekcja ekranu (SCRSEC)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Jeden wydzielony fragment ekranu: pola i elementy, źródła danych, walidacje,
reguły biznesowe, zachowania. Sekcja jest podrzędna wobec ekranu. Jedna sekcja
może leżeć na kilku ekranach.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz szczegółowo pola w sekcji ekranu.

**Nie używaj gdy:**

- opisujesz układ całego ekranu → [screen](../screen/guide.md),
- opisujesz kroki pracy użytkownika z wywołaniami API → [use-case](../../../../functional/use-cases/use-case/guide.md),
- opisujesz nawigację między ekranami → [navigation-map](../../navigation-maps/navigation-map/guide.md),
- opisujesz atrybuty encji, a nie pola formularza → [ldm-entity](../../../data-models/ldm-entity/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Na których ekranach sekcja występuje i czy zachowuje się na nich tak samo?
- Skąd każde pole bierze dane i gdzie je utrwala?
- Które pola są edytowalne, które wymagane i kto ma do nich uprawnienia?
- Które wywołania API należą do sekcji, a które do kroków scenariusza?

Reguły zapisu:

- „Opis sekcji” to 3–4 zdania: co sekcja pokazuje i do czego służy. Jeśli obraz sekcji jest potrzebny, wstawiasz go w tym miejscu jako `![…](assets/{nazwa-pliku}.png)`. Plik obrazu leży w `assets/` folderu `ui-specs/`, obok pliku sekcji.
- Każde pole albo element ma blok `### {Nazwa pola albo elementu}` z tabelą atrybutów. Wiersz „WCAG” podaje atrybut aria albo element HTML. Wiersz „Analityka zdarzeń (opcjonalnie)” ma zapis `Zdarzenie: {nazwa}, atrybuty: {klucz: wartość}`. Pole bez analityki ma w tym wierszu „—”.
- „Reguły biznesowe” to lista numerowana `1. **{Nazwa reguły}**: {Opis}`. Numery porządkują listę i nie są identyfikatorami w grafie.
- „Zachowania specjalne” są opcjonalne. Mają podsekcję `### {Stan albo scenariusz}` na każdy stan albo scenariusz, opisaną prozą albo pseudokodem.
- Sekcję wskazuje ekran: `SCR-001 contains SCRSEC-001`. Wskazuje ją też scenariusz UC, którego krok opisuje pracę w tej sekcji: `UC-010 contains SCRSEC-010`. Sekcja nie wymienia ekranów ani scenariuszy, które ją wskazują.
- Atrybuty „Źródło danych” i „Miejsce utrwalenia” wskazują encję: `SCRSEC-001 consumes ENT-Client`. Wskazujesz tylko encję, która w sekcji jest osobnym bytem. Do encji zagnieżdżonej w innej graf dochodzi przez wpis `ENT contains ENT`. Przykład: sekcja „Pozycje” z listą pozycji wskazuje `ENT-DispositionItem`: `SCRSEC-002 consumes ENT-DispositionItem`.
- Atrybut „Zachowanie” wskazuje API tych wywołań, które nie są krokiem scenariusza: podpowiadanie, walidacja w locie, słownik wartości. Sekcja nie woła integracji INT wprost, tylko przez API. Wywołanie, które jest krokiem scenariusza, wpisujesz w kolumnie „Wywołanie” w UC albo TUC. Test: jeśli podpowiadanie da się zastąpić listą rozwijaną bez zmiany scenariusza, wywołanie należy do sekcji.

## 4. Warianty

Brak wariantów.
