# Integracja (INT)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Integracja z systemem zewnętrznym z perspektywy konsumenta: cel, protokół,
operacja, obsługa błędów. Jedna operacja systemu zewnętrznego to jeden plik.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** system konsumuje operację systemu zewnętrznego (REST, SOAP, gRPC, JMS).

**Nie używaj gdy:**

- opisujesz własny punkt końcowy → [api-endpoint](../../apis/api-endpoint/guide.md),
- opisujesz, co system potrafi, a nie połączenie → [capability](../../capabilities/capability/guide.md),
- opisujesz kontrakt zdarzenia w brokerze → [asyncapi-event](../../asyncapi/asyncapi-event/guide.md),
- opisujesz sekwencję kroków przebiegu → [flow](../../flows/flow/guide.md),
- opisujesz zasadę wspólną dla wielu integracji, np. ponawianie wywołań → [convention](../../conventions/convention/guide.md); integracja wskaże tę konwencję.

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaki protokół, właściciela i adres ma system zewnętrzny i czy ma wpis w katalogu API?
- Jaki format ma żądanie i odpowiedź konsumowanej operacji, licząc tylko pola istotne dla nas?
- Kiedy system woła integrację?
- Jak obsługujemy błędy: 404, 5xx, przekroczenie czasu?

Reguły zapisu:

- Integrację opisujesz z perspektywy konsumenta. W odpowiedzi opisujesz tylko pola istotne dla nas, bez kopiowania pełnej specyfikacji dostawcy.
- Tabela „Protokół” ma cztery stałe wiersze. Wolno dopisać wiersze właściwe dla protokołu, np. WSDL przy SOAP albo nazwę kolejki przy JMS. Walidator ich nie odrzuca.
- Kolumna „Źródło” w tabeli żądania mówi, skąd bierze się wartość pola: z parametru, ze stałej albo z nagłówka.
- Zdolność podajesz w polu „Zdolność” i wskazujesz wpisem `realizes`: `INT-017 realizes CAP-022`.
- Sekcja „Encje” wymienia encje, które w operacji są osobnym bytem: `INT-010 consumes ENT-Client`.
- Sekcja „Ograniczenia NFR” wskazuje wiersze NFR: `INT-001 constrained_by NFR-001.NFRT-AVAIL-01`. Nie powtarzasz wiersza NFR, który ma już zdolność integracji. Przykład: `INT-010` podlega `NFR-002.NFRT-SEC-02` przez `CAP-011`, więc sama tego wiersza nie wskazuje.
- „Obsługa błędów” wskazuje konwencję, która opisuje limit czasu i ponawianie wywołań: `INT-001 applies CONV-003`. W wierszach dopisujesz tylko skutek dla procesu, np. odrzucenie dyspozycji, gdy ponowienia zawiodą.
- Integracja, która odstępuje od konwencji, nie wskazuje jej i sama opisuje obsługę błędów. Przykład: INT-003 nie ponawia wywołań, więc nie wskazuje CONV-003.
- „Diagram sekwencji” pokazuje wywołanie i warianty odpowiedzi.

## 4. Warianty

Brak wariantów.
