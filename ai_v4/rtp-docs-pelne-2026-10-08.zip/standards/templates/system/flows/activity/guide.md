# Aktywność, Activity (ACT)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Jedna aktywność z diagramu przepływu: jej logika biznesowa, wejście
i wyjście, reguły i scenariusze błędów. Jeden plik to jedna aktywność.
Aktywność może należeć do kilku przepływów.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** wydzielasz z przepływu logikę ze złożonym algorytmem albo logikę, której używa kilka przepływów.

**Nie używaj gdy:**

- krok jest prosty, więc opisujesz go w przepływie → [flow](../flow/guide.md),
- opisujesz scenariusz z perspektywy użytkownika → [use-case](../../../functional/use-cases/use-case/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Którego przepływu częścią jest aktywność?
- Jakie dane przyjmuje na wejściu i jakie oddaje na wyjściu?
- Jakie warunki uruchomienia i reguły biznesowe jej dotyczą?

Reguły zapisu:

- Osobny plik dostaje tylko logika ze złożonym algorytmem albo logika, której używa kilka przepływów.
- Aktywność nie zapisuje relacji. Wskazuje ją tylko przepływ: `FLOW-001 contains ACT-002`. Scenariusz UC ani TUC nie wskazuje aktywności. Wywołania INT, QUE i BPMS wpisuje przepływ w kolumnie „Wywołanie”.
- Matryca relacji nie ma trójek między ACT a API, INT, QUE ani BPMS. Dlatego ID tych dokumentów w treści aktywności to błąd walidatora. Aktywność nie wymienia też przepływu, który ją zawiera ([methodology.md](../../../../methodology.md), sekcja 7).
- Aktywność nie opisuje kontekstu konkretnego przepływu, bo może należeć do kilku przepływów. Opisuje tylko swoje wejście, wyjście, reguły i błędy. Wejście nazywa dane, a nie krok, który je dostarczył. To, co dzieje się przed aktywnością i po niej, opisuje przepływ.
- „Opis akcji” to kroki działania. Reguły stoją tylko w „Warunkach i regułach”, w dwóch listach: warunki uruchomienia oraz reguły i ograniczenia.
- Opisujesz znaczenie biznesowe, nie implementację, i nie kopiujesz kontraktów OpenAPI.
- „Scenariusze błędów” to tabela z kolumnami scenariusz i zachowanie. Aktywność bez nietrywialnych odchyleń ma w tabeli wiersz „Nie dotyczy” z uzasadnieniem.

## 4. Warianty

Brak wariantów, struktura jest jednolita.
