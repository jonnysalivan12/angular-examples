# Przepływ (FLOW)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Sekwencja kroków procesu biznesowego albo technicznego między uczestnikami,
z warunkami i wariantami, bez szczegółów implementacji. Przepływ może
opisywać część przebiegu API. Jedno API może korzystać z kilku przepływów,
a jeden przepływ może należeć do kilku API.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz sekwencję kroków przepływu biznesowego lub technicznego i chcesz pokazać przebieg między komponentami.

**Nie używaj gdy:**

- krok ma złożony algorytm i wymaga osobnej specyfikacji → [activity](../activity/guide.md),
- opisujesz scenariusz z perspektywy użytkownika → [use-case](../../../functional/use-cases/use-case/guide.md),
- opisujesz, co system potrafi, a nie przebieg → [capability](../../capabilities/capability/guide.md),
- proces wykonuje silnik Workflow → [bpms-process](../../workflows/bpms-process/guide.md).

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jakie warunki muszą być spełnione przed uruchomieniem przepływu?
- Jakie kroki składają się na przebieg i którzy uczestnicy biorą w nim udział?
- Które aktywności wymagają osobnej specyfikacji?
- Czy przebieg podstawowy i obsługa błędów to osobne pliki?

Reguły zapisu:

- Obsługę błędów możesz opisać w osobnym pliku (wariant „Obsługa błędów”). Taki plik ma w tytule dopisek „: obsługa błędów”. Plik podstawowy nie ma dopisku.
- Diagram jest opcjonalny przy prostym przepływie, gdy rysunek nic nie wnosi. Diagram musi zgadzać się z tabelą kroków. Rysujesz go w Mermaid i mieścisz w nim najwyżej 10–15 uczestników albo kroków. Większy diagram dzielisz na poddiagramy.
- „Opis przepływu” ma kolumnę „Wywołanie” z ID INT, QUE albo BPMS: `FLOW-001 consumes INT-001`, `QUE-001`. Proces BPMS wskazujesz, gdy przepływ go uruchamia.
- Przepływ nie wymienia API, które z niego korzystają, i nie woła API. Relację zapisuje API: `API-001 consumes FLOW-001`. ID API w treści przepływu to błąd walidatora ([methodology.md](../../../../methodology.md), sekcja 7).
- Aktywność, która wymaga osobnej specyfikacji, dostaje czytelny tytuł i ID: `FLOW-001 contains ACT-002`. Kolejność aktywności wynika z przepływu. Graf jej nie zapisuje.
- „Scenariusze błędów” to obowiązkowa tabela z kolumnami scenariusz i zachowanie. Wyjątek: gdy obsługę błędów opisuje osobny plik wariantu, plik podstawowy pomija tę sekcję.
- Opisujesz zachowanie systemu, nie implementację.
- Zdolność podajesz w polu „Zdolność” i wskazujesz wpisem `realizes`.

## 4. Warianty

- **Przebieg podstawowy**: plik bez dopisku w tytule. Gdy istnieje plik obsługi błędów, ten plik nie ma sekcji „Scenariusze błędów”.
- **Obsługa błędów**: osobny plik z dopiskiem „: obsługa błędów” w tytule. Opisuje warianty błędne.
