# AsyncAPI, publikacja zdarzenia (QUE)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Dokument to kontrakt zdarzenia, które broker publikuje asynchronicznie:
ładunek, nagłówki i charakterystyka dostarczenia. Jeden plik opisuje jedno
zdarzenie, tak jak jeden plik API opisuje jeden punkt końcowy.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** opisujesz kontrakt zdarzenia publikowanego przez brokera
(Kafka, RabbitMQ) do jednego albo wielu konsumentów.

**Nie używaj gdy:**

- opisujesz synchroniczny punkt końcowy → [api-endpoint](../../apis/api-endpoint/guide.md),
- opisujesz połączenie z systemem zewnętrznym → [integration](../../integrations/integration/guide.md),
- opisujesz logikę przetwarzania po odbiorze komunikatu → [flow](../../flows/flow/guide.md) albo [workflow-step](../../workflows/workflow-step/guide.md),
- opisujesz decyzję albo proces, który prowadzi do publikacji zdarzenia → [technical-use-case](../../../functional/technical-use-cases/technical-use-case/guide.md), [use-case](../../../functional/use-cases/use-case/guide.md) albo [business-functional-spec](../../../functional/business-functional-specs/business-functional-spec/guide.md),
- opisujesz zasadę wspólną dla wielu zdarzeń, np. nagłówki komunikatu → [convention](../../conventions/convention/guide.md); zdarzenie wskaże tę konwencję.

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Który system produkuje zdarzenie i po jakim zdarzeniu biznesowym je publikuje?
- Jaki jest adres kanału: temat, wymiana, klucz trasowania?
- Jaką strukturę ma ładunek, czyli pola biznesowe opisane w „Specyfikacji schematu”?
- Jaką konwencję nazewniczą ma komunikat, jeśli projekt ją ustalił?
- Na jakim brokerze działa komunikacja: Kafka z tematami, RabbitMQ z wymianą i trasowaniem?
- Czy istnieje dokument nadrzędny (BFS, UC, TUC), który opisuje kontekst biznesowy?

Reguły zapisu:

- Nagłówki wspólne dla wielu zdarzeń, np. zgodne z AsyncAPI 3.0 i CloudEvents, opisuje konwencja. Wskazujesz ją w sekcji „Nagłówek komunikatu”: `QUE-001 applies CONV-004`. W tej sekcji podajesz tylko nagłówki własne zdarzenia, tekstem albo w tabeli.
- Jeśli projekt ma konwencję nazewnictwa, to ona ustala nazwę zdarzenia. Wskazujesz ją wpisem `applies CONV`.
- Zdolność publikującą podajesz w polu „Zdolność publikująca” i wskazujesz wpisem `realizes`: `QUE-001 realizes CAP-001`.
- Zdarzenie nie wymienia producenta ani konsumentów. Listę odbiorców graf wylicza z wpisów `consumes QUE` w innych dokumentach: `UC-001 consumes QUE-001` (publikacja), `TUC-010 consumes QUE-010` (odbiór). Zdolność, która odbiera zdarzenie, wskazuje je sama: `CAP-001 consumes QUE-002`.
- Sekcja „Encje” wymienia encje, które w schemacie zdarzenia są osobnym bytem: `QUE-002 consumes ENT-Client`.
- „Przykład ładunku” pokazuje sam ładunek zdarzenia, bez pól koperty, które opisuje konwencja.
- „Charakterystyka dostarczenia” jest obowiązkowa. Wartość, której nie znasz, oznaczasz blokiem `> Założenie:`. Przy gwarancji `at-least-once` idempotencja konsumenta jest zawsze wymagana.
- Zdarzenie nie ma sekcji powiązanych dokumentów. Listę powiązań wylicza graf.

## 4. Warianty

- **Plik AsyncAPI wygenerowany z Enterprise Architect**: szablon jest wtedy dokumentacją uzupełniającą. Każde zdarzenie z pliku AsyncAPI ma własny dokument QUE.
