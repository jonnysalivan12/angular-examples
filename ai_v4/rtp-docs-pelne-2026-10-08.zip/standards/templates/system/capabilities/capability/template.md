---
doc-id: CAP-{nnn}
title: "{Nazwa zdolności}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active
owner: "{Imię Nazwisko}"
relations:
  - type: consumes
    target: QUE-{nnn}                          # odbierane zdarzenie
  - type: constrained_by
    target: NFR-{nnn}.NFRT-{KATEGORIA}-{nn}    # wiersz NFR
---

# {Nazwa zdolności}

## Opis

{Co system robi w ramach zdolności, dla kogo i jaki obserwowalny rezultat daje}

## Wartość biznesowa

{Jaką wartość daje zdolność, komu i jaki problem rozwiązuje}

## Zakres odpowiedzialności

- {Odpowiedzialność systemu w ramach zdolności}

## Poza zakresem

| Element poza zakresem | System lub zdolność właściciela | Właściciel | Dokumentacja właściciela |
|---|---|---|---|
| {Odpowiedzialność realizowana poza zdolnością} | {System albo nazwa zdolności} | {Jednostka albo osoba} | {Odnośnik albo luka do uzupełnienia} |

## Zdarzenia i kontrakty domenowe

### Odbierane

- QUE-{nnn}: {po co zdolność je odbiera}

## Regulacje

| Regulacja i źródło | Wymaganie lub artykuł | Wpływ na zdolność | Właściciel interpretacji | Monitorowanie zmian |
|---|---|---|---|---|
| {Nazwa i identyfikator regulacji} | {Konkretny zapis} | {Wpływ na działanie zdolności} | {Rola albo obszar} | {Źródło albo cykl przeglądu} |

## Miary i kryteria skuteczności

| Miara | Definicja i jednostka | Wartość bazowa | Oczekiwany próg | Źródło pomiaru | Właściciel |
|---|---|---|---|---|---|
| {Miara} | {Co i jak mierzymy} | {Wartość albo brak danych} | {Próg albo do ustalenia} | {Metryka albo raport i cykl pomiaru} | {Rola albo osoba} |

## Ograniczenia NFR

- NFR-{nnn}.NFRT-{KATEGORIA}-{nn}

## Ryzyka i ograniczenia

| Ryzyko lub ograniczenie | Prawdopodobieństwo lub warunek | Wpływ na zdolność | Mitygacja | Właściciel |
|---|---|---|---|---|
| {Opis ryzyka albo ograniczenia} | {Ocena albo warunek wystąpienia} | {Skutek dla zdolności} | {Kontrola, zachowanie zapasowe albo do ustalenia} | {Rola albo osoba} |
