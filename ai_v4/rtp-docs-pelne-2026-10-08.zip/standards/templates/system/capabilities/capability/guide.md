# Capability (CAP)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Zdolność to konkretna, mierzalna umiejętność systemu, oprogramowania,
urządzenia albo organizacji: umiejętność wykonania określonego zadania albo
osiągnięcia celu. Dokument odpowiada na pytanie, co system potrafi, a nie jak
to robi. Jedna zdolność to jedna spójna umiejętność, a nie zbiór funkcji,
komponentów ani integracji. Zdolność ma własną wartość biznesową, miary
skuteczności, ryzyka, regulacje i ograniczenia.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:**

- projektujesz architekturę systemu i ustalasz jego zdolności,
- określasz, co system dostarcza w granicach własnej domeny,
- nowa zdolność albo zmiana istniejącej oznacza nowy zakres wymagań albo zmian w systemie.

**Nie używaj gdy:**

- opisujesz kroki scenariusza → [use-case](../../../functional/use-cases/use-case/guide.md), [technical-use-case](../../../functional/technical-use-cases/technical-use-case/guide.md),
- opisujesz kontrakt punktu końcowego → [api-endpoint](../../apis/api-endpoint/guide.md),
- opisujesz połączenie z systemem zewnętrznym → [integration](../../integrations/integration/guide.md),
- opisujesz wymagania jakościowe, np. SLA, SLO, bezpieczeństwo → [non-functional-requirements](../../non-functional-requirements/non-functional-requirements/guide.md); zdolność wskaże ich wiersze,
- opisujesz reguły biznesowe → [business-functional-spec](../../../functional/business-functional-specs/business-functional-spec/guide.md), bo tam leżą reguły biznesowe,
- dokumentujesz cudzą zdolność domenową → wskaż ją nazwą w „Poza zakresem” i nie przejmuj jej odpowiedzialności,
- opisujesz szeroki, niespójny zestaw funkcji → rozbij go na kilka zdolności.

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaką jedną konkretną czynność albo wartość system dostarcza?
- Do jakiej domeny należy zdolność i kto jest właścicielem tej odpowiedzialności?
- Czym zdolność różni się od innych zdolności systemu? Nazwa i zakres muszą być na tyle wąskie, żeby dało się ją odróżnić od innych.
- Jakie dane, API, moduły albo zdolności innych domen są potrzebne do jej działania i co się dzieje, gdy są niedostępne?
- Jakie regulacje, wytyczne albo wymagania zgodności wpływają na zachowanie systemu?
- Jakimi miarami i progami da się ocenić skuteczność zdolności?
- Jakie są jej własne ryzyka, ograniczenia i granice odpowiedzialności?

Reguły zapisu:

- Zdolność opisuje zachowanie, nie implementację, i nie jest kopią kodu. Jedna zdolność to jeden plik.
- Gdy zmienia się zakres albo powiązania zdolności, aktualizujesz ten sam plik. Nowy dokument nie powstaje przy każdej zmianie.
- UC, TUC, API, INT, QUE, FLOW, BPMS i STM wskazują zdolność wpisem `realizes`: `UC-001 realizes CAP-001`. Zdolność nie wymienia tych dokumentów. Ich listę wylicza graf.
- Zdarzenia, które zdolność odbiera, wskazujesz po ID: `CAP-001 consumes QUE-002`. Zdolność publikującą wskazuje samo zdarzenie: `QUE-001 realizes CAP-001`.
- Progi jakości wskazujesz wierszem NFR: `CAP-002 constrained_by NFR-001.NFRT-SEC-01`. Tabela miar zawiera tylko miary biznesowe zdolności. Progi SLA i inne progi jakości zostają w NFR.
- Zdolność nie wskazuje wymagań BFS. Wymaganie łączy się ze zdolnością przez scenariusz, który realizuje jedno i drugie: `UC-001 realizes BFS-001.REQ-01` i `CAP-001`.
- W „Poza zakresem” inną zdolność podajesz nazwą, bez ID, także gdy należy do tego samego systemu, bo matryca relacji nie ma trójki między zdolnościami. Nieznanego właściciela albo brak dokumentacji oznaczasz jako lukę do uzupełnienia.
- Jeśli nie zidentyfikowano żadnych regulacji, w „Regulacjach” wpisujesz „Nie zidentyfikowano” oraz osobę i termin potwierdzenia. Nie zakładasz bez sprawdzenia, że obowiązków nie ma.

Po co są sekcje:

- „Opis” mówi, co system robi w ramach zdolności, dla kogo i jaki obserwowalny rezultat daje.
- „Wartość biznesowa” podaje wartość, jej odbiorcę i problem, który zdolność rozwiązuje. Wartość ma dać się ocenić miarami z tabeli niżej.
- „Zakres odpowiedzialności” wyznacza odpowiedzialność systemu i jego domeny, spójną z jedną zdolnością.
- „Poza zakresem” wymienia elementy ważne dla pełnego obrazu, które realizuje inna zdolność, domena albo system. Przy każdym elemencie stoi właściciel i odnośnik do jego dokumentacji.
- „Zdarzenia i kontrakty domenowe” wskazują zdarzenia, które zdolność odbiera.
- „Regulacje” pozwalają prześledzić wpływ zmiany regulacji na zdolność.
- „Miary i kryteria skuteczności” to własne, mierzalne kryteria zdolności. Nieuzgodniony próg oznaczasz jako lukę do decyzji właściciela.
- „Ograniczenia NFR” wskazują progi jakości po ID.
- „Ryzyka i ograniczenia” obejmują skutki niedostępności zależności oraz ograniczenia regulacyjne i domenowe, bez powtarzania ogólnych ryzyk systemu.

## 4. Warianty

- **Minimalny**: Opis, Wartość biznesowa, Zakres odpowiedzialności, Poza zakresem.
- **Pełny**, zalecany: do tego Zdarzenia i kontrakty domenowe, Regulacje, Miary i kryteria skuteczności, Ograniczenia NFR, Ryzyka i ograniczenia.
