# Zapis decyzji architektonicznej, Architecture Decision Record (ADR)

Szablon do skopiowania: [template.md](template.md).

## 1. Jakiego artefaktu to szablon?

Pojedyncza decyzja architektoniczna: kontekst, rozważane opcje, wybór
i konsekwencje. Dokument zachowuje historię decyzji: wycofana decyzja dostaje
status `deprecated`, a nie znika z repozytorium. Dokument nie zachowuje
dyskusji. Dyskusja zostaje w zgłoszeniu albo w żądaniu scalenia.

## 2. Kiedy analityk powinien go użyć?

**Użyj gdy:** podejmujesz decyzję architektoniczną, która wymaga uzasadnienia
i śladu, i chcesz zapisać rozważane opcje oraz konsekwencje wyboru.

**Nie używaj gdy:**

- opisujesz zachowanie systemu → [capability](../../../system/capabilities/capability/guide.md), [flow](../../../system/flows/flow/guide.md),
- dokumentujesz dyskusję, a nie rozstrzygniętą decyzję → zostaw ją w zgłoszeniu albo w żądaniu scalenia.

## 3. Co analityk musi wiedzieć, zanim zacznie wypełniać?

Pytania przed pisaniem:

- Jaki problem rozwiązuje decyzja i dlaczego jest potrzebna?
- Jakie opcje były rozważane i jakie mają zalety i wady?
- Jaki jest status decyzji: proponowana, przyjęta czy wycofana?
- Czy decyzja zastępuje wcześniejszą decyzję?

Reguły zapisu:

- Jedna decyzja to jeden plik (inwariant I3). Numeracja jest trzycyfrowa i sekwencyjna: `ADR-001`, `ADR-002`.
- Status `draft` oznacza decyzję proponowaną, `active` przyjętą, a `deprecated` wycofaną albo zastąpioną. Status `deprecated` ma tylko ten typ. Wycofana decyzja zostaje w repozytorium.
- Sekcja „Opcje” ma podsekcję na każdą opcję: `### A. {Nazwa opcji}`, `### B. {Nazwa opcji}`. Opcji jest co najmniej dwie. Wybraną opcję oznacza dopisek „(wybrana)” w nagłówku. Każda opcja ma listę zalet i wad.
- Decyzja nie ma powiązań z innymi typami i żaden inny typ jej nie wskazuje. Dokumenty, których decyzja dotyczy, podajesz w treści nazwą, bez ID (plik [methodology.md](../../../../methodology.md), sekcja 7).
- Jedyna relacja to `supersedes`. Nowa decyzja wymienia w treści ID decyzji, którą zastępuje, i ma wpis `ADR-002 supersedes ADR-001`. Stara decyzja dostaje status `deprecated`. Stara decyzja może podać nową tytułem, bez ID, bo graf pokazuje zastąpienie z wpisu nowej decyzji.
- Walidator nie zgłasza decyzji jako dokumentu bez połączenia z grafem.
- Plik leży w `architecture/decision-records/`. Nazwa pliku to skrót tytułu, na przykład `camunda-8-dla-nowych-procesow.md`.

## 4. Warianty

Brak wariantów: struktura jest jedna. Liczbę opcji dopasowujesz do liczby
rozważanych rozwiązań, ale opcji jest co najmniej dwie.
