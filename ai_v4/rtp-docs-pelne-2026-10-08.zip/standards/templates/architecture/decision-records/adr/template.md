---
doc-id: ADR-{nnn}
title: "{Tytuł decyzji}"
description: "{Krótki opis dokumentu}"
status: draft                                  # draft | active | deprecated
owner: "{Imię Nazwisko}"
relations:
  - type: supersedes
    target: ADR-{nnn}                          # decyzja, którą ta zastępuje
---

# {Tytuł decyzji}

## Kontekst

{Dlaczego decyzja jest potrzebna i jaki problem rozwiązuje}

## Opcje

<!-- Podsekcja na każdą opcję, co najmniej dwie; wybraną oznacza dopisek „(wybrana)”. -->

### {Litera}. {Nazwa opcji}

{Opis opcji}

- Zalety: {Zalety}
- Wady: {Wady}

## Decyzja

{Wybrana opcja i uzasadnienie}

## Konsekwencje

{Co zmienia decyzja: ryzyka, kompromisy, ograniczenia}
