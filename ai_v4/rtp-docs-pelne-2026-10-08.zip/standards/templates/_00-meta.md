# Szablony dokumentów

Jeden folder to jeden typ dokumentu. Typ wynika z prefiksu `doc-id`. Foldery
typów leżą w drzewie trzech warstw: `functional/` (co ma działać: procesy,
scenariusze, aktorzy, pojęcia), `system/` (jak system to robi: zdolności,
kontrakty, przepływy, ekrany, dane) i `architecture/` (decyzje
architektoniczne). Kolumna „Typ” w spisie treści podaje ścieżkę folderu typu
względem tego folderu. Ostatni segment ścieżki jest nazwą typu. Dokumenty
projektu mają taki sam układ warstw ([../methodology.md](../methodology.md),
sekcja 11). W folderze typu leżą dwa pliki:

| Plik | Zawartość |
|---|---|
| `template.md` | czysty szablon: front matter i sekcje do skopiowania |
| `guide.md` | opis działania: czym jest dokument, kiedy go użyć, co trzeba wiedzieć, warianty |

Zasady grafu opisuje [../methodology.md](../methodology.md). Dozwolone relacje
wymienia [../config/relation-matrix.yaml](../config/relation-matrix.yaml).

## Spis treści

### Wymagania

Co ma działać i jakie progi jakości spełnić.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `functional/business-functional-specs/business-functional-spec` | [szablon](functional/business-functional-specs/business-functional-spec/template.md), [opis](functional/business-functional-specs/business-functional-spec/guide.md) | BFS | Punkt wejścia do analizy systemowej, w pracy przyrostowej i projektowej |
| `system/non-functional-requirements/non-functional-requirements` | [szablon](system/non-functional-requirements/non-functional-requirements/template.md), [opis](system/non-functional-requirements/non-functional-requirements/guide.md) | NFR | Wymagania jakościowe systemu lub komponentu |

### Odpowiedzialność

Kto za co odpowiada: role aktorów i zdolności systemu.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `functional/actors/actors` | [szablon](functional/actors/actors/template.md), [opis](functional/actors/actors/guide.md) | ACTOR | Wspólna baza aktorów systemu |
| `system/capabilities/capability` | [szablon](system/capabilities/capability/template.md), [opis](system/capabilities/capability/guide.md) | CAP | Konkretna, mierzalna umiejętność systemu do wykonania zadania albo osiągnięcia celu: co system potrafi, nie jak to robi |

### Scenariusze

Cel aktora i kroki, które do niego prowadzą.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `functional/use-cases/use-case` | [szablon](functional/use-cases/use-case/template.md), [opis](functional/use-cases/use-case/guide.md) | UC | Scenariusz działania użytkownika |
| `functional/technical-use-cases/technical-use-case` | [szablon](functional/technical-use-cases/technical-use-case/template.md), [opis](functional/technical-use-cases/technical-use-case/guide.md) | TUC | Scenariusz działania systemu bez udziału użytkownika (cron, harmonogram, zadanie nocne) |

### Ekrany

To, co użytkownik widzi i wypełnia.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `system/gui/screens/screen` | [szablon](system/gui/screens/screen/template.md), [opis](system/gui/screens/screen/guide.md) | SCR | Opis ekranu z odnośnikami do makiet, z podziałem na sekcje |
| `system/gui/screens/screen-section` | [szablon](system/gui/screens/screen-section/template.md), [opis](system/gui/screens/screen-section/guide.md) | SCRSEC | Szczegółowy opis pól w sekcji ekranu |

### Kontrakty

Format i zasady komunikacji z elementem systemu.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `system/apis/api-endpoint` | [szablon](system/apis/api-endpoint/template.md), [opis](system/apis/api-endpoint/guide.md) | API | Opis jednego punktu końcowego API |
| `system/integrations/integration` | [szablon](system/integrations/integration/template.md), [opis](system/integrations/integration/guide.md) | INT | Integracja z systemem zewnętrznym |
| `system/asyncapi/asyncapi-event` | [szablon](system/asyncapi/asyncapi-event/template.md), [opis](system/asyncapi/asyncapi-event/guide.md) | QUE | Kontrakt zdarzenia publikowanego przez brokera (Kafka, RabbitMQ) |
| `system/conventions/convention` | [szablon](system/conventions/convention/template.md), [opis](system/conventions/convention/guide.md) | CONV | Zasady wspólne dla wielu kontraktów, na przykład model odpowiedzi błędnej albo autentykacja |

### Przepływy

Kolejność kroków i wywołań: przepływ zawiera aktywności, proces silnika zawiera kroki.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `system/flows/flow` | [szablon](system/flows/flow/template.md), [opis](system/flows/flow/guide.md) | FLOW | Przepływ biznesowy lub techniczny |
| `system/flows/activity` | [szablon](system/flows/activity/template.md), [opis](system/flows/activity/guide.md) | ACT | Wydzielony krok przepływu ze złożonym algorytmem |
| `system/workflows/bpms-process` | [szablon](system/workflows/bpms-process/template.md), [opis](system/workflows/bpms-process/guide.md) | BPMS | Mapa procesu w silniku Workflow: orkiestracja, nie logika |
| `system/workflows/workflow-step` | [szablon](system/workflows/workflow-step/template.md), [opis](system/workflows/workflow-step/guide.md) | SPEC-WF | Logika złożonego zadania procesu BPMS (reguły, zmienne procesowe, kryteria akceptacji); małe zadanie to tylko wiersz STEP w procesie |

### Pojęcia i dane

Co znaczy pojęcie, jak wygląda w danych i jakie ma stany.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `functional/data-models/ddm` | [szablon](functional/data-models/ddm/template.md), [opis](functional/data-models/ddm/guide.md) | DDM | Domenowy model danych (pojęcia biznesowe i relacje) |
| `system/data-models/ldm` | [szablon](system/data-models/ldm/template.md), [opis](system/data-models/ldm/guide.md) | LDM | Logiczny model danych (encje, atrybuty, relacje) |
| `system/data-models/ldm-entity` | [szablon](system/data-models/ldm-entity/template.md), [opis](system/data-models/ldm-entity/guide.md) | ENT | Szczegółowy opis pojedynczej encji |
| `system/state-machines/state-machine` | [szablon](system/state-machines/state-machine/template.md), [opis](system/state-machines/state-machine/guide.md) | STM | Cykl życia obiektu jako maszyna stanów |

### Mapy

Zestawienie cudzych dokumentów: powiązania scenariuszy i przejścia między ekranami.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `functional/use-case-technical-map/use-case-technical-map` | [szablon](functional/use-case-technical-map/use-case-technical-map/template.md), [opis](functional/use-case-technical-map/use-case-technical-map/guide.md) | UCMAP | Mapa relacji UC i TUC z aktorami oraz relacjami include, extend, exclude |
| `system/gui/navigation-maps/navigation-map` | [szablon](system/gui/navigation-maps/navigation-map/template.md), [opis](system/gui/navigation-maps/navigation-map/guide.md) | NAV | Przejścia i połączenia między ekranami procesu |

### Architektura

Decyzje architektoniczne: kontekst, opcje, wybór i konsekwencje.

| Typ | Pliki | Prefiks | Kiedy używać |
|---|---|---|---|
| `architecture/decision-records/adr` | [szablon](architecture/decision-records/adr/template.md), [opis](architecture/decision-records/adr/guide.md) | ADR | Zapis jednej decyzji architektonicznej z rozważanymi opcjami |

## Budowa folderu typu

`template.md` zaczyna się od front matter dokumentu i zawiera sekcje
w kolejności, w jakiej trafiają do dokumentu. Miejsce do wypełnienia
w nawiasach klamrowych (placeholder) mówi, co wpisać: `{Opis kroku}`.
Komentarz HTML oznacza regułę sekcji.

`guide.md` ma cztery sekcje:

1. Jakiego artefaktu to szablon?
2. Kiedy analityk powinien go użyć? „Użyj gdy” i „Nie używaj gdy” z odesłaniem do właściwego typu.
3. Co analityk musi wiedzieć, zanim zacznie wypełniać?
4. Warianty.

Nowy typ tworzysz jako kopię tego układu: folder z nazwą typu we właściwej
warstwie drzewa, własny prefiks `doc-id` dopisany w `scripts/lib/ids.js`, oba
pliki i wiersz w spisie treści ze ścieżką folderu.

## Wspólne dla dokumentów

| Pole | Zawartość |
|---|---|
| `doc-id` | prefiks typu i numer (`UC-001`), dla encji nazwa (`ENT-Disposition`); unikalny w całej dokumentacji |
| `title` | nazwa dokumentu |
| `description` | krótki opis dokumentu, jedno zdanie |
| `status` | `draft` przy tworzeniu, `active` po akceptacji właściciela dokumentu (`owner`); `deprecated` tylko dla ADR: decyzja wycofana albo zastąpiona |
| `owner` | właściciel dokumentu |
| `relations` | relacja do każdego ID wspomnianego w treści ([../methodology.md](../methodology.md), sekcje 1 i 2) |

Wartość zaczynająca się od `{` stoi w cudzysłowie, bo YAML czyta nawias
klamrowy jako mapę.

Historię zmian dokumentu trzyma repozytorium, nie sekcja w dokumencie.

Zasady wspólne dla treści:

- Sekcja, której nie da się wypełnić, dostaje wpis „Nie dotyczy” z uzasadnieniem. Sekcję, którą pomija wariant opisany w `guide.md`, można pominąć.
- Gdy brakuje danych, dokument dostaje blok `> Założenie: …` z tym, co przyjęto zamiast brakującej informacji. Zgadywanie nie zastępuje tego bloku. Założenie zostaje w dokumencie do czasu potwierdzenia.

Inwarianty:

- I1: jedno źródło prawdy dla diagramu, bez powtarzania go w innej notacji.
- I3: jeden byt to jeden plik: jedno API, jedna operacja integracji, jedno zdarzenie, jedna encja, jedna aktywność, jedno złożone zadanie procesu BPMS, jeden wariant UC lub TUC.
- I7: opis zachowania z perspektywy biznesowej, nie kopia kodu ani kontraktu OpenAPI.
