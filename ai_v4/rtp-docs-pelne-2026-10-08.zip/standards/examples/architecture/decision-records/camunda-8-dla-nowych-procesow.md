---
doc-id: ADR-003
title: "Camunda 8 dla nowych procesów"
description: "Decyzja o uruchamianiu nowych procesów, od procesu otwarcia rachunku, w Camunda 8 i pozostawieniu istniejących procesów w Camunda 7 do czasu migracji."
status: active                                 # draft | active | deprecated
owner: "Katarzyna Wójcik"
relations:
  - type: supersedes
    target: ADR-001
---

# Camunda 8 dla nowych procesów

## Kontekst

Decyzja ADR-001 „Camunda 7 jako silnik procesów” osadziła silnik w serwisach
rozliczeń i reklamacji. Nowe wersje silnika powstają w linii Camunda 8,
która ma inny model wdrożenia: silnik działa jako osobna usługa, serwisy
rejestrują zadania przez klientów, a instancje ogląda się w Operate zamiast
w Cockpit. Proces otwarcia rachunku jest pierwszym nowym procesem od tamtej
decyzji i trzeba było wybrać dla niego silnik.

## Opcje

### A. Camunda 7 dla wszystkich procesów

Nowe procesy powstają w Camunda 7 osadzonej w serwisach, jak dotychczas.

- Zalety: jeden silnik i jeden sposób wdrożenia; zespoły znają Cockpit i model osadzony.
- Wady: nowe procesy wiążą się z linią silnika, którą trzeba będzie migrować; brak doświadczenia z Camunda 8 przed migracją.

### B. Camunda 8 dla nowych procesów, istniejące do migracji (wybrana)

Nowe procesy działają w Camunda 8 jako osobnej usłudze; procesy rozliczenia
dyspozycji i obsługi reklamacji zostają w Camunda 7 do osobnej decyzji
o migracji.

- Zalety: pierwszy proces w Camunda 8 daje doświadczenie przed migracją; istniejące procesy nie zmieniają się bez potrzeby.
- Wady: dwa silniki w infrastrukturze przez okres przejściowy; specyfikacje procesów muszą podawać, w którym silniku proces działa.

### C. Migracja wszystkich procesów naraz

Wszystkie procesy przechodzą na Camunda 8 w jednym wdrożeniu.

- Zalety: jeden silnik od razu.
- Wady: migracja działających instancji rozliczeń i reklamacji w trakcie ich przebiegu; zmiana trzech procesów bez doświadczenia z nowym silnikiem.

## Decyzja

Wybrana opcja B: proces otwarcia rachunku i kolejne nowe procesy działają
w Camunda 8. Procesy rozliczenia dyspozycji i obsługi reklamacji zostają
w Camunda 7 do osobnej decyzji o migracji. Decyzja zastępuje ADR-001
„Camunda 7 jako silnik procesów”.

## Konsekwencje

- Proces otwarcia rachunku ma widok w Operate, a procesy rozliczeń i reklamacji nadal w Cockpit; specyfikacja procesu podaje silnik w polu „Silnik BPMN”.
- Infrastruktura utrzymuje dwa silniki do końca migracji.
- Migracja istniejących procesów wymaga osobnej decyzji z planem przeniesienia działających instancji.
