---
doc-id: ADR-001
title: "Camunda 7 jako silnik procesów"
description: "Decyzja o uruchamianiu procesów rozliczenia dyspozycji i obsługi reklamacji w silniku Camunda 7 osadzonym w serwisach zamiast orkiestracji w kodzie."
status: deprecated                             # draft | active | deprecated
owner: "Anna Nowak"
relations: []
---

# Camunda 7 jako silnik procesów

## Kontekst

Procesy rozliczenia dyspozycji i obsługi reklamacji mają kroki, które czekają
na człowieka albo na zewnętrzny system, ponowienia po błędach i terminy, np.
14 dni na decyzję w sprawie reklamacji. Orkiestracja tych kroków w kodzie
serwisów wymagałaby własnej obsługi stanu instancji, timerów i incydentów
w każdym serwisie. Zespół potrzebował silnika, w którym analityk modeluje
proces w BPMN, a programista wdraża ten sam diagram.

## Opcje

### A. Orkiestracja w kodzie serwisów

Każdy serwis sam steruje kolejnością kroków, zapisuje stan instancji w swojej
bazie i ponawia wywołania.

- Zalety: bez nowego komponentu w infrastrukturze; pełna kontrola nad kodem.
- Wady: własna obsługa timerów, incydentów i ponowień w każdym serwisie; diagram procesu nie jest wykonywany, więc rozjeżdża się z kodem.

### B. Camunda 7 osadzona w serwisach (wybrana)

Silnik Camunda 7 działa jako biblioteka w serwisie, który jest właścicielem
procesu; diagram BPMN XML leży w repozytorium kodu tego serwisu.

- Zalety: wykonywany diagram BPMN jest jedynym źródłem prawdy dla przebiegu procesu; silnik obsługuje timery, zdarzenia graniczne, ponowienia i incydenty; Cockpit pokazuje instancje operatorowi.
- Wady: każdy serwis z procesem utrzymuje własną bazę silnika; wersja silnika jest związana z wersją serwisu.

### C. Camunda 7 jako osobna usługa wspólna

Jedna instalacja silnika dla wszystkich procesów; serwisy rejestrują
zewnętrzne zadania.

- Zalety: jedna baza i jeden Cockpit dla wszystkich procesów.
- Wady: wspólny komponent wiąże wdrożenia zespołów; zmiana procesu jednego zespołu wymaga wdrożenia wspólnej usługi.

## Decyzja

Wybrana opcja B: Camunda 7 osadzona w serwisie, który jest właścicielem
procesu. Diagram BPMN XML powstaje u analityka i trafia do repozytorium kodu
serwisu bez zmian w przebiegu procesu.

Decyzja wycofana: dla nowych procesów obowiązuje decyzja „Camunda 8 dla
nowych procesów”, a procesy rozliczenia dyspozycji i obsługi reklamacji
zostają w Camunda 7 do czasu migracji.

## Konsekwencje

- Serwis rozliczeń i serwis reklamacji dostają bazę danych silnika i Cockpit.
- Specyfikacja procesu opisuje mapę zadań i bramek, a logikę zadań złożonych osobne pliki kroków; diagram nie jest powtarzany w innej notacji.
- Przejście na nowszą linię silnika wymaga osobnej decyzji, bo Camunda 8 ma inny model wdrożenia.
