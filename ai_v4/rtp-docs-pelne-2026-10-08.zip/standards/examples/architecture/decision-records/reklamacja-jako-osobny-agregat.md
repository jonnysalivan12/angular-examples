---
doc-id: ADR-002
title: "Reklamacja jako osobny agregat"
description: "Decyzja o modelowaniu reklamacji jako osobnego agregatu z własnym cyklem życia i procesem, który wskazuje reklamowaną dyspozycję."
status: active                                 # draft | active | deprecated
owner: "Piotr Zieliński"
relations: []
---

# Reklamacja jako osobny agregat

## Kontekst

Klient może reklamować rozliczoną dyspozycję w ciągu 30 dni od rozliczenia.
Reklamacja ma własne statusy, od zgłoszenia przez rozpatrzenie i eskalację po
odrzucenie albo zamknięcie, i własny proces w silniku, w którym pracownik
zaplecza zapisuje decyzję. Jedna dyspozycja może mieć wiele reklamacji.
Trzeba było rozstrzygnąć, czy reklamacja jest częścią dyspozycji, czy
osobnym obiektem.

## Opcje

### A. Reklamacja jako część agregatu dyspozycji

Reklamacja jest listą w dyspozycji; zmiana statusu reklamacji zmienia
dyspozycję.

- Zalety: jeden agregat i jedna transakcja na zmianę; reklamacja zawsze ma dyspozycję.
- Wady: proces reklamacji blokuje dyspozycję na czas rozpatrzenia; serwis reklamacji musiałby zapisywać dane w bazie dyspozycji; cykl życia dyspozycji mieszałby się z cyklem życia reklamacji.

### B. Reklamacja jako osobny agregat w domenie dyspozycji (wybrana)

Reklamacja jest osobnym agregatem z własnym cyklem życia, który wskazuje
reklamowaną dyspozycję. Pojęcie zostaje w domenie dyspozycji, bo reklamacja
nie istnieje bez rozliczonej dyspozycji.

- Zalety: serwis reklamacji jest właścicielem danych i procesu reklamacji; dyspozycja zmienia status tylko raz, przy korekcie rozliczenia po uznanej reklamacji; wiele reklamacji jednej dyspozycji nie komplikuje dyspozycji.
- Wady: reguła 30 dni łączy dwa agregaty, więc nie jest regułą walidacyjną encji, tylko regułą domenową i regułą procesu; serwis reklamacji pobiera dyspozycję przez API.

### C. Osobna domena reklamacji

Reklamacje dostają własny model domenowy i własny model logiczny.

- Zalety: pełna niezależność zespołu reklamacji.
- Wady: pojęcie reklamacji bez dyspozycji nie ma sensu, więc domena powielałaby pojęcia dyspozycji; dwa modele domenowe dla jednego procesu biznesowego.

## Decyzja

Wybrana opcja B: reklamacja jest osobnym agregatem w domenie dyspozycji.
Encja reklamacji leży w modelu logicznym dyspozycji, ma własną maszynę
stanów i własny proces obsługi reklamacji w serwisie reklamacji.

## Konsekwencje

- Reklamacja wskazuje dyspozycję, a dyspozycja nie zna swoich reklamacji; listę reklamacji dyspozycji daje serwis reklamacji.
- Korekta rozliczenia po uznanej reklamacji jest osobnym podprocesem, który księguje korektę w księdze głównej i dopiero potem proces publikuje decyzję.
- Termin 30 dni sprawdza zgłoszenie reklamacji, a nie encja; zmiana terminu nie zmienia modelu danych.
