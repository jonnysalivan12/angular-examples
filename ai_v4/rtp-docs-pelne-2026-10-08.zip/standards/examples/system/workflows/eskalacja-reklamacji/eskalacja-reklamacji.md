---
doc-id: BPMS-004
title: "Eskalacja przeterminowanej reklamacji"
description: "Proces obsługi błędów uruchamiany timerem 14 dni w obsłudze reklamacji, który oznacza reklamację bez decyzji jako eskalowaną i powiadamia kierownika."
status: draft                                  # draft | active
bpms-process-id: "eskalacja-reklamacji"
process-version: "1.0"                         # znacznik lub skrót zapisu pliku BPMN XML
owner: "Piotr Zieliński"
relations:
  - type: contains
    target: STEP-01
  - type: contains
    target: SPEC-WF-010
  - type: realizes
    target: CAP-004
---

# Eskalacja przeterminowanej reklamacji

## Cel procesu

Gdy reklamacja czeka na decyzję dłużej niż 14 dni, oznaczyć ją jako
eskalowaną i powiadomić kierownika zespołu reklamacji, żeby przyspieszył
rozpatrzenie albo przydzielił zadanie innemu pracownikowi. Proces nie zapisuje
decyzji ani nie przejmuje zadania rozpatrzenia.

## Kontekst

| Pole | Wartość |
|---|---|
| System | System reklamacji (serwis complaint-service) |
| Silnik BPMN | Camunda |
| Inicjator | Timer bez przerywania 14 dni na zadaniu „Rozpatrzenie reklamacji” w procesie „Obsługa reklamacji”, który wysyła komunikat startowy z identyfikatorem reklamacji i osobą przypisaną do zadania |
| Zakres | Zmiana statusu jednej przeterminowanej reklamacji na eskalowaną i jedno powiadomienie kierownika; rozpatrzenie reklamacji trwa dalej w procesie „Obsługa reklamacji” |
| Zdolność | CAP-004 |

## Diagram procesu

| Zasób | Odnośnik |
|---|---|
| BPMN XML | assets/eskalacja-reklamacji.bpmn |
| Widok w silniku | https://camunda.bank.local/camunda/app/cockpit/default/#/process-definition/eskalacja-reklamacji |
| Eksport PNG/SVG | assets/eskalacja-reklamacji.svg |

## Zadania procesu

| ID | W silniku | Typ | Nazwa | Rola | Wywołanie | Opis działania | SPEC-WF |
|---|---|---|---|---|---|---|---|
| STEP-01 | powiadomienie-kierownika | service-task | Powiadomienie kierownika o eskalacji | — | — | Oznacza reklamację bez decyzji po 14 dniach jako eskalowaną i wysyła o niej e-mail kierownikowi zespołu reklamacji. | SPEC-WF-010 |

Niedostępność bramki e-mail obsługują ponowienia w zadaniu; po ich wyczerpaniu
silnik zgłasza incydent do obsługi przez administratora procesu.

## Bramki i warunki

| Bramka | Rodzaj | Warunki |
|---|---|---|
| — | — | Proces nie ma bramek: startowe zdarzenie komunikatu, jedno zadanie i zdarzenie końcowe „Kierownik powiadomiony” |

## Podprocesy

Proces nie wywołuje podprocesów.
