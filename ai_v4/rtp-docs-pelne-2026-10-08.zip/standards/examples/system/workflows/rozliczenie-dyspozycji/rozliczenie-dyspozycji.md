---
doc-id: BPMS-001
title: "Rozliczenie dyspozycji"
description: "Proces silnika, który księguje dyspozycje wybrane do przebiegu rozliczenia i zamyka dzień rozliczeniowy."
status: draft                                  # draft | active
bpms-process-id: "rozliczenie-dyspozycji"
process-version: "1.0"                         # znacznik lub skrót zapisu pliku BPMN XML
owner: "Anna Nowak"
relations:
  - type: contains
    target: STEP-01
  - type: contains
    target: STEP-02
  - type: contains
    target: STEP-03
  - type: contains
    target: SPEC-WF-001
  - type: contains
    target: SPEC-WF-002
  - type: contains
    target: SPEC-WF-003
  - type: realizes
    target: CAP-003
---

# Rozliczenie dyspozycji

## Cel procesu

Zaksięgować w księdze głównej dyspozycje wybrane do przebiegu rozliczenia
i zamknąć przebieg podsumowaniem: ile dyspozycji rozliczono, a ile zostało
nierozliczonych. Przebieg nocny kończy się przed 05:00.

## Kontekst

| Pole | Wartość |
|---|---|
| System | Rozliczenia dyspozycji (settlement-service) |
| Silnik BPMN | Camunda |
| Inicjator | Uruchomienie przebiegu rozliczenia przez punkt końcowy POST /settlement-runs: harmonogram nocny o 01:00 albo harmonogram ponowień |
| Zakres | Jeden przebieg rozliczenia typu NIGHTLY albo RETRY, od pobrania dyspozycji do zamknięcia dnia rozliczeniowego |
| Zdolność | CAP-003 |

## Diagram procesu

| Zasób | Odnośnik |
|---|---|
| BPMN XML | assets/rozliczenie-dyspozycji.bpmn |
| Widok w silniku | Camunda Cockpit, definicja procesu `rozliczenie-dyspozycji`, znacznik wersji 1.0 |
| Eksport PNG/SVG | assets/rozliczenie-dyspozycji.svg |

## Zadania procesu

| ID | W silniku | Typ | Nazwa | Rola | Wywołanie | Opis działania | SPEC-WF |
|---|---|---|---|---|---|---|---|
| STEP-01 | pobranie-dyspozycji | service-task | Pobranie dyspozycji do rozliczenia | — | — | Ustala listę dyspozycji, które rozliczy bieżący przebieg, nadaje im status W_ROZLICZENIU i wyłącza je z korekty. | SPEC-WF-001 |
| STEP-02 | ksiegowanie-pozycji | service-task | Księgowanie pozycji | — | — | Księguje pozycje pobranych dyspozycji w księdze głównej i ustala wynik rozliczenia każdej dyspozycji: ROZLICZONA albo NIEROZLICZONA. | SPEC-WF-002 |
| STEP-03 | zamkniecie-dnia | script-task | Zamknięcie dnia rozliczeniowego | — | — | Podsumowuje wyniki księgowania i ustala stan końcowy przebiegu rozliczenia. | SPEC-WF-003 |

Błąd techniczny zadania serwisowego po wyczerpaniu 3 ponowień tworzy incydent
w silniku; instancja czeka na operatora, który ponawia zadanie albo przerywa
przebieg. Gdy operator przerwie przebieg, settlement-service ustawia status
NIEROZLICZONA dyspozycjom z listy dispositionIds, które mają jeszcze status
W_ROZLICZENIU, bez zwiększania failedSettlementAttempts.

## Bramki i warunki

| Bramka | Rodzaj | Warunki |
|---|---|---|
| GW1: Są dyspozycje do rozliczenia? | Exclusive (XOR) | `tak`, gdy lista dispositionIds z STEP-01 nie jest pusta: proces przechodzi do STEP-02; `nie`, gdy lista jest pusta: proces pomija księgowanie i przechodzi do STEP-03 |

Za księgowaniem proces nie ma bramek. Każda dyspozycja kończy przebieg ze
statusem ROZLICZONA albo NIEROZLICZONA, a nierozliczone z mniej niż trzema
nieudanymi próbami rozliczenia podejmuje kolejny przebieg typu RETRY.
Dyspozycję z trzecią nieudaną próbą rozliczenia zadanie księgowania zgłasza
do ręcznego wyjaśnienia w zespole rozliczeń.

## Podprocesy

Proces nie wywołuje podprocesów: wszystkie trzy zadania wykonuje jedna
instancja procesu.
