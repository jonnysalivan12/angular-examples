---
doc-id: BPMS-002
title: "Obsługa reklamacji"
description: "Proces w silniku Workflow od zarejestrowania zgłoszenia reklamacji do decyzji pracownika, a przy uznaniu do korekty rozliczenia i publikacji decyzji."
status: draft                                  # draft | active
bpms-process-id: "obsluga-reklamacji"
process-version: "1.2"                         # znacznik lub skrót zapisu pliku BPMN XML
owner: "Piotr Zieliński"
relations:
  - type: contains
    target: STEP-01
  - type: contains
    target: STEP-02
  - type: contains
    target: STEP-03
  - type: contains
    target: STEP-04
  - type: contains
    target: STEP-05
  - type: contains
    target: SPEC-WF-004
  - type: contains
    target: SPEC-WF-005
  - type: contains
    target: SPEC-WF-006
  - type: contains
    target: SPEC-WF-007
  - type: contains
    target: SPEC-WF-008
  - type: realizes
    target: CAP-004
  - type: involves
    target: ACTOR-001.ROLE-02
---

# Obsługa reklamacji

## Cel procesu

Doprowadzić każdą zgłoszoną reklamację rozliczonej dyspozycji do decyzji
pracownika zaplecza w ciągu 14 dni. Przy uznaniu reklamacji proces wylicza
rekompensatę, koryguje rozliczenie dyspozycji i dopiero po zaksięgowaniu
korekty publikuje decyzję z kwotą dla wypłaty rekompensaty. Przy odrzuceniu
proces kończy się po zapisie decyzji, bez publikacji.

## Kontekst

| Pole | Wartość |
|---|---|
| System | System reklamacji (serwis complaint-service) |
| Silnik BPMN | Camunda |
| Inicjator | Zgłoszenie reklamacji: punkt końcowy zgłoszenia tworzy reklamację i uruchamia instancję procesu z identyfikatorem reklamacji jako kluczem biznesowym |
| Zakres | Od zarejestrowania reklamacji w procesie do zdarzenia końcowego „Reklamacja odrzucona” albo „Reklamacja uznana”; wypłatę rekompensaty i zamknięcie reklamacji wykonuje odbiorca zdarzenia ComplaintResolved poza procesem |
| Zdolność | CAP-004 |

## Diagram procesu

| Zasób | Odnośnik |
|---|---|
| BPMN XML | assets/obsluga-reklamacji.bpmn |
| Widok w silniku | https://camunda.bank.local/camunda/app/cockpit/default/#/process-definition/obsluga-reklamacji |
| Eksport PNG/SVG | assets/obsluga-reklamacji.svg |

## Zadania procesu

| ID | W silniku | Typ | Nazwa | Rola | Wywołanie | Opis działania | SPEC-WF |
|---|---|---|---|---|---|---|---|
| STEP-01 | rejestracja-reklamacji | service-task | Rejestracja reklamacji w procesie | — | — | Pobiera zgłoszoną reklamację, zapisuje w zmiennych procesu jej identyfikator, reklamowaną dyspozycję i kwotę tej dyspozycji oraz przekazuje reklamację do rozpatrzenia. | SPEC-WF-004 |
| STEP-02 | rozpatrzenie-reklamacji | user-task | Rozpatrzenie reklamacji | ACTOR-001.ROLE-02 | — | Pracownik zaplecza zapisuje decyzję w sprawie reklamacji i kwotę rekompensaty w terminie 14 dni. | SPEC-WF-005 |
| STEP-03 | wyliczenie-rekompensaty | script-task | Wyliczenie rekompensaty | — | — | Ustala kwotę rekompensaty jako mniejszą z kwoty wpisanej przez pracownika i kwoty reklamowanej dyspozycji. | SPEC-WF-006 |
| STEP-04 | wywolanie-korekty-rozliczenia | call-activity | Wywołanie korekty rozliczenia | — | — | Wywołuje podproces korekty rozliczenia z identyfikatorem reklamacji i kwotą rekompensaty i czeka na jego zakończenie. | SPEC-WF-008 |
| STEP-05 | publikacja-decyzji | service-task | Publikacja decyzji reklamacyjnej | — | — | Po zaksięgowaniu korekty publikuje zdarzenie o uznaniu reklamacji z kwotą rekompensaty. | SPEC-WF-007 |

Błędy techniczne zadań serwisowych obsługują ponowienia i incydenty silnika
opisane w plikach zadań.

## Bramki i warunki

| Bramka | Rodzaj | Warunki |
|---|---|---|
| GW1: Decyzja w sprawie reklamacji | Exclusive (XOR) | Bramka stoi za STEP-02 i czyta zmienną `decision` zapisaną przy zakończeniu zadania. `decision = UZNANA`: STEP-03, STEP-04, STEP-05 i zdarzenie końcowe „Reklamacja uznana”; `decision = ODRZUCONA`: zdarzenie końcowe „Reklamacja odrzucona”, bez publikacji decyzji. Bramka nie ma ścieżki domyślnej: inna wartość zatrzymuje instancję incydentem w silniku |

## Zdarzenia graniczne

| Zadanie | Typ zdarzenia | Obsługa |
|---|---|---|
| STEP-02 | Timer bez przerywania `P14D`, liczony od utworzenia zadania | Po 14 dniach proces wysyła komunikat startowy procesu „Eskalacja przeterminowanej reklamacji” z identyfikatorem reklamacji i osobą przypisaną do zadania. Zadanie zostaje otwarte u pracownika, a decyzję zapisuje się jak przed terminem. Zapis decyzji przed upływem 14 dni usuwa timer |

## Podprocesy

- „Korekta rozliczenia po reklamacji”: wywołuje go STEP-04 po wyliczeniu rekompensaty; proces czeka na zakończenie podprocesu i dopiero potem publikuje decyzję.

Proces „Eskalacja przeterminowanej reklamacji” nie jest podprocesem: uruchamia
go komunikat z timera, a obsługa reklamacji nie czeka na jego zakończenie.
