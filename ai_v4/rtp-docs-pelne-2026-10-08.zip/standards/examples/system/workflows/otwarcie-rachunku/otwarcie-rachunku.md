---
doc-id: BPMS-010
title: "Otwarcie rachunku"
description: "Proces w silniku Workflow od wysłania wniosku przez weryfikację tożsamości do otwarcia rachunku i publikacji zdarzenia albo do odrzucenia wniosku."
status: draft                                  # draft | active
bpms-process-id: "otwarcie-rachunku"
process-version: "2.0"                         # znacznik lub skrót zapisu pliku BPMN XML
owner: "Katarzyna Wójcik"
relations:
  - type: contains
    target: STEP-01
  - type: contains
    target: STEP-02
  - type: contains
    target: STEP-03
  - type: contains
    target: STEP-04
  - type: contains
    target: STEP-05
  - type: contains
    target: SPEC-WF-011
  - type: contains
    target: SPEC-WF-012
  - type: contains
    target: SPEC-WF-013
  - type: contains
    target: SPEC-WF-014
  - type: contains
    target: SPEC-WF-015
  - type: realizes
    target: CAP-010
  - type: involves
    target: ACTOR-001.ROLE-02
---

# Otwarcie rachunku

## Cel procesu

Doprowadzić wysłany wniosek o rachunek osobisty albo lokatę terminową do
otwartego rachunku: zweryfikować tożsamość wnioskodawcy automatycznie, a gdy
wynik jest niejednoznaczny, przez pracownika zaplecza; odrzucić wniosek osoby
z listy sankcyjnej albo wniosek odrzucony przez pracownika, zamknąć rachunek
z wniosku i powiadomić klienta; otworzyć rachunek i ogłosić jego otwarcie
innym systemom.

## Kontekst

| Pole | Wartość |
|---|---|
| System | System wniosków o rachunek |
| Silnik BPMN | Camunda 8, identyfikator procesu otwarcie-rachunku |
| Inicjator | Wysłanie wniosku o rachunek przez klienta w bankowości internetowej |
| Zakres | Od zapisania wniosku do publikacji zdarzenia o otwarciu rachunku albo do odrzucenia wniosku; aktywacja rachunku w systemie centralnym leży poza procesem |
| Zdolność | CAP-010 |

## Diagram procesu

| Zasób | Odnośnik |
|---|---|
| BPMN XML | assets/otwarcie-rachunku.bpmn |
| Widok w silniku | https://operate.bank.example/processes/otwarcie-rachunku |
| Eksport PNG/SVG | assets/otwarcie-rachunku.svg |

## Zadania procesu

| ID | W silniku | Typ | Nazwa | Rola | Wywołanie | Opis działania | SPEC-WF |
|---|---|---|---|---|---|---|---|
| STEP-01 | Task_AutomaticIdentityVerification | service-task | Automatyczna weryfikacja tożsamości | — | — | Woła weryfikację automatyczną i zapisuje jej wynik dla bramki procesu. | SPEC-WF-011 |
| STEP-02 | Task_ManualIdentityVerification | user-task | Ręczna weryfikacja tożsamości | ACTOR-001.ROLE-02 | — | Pracownik zaplecza rozstrzyga weryfikację tożsamości, której system nie rozstrzygnął. | SPEC-WF-012 |
| STEP-03 | Task_OpenAccount | service-task | Otwarcie rachunku w systemie | — | — | Po pozytywnej weryfikacji tożsamości otwiera rachunek i nadaje mu numer IBAN. | SPEC-WF-013 |
| STEP-04 | Task_PublishAccountOpened | service-task | Publikacja otwarcia rachunku | — | — | Publikuje zdarzenie AccountOpened z numerem otwartego rachunku. | SPEC-WF-014 |
| STEP-05 | Task_RejectApplication | service-task | Odrzucenie wniosku o rachunek | — | — | Po negatywnej weryfikacji tożsamości zamyka rachunek z wniosku i powiadamia klienta o odrzuceniu wniosku. | SPEC-WF-015 |

## Bramki i warunki

| Bramka | Rodzaj | Warunki |
|---|---|---|
| GW1: Wynik weryfikacji automatycznej | Exclusive (XOR) | Bramka stoi za STEP-01 i czyta zmienną verificationResult. NO_MATCH: proces przechodzi do STEP-03; POSSIBLE_MATCH: proces tworzy zadanie STEP-02; MATCH: proces przechodzi do STEP-05, w którym rachunek z wniosku przechodzi do stanu ZAMKNIETY, a klient dostaje powiadomienie, i kończy się zdarzeniem końcowym „Wniosek odrzucony” |
| GW2: Decyzja pracownika | Exclusive (XOR) | Bramka stoi za STEP-02 i czyta zmienną manualDecision. ZATWIERDZONA: proces przechodzi do STEP-03; ODRZUCONA: proces przechodzi do STEP-05 i kończy się zdarzeniem końcowym „Wniosek odrzucony” |

## Zdarzenia graniczne

| Zadanie | Typ zdarzenia | Obsługa |
|---|---|---|
| STEP-01 | Graniczne zdarzenie błędu IDENTITY_VERIFICATION_UNAVAILABLE | Zadanie zgłasza je, gdy weryfikacja automatyczna nie daje wyniku po wyczerpaniu ponowień; proces przechodzi do STEP-02 z pustą zmienną verificationResult |
| STEP-03 | Graniczne zdarzenie błędu ACCOUNT_OPENING_FAILED | Tworzy incydent w silniku; proces czeka na ponowienie zadania przez administratora |

## Podprocesy

Proces nie wywołuje podprocesów.
