---
doc-id: BPMS-003
title: "Korekta rozliczenia po reklamacji"
description: "Podproces wywoływany z obsługi reklamacji, który pobiera reklamowaną dyspozycję i księguje w księdze głównej korektę jej rozliczenia na kwotę rekompensaty."
status: draft                                  # draft | active
bpms-process-id: "korekta-rozliczenia"
process-version: "1.1"                         # znacznik lub skrót zapisu pliku BPMN XML
owner: "Piotr Zieliński"
relations:
  - type: contains
    target: STEP-01
  - type: contains
    target: STEP-02
  - type: contains
    target: SPEC-WF-009
  - type: realizes
    target: CAP-004
  - type: consumes
    target: API-007
---

# Korekta rozliczenia po reklamacji

## Cel procesu

Po uznaniu reklamacji zaksięgować w księdze głównej korektę rozliczenia
reklamowanej dyspozycji na kwotę rekompensaty i oddać procesowi nadrzędnemu
identyfikator oraz status księgowania korygującego, zanim proces nadrzędny
opublikuje decyzję o uznaniu reklamacji.

## Kontekst

| Pole | Wartość |
|---|---|
| System | System reklamacji (serwis complaint-service) |
| Silnik BPMN | Camunda |
| Inicjator | Proces nadrzędny „Obsługa reklamacji”: zadanie „Wywołanie korekty rozliczenia” (Call Activity) przekazuje identyfikator reklamacji i kwotę rekompensaty |
| Zakres | Jedno księgowanie korygujące dla jednej uznanej reklamacji; publikacja decyzji po zakończeniu podprocesu i wypłata rekompensaty leżą poza podprocesem |
| Zdolność | CAP-004 |

## Diagram procesu

| Zasób | Odnośnik |
|---|---|
| BPMN XML | assets/korekta-rozliczenia.bpmn |
| Widok w silniku | https://camunda.bank.local/camunda/app/cockpit/default/#/process-definition/korekta-rozliczenia |
| Eksport PNG/SVG | assets/korekta-rozliczenia.svg |

## Zadania procesu

| ID | W silniku | Typ | Nazwa | Rola | Wywołanie | Opis działania | SPEC-WF |
|---|---|---|---|---|---|---|---|
| STEP-01 | pobranie-reklamacji | service-task | Pobranie reklamowanej dyspozycji | — | API-007 | Pobiera reklamację z reklamowaną dyspozycją i zapisuje w zmiennych podprocesu identyfikator dyspozycji i jej walutę. Przy braku odpowiedzi albo błędzie 5xx silnik ponawia zadanie 3 razy co minutę, a potem zgłasza incydent. | — |
| STEP-02 | korekta-ksiegowania | service-task | Korekta księgowania dyspozycji | — | — | Księguje w księdze głównej korektę rozliczenia dyspozycji na kwotę rekompensaty i oddaje identyfikator oraz status księgowania korygującego. | SPEC-WF-009 |

## Bramki i warunki

| Bramka | Rodzaj | Warunki |
|---|---|---|
| — | — | Podproces nie ma bramek: zdarzenie startowe, dwa zadania i zdarzenie końcowe „Korekta zaksięgowana” |

## Podprocesy

Podproces nie wywołuje kolejnych podprocesów. Niedostępność księgi głównej
obsługują ponowienia w STEP-02; po ich wyczerpaniu silnik zgłasza incydent,
status dyspozycji się nie zmienia, a proces nadrzędny czeka na zakończenie
podprocesu i do tego czasu nie publikuje decyzji.
