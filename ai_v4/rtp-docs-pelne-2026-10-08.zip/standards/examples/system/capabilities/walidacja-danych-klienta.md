---
doc-id: CAP-002
title: "Walidacja danych klienta"
description: "Zdolność sprawdzania danych klienta: identyfikacji klienta w oddziale w rejestrze PESEL i podpowiadania adresu korespondencyjnego we wniosku o rachunek."
status: draft                                  # draft | active
owner: "Piotr Zieliński"
relations: []
---

# Walidacja danych klienta

## Opis

Zdolność sprawdza dane klienta w dwóch sytuacjach: identyfikuje klienta
obecnego w oddziale, porównując dane z jego dowodu osobistego z rejestrem
PESEL, i podpowiada adres korespondencyjny ze słownika adresów TERYT we
wniosku o rachunek. Wynikiem jest potwierdzenie tożsamości dla doradcy albo
lista podpowiedzi adresu dla klienta.

## Wartość biznesowa

Doradca w oddziale działa w imieniu klienta dopiero wtedy, gdy dane z jego
dowodu osobistego zgadzają się z rejestrem PESEL, więc bank nie przyjmuje
zgłoszeń od osoby podszywającej się pod klienta. Wniosek o rachunek dostaje
adres korespondencyjny ze słownika adresów, więc bank nie wysyła
korespondencji na nieistniejący adres.

## Zakres odpowiedzialności

- Identyfikacja klienta obecnego w oddziale: sprawdzenie numeru PESEL (11 cyfr, suma kontrolna, zgodność z datą urodzenia) i porównanie imienia, nazwiska oraz daty urodzenia z dowodu osobistego z rejestrem PESEL.
- Podpowiadanie adresu korespondencyjnego ze słownika adresów TERYT we wniosku o rachunek.

## Poza zakresem

| Element poza zakresem | System lub zdolność właściciela | Właściciel | Dokumentacja właściciela |
|---|---|---|---|
| Zmiana danych osobowych klienta: imienia, nazwiska i numeru PESEL | System kartoteki klientów | Departament Klienta Detalicznego | Luka do uzupełnienia: brak wpisu w katalogu API banku |
| Weryfikacja tożsamości wnioskodawcy przy otwieraniu rachunku | Zdolność „Weryfikacja tożsamości” | Katarzyna Wójcik | Opis zdolności w tej dokumentacji |
| Rejestracja reklamacji po identyfikacji klienta w oddziale | Zdolność „Obsługa reklamacji” | Piotr Zieliński | Opis zdolności w tej dokumentacji |
