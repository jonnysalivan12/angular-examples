---
doc-id: CAP-003
title: "Rozliczanie dyspozycji"
description: "Zdolność rozliczania zaakceptowanych dyspozycji w księdze głównej: nocny przebieg, ponowienia i korekta rozliczenia po uznanej reklamacji."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations:
  - type: consumes
    target: QUE-003
  - type: constrained_by
    target: NFR-001.NFRT-PERF-02
---

# Rozliczanie dyspozycji

## Opis

Zdolność księguje w księdze głównej pozycje dyspozycji zaakceptowanych
w ciągu dnia: uruchamia nocny przebieg rozliczenia, ponawia w ciągu dnia
rozliczenia, które się nie powiodły, zamyka dzień rozliczeniowy i po uznanej
reklamacji oznacza dyspozycję jako skorygowaną. Rezultatem jest dyspozycja
w statusie ROZLICZONA albo NIEROZLICZONA z pełnym śladem decyzji.

## Wartość biznesowa

Każda zaakceptowana dyspozycja zostaje zaksięgowana w księdze głównej przed
otwarciem dnia operacyjnego, więc rano saldo klienta odpowiada zleconym
przelewom. Zaplecze nie uzgadnia księgowań ręcznie, a dyspozycje, których nie
udało się rozliczyć, dostają kolejne próby bez udziału człowieka.

## Zakres odpowiedzialności

- Nocny przebieg rozliczenia dyspozycji w statusie ZAAKCEPTOWANA i księgowanie ich pozycji w księdze głównej.
- Ponawianie w ciągu dnia rozliczeń, które się nie powiodły, i eskalacja dyspozycji nierozliczonych po trzeciej nieudanej próbie rozliczenia.
- Zamknięcie dnia rozliczeniowego i nadzór nad przebiegiem rozliczenia od uruchomienia do zakończenia.
- Oznaczenie dyspozycji i jej pozycji jako skorygowanych po uznaniu reklamacji.

## Poza zakresem

| Element poza zakresem | System lub zdolność właściciela | Właściciel | Dokumentacja właściciela |
|---|---|---|---|
| Przyjmowanie i korekta dyspozycji przed rozliczeniem | Zdolność „Przyjmowanie dyspozycji” | Anna Nowak | Opis zdolności w tej dokumentacji |
| Rozpatrzenie reklamacji i wypłata rekompensaty | Zdolność „Obsługa reklamacji” | Piotr Zieliński | Opis zdolności w tej dokumentacji |
| Plan kont i salda w księdze głównej | Księga główna | Area Finanse | Katalog API banku, pozycja „Księga główna: usługa księgowań” |

## Zdarzenia i kontrakty domenowe

### Odbierane

- QUE-003: uznana reklamacja wymaga korekty rozliczenia, więc zdolność oznacza reklamowaną dyspozycję i jej pozycje jako skorygowane.

## Regulacje

| Regulacja i źródło | Wymaganie lub artykuł | Wpływ na zdolność | Właściciel interpretacji | Monitorowanie zmian |
|---|---|---|---|---|
| Ustawa o usługach płatniczych, wdrożenie dyrektywy PSD2 | Termin wykonania transakcji płatniczej: uznanie rachunku odbiorcy najpóźniej następnego dnia roboczego po przyjęciu zlecenia | Nocny przebieg rozlicza wszystkie dyspozycje z dnia, a ponowienia w ciągu dnia domykają rozliczenia nieudane w nocy | Departament Compliance | Kwartalny przegląd zmian prawa płatniczego |
| Rekomendacja D KNF | Zarządzanie ciągłością działania i ślad przetwarzania wsadowego | Przebieg zapisuje decyzję o statusie każdej rozliczanej dyspozycji i kończy się przed otwarciem dnia operacyjnego | Departament Ryzyka Operacyjnego | Roczny przegląd zgodności z rekomendacją |

## Miary i kryteria skuteczności

| Miara | Definicja i jednostka | Wartość bazowa | Oczekiwany próg | Źródło pomiaru | Właściciel |
|---|---|---|---|---|---|
| Rozliczenia w pierwszym przebiegu | Odsetek zaakceptowanych dyspozycji rozliczonych w pierwszym nocnym przebiegu, w % | Brak danych, zdolność nowa | ≥ 99% | Raport przebiegu rozliczenia, dziennie | Anna Nowak |
| Dyspozycje nierozliczone po trzech próbach | Odsetek dyspozycji w miesiącu nierozliczonych po trzeciej nieudanej próbie rozliczenia, w % | Brak danych, zdolność nowa | ≤ 0,1% | Raport miesięczny z dziennika rozliczeń | Anna Nowak |
| Czas oznaczenia korekty | Czas od odebrania decyzji o uznaniu reklamacji do oznaczenia dyspozycji jako skorygowanej, w godzinach | Brak danych, zdolność nowa | ≤ 1 h | Metryka konsumenta zdarzeń, dziennie | Anna Nowak |

## Ograniczenia NFR

- NFR-001.NFRT-PERF-02

## Ryzyka i ograniczenia

| Ryzyko lub ograniczenie | Prawdopodobieństwo lub warunek | Wpływ na zdolność | Mitygacja | Właściciel |
|---|---|---|---|---|
| Niedostępność księgi głównej w nocy | Awaria albo okno serwisowe księgi głównej | Rozliczenia przechodzą na ponowienia w ciągu dnia, a księgowanie przelewów klientów się opóźnia | Ponowienia w ciągu dnia co pełną godzinę; eskalacja dyspozycji po trzeciej nieudanej próbie | Anna Nowak |
| Zdublowane księgowanie po przekroczeniu limitu czasu | Ponowienie wywołania, na które księga główna odpowiedziała po limicie czasu | Pozycja zaksięgowana dwa razy | Księga główna rozpoznaje powtórzone żądanie po kluczu idempotencji: identyfikatorze dyspozycji i typie księgowania, a przy korekcie także identyfikatorze reklamacji | Anna Nowak |
| Duża liczba dyspozycji z jednego dnia | Dzień wypłat albo koniec miesiąca | Wydłużony przebieg zagraża zakończeniu przetwarzania w nocnym oknie | Test przebiegu na danych z dnia o największym wolumenie; alert, gdy przebieg nie kończy się o 04:30 | Anna Nowak |
