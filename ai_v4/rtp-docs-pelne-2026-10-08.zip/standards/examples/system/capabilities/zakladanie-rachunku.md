---
doc-id: CAP-010
title: "Zakładanie rachunku"
description: "Zdolność przyjmowania wniosku, otwierania rachunku osobistego albo lokaty i aktywowania ich w systemie centralnym."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations:
  - type: constrained_by
    target: NFR-001.NFRT-PERF-01
---

# Zakładanie rachunku

## Opis

Zdolność przyjmuje online wniosek klienta o rachunek osobisty albo lokatę
terminową, uruchamia proces otwarcia rachunku, po pozytywnej weryfikacji
tożsamości nadaje numer IBAN i otwiera rachunek, publikuje zdarzenie
o otwarciu, powiadamia klienta i aktywuje rachunek albo lokatę w systemie
centralnym. Rezultatem jest aktywny rachunek gotowy do wpłat i przelewów
albo odrzucony wniosek z powiadomieniem klienta.

## Wartość biznesowa

Klient zostaje posiadaczem rachunku osobistego albo lokaty terminowej
w jednym wniosku online, bez wizyty w oddziale. Bank pozyskuje klientów
w kanale cyfrowym, a nowy rachunek trafia do systemu centralnego jako
aktywny, gotowy do wpłat i przelewów. Wartość mierzy odsetek wniosków
zakończonych aktywnym rachunkiem i czas od wysłania wniosku do aktywacji.

## Zakres odpowiedzialności

- Przyjęcie wniosku z danymi klienta, wybranym produktem i zgodami oraz zapis rachunku w stanie WNIOSEK.
- Sprawdzenie przy przyjęciu wniosku pełnoletności wnioskodawcy dla rachunku osobistego i zgody na regulamin produktu.
- Uruchomienie procesu otwarcia rachunku w silniku procesów po zapisaniu wniosku.
- Otwarcie rachunku po pozytywnej weryfikacji tożsamości: nadanie numeru IBAN i stan OTWARTY.
- Odrzucenie wniosku po negatywnej weryfikacji tożsamości: stan ZAMKNIETY rachunku z wniosku i powiadomienie klienta.
- Publikacja zdarzenia o otwarciu rachunku dla innych zdolności banku.
- Powiadomienie klienta e-mailem i SMS o otwarciu rachunku.
- Aktywacja rachunku albo lokaty w systemie centralnym i prowadzenie ich cyklu życia.

## Poza zakresem

| Element poza zakresem | System lub zdolność właściciela | Właściciel | Dokumentacja właściciela |
|---|---|---|---|
| Weryfikacja tożsamości wnioskodawcy; zakładanie rachunku korzysta tylko z jej wyniku | Zdolność „Weryfikacja tożsamości” | Katarzyna Wójcik | Opis zdolności w tej dokumentacji |
| Oferta produktów, opłaty i oprocentowanie; zdolność czyta je z katalogu produktów, ale ich nie zmienia | Katalog produktów | Tribe Oferta | Luka do uzupełnienia: brak wpisu w katalogu API banku |
| Prowadzenie rachunku po aktywacji: salda, wpłaty i przelewy | System centralny | Area Core Banking | Katalog API banku, pozycja „System centralny: aktywacja rachunku” |
| Wydanie karty, dostęp do bankowości internetowej i dyspozycje z nowego rachunku | Zdolności kart i kanałów cyfrowych oraz zdolność „Przyjmowanie dyspozycji” | Anna Nowak dla dyspozycji; pozostali właściciele do ustalenia | Opis zdolności „Przyjmowanie dyspozycji” w tej dokumentacji |
| Zerwanie lokaty i zamknięcie rachunku | System centralny | Area Core Banking | Luka do uzupełnienia: operacje bez wpisu w katalogu API banku |

## Zdarzenia i kontrakty domenowe

### Odbierane

Zdarzenie o otwarciu rachunku odbierają scenariusze zdolności; zdolność nie
odbiera zdarzeń innych zdolności.

## Regulacje

| Regulacja i źródło | Wymaganie lub artykuł | Wpływ na zdolność | Właściciel interpretacji | Monitorowanie zmian |
|---|---|---|---|---|
| Kodeks cywilny | Pełną zdolność do czynności prawnych ma osoba pełnoletnia | Rachunek osobisty otwiera się tylko dla osoby pełnoletniej; wniosek osoby poniżej 18 lat jest odrzucany | Departament Prawny | Przegląd przy zmianie przepisów o zdolności do czynności prawnych |
| Ustawa o przeciwdziałaniu praniu pieniędzy oraz finansowaniu terroryzmu | Identyfikacja i weryfikacja tożsamości klienta przed nawiązaniem stosunków gospodarczych | Rachunek zostaje otwarty dopiero po pozytywnym wyniku weryfikacji tożsamości | Departament Compliance | Kwartalny przegląd komunikatów GIIF i zmian ustawy |
| Regulamin produktu | Umowa rachunku wymaga akceptacji regulaminu w jego aktualnej wersji | Wniosek bez zgody na regulamin nie przechodzi dalej; zgoda zapisuje wersję dokumentu | Departament Produktów | Przegląd przy każdej nowej wersji regulaminu |

## Miary i kryteria skuteczności

| Miara | Definicja i jednostka | Wartość bazowa | Oczekiwany próg | Źródło pomiaru | Właściciel |
|---|---|---|---|---|---|
| Wnioski zakończone aktywnym rachunkiem | Odsetek wniosków, które przeszły weryfikację tożsamości i zakończyły się aktywnym rachunkiem, w % | Brak danych, zdolność nowa | ≥ 85% | Raport miesięczny z procesu otwarcia rachunku | Katarzyna Wójcik |
| Czas od wniosku do aktywacji | Mediana czasu od wysłania wniosku do aktywacji rachunku | Brak danych, zdolność nowa | ≤ 15 min przy weryfikacji automatycznej, ≤ 1 dzień roboczy przy weryfikacji ręcznej | Metryka procesu otwarcia rachunku, dziennie | Katarzyna Wójcik |
| Wnioski porzucone na kroku zgód | Odsetek wniosków w miesiącu porzuconych na kroku zgód, w % | Brak danych, zdolność nowa | ≤ 10% | Analityka formularza wniosku, miesięcznie | Katarzyna Wójcik |
| Rachunki otwarte, ale nieaktywne | Liczba rachunków w stanie OTWARTY dłużej niż 24 godziny na koniec dnia roboczego | Brak danych, zdolność nowa | 0 | Raport dzienny stanów rachunków | Katarzyna Wójcik |

## Ograniczenia NFR

- NFR-001.NFRT-PERF-01

## Ryzyka i ograniczenia

| Ryzyko lub ograniczenie | Prawdopodobieństwo lub warunek | Wpływ na zdolność | Mitygacja | Właściciel |
|---|---|---|---|---|
| Niedostępność systemu centralnego | Awaria albo okno serwisowe systemu centralnego | Aktywacja wstrzymana; rachunek zostaje w stanie OTWARTY, a klient nie może z niego korzystać | Ponowienie aktywacji po odebraniu zdarzenia; zgłoszenie do zespołu obsługi rachunków po odrzuceniu aktywacji | Katarzyna Wójcik |
| Kilka wniosków jednego klienta pod rząd | Klient wysyła kolejny wniosek przed zakończeniem poprzedniego | Zdolność nie scala wniosków tego samego numeru PESEL; powstaje kilka rachunków | Ograniczenie do ustalenia z właścicielem produktu | Katarzyna Wójcik |
| Zmiana regulaminu produktu | Nowa wersja regulaminu w trakcie obsługi wniosku | Wniosek zapisany ze starszą wersją zgody trzeba potwierdzić ponownie | Wersja dokumentu zgody zapisana we wniosku; ponowne potwierdzenie przed otwarciem rachunku | Katarzyna Wójcik |
