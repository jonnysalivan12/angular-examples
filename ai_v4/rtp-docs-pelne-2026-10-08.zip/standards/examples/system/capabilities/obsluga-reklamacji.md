---
doc-id: CAP-004
title: "Obsługa reklamacji"
description: "Zdolność obsługi reklamacji rozliczonych dyspozycji: rejestracja, rozpatrzenie, eskalacja i wypłata rekompensaty."
status: draft                                  # draft | active
owner: "Piotr Zieliński"
relations:
  - type: constrained_by
    target: NFR-001.NFRT-OBS-01
---

# Obsługa reklamacji

## Opis

Zdolność przyjmuje reklamację rozliczonej dyspozycji od klienta
w bankowości internetowej albo od doradcy w oddziale, prowadzi ją przez
rozpatrzenie przez pracownika zaplecza, eskaluje reklamację bez decyzji po
14 dniach, a po uznaniu księguje korektę, publikuje decyzję, zleca przelew
rekompensaty i zamyka reklamację. Rezultatem jest reklamacja w statusie
końcowym ODRZUCONA albo ZAMKNIETA z decyzją w śladzie audytowym.

## Wartość biznesowa

Klient dostaje decyzję w sprawie reklamacji rozliczonej dyspozycji w 14 dni,
a zasadna reklamacja kończy się wypłatą rekompensaty bez ręcznego przelewu
wykonywanego przez zaplecze. Bank ma pełny ślad każdej decyzji na potrzeby
kontroli wewnętrznej i nadzoru.

## Zakres odpowiedzialności

- przyjęcie reklamacji z bankowości internetowej i z oddziału wraz ze sprawdzeniem, że dyspozycję rozliczono nie dawniej niż 30 dni temu,
- prowadzenie reklamacji przez cykl życia: zgłoszona, w rozpatrzeniu, eskalowana po 14 dniach bez decyzji, a na końcu odrzucona albo uznana i zamknięta po wypłacie rekompensaty,
- zapis decyzji pracownika zaplecza i kwoty rekompensaty, nie większej niż kwota dyspozycji,
- eskalacja reklamacji nierozpatrzonej w 14 dni przez powiadomienie kierownika zespołu reklamacji,
- uruchomienie korekty księgowania uznanej reklamacji w księdze głównej,
- publikacja decyzji o uznaniu reklamacji po zaksięgowaniu korekty, dla zdolności, które zależą od wyniku reklamacji,
- zlecenie przelewu rekompensaty w systemie płatności i zamknięcie reklamacji.

## Poza zakresem

| Element poza zakresem | System lub zdolność właściciela | Właściciel | Dokumentacja właściciela |
|---|---|---|---|
| Identyfikacja klienta w oddziale przed zgłoszeniem reklamacji | Zdolność „Walidacja danych klienta” | Piotr Zieliński | Opis zdolności w tej dokumentacji |
| Zmiana statusu dyspozycji po korekcie | Zdolność „Rozliczanie dyspozycji”, która odbiera decyzję o uznaniu reklamacji | Anna Nowak | Opis zdolności w tej dokumentacji |
| Przyjmowanie, korekta i nocne rozliczenie dyspozycji | Zdolności „Przyjmowanie dyspozycji” i „Rozliczanie dyspozycji” | Anna Nowak | Opisy zdolności w tej dokumentacji |
| Wykonanie przelewu rekompensaty | System płatności | Tribe Płatności | Katalog API banku, pozycja „Payments — transfer orders v1” |
| Reklamacje kart, kredytów i innych produktów niż dyspozycje przelewu | Systemy reklamacji produktowych | Departament Reklamacji | Luka do uzupełnienia: brak wpisu w katalogu API banku |
| Odwołania klientów od decyzji reklamacyjnych | Proces odwołań Departamentu Reklamacji | Departament Reklamacji | Luka do uzupełnienia: procedura wewnętrzna bez dokumentacji systemowej |

## Zdarzenia i kontrakty domenowe

### Odbierane

Zdarzenie o uznaniu reklamacji odbiera scenariusz zdolności „Wypłata rekompensaty”; zdolność nie odbiera zdarzeń innych zdolności.

## Regulacje

| Regulacja i źródło | Wymaganie lub artykuł | Wpływ na zdolność | Właściciel interpretacji | Monitorowanie zmian |
|---|---|---|---|---|
| Ustawa o rozpatrywaniu reklamacji przez podmioty rynku finansowego i o Rzeczniku Finansowym | Odpowiedź na reklamację bez zbędnej zwłoki, w ustawowym terminie od otrzymania reklamacji | Wewnętrzny termin 14 dni na decyzję i eskalacja reklamacji bez decyzji | Departament Compliance | Półroczny przegląd zmian prawa konsumenckiego |
| Polityka reklamacji banku | Rekompensata pokrywa szkodę z jednej dyspozycji | Kwota rekompensaty nie przekracza kwoty reklamowanej dyspozycji | Departament Reklamacji | Przegląd przy każdej zmianie polityki |

## Miary i kryteria skuteczności

| Miara | Definicja i jednostka | Wartość bazowa | Oczekiwany próg | Źródło pomiaru | Właściciel |
|---|---|---|---|---|---|
| Decyzje w terminie | Odsetek reklamacji w miesiącu z decyzją w 14 dni od zgłoszenia, w % | Brak danych, zdolność nowa | ≥ 95% | Raport miesięczny z dziennika decyzji reklamacyjnych | Piotr Zieliński |
| Reklamacje eskalowane | Odsetek reklamacji w miesiącu, które trafiły do eskalacji, w % | Brak danych, zdolność nowa | ≤ 5% | Raport miesięczny z dziennika eskalacji | Piotr Zieliński |
| Czas zlecenia rekompensaty | Czas od decyzji o uznaniu do zlecenia przelewu rekompensaty, w minutach | Brak danych, zdolność nowa | ≤ 15 min | Metryka procesu obsługi reklamacji, dziennie | Piotr Zieliński |
| Decyzje ze śladem audytowym | Odsetek decyzji (uznanie, odrzucenie, eskalacja) z wpisem w śladzie audytowym, w % | Brak danych, zdolność nowa | 100% | Miesięczne uzgodnienie liczby decyzji i wpisów audytowych | Piotr Zieliński |

## Ograniczenia NFR

- NFR-001.NFRT-OBS-01: ślad audytowy każdej decyzji reklamacyjnej, przechowywany 5 lat.

## Ryzyka i ograniczenia

| Ryzyko lub ograniczenie | Prawdopodobieństwo lub warunek | Wpływ na zdolność | Mitygacja | Właściciel |
|---|---|---|---|---|
| Niedostępność systemu płatności | Awaria albo okno serwisowe systemu płatności | Wstrzymanie wypłaty rekompensaty | Zatrzymanie wypłaty do ręcznego wznowienia przez pracownika zaplecza; reklamacja zostaje w statusie UZNANA | Piotr Zieliński |
| Spiętrzenie zgłoszeń | Awaria rozliczeń albo błąd masowy w księgowaniu | Termin 14 dni zależy od obsady zaplecza, więc rośnie liczba eskalacji | Monitoring liczby reklamacji w rozpatrzeniu i wcześniejsze powiadomienie kierownika zespołu | Piotr Zieliński |
| Błędna kwota źródłowa dyspozycji | Niezgodność kwoty dyspozycji w procesie obsługi dyspozycji | Limit rekompensaty liczony z błędnej kwoty | Kwota dyspozycji pobierana z rejestru dyspozycji w chwili zapisu decyzji, nie z kopii w reklamacji | Piotr Zieliński |
