---
doc-id: CAP-001
title: "Przyjmowanie dyspozycji"
description: "Zdolność przyjmowania, korygowania i udostępniania dyspozycji przelewów wielopozycyjnych składanych w kanałach cyfrowych."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations:
  - type: consumes
    target: QUE-010
  - type: constrained_by
    target: NFR-001.NFRT-OBS-01
---

# Przyjmowanie dyspozycji

## Opis

Zdolność przyjmuje od klienta dyspozycję przelewu wielopozycyjnego z 1–50
pozycjami złożoną w aplikacji mobilnej albo w bankowości internetowej,
sprawdza jej kompletność i limit klienta, zapisuje ją ze statusem
ZAAKCEPTOWANA albo odrzuca z przyczyną i powiadamia inne systemy
o przyjęciu. Do startu rozliczenia pozwala klientowi zmienić kwoty pozycji
i pokazuje mu listę dyspozycji ze statusami.

## Wartość biznesowa

Klient zleca kilka przelewów jedną dyspozycją i jednym silnym
uwierzytelnieniem, zamiast wypełniać osobny formularz dla każdego przelewu.
Bank przyjmuje do rozliczenia tylko dyspozycje kompletne i mieszczące się
w limicie klienta, więc błędy danych i przekroczenie limitu wychodzą przy
złożeniu, a nie w nocnym księgowaniu. Wartość mierzy odsetek dyspozycji
rozstrzygniętych bez błędu technicznego i liczba korekt odrzuconych po
starcie rozliczenia.

## Zakres odpowiedzialności

- Przyjęcie dyspozycji z 1–50 pozycjami: sprawdzenie kompletności danych, sprawdzenie limitu w systemie limitów i zapis dyspozycji ze statusem ZAAKCEPTOWANA.
- Odrzucenie dyspozycji z kodem przyczyny i komunikatem dla klienta.
- Powiadomienie innych systemów o przyjęciu dyspozycji.
- Zmiana kwot pozycji dyspozycji bez zmiany kwoty łącznej, dopóki nie rozpoczęło się jej rozliczenie.
- Udostępnienie klientowi listy dyspozycji z pozycjami i etykietą statusu.
- Aktualizacja listy rachunków obciążanych po otwarciu nowego rachunku klienta.

## Poza zakresem

| Element poza zakresem | System lub zdolność właściciela | Właściciel | Dokumentacja właściciela |
|---|---|---|---|
| Sprawdzanie danych klienta, takich jak numer PESEL i adres korespondencyjny | Zdolność „Walidacja danych klienta” | Piotr Zieliński | Opis zdolności w tej dokumentacji |
| Księgowanie i rozliczanie dyspozycji w księdze głównej | Zdolność „Rozliczanie dyspozycji” | Anna Nowak | Opis zdolności w tej dokumentacji |
| Ustalanie i zmiana limitów klienta | System limitów | Tribe Limity | Katalog API banku, pozycja „Limity: sprawdzenie limitu” |
| Reklamacje rozliczonych dyspozycji | Zdolność „Obsługa reklamacji” | Piotr Zieliński | Opis zdolności w tej dokumentacji |

## Zdarzenia i kontrakty domenowe

### Odbierane

- QUE-010: nowy rachunek klienta trafia na listę rachunków, z których klient może złożyć dyspozycję.

## Regulacje

| Regulacja i źródło | Wymaganie lub artykuł | Wpływ na zdolność | Właściciel interpretacji | Monitorowanie zmian |
|---|---|---|---|---|
| Ustawa o usługach płatniczych, wdrożenie dyrektywy PSD2 | Silne uwierzytelnienie klienta przy inicjowaniu transakcji płatniczej | Złożenie dyspozycji wymaga potwierdzenia SCA; korekta kwot pozycji bez zmiany kwoty łącznej go nie wymaga | Departament Compliance | Kwartalny przegląd zmian prawa płatniczego |
| Regulamin bankowości elektronicznej | Dyspozycji przekazanej do rozliczenia nie można zmienić | Korekta jest możliwa tylko w statusie ZAAKCEPTOWANA, przed startem rozliczenia | Departament Płatności | Przegląd przy każdej zmianie regulaminu |

## Miary i kryteria skuteczności

| Miara | Definicja i jednostka | Wartość bazowa | Oczekiwany próg | Źródło pomiaru | Właściciel |
|---|---|---|---|---|---|
| Dyspozycje rozstrzygnięte biznesowo | Odsetek dyspozycji w miesiącu przyjętych albo odrzuconych z przyczyną biznesową, bez błędu technicznego, w % | Brak danych, zdolność nowa | ≥ 99,5% | Raport miesięczny z dziennika decyzji o przyjęciu i odrzuceniu | Anna Nowak |
| Korekty odrzucone po starcie rozliczenia | Odsetek korekt w miesiącu odrzuconych, bo rozliczenie dyspozycji już się rozpoczęło, w % | Brak danych, zdolność nowa | < 2% | Metryka punktu końcowego korekty, miesięcznie | Anna Nowak |
| Czas udostępnienia nowego rachunku | Czas od odebrania zdarzenia o otwarciu rachunku do pojawienia się rachunku na liście rachunków obciążanych, w minutach | Brak danych, zdolność nowa | ≤ 5 min | Metryka konsumenta zdarzeń, dziennie | Anna Nowak |

## Ograniczenia NFR

- NFR-001.NFRT-OBS-01: ślad audytowy każdej decyzji o przyjęciu albo odrzuceniu dyspozycji.

## Ryzyka i ograniczenia

| Ryzyko lub ograniczenie | Prawdopodobieństwo lub warunek | Wpływ na zdolność | Mitygacja | Właściciel |
|---|---|---|---|---|
| Niedostępność systemu limitów | Awaria albo przeciążenie systemu limitów | Wstrzymanie przyjmowania dyspozycji | Ponowienia według konwencji; po ich wyczerpaniu dyspozycja zostaje odrzucona z przyczyną niedostępności limitu, a klient może złożyć ją ponownie | Anna Nowak |
| Korekta tuż przed startem nocnego rozliczenia | Korekta wysłana około 01:00 | Korekta odrzucona, bo dyspozycja weszła do rozliczenia | Komunikat na ekranie podsumowania; rozliczoną dyspozycję klient może zareklamować | Anna Nowak |
| Opóźnione zdarzenie o otwarciu rachunku | Zaległości u konsumenta zdarzeń | Nowy rachunek przez pewien czas niedostępny jako rachunek obciążany | Monitoring opóźnienia konsumenta z progiem alertu 5 minut | Anna Nowak |
