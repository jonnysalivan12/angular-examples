---
doc-id: CAP-011
title: "Weryfikacja tożsamości"
description: "Zdolność potwierdzania tożsamości wnioskodawcy automatycznie w rejestrach i ręcznie przez pracownika zaplecza."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations:
  - type: constrained_by
    target: NFR-001.NFRT-OBS-01
  - type: constrained_by
    target: NFR-002.NFRT-AVAIL-01
  - type: constrained_by
    target: NFR-002.NFRT-SEC-01
---

# Weryfikacja tożsamości

## Opis

Zdolność potwierdza tożsamość wnioskodawcy: automatycznie sprawdza numer
PESEL i dane osobowe w rejestrze PESEL oraz osobę na liście sankcyjnej,
ocenia zgodność danych i wydaje wynik NO_MATCH, POSSIBLE_MATCH albo MATCH,
a wynik niejednoznaczny przekazuje pracownikowi zaplecza do ręcznej
weryfikacji ze szczegółami i zdjęciem dokumentu. Rezultatem jest decyzja
o tożsamości wnioskodawcy ze śladem audytowym.

## Wartość biznesowa

Bank nawiązuje relację tylko z osobą, której tożsamość potwierdził, i nie
otwiera rachunku osobie z listy sankcyjnej. Zdolność spełnia obowiązek
identyfikacji klienta bez wizyty w oddziale, a większość wniosków rozstrzyga
automatycznie, bez pracy zaplecza. Wartość mierzy odsetek wniosków
rozstrzygniętych automatycznie i czas zamknięcia zadania ręcznej weryfikacji.

## Zakres odpowiedzialności

- Automatyczna weryfikacja tożsamości: sprawdzenie numeru PESEL, jego statusu i danych osobowych w rejestrze PESEL oraz sprawdzenie osoby na liście sankcyjnej.
- Ocena zgodności danych wnioskodawcy z rejestrem i wynik weryfikacji: NO_MATCH, POSSIBLE_MATCH albo MATCH.
- Udostępnienie pracownikowi zaplecza szczegółów weryfikacji: wyniku weryfikacji automatycznej i zdjęcia dokumentu tożsamości.
- Ręczna weryfikacja tożsamości przez pracownika zaplecza, gdy wynik automatyczny to POSSIBLE_MATCH albo weryfikacja automatyczna była niedostępna.
- Ślad audytowy każdej decyzji weryfikacji: wyniku weryfikacji automatycznej i decyzji pracownika zaplecza.
- Ochrona danych dokumentu tożsamości: szyfrowanie zapisanych danych i maskowanie ich w logach.

## Poza zakresem

| Element poza zakresem | System lub zdolność właściciela | Właściciel | Dokumentacja właściciela |
|---|---|---|---|
| Przyjęcie wniosku, otwarcie i aktywacja rachunku | Zdolność „Zakładanie rachunku” | Katarzyna Wójcik | Opis zdolności w tej dokumentacji |
| Weryfikacja tożsamości przez przelew weryfikacyjny, wideorozmowę albo w oddziale | Inne kanały weryfikacji banku; identyfikacja w oddziale należy do zdolności „Walidacja danych klienta” | Piotr Zieliński dla oddziału; pozostali właściciele do ustalenia | Opis zdolności „Walidacja danych klienta” w tej dokumentacji |
| Okresowa aktualizacja danych klienta i monitorowanie transakcji pod kątem prania pieniędzy | System monitorowania AML | Departament Compliance | Luka do uzupełnienia: brak wpisu w katalogu API banku |
| Utrzymanie rejestru PESEL i listy sankcyjnej; zdolność tylko z nich czyta | Rejestr PESEL i dostawca list sankcyjnych | Administrator państwowego rejestru PESEL; zewnętrzny dostawca list sankcyjnych | Katalog API banku, pozycje „Rejestr PESEL: weryfikacja numeru” i „Lista sankcyjna: sprawdzenie osoby” |

## Zdarzenia i kontrakty domenowe

### Odbierane

Zdolność nie odbiera zdarzeń. Weryfikację automatyczną uruchamia krok procesu
otwarcia rachunku wywołaniem synchronicznym, a ręczną weryfikację zadanie
pracownika w silniku procesów.

## Regulacje

| Regulacja i źródło | Wymaganie lub artykuł | Wpływ na zdolność | Właściciel interpretacji | Monitorowanie zmian |
|---|---|---|---|---|
| Ustawa o przeciwdziałaniu praniu pieniędzy oraz finansowaniu terroryzmu | Identyfikacja klienta, weryfikacja jego tożsamości na podstawie dokumentu i sprawdzenie na listach sankcyjnych | Weryfikacja w rejestrze PESEL i na liście sankcyjnej przed otwarciem rachunku; osoba z listy sankcyjnej dostaje wynik MATCH | Departament Compliance | Kwartalny przegląd komunikatów GIIF i aktualizacji list sankcyjnych |
| RODO | Minimalizacja danych, ograniczenie dostępu do danych osobowych i rozliczalność przetwarzania | Dostęp do zdjęć dokumentów tylko dla pracowników zaplecza, każdy odczyt w logu audytowym, dane dokumentu szyfrowane i maskowane w logach | Inspektor Ochrony Danych | Roczny przegląd rejestru czynności przetwarzania |

## Miary i kryteria skuteczności

| Miara | Definicja i jednostka | Wartość bazowa | Oczekiwany próg | Źródło pomiaru | Właściciel |
|---|---|---|---|---|---|
| Wnioski rozstrzygnięte automatycznie | Odsetek wniosków w miesiącu rozstrzygniętych bez zadania ręcznej weryfikacji, w % | Brak danych, zdolność nowa | ≥ 90% | Raport miesięczny z rekordów weryfikacji | Katarzyna Wójcik |
| Czas zamknięcia zadania ręcznej weryfikacji | Odsetek zadań ręcznej weryfikacji zamkniętych w ciągu 4 godzin roboczych, w % | Brak danych, zdolność nowa | ≥ 90% | Metryka zadań w silniku procesów, tygodniowo | Katarzyna Wójcik |
| Pozytywne decyzje po POSSIBLE_MATCH | Odsetek wyników POSSIBLE_MATCH zakończonych pozytywną decyzją pracownika, w % | Brak danych, zdolność nowa | Monitorowany; powyżej 70% sygnał do przeglądu progów zgodności | Raport miesięczny z rekordów weryfikacji | Katarzyna Wójcik |
| Rachunki otwarte dla osoby z listy sankcyjnej | Liczba rachunków otwartych dla osoby z wynikiem MATCH na liście sankcyjnej | 0 | 0 | Miesięczne uzgodnienie otwartych rachunków z wynikami sprawdzeń | Katarzyna Wójcik |

## Ograniczenia NFR

- NFR-002.NFRT-SEC-01
- NFR-002.NFRT-AVAIL-01
- NFR-001.NFRT-OBS-01: ślad audytowy każdej decyzji weryfikacji tożsamości, automatycznej i ręcznej, przechowywany 5 lat.

## Ryzyka i ograniczenia

| Ryzyko lub ograniczenie | Prawdopodobieństwo lub warunek | Wpływ na zdolność | Mitygacja | Właściciel |
|---|---|---|---|---|
| Niedostępność rejestru PESEL albo listy sankcyjnej | Awaria systemu zewnętrznego albo przekroczenie limitu czasu po ponowieniach | Wnioski trafiają do ręcznej weryfikacji, a otwarcie rachunku się wydłuża | Ręczna weryfikacja z danymi wnioskodawcy; ponowne sprawdzenie w tym samym rekordzie, gdy źródło wróci | Katarzyna Wójcik |
| Rozbieżność zapisu nazwiska | Nazwisko dwuczłonowe zapisane we wniosku inaczej niż w rejestrze | Wniosek kierowany do ręcznej weryfikacji mimo zgodnej tożsamości | Porównanie nazwisk uznaje za zgodne nazwiska różniące się jedną literą; progi zgodności przeglądane co miesiąc | Katarzyna Wójcik |
| Dane wrażliwe w zdjęciach dokumentów | Każdy odczyt szczegółów weryfikacji | Wyciek danych dokumentu tożsamości | Dostęp tylko dla pracowników zaplecza, podpisane adresy obrazów ważne 5 minut, każdy odczyt w logu audytowym | Katarzyna Wójcik |
