---
doc-id: LDM-001
title: "Model logiczny dyspozycji"
description: "Indeks encji logicznych dyspozycji, pozycji, klienta, reklamacji i słownika statusów z mapowaniem pojęć domeny dyspozycji."
status: active                                 # draft | active
source: "Eksport XML z EA, pakiet DispositionLogical"
owner: "Tomasz Lewandowski"
relations:
  - type: contains
    target: ENT-Client
  - type: contains
    target: ENT-Complaint
  - type: contains
    target: ENT-Disposition
  - type: contains
    target: ENT-DispositionItem
  - type: contains
    target: ENT-StatusDict
  - type: realizes
    target: DDM-001.DOM-Dyspozycja
  - type: realizes
    target: DDM-001.DOM-Klient
  - type: realizes
    target: DDM-001.DOM-Pozycja
  - type: realizes
    target: DDM-001.DOM-Reklamacja
---

# Model logiczny dyspozycji

| Pole | Wartość |
|---|---|
| ID | LDM-001 |
| Źródło DDM | DDM-001 |
| Wersja | 1.4 |
| Źródło | Eksport XML z EA, pakiet DispositionLogical |

## Cel i zakres

Model opisuje dane dyspozycji przelewu wielopozycyjnego, jej pozycji, klienta
i reklamacji w systemie transakcyjnym: encje, atrybuty z typami logicznymi,
powiązania i słownik statusów. Jest niezależny od bazy danych; szczegóły
każdej encji leżą w osobnym pliku.

## Źródło (DDM)

Model wynika z DDM-001 „Domena dyspozycji”. Każde z czterech pojęć domeny ma
jedną encję, a reguły domenowe, które da się sprawdzić na danych jednej
encji, wracają w encjach jako reguły walidacyjne z kolumną RD.

## Mapowanie DDM → LDM

| Pojęcie | Encja | Uzasadnienie |
|---|---|---|
| DDM-001.DOM-Dyspozycja | ENT-Disposition | Korzeń agregatu: rachunek obciążany, kwota łączna, waluta, status i daty dyspozycji |
| DDM-001.DOM-Pozycja | ENT-DispositionItem | Pozycja ma własny status księgowania i jest zmieniana pojedynczo, więc jest osobną encją zawartą w dyspozycji |
| DDM-001.DOM-Klient | ENT-Client | Dane identyfikacyjne i adresowe klienta |
| DDM-001.DOM-Reklamacja | ENT-Complaint | Osobny agregat z własnym cyklem życia, który wskazuje reklamowaną dyspozycję |

## Diagram ER

<!-- Bez kluczy PK/FK, z notacją liczebności. -->

```mermaid
erDiagram
    KLIENT ||--o{ DYSPOZYCJA : "składa"
    DYSPOZYCJA ||--|{ POZYCJA_DYSPOZYCJI : "zawiera"
    DYSPOZYCJA ||--o{ REKLAMACJA : "dotyczy"
    SLOWNIK_STATUSOW ||--o{ DYSPOZYCJA : "nazywa status"
```

## Encje

| Encja | Opis |
|---|---|
| ENT-Disposition | Dyspozycja przelewu wielopozycyjnego: korzeń agregatu z rachunkiem obciążanym, kwotą łączną, walutą i statusem |
| ENT-DispositionItem | Pojedynczy przelew w dyspozycji z własnym statusem i identyfikatorem księgowania |
| ENT-Client | Osoba fizyczna, która składa dyspozycje i reklamacje w swoim imieniu |
| ENT-Complaint | Zgłoszenie klienta kwestionujące rozliczenie dyspozycji; osobny agregat z własnym cyklem życia |
| ENT-StatusDict | Słownik techniczny kodów statusów z etykietą i znacznikiem statusu końcowego |

## Kluczowe relacje

| Encja źródłowa | Liczebność | Encja docelowa | Opis relacji |
|---|---|---|---|
| ENT-Disposition | 1:N | ENT-DispositionItem | Dyspozycja zawiera od 1 do 50 pozycji; pozycja nie istnieje bez dyspozycji |
| ENT-Disposition | N:1 | ENT-Client | Dyspozycja wskazuje klienta, który ją złożył; klient ma wiele dyspozycji |
| ENT-Complaint | N:1 | ENT-Disposition | Reklamacja wskazuje jedną dyspozycję, a dyspozycja może mieć wiele reklamacji; reklamacja nie należy do agregatu dyspozycji |
| ENT-Disposition | N:1 | ENT-StatusDict | Status dyspozycji przyjmuje kody ze słownika statusów |

## Słowniki zewnętrzne

| Słownik | Używany w | Źródło |
|---|---|---|
| StatusDyspozycji | ENT-Disposition, atrybut status | ENT-StatusDict w tym modelu: słownik techniczny bez pojęcia w domenie, który przechowuje kody, etykiety i znacznik statusu końcowego |
| Waluta | ENT-Disposition, atrybut currency | System danych referencyjnych banku, kody ISO 4217, poza tym modelem |

## Zakres poza dokumentem

- Rachunki, produkty i zgody: opisuje je model logiczny domeny rachunków.
- Historia zmian statusów.
- Limity klienta i ich wykorzystanie.
- Fizyczna struktura bazy: tabele, klucze, indeksy i typy kolumn.
