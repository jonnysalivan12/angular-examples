---
doc-id: LDM-003
title: "Model hurtowni rachunków"
description: "Model logiczny hurtowni danych ze stanem każdego rachunku na koniec dnia."
status: draft                                  # draft | active
source: "eksport XML z EA, pakiet DWH Accounts v0.2"
owner: "Tomasz Lewandowski"
relations:
  - type: contains
    target: ENT-AccountSnapshot
  - type: realizes
    target: DDM-002.DOM-Rachunek
---

# Model hurtowni rachunków

| Pole | Wartość |
|---|---|
| ID | LDM-003 |
| Źródło DDM | DDM-002 |
| Wersja | 0.2 |
| Źródło | Eksport XML z EA, pakiet DWH Accounts |

## Cel i zakres

Model opisuje dane rachunków w hurtowni danych: stan każdego rachunku na koniec
dnia. Hurtownia zasila raporty sald i struktury portfela rachunków oraz
sprawozdawczość regulacyjną. To drugi model logiczny domeny rachunków, obok
modelu systemu transakcyjnego. Różni się ziarnem danych: jeden rachunek ma tu
osobny wiersz na każdy dzień.

## Źródło (DDM)

DDM-002 „Domena rachunków”, pojęcie DDM-002.DOM-Rachunek. Pojęć produktu
i zgody hurtownia nie realizuje: kod produktu przechowuje jako atrybut stanu
rachunku.

## Mapowanie DDM → LDM

| Pojęcie | Encja | Uzasadnienie |
|---|---|---|
| DDM-002.DOM-Rachunek | ENT-AccountSnapshot | Hurtownia utrwala stan rachunku na koniec dnia, a nie bieżący rachunek; nazwa encji odróżnia ją od rachunku systemu transakcyjnego |

## Diagram ER

<!-- Bez kluczy PK/FK, z notacją liczebności. -->

```mermaid
erDiagram
    Rachunek ||--o{ StanDziennyRachunku : "stan na koniec dnia"
```

## Encje

| Encja | Opis |
|---|---|
| ENT-AccountSnapshot | Stan rachunku na koniec dnia: jeden wiersz na rachunek i dzień |

## Kluczowe relacje

| Encja źródłowa | Liczebność | Encja docelowa | Opis relacji |
|---|---|---|---|
| Rachunek (encja modelu logicznego rachunków) | 1:N | ENT-AccountSnapshot | Jeden rachunek ma wiele stanów dziennych, po jednym na każdy dzień od dnia otwarcia do dnia zamknięcia włącznie; tożsamość stanu tworzą data stanu i numer rachunku |

Rachunek na diagramie to encja modelu logicznego rachunków w systemie
transakcyjnym, z której nocne ładowanie pobiera dane. Nie należy do tego
modelu.

## Słowniki zewnętrzne

| Słownik | Używany w | Źródło |
|---|---|---|
| Nie dotyczy | — | Hurtownia przepisuje kod produktu i status z systemu transakcyjnego bez dekodowania; nazwy produktów dołącza warstwa raportowa |

## Zakres poza dokumentem

Model nie opisuje:

- zmian stanu rachunku w ciągu dnia i operacji na rachunku,
- parametrów lokat terminowych i zgód klienta,
- procesu ładowania danych i jego harmonogramu.
