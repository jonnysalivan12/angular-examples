---
doc-id: LDM-002
title: "Model logiczny rachunków"
description: "Indeks encji systemu transakcyjnego rachunków: rachunek, lokata terminowa, produkt i zgoda klienta."
status: draft                                  # draft | active
source: "eksport XML z EA, pakiet Accounts LDM v0.4"
owner: "Tomasz Lewandowski"
relations:
  - type: contains
    target: ENT-Account
  - type: contains
    target: ENT-Consent
  - type: contains
    target: ENT-Deposit
  - type: contains
    target: ENT-Product
  - type: realizes
    target: DDM-002.DOM-Produkt
  - type: realizes
    target: DDM-002.DOM-Rachunek
  - type: realizes
    target: DDM-002.DOM-Zgoda
---

# Model logiczny rachunków

| Pole | Wartość |
|---|---|
| ID | LDM-002 |
| Źródło DDM | DDM-002 |
| Wersja | 0.4 |
| Źródło | Eksport XML z EA, pakiet Accounts LDM |

## Cel i zakres

Model opisuje dane rachunków w systemie transakcyjnym: jakie encje powstają
przy wniosku o rachunek, jego otwarciu i prowadzeniu, jakie mają atrybuty
i jak się ze sobą wiążą. Obejmuje rachunek osobisty, lokatę terminową, katalog
produktów i zgody klienta.

## Źródło (DDM)

DDM-002 „Domena rachunków”. Model realizuje wszystkie trzy pojęcia tej domeny:
DDM-002.DOM-Rachunek, DDM-002.DOM-Produkt i DDM-002.DOM-Zgoda. Reguły
domenowe DDM-002 wiążą rachunek z danymi spoza jego agregatu, więc nie wracają
w encjach jako reguły walidacyjne. Reguły walidacyjne encji sprawdzają dane
jednej encji albo warunki oferty.

## Mapowanie DDM → LDM

| Pojęcie | Encja | Uzasadnienie |
|---|---|---|
| DDM-002.DOM-Rachunek | ENT-Account | Dane wspólne obu rodzajów rachunku: właściciel, produkt, waluta, status i data otwarcia |
| DDM-002.DOM-Rachunek | ENT-Deposit | Lokata terminowa to rodzaj rachunku; jej parametry (kwota, okres, oprocentowanie, dzień zapadalności) i stan umowy leżą w osobnej encji |
| DDM-002.DOM-Produkt | ENT-Product | Value Object z oferty utrwalony jako pozycja katalogu produktów, którą wskazuje rachunek |
| DDM-002.DOM-Zgoda | ENT-Consent | Oświadczenie klienta z typem zgody, decyzją i wersją dokumentu |

## Diagram ER

<!-- Bez kluczy PK/FK, z notacją liczebności. -->

```mermaid
erDiagram
    Klient ||--o{ Rachunek : "posiada"
    Produkt ||--o{ Rachunek : "określa rodzaj"
    Rachunek ||--o| LokataTerminowa : "rodzaj: lokata"
    Klient ||--o{ Zgoda : "składa"
```

## Encje

| Encja | Opis |
|---|---|
| ENT-Account | Rachunek bankowy klienta: dane wspólne rachunku osobistego i lokaty terminowej |
| ENT-Deposit | Lokata terminowa: parametry i stan umowy lokaty |
| ENT-Product | Pozycja katalogu produktów banku, którą wskazuje rachunek |
| ENT-Consent | Oświadczenie klienta: akceptacja regulaminu albo zgoda marketingowa |

## Kluczowe relacje

| Encja źródłowa | Liczebność | Encja docelowa | Opis relacji |
|---|---|---|---|
| ENT-Account | N:1 | ENT-Product | Typ produktu rozstrzyga rodzaj rachunku: rachunek osobisty albo lokata terminowa; waluta rachunku pochodzi z produktu |
| ENT-Deposit | 1:1 | ENT-Account | Lokata terminowa jest rodzajem rachunku: ENT-Deposit przechowuje parametry i stan umowy lokaty, a dane wspólne ma ENT-Account. Lokata nie jest częścią rachunku, więc żadna encja modelu nie zawiera innej |
| ENT-Account | N:1 | Klient (encja modelu logicznego dyspozycji) | Rachunek wskazuje właściciela; na diagramie Klient pokazuje tylko, do kogo należą rachunki i zgody |
| ENT-Consent | N:1 | Klient (encja modelu logicznego dyspozycji) | Zgoda wskazuje klienta, który ją złożył |

## Słowniki zewnętrzne

| Słownik | Używany w | Źródło |
|---|---|---|
| Waluta | ENT-Product i ENT-Account, atrybut currency | Słownik walut ISO 4217 prowadzony w systemie centralnym |

Statusy rachunku, stany lokaty, typy produktu i typy zgód są typami
wyliczeniowymi encji, nie słownikami zewnętrznymi.

## Zakres poza dokumentem

Model nie opisuje:

- klienta, którego encja należy do modelu logicznego domeny dyspozycji,
- stanu dziennego rachunków w hurtowni danych, który opisuje osobny model logiczny tej domeny,
- sald, operacji na rachunkach, rachunków wspólnych i pełnomocnictw,
- przejść między statusami rachunku i stanami lokaty.
