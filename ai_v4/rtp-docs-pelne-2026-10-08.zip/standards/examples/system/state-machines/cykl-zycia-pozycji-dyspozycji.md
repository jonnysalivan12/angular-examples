---
doc-id: STM-004
title: "Cykl życia pozycji dyspozycji"
description: "Statusy księgowania pojedynczej pozycji dyspozycji od wejścia do przebiegu rozliczenia przez księgowanie i ponowienia do korekty po uznanej reklamacji."
status: draft                                  # draft | active
owner: "Tomasz Lewandowski"
relations:
  - type: realizes
    target: DDM-001.DOM-Pozycja
  - type: realizes
    target: CAP-003
---

# Cykl życia pozycji dyspozycji

| Pole | Wartość |
|---|---|
| Obiekt (pojęcie DDM) | DDM-001.DOM-Pozycja |
| Zdolność | CAP-003 |

Maszyna opisuje statusy księgowania pojedynczej pozycji dyspozycji od wejścia do przebiegu rozliczenia do korekty po uznanej reklamacji.

## Warunki wstępne

Pozycja wchodzi w cykl księgowania, gdy przebieg rozliczenia wybierze
dyspozycję ZAAKCEPTOWANA, do której należy. Do tej chwili pozycja nie ma
statusu księgowania, a klient może zmienić jej kwotę. Pozycja ma rachunek
odbiorcy w formacie IBAN, tytuł i kwotę większą od zera, nie większą niż
1 000 000 PLN. Pozycje dyspozycji odrzuconej nie wchodzą w cykl księgowania.

## Diagram maszyny stanów

<!-- Generowany z tabel poniżej albo eksportowany z EA do katalogu assets/. -->

```mermaid
stateDiagram-v2
    state "OCZEKUJE. Oczekuje" as OCZEKUJE
    state "ZAKSIEGOWANA. Zaksięgowana" as ZAKSIEGOWANA
    state "NIEZAKSIEGOWANA. Niezaksięgowana" as NIEZAKSIEGOWANA
    state "SKORYGOWANA. Skorygowana" as SKORYGOWANA
    [*] --> OCZEKUJE : dyspozycja wchodzi do przebiegu rozliczenia
    OCZEKUJE --> ZAKSIEGOWANA : księga główna potwierdza księgowanie
    OCZEKUJE --> NIEZAKSIEGOWANA : księgowanie odrzucone albo brak odpowiedzi
    NIEZAKSIEGOWANA --> ZAKSIEGOWANA : ponowienie kończy się księgowaniem
    ZAKSIEGOWANA --> SKORYGOWANA : księgowanie korygujące po uznanej reklamacji
    SKORYGOWANA --> [*]
```

## Stany — opis

### Słownik statusów

| Kod | Status | Opis | Czy końcowy |
|---|---|---|---|
| OCZEKUJE | Oczekuje | Dyspozycja weszła do przebiegu rozliczenia, pozycja czeka na księgowanie; zmiana kwoty jest odrzucana | nie |
| ZAKSIEGOWANA | Zaksięgowana | Księga główna potwierdziła księgowanie pozycji i zwróciła jego identyfikator; uznana reklamacja przenosi pozycję do SKORYGOWANA | nie |
| NIEZAKSIEGOWANA | Niezaksięgowana | Księgowanie odrzucone przez księgę główną albo niepotwierdzone w limicie czasu; pozycja czeka na ponowienie | nie |
| SKORYGOWANA | Skorygowana | Po uznanej reklamacji księga główna zaksięgowała korektę rozliczenia dyspozycji, do której należy pozycja | tak |

### Stany procesowe

| Stan z | Stan do | Opis przejścia | Typ przepływu |
|---|---|---|---|
| [*] | OCZEKUJE. Oczekuje | dyspozycja wchodzi do przebiegu rozliczenia | MAIN |
| OCZEKUJE. Oczekuje | ZAKSIEGOWANA. Zaksięgowana | księga główna potwierdza księgowanie | MAIN |
| OCZEKUJE. Oczekuje | NIEZAKSIEGOWANA. Niezaksięgowana | księgowanie odrzucone albo brak odpowiedzi | ERROR |
| NIEZAKSIEGOWANA. Niezaksięgowana | ZAKSIEGOWANA. Zaksięgowana | ponowienie kończy się księgowaniem | ALTERNATIVE |
| ZAKSIEGOWANA. Zaksięgowana | SKORYGOWANA. Skorygowana | księgowanie korygujące po uznanej reklamacji | ALTERNATIVE |

## Kluczowe elementy

- Główna ścieżka sukcesu: OCZEKUJE → ZAKSIEGOWANA w nocnym przebiegu
  rozliczenia. Przebieg, który wybrał dyspozycję, na starcie ustawia OCZEKUJE
  jej pozycjom bez statusu księgowania. Każda pozycja jest księgowana osobno,
  więc pozycje jednej dyspozycji mogą mieć różne statusy.
- Przejścia alternatywne: przebieg ponowienia księguje pozycje OCZEKUJE
  i NIEZAKSIEGOWANA, a pozycje ZAKSIEGOWANA pomija. Uznana reklamacja przenosi
  pozycje z ZAKSIEGOWANA do SKORYGOWANA.
- Przekroczenie czasu: brak odpowiedzi księgi głównej w 3 s po 3 ponowieniach
  wywołania przenosi pozycję do NIEZAKSIEGOWANA.
- Odrzucenia i rezygnacje: księga główna odrzuca księgowanie, np. z powodu
  zablokowanego rachunku obciążanego, i pozycja przechodzi do
  NIEZAKSIEGOWANA. Pozycji nie usuwa się z przyjętej dyspozycji; korekta
  przed wejściem do przebiegu zmienia tylko kwotę.

## Scenariusze błędów

| Scenariusz | Stan | Zachowanie |
|---|---|---|
| Księga główna odrzuca księgowanie z błędem biznesowym | NIEZAKSIEGOWANA. Niezaksięgowana | Jeśli trzecia próba rozliczenia dyspozycji też się nie powiedzie, pozycja zostaje w tym statusie i trafia do wyjaśnienia razem z dyspozycją |
| Księga główna zaksięgowała pozycję, ale potwierdzenie nie dotarło | NIEZAKSIEGOWANA. Niezaksięgowana | Ponowienie z tym samym kluczem idempotencji dostaje potwierdzenie istniejącego księgowania i przenosi pozycję do ZAKSIEGOWANA bez drugiego obciążenia |
