---
doc-id: STM-003
title: "Cykl życia przebiegu rozliczenia"
description: "Stany technicznego przebiegu rozliczenia dyspozycji od uruchomienia do zakończenia albo przerwania."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations:
  - type: realizes
    target: CAP-003
---

# Cykl życia przebiegu rozliczenia

| Pole | Wartość |
|---|---|
| Obiekt (pojęcie DDM) | — |
| Zdolność | CAP-003 |

Maszyna opisuje stany technicznego przebiegu rozliczenia dyspozycji od uruchomienia do zakończenia albo przerwania. Przebieg nie ma pojęcia w domenie.

## Warunki wstępne

Przebieg rozliczenia powstaje, gdy harmonogram nocny o 01:00 albo harmonogram
ponowień (co godzinę w godzinach 06:00–22:00) uruchomi rozliczenie. Żaden inny
przebieg, niezależnie od typu, nie jest w tej chwili w stanie URUCHOMIONY ani
W_TOKU.

## Diagram maszyny stanów

<!-- Generowany z tabel poniżej albo eksportowany z EA do katalogu assets/. -->

```mermaid
stateDiagram-v2
    state "URUCHOMIONY. Uruchomiony" as URUCHOMIONY
    state "W_TOKU. W toku" as W_TOKU
    state "ZAKONCZONY. Zakończony" as ZAKONCZONY
    state "ZAKONCZONY_Z_BLEDAMI. Zakończony z błędami" as ZAKONCZONY_Z_BLEDAMI
    state "PRZERWANY. Przerwany" as PRZERWANY
    [*] --> URUCHOMIONY
    URUCHOMIONY --> W_TOKU : lista dyspozycji ustalona
    URUCHOMIONY --> PRZERWANY : silnik procesów nie przyjął uruchomienia
    URUCHOMIONY --> PRZERWANY : operator przerywa po incydencie
    W_TOKU --> ZAKONCZONY : wszystkie dyspozycje rozliczone
    W_TOKU --> ZAKONCZONY_Z_BLEDAMI : część dyspozycji nierozliczona
    W_TOKU --> PRZERWANY : operator przerywa po incydencie
    ZAKONCZONY --> [*]
    ZAKONCZONY_Z_BLEDAMI --> [*]
    PRZERWANY --> [*]
```

## Stany — opis

### Słownik statusów

| Kod | Status | Opis | Czy końcowy |
|---|---|---|---|
| URUCHOMIONY | Uruchomiony | Przebieg zarejestrowany i przekazany do uruchomienia w silniku procesów; lista dyspozycji nie jest jeszcze ustalona | nie |
| W_TOKU | W toku | Lista dyspozycji ustalona, trwa księgowanie w księdze głównej albo podsumowanie przebiegu | nie |
| ZAKONCZONY | Zakończony | Wszystkie dyspozycje przebiegu są rozliczone albo przebieg nie miał dyspozycji | tak |
| ZAKONCZONY_Z_BLEDAMI | Zakończony z błędami | Przebieg doszedł do końca, ale co najmniej jedna dyspozycja ma status NIEROZLICZONA | tak |
| PRZERWANY | Przerwany | Silnik procesów nie przyjął uruchomienia albo operator anulował instancję procesu po incydencie; przebieg nie ma podsumowania | tak |

### Stany procesowe

| Stan z | Stan do | Opis przejścia | Typ przepływu |
|---|---|---|---|
| [*] | URUCHOMIONY. Uruchomiony | Harmonogram uruchamia przebieg NIGHTLY albo RETRY, a przebieg zostaje zapisany przed startem instancji procesu rozliczenia | MAIN |
| URUCHOMIONY. Uruchomiony | W_TOKU. W toku | Zadanie pobrania dyspozycji kończy się poprawnie, także z pustą listą | MAIN |
| W_TOKU. W toku | ZAKONCZONY. Zakończony | Zamknięcie dnia rozliczeniowego nie znajduje wyniku NIEROZLICZONA | MAIN |
| W_TOKU. W toku | ZAKONCZONY_Z_BLEDAMI. Zakończony z błędami | Zamknięcie dnia rozliczeniowego znajduje co najmniej jeden wynik NIEROZLICZONA | ALTERNATIVE |
| URUCHOMIONY. Uruchomiony | PRZERWANY. Przerwany | Silnik procesów nie przyjął uruchomienia | ERROR |
| URUCHOMIONY. Uruchomiony | PRZERWANY. Przerwany | Operator anuluje instancję po incydencie w zadaniu pobrania dyspozycji | ERROR |
| W_TOKU. W toku | PRZERWANY. Przerwany | Operator anuluje instancję po incydencie w zadaniu księgowania albo zamknięcia dnia | ERROR |

## Kluczowe elementy

- Główna ścieżka sukcesu: URUCHOMIONY → W_TOKU → ZAKONCZONY; przebieg nocny kończy się przed 05:00.
- Przejścia alternatywne: W_TOKU → ZAKONCZONY_Z_BLEDAMI, gdy księga główna nie zaksięgowała części dyspozycji; nierozliczone dyspozycje z mniej niż trzema nieudanymi próbami rozliczenia podejmuje najbliższy przebieg RETRY.
- Przekroczenie czasu: stan nie zmienia się z upływem czasu. Przebieg nocny, który o 05:00 jest nadal w stanie W_TOKU, narusza termin nocnego przetwarzania i wymaga reakcji operatora.
- Odrzucenia i rezygnacje: przebieg kończy się stanem PRZERWANY, gdy silnik procesów nie przyjmie uruchomienia albo gdy operator przerwie przebieg po incydencie w silniku. Próba uruchomienia rozliczenia w trakcie trwającego przebiegu dowolnego typu nie tworzy nowego przebiegu.

## Scenariusze błędów

| Scenariusz | Stan | Zachowanie |
|---|---|---|
| Silnik procesów nie przyjmuje uruchomienia | PRZERWANY. Przerwany | Przebieg przechodzi z URUCHOMIONY do PRZERWANY bez instancji procesu i bez zmiany statusów dyspozycji; harmonogram może ponowić uruchomienie |
| Incydent w zadaniu pobrania dyspozycji, bo lista dyspozycji jest niedostępna po ponowieniach | PRZERWANY. Przerwany | Przebieg zostaje w URUCHOMIONY, a operator ponawia zadanie albo przerywa przebieg |
| Incydent w zadaniu księgowania, np. błąd bazy danych | PRZERWANY. Przerwany | Przebieg zostaje w W_TOKU do decyzji operatora. Przy przejściu do PRZERWANY settlement-service ustawia status NIEROZLICZONA dyspozycjom z listy przebiegu, które mają jeszcze status W_ROZLICZENIU, bez zwiększania failedSettlementAttempts, żeby rozliczył je przebieg ponowienia |
| Księga główna niedostępna | ZAKONCZONY_Z_BLEDAMI. Zakończony z błędami | Nie jest błędem przebiegu: dyspozycje bez zaksięgowanych pozycji dostają status NIEROZLICZONA, a przebieg kończy się podsumowaniem |
