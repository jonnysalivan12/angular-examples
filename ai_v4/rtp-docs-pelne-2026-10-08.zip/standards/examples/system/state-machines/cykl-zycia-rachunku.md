---
doc-id: STM-010
title: "Cykl życia rachunku"
description: "Stany rachunku od wniosku do zamknięcia i zdarzenia, które je zmieniają."
status: draft                                  # draft | active
owner: "Tomasz Lewandowski"
relations:
  - type: realizes
    target: DDM-002.DOM-Rachunek
  - type: realizes
    target: CAP-010
---

# Cykl życia rachunku

| Pole | Wartość |
|---|---|
| Obiekt (pojęcie DDM) | DDM-002.DOM-Rachunek |
| Zdolność | CAP-010 |

Maszyna opisuje stany rachunku od wniosku do zamknięcia; obejmuje rachunek osobisty i rachunek lokaty terminowej.

## Warunki wstępne

Rachunek wchodzi w cykl życia, gdy klient wyśle wniosek, w którym:

- wybrał produkt z oferty: rachunek osobisty albo lokatę terminową,
- zaakceptował regulamin wybranego produktu,
- jest pełnoletni, jeśli wybrał rachunek osobisty.

Maszyna obejmuje oba rodzaje rachunku. Stany umowy lokaty, od założenia do
zakończenia albo zerwania, opisuje osobno cykl życia lokaty.

## Diagram maszyny stanów

<!-- Generowany z tabel poniżej albo eksportowany z EA do katalogu assets/. -->

![Cykl życia rachunku](assets/cykl-zycia-rachunku.svg)

## Stany — opis

### Słownik statusów

| Kod | Status | Opis | Czy końcowy |
|---|---|---|---|
| WNIOSEK | Wniosek | Wniosek zapisany; rachunek nie ma numeru i czeka na weryfikację tożsamości klienta | nie |
| OTWARTY | Otwarty | Weryfikacja zakończona pozytywnie; rachunek ma numer IBAN i czeka na aktywację w systemie centralnym | nie |
| AKTYWNY | Aktywny | Rachunek działa w systemie centralnym; klient może z niego korzystać | nie |
| ZABLOKOWANY | Zablokowany | Bank wstrzymał operacje na rachunku do wyjaśnienia przyczyny blokady | nie |
| ZAMKNIETY | Zamknięty | Rachunek zamknięty albo wniosek odrzucony; stan już się nie zmienia | tak |

### Stany procesowe

| Stan z | Stan do | Opis przejścia | Typ przepływu |
|---|---|---|---|
| [*] | WNIOSEK. Wniosek | Klient wysyła wniosek o rachunek osobisty albo lokatę terminową; system zapisuje rachunek bez numeru | MAIN |
| WNIOSEK. Wniosek | OTWARTY. Otwarty | Weryfikacja tożsamości kończy się pozytywnie, automatycznie albo decyzją pracownika; system nadaje numer IBAN | MAIN |
| OTWARTY. Otwarty | AKTYWNY. Aktywny | System centralny aktywuje rachunek po zdarzeniu otwarcia; lokata przechodzi do stanu AKTYWNA i dostaje dzień zapadalności | MAIN |
| AKTYWNY. Aktywny | ZAMKNIETY. Zamknięty | Klient wypowiada umowę rachunku osobistego albo lokata się kończy; bank wypłaca saldo i zamyka rachunek | MAIN |
| AKTYWNY. Aktywny | ZABLOKOWANY. Zablokowany | Bank blokuje rachunek z powodu podejrzenia nadużycia albo na żądanie uprawnionego organu | ALTERNATIVE |
| ZABLOKOWANY. Zablokowany | AKTYWNY. Aktywny | Bank zdejmuje blokadę po wyjaśnieniu przyczyny | ALTERNATIVE |
| ZABLOKOWANY. Zablokowany | ZAMKNIETY. Zamknięty | Bank wypowiada umowę zablokowanego rachunku po potwierdzeniu nadużycia | ALTERNATIVE |
| WNIOSEK. Wniosek | ZAMKNIETY. Zamknięty | Wniosek odrzucony w weryfikacji tożsamości: trafienie na liście sankcyjnej albo negatywna decyzja pracownika; rachunek zostaje bez numeru, a klient dostaje powiadomienie o odrzuceniu wniosku | ALTERNATIVE |
| OTWARTY. Otwarty | ZAMKNIETY. Zamknięty | System centralny trwale odrzuca aktywację, a eskalacja kończy się anulowaniem otwarcia | ERROR |

## Kluczowe elementy

- Główna ścieżka sukcesu: WNIOSEK → OTWARTY → AKTYWNY; rachunek kończy cykl życia w stanie ZAMKNIETY po wypowiedzeniu umowy albo zakończeniu lokaty.
- Przejścia alternatywne: blokada i zdjęcie blokady (AKTYWNY ↔ ZABLOKOWANY) oraz zamknięcie zablokowanego rachunku po potwierdzeniu nadużycia.
- Przekroczenie czasu: maszyna nie ma przejść wyzwalanych upływem czasu; wniosek czeka w stanie WNIOSEK na wynik weryfikacji, także gdy rejestr PESEL albo lista sankcyjna są niedostępne i proces otwarcia ponawia weryfikację, a blokada trwa do jej zdjęcia. Zamknięcie rachunku lokaty w dniu zapadalności wyzwala zakończenie lokaty, a nie zegar tej maszyny.
- Odrzucenia i rezygnacje: odrzucenie wniosku w weryfikacji tożsamości (WNIOSEK → ZAMKNIETY) kończy się powiadomieniem klienta; rezygnacja klienta z działającego rachunku to wypowiedzenie umowy (AKTYWNY → ZAMKNIETY). Operację na rachunku ZABLOKOWANY albo ZAMKNIETY system odrzuca bez zmiany stanu. Zdarzenie spoza tabeli przejść, np. aktywację rachunku w stanie WNIOSEK, system odrzuca i zapisuje próbę w śladzie audytowym.

## Scenariusze błędów

| Scenariusz | Stan | Zachowanie |
|---|---|---|
| Wniosek odrzucony w weryfikacji tożsamości | ZAMKNIETY. Zamknięty | Trafienie na liście sankcyjnej albo negatywna decyzja pracownika; rachunek zostaje bez numeru, a klient dostaje powiadomienie o odrzuceniu wniosku |
| System centralny trwale odrzuca aktywację | ZAMKNIETY. Zamknięty | Rachunek zostaje w OTWARTY, a sprawa trafia do eskalacji; ponowna aktywacja przenosi rachunek do AKTYWNY, a anulowanie otwarcia do ZAMKNIETY |
