---
doc-id: STM-002
title: "Cykl życia reklamacji"
description: "Statusy reklamacji od zgłoszenia przez rozpatrzenie i eskalację po 14 dniach do odrzucenia albo zamknięcia po wypłacie rekompensaty."
status: draft                                  # draft | active
owner: "Tomasz Lewandowski"
relations:
  - type: realizes
    target: DDM-001.DOM-Reklamacja
  - type: realizes
    target: CAP-004
---

# Cykl życia reklamacji

| Pole | Wartość |
|---|---|
| Obiekt (pojęcie DDM) | DDM-001.DOM-Reklamacja |
| Zdolność | CAP-004 |

Maszyna opisuje statusy reklamacji od zgłoszenia przez rozpatrzenie i eskalację po 14 dniach do odrzucenia albo zamknięcia po wypłacie rekompensaty.

## Warunki wstępne

Reklamacja wchodzi w cykl życia, gdy klient w bankowości internetowej albo
doradca w oddziale w imieniu klienta zgłosi ją dla dyspozycji rozliczonej nie
dawniej niż 30 dni, z powodem wybranym z listy i opisem. Zgłoszenie dyspozycji
rozliczonej wcześniej jest odrzucane i reklamacja nie powstaje.

## Diagram maszyny stanów

<!-- Generowany z tabel poniżej albo eksportowany z EA do katalogu assets/. -->

```mermaid
stateDiagram-v2
    state "ZGLOSZONA. Zgłoszona" as ZGLOSZONA
    state "W_ROZPATRZENIU. W rozpatrzeniu" as W_ROZPATRZENIU
    state "UZNANA. Uznana" as UZNANA
    state "ODRZUCONA. Odrzucona" as ODRZUCONA
    state "ESKALOWANA. Eskalowana" as ESKALOWANA
    state "ZAMKNIETA. Zamknięta" as ZAMKNIETA
    [*] --> ZGLOSZONA : zapis zgłoszenia reklamacji przez klienta albo doradcę w oddziale
    ZGLOSZONA --> W_ROZPATRZENIU : zadanie rejestracji reklamacji w procesie
    W_ROZPATRZENIU --> UZNANA : zapis decyzji o uznaniu z kwotą rekompensaty
    W_ROZPATRZENIU --> ODRZUCONA : zapis decyzji o odrzuceniu
    W_ROZPATRZENIU --> ESKALOWANA : brak decyzji w 14 dni, zadanie powiadomienia kierownika ustawia status przed wysłaniem e-maila
    ESKALOWANA --> UZNANA : zapis decyzji o uznaniu po eskalacji
    ESKALOWANA --> ODRZUCONA : zapis decyzji o odrzuceniu po eskalacji
    UZNANA --> ZAMKNIETA : scenariusz wypłaty rekompensaty po przyjęciu przelewu przez system płatności
    ODRZUCONA --> [*]
    ZAMKNIETA --> [*]
```

## Stany — opis

### Słownik statusów

| Kod | Status | Opis | Czy końcowy |
|---|---|---|---|
| ZGLOSZONA | Zgłoszona | Reklamacja zapisana, proces obsługi reklamacji uruchomiony; czeka na rejestrację w procesie | nie |
| W_ROZPATRZENIU | W rozpatrzeniu | Zadanie rozpatrzenia czeka na decyzję pracownika zaplecza; biegnie termin 14 dni | nie |
| UZNANA | Uznana | Bank uznał reklamację; proces księguje korektę rozliczenia dyspozycji i publikuje decyzję, a potem trwa wypłata rekompensaty | nie |
| ODRZUCONA | Odrzucona | Bank odrzucił reklamację; obsługa reklamacji kończy się po zapisie decyzji | tak |
| ESKALOWANA | Eskalowana | Minęło 14 dni bez decyzji; kierownik zespołu dostał e-mail, zadanie nadal czeka na decyzję | nie |
| ZAMKNIETA | Zamknięta | Reklamacja uznana, rekompensata wypłacona: system płatności przyjął przelew | tak |

### Stany procesowe

| Stan z | Stan do | Opis przejścia | Typ przepływu |
|---|---|---|---|
| [*] | ZGLOSZONA. Zgłoszona | zapis zgłoszenia reklamacji przez klienta albo doradcę w oddziale | MAIN |
| ZGLOSZONA. Zgłoszona | W_ROZPATRZENIU. W rozpatrzeniu | zadanie rejestracji reklamacji w procesie | MAIN |
| W_ROZPATRZENIU. W rozpatrzeniu | UZNANA. Uznana | zapis decyzji o uznaniu z kwotą rekompensaty | MAIN |
| W_ROZPATRZENIU. W rozpatrzeniu | ODRZUCONA. Odrzucona | zapis decyzji o odrzuceniu | ALTERNATIVE |
| W_ROZPATRZENIU. W rozpatrzeniu | ESKALOWANA. Eskalowana | brak decyzji w 14 dni, zadanie powiadomienia kierownika ustawia status przed wysłaniem e-maila | ERROR |
| ESKALOWANA. Eskalowana | UZNANA. Uznana | zapis decyzji o uznaniu po eskalacji | ALTERNATIVE |
| ESKALOWANA. Eskalowana | ODRZUCONA. Odrzucona | zapis decyzji o odrzuceniu po eskalacji | ALTERNATIVE |
| UZNANA. Uznana | ZAMKNIETA. Zamknięta | scenariusz wypłaty rekompensaty po przyjęciu przelewu przez system płatności | MAIN |

## Kluczowe elementy

- Główna ścieżka sukcesu: ZGLOSZONA → W_ROZPATRZENIU → UZNANA → ZAMKNIETA.
  Po uznaniu proces wylicza rekompensatę, księguje korektę rozliczenia
  dyspozycji i dopiero potem publikuje decyzję. Scenariusz wypłaty
  rekompensaty odbiera decyzję, zleca przelew i zamyka reklamację, gdy system
  płatności przyjmie przelew.
- Przejścia alternatywne: pracownik odrzuca reklamację (W_ROZPATRZENIU →
  ODRZUCONA); proces kończy się po zapisie decyzji, bez publikacji. Decyzja
  zapisana po eskalacji prowadzi do UZNANA albo ODRZUCONA tak samo jak przed
  eskalacją.
- Przekroczenie czasu: zdarzenie graniczne 14 dni na zadaniu rozpatrzenia
  uruchamia proces eskalacji. Zadanie powiadomienia kierownika ustawia
  ESKALOWANA, a potem wysyła e-mail do kierownika. Zadanie rozpatrzenia nie
  jest przerywane i zostaje u pracownika do decyzji.
- Odrzucenia i rezygnacje: zapis decyzji z kwotą rekompensaty większą niż kwota reklamowanej dyspozycji jest odrzucany, a reklamacja zostaje w W_ROZPATRZENIU albo ESKALOWANA. ODRZUCONA po decyzji pracownika kończy cykl życia
  reklamacji. Maszyna nie ma stanu rezygnacji; wycofania zgłoszenia przez
  klienta system nie obsługuje.

## Scenariusze błędów

| Scenariusz | Stan | Zachowanie |
|---|---|---|
| Brak decyzji pracownika w 14 dni | ESKALOWANA. Eskalowana | Zadanie powiadomienia kierownika ustawia ESKALOWANA i wysyła e-mail; zadanie rozpatrzenia zostaje u pracownika, a decyzja po eskalacji prowadzi do UZNANA albo ODRZUCONA |
| System płatności odrzuca przelew rekompensaty albo przy wypłacie kwota rekompensaty przekracza kwotę dyspozycji | UZNANA. Uznana | Reklamacja zostaje w UZNANA, wypłata jest zatrzymana do wyjaśnienia i reklamacja nie przechodzi do ZAMKNIETA |
