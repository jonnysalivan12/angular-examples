---
doc-id: STM-014
title: "Cykl życia lokaty"
description: "Stany lokaty terminowej od założenia do zakończenia w dniu zapadalności albo zerwania."
status: draft                                  # draft | active
owner: "Tomasz Lewandowski"
relations:
  - type: realizes
    target: DDM-002.DOM-Rachunek
  - type: realizes
    target: CAP-010
---

# Cykl życia lokaty

| Pole | Wartość |
|---|---|
| Obiekt (pojęcie DDM) | DDM-002.DOM-Rachunek |
| Zdolność | CAP-010 |

Maszyna opisuje stany umowy lokaty terminowej od założenia do zakończenia w dniu zapadalności albo zerwania.

## Warunki wstępne

Lokata wchodzi w cykl życia, gdy:

- klient wybrał we wniosku produkt typu lokata terminowa i podał kwotę oraz okres od 1 do 24 miesięcy,
- weryfikacja tożsamości zakończyła się pozytywnie, a rachunek lokaty dostał numer.

Lokata to rodzaj rachunku, więc ta maszyna jest drugą maszyną stanów tego
samego pojęcia. Stany rachunku lokaty, od wniosku do zamknięcia, opisuje cykl
życia rachunku; ta maszyna opisuje stany umowy lokaty.

## Diagram maszyny stanów

<!-- Generowany z tabel poniżej albo eksportowany z EA do katalogu assets/. -->

```mermaid
stateDiagram-v2
    state "ZALOZONA. Założona" as ZALOZONA
    state "AKTYWNA. Aktywna" as AKTYWNA
    state "ZERWANA. Zerwana" as ZERWANA
    state "ZAKONCZONA. Zakończona" as ZAKONCZONA
    [*] --> ZALOZONA: otwarcie rachunku lokaty
    ZALOZONA --> AKTYWNA: aktywacja z datą startu
    AKTYWNA --> ZAKONCZONA: dzień zapadalności
    AKTYWNA --> ZERWANA: zerwanie przed terminem
    ZALOZONA --> ZERWANA: anulowanie po odrzuceniu aktywacji
    ZAKONCZONA --> [*]
    ZERWANA --> [*]
```

## Stany — opis

### Słownik statusów

| Kod | Status | Opis | Czy końcowy |
|---|---|---|---|
| ZALOZONA | Założona | Rachunek lokaty otwarty, warunki lokaty ustalone; kapitał jeszcze nieprzyjęty | nie |
| AKTYWNA | Aktywna | Kapitał przyjęty; odsetki naliczają się od daty startu do dnia zapadalności | nie |
| ZERWANA | Zerwana | Lokata zakończona przed dniem zapadalności: zerwana przez klienta albo anulowana przed aktywacją; odsetki nie są wypłacane | tak |
| ZAKONCZONA | Zakończona | Okres lokaty upłynął; kapitał z odsetkami wypłacony klientowi | tak |

### Stany procesowe

| Stan z | Stan do | Opis przejścia | Typ przepływu |
|---|---|---|---|
| [*] | ZALOZONA. Założona | Otwarcie rachunku lokaty po pozytywnej weryfikacji tożsamości; kwota i okres z wniosku, oprocentowanie z oferty w dniu otwarcia | MAIN |
| ZALOZONA. Założona | AKTYWNA. Aktywna | System centralny aktywuje lokatę z datą startu, przyjmuje kapitał i wyznacza dzień zapadalności | MAIN |
| AKTYWNA. Aktywna | ZAKONCZONA. Zakończona | Nadchodzi dzień zapadalności; system wypłaca kapitał z odsetkami | MAIN |
| AKTYWNA. Aktywna | ZERWANA. Zerwana | Klient zrywa lokatę przed dniem zapadalności; system wypłaca sam kapitał | ALTERNATIVE |
| ZALOZONA. Założona | ZERWANA. Zerwana | System centralny trwale odrzuca aktywację, a eskalacja kończy się anulowaniem lokaty | ERROR |

## Kluczowe elementy

- Główna ścieżka sukcesu: ZALOZONA → AKTYWNA → ZAKONCZONA; w dniu zapadalności kapitał wraca do klienta z odsetkami, a rachunek lokaty zostaje zamknięty.
- Przejścia alternatywne: zerwanie aktywnej lokaty przed terminem (AKTYWNA → ZERWANA).
- Przekroczenie czasu: dzień zapadalności przenosi lokatę z AKTYWNA do ZAKONCZONA bez udziału klienta; lokata nie odnawia się automatycznie.
- Odrzucenia i rezygnacje: rezygnacja klienta to zerwanie lokaty z utratą odsetek; trwałe odrzucenie aktywacji kończy się anulowaniem lokaty (ZALOZONA → ZERWANA). Żądanie zerwania lokaty w stanie ZAKONCZONA albo ZERWANA system odrzuca bez zmiany stanu.

## Scenariusze błędów

| Scenariusz | Stan | Zachowanie |
|---|---|---|
| System centralny trwale odrzuca aktywację lokaty | ZERWANA. Zerwana | Lokata zostaje w ZALOZONA, a sprawa trafia do eskalacji; ponowna aktywacja przenosi lokatę do AKTYWNA, a anulowanie do ZERWANA |
| Wypłata kapitału w dniu zapadalności kończy się błędem | AKTYWNA. Aktywna | Lokata zostaje w AKTYWNA do skutecznej wypłaty, a za dni po dniu zapadalności odsetki się nie naliczają |
