---
doc-id: ACT-002
title: "Zapis dyspozycji"
description: "Transakcyjny zapis dyspozycji z pozycjami po pozytywnej walidacji i decyzji limitu, z nadaniem statusu ZAAKCEPTOWANA."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations: []
---

# Zapis dyspozycji

## Cel

Utrwalić dyspozycję, która przeszła walidację i sprawdzenie limitu, razem ze
wszystkimi pozycjami i ze statusem ZAAKCEPTOWANA, tak aby w bazie nie powstała
dyspozycja bez pozycji ani pozycja bez dyspozycji.

## Opis akcji

1. Nadaje dyspozycji identyfikator dispositionId (UUID) i czas utworzenia createdAt.
2. Ustawia status dyspozycji ZAAKCEPTOWANA; settledAt zostaje puste do rozliczenia.
3. Nadaje każdej pozycji identyfikator itemId i numer lineNo od 1 w kolejności z żądania; postingStatus zostaje pusty, dopóki dyspozycja nie wejdzie do przebiegu rozliczenia.
4. W jednej transakcji zapisuje dyspozycję i wszystkie pozycje, po czym zatwierdza transakcję.
5. Zwraca dispositionId, status i createdAt.

## Wejście i wyjście

| Kierunek | Dane | Opis |
|---|---|---|
| Wejście | Dyspozycja z pozycjami | clientId, accountNumber, totalAmount, currency oraz pozycje z kwotą, rachunkiem odbiorcy i tytułem, po walidacji bez naruszeń |
| Wejście | Decyzja limitu | Pozytywna decyzja systemu limitów dla kwoty łącznej dyspozycji |
| Wyjście | Zapisana dyspozycja | dispositionId, status ZAAKCEPTOWANA i createdAt |

## Warunki i reguły

### Warunki uruchomienia

- Walidacja wejścia dyspozycji zwróciła pustą listę naruszeń.
- System limitów wydał pozytywną decyzję dla kwoty łącznej dyspozycji.

### Reguły i ograniczenia

- Jeśli zapis którejkolwiek pozycji się nie powiedzie, to transakcja jest wycofywana w całości.
- Kwota totalAmount jest zapisywana tak, jak przyszła w żądaniu; aktywność nie przelicza jej z pozycji, bo dostaje na wejściu dyspozycję bez naruszeń.
- Kwoty są zapisywane z dokładnością do 0,01 w walucie dyspozycji, bez zaokrąglania.
- Dyspozycja pojawia się w bazie od razu ze statusem ZAAKCEPTOWANA; nie ma zapisu w stanie pośrednim.

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| Błąd bazy danych albo przekroczenie limitu czasu transakcji (5 s) | Zapis jest wycofany w całości, a aktywność zwraca błąd techniczny |

## Zależności

<!-- Bez ID dokumentów: wywołania INT, QUE i BPMS wskazuje przepływ w kolumnie „Wywołanie”. -->

Baza danych dyspozycji (tabele dyspozycji i pozycji) oraz generator
identyfikatorów UUID.
