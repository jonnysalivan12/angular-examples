---
doc-id: ACT-003
title: "Odrzucenie dyspozycji"
description: "Nadanie odrzuconej dyspozycji kodu przyczyny i statusu ODRZUCONA oraz przygotowanie komunikatu dla klienta."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations: []
---

# Odrzucenie dyspozycji

## Cel

Odrzucić dyspozycję z podaną przyczyną tak, aby klient wiedział, dlaczego
dyspozycja nie została przyjęta i co może zrobić dalej.

## Opis akcji

1. Przyjmuje przyczynę odrzucenia: listę naruszeń danych dyspozycji, decyzję odmowną limitu, informację, że system limitów nie zna klienta, albo informację o braku odpowiedzi systemu limitów.
2. Ustala kod przyczyny: BLAD_WALIDACJI, LIMIT_PRZEKROCZONY, KLIENT_NIEZNANY_W_SYSTEMIE_LIMITOW albo LIMIT_NIEDOSTEPNY.
3. Przy kodach sprawdzenia limitu nadaje dyspozycji status ODRZUCONA i zapisuje ją z pozycjami, kodem przyczyny w rejectionReason i czasem odrzucenia w rejectedAt; pozycje nie dostają statusu księgowania. Przy BLAD_WALIDACJI niczego nie zapisuje, więc dyspozycja nie dostaje statusu.
4. Dobiera komunikat dla klienta ze słownika komunikatów według kodu przyczyny i języka kanału.
5. Zwraca kod przyczyny i komunikat oraz status ODRZUCONA przy kodach sprawdzenia limitu albo listę naruszeń przy błędzie walidacji.

## Wejście i wyjście

| Kierunek | Dane | Opis |
|---|---|---|
| Wejście | Dyspozycja z pozycjami | Dane z żądania złożenia dyspozycji |
| Wejście | Przyczyna odrzucenia | Lista naruszeń, decyzja odmowna z dostępnym limitem, odpowiedź, że system limitów nie zna klienta, albo informacja o braku odpowiedzi systemu limitów |
| Wyjście | Wynik odrzucenia | Kod przyczyny, komunikat dla klienta, status ODRZUCONA (tylko kody sprawdzenia limitu) i lista naruszeń (tylko BLAD_WALIDACJI) |

## Warunki i reguły

### Warunki uruchomienia

- Przepływ przekazał dyspozycję z pozycjami i przyczynę odrzucenia: listę naruszeń, decyzję odmowną limitu, informację o kliencie nieznanym w systemie limitów albo o braku odpowiedzi tego systemu.

### Reguły i ograniczenia

- Jeśli przyczyną jest niepusta lista naruszeń, to kod przyczyny to BLAD_WALIDACJI, a dyspozycja nie jest zapisywana.
- Jeśli system limitów zwrócił decyzję odmowną, to kod przyczyny to LIMIT_PRZEKROCZONY, a komunikat podaje dostępny limit w walucie rachunku.
- Jeśli system limitów nie zna klienta, to kod przyczyny to KLIENT_NIEZNANY_W_SYSTEMIE_LIMITOW, a komunikat kieruje klienta do kontaktu z bankiem.
- Jeśli przyczyną jest brak odpowiedzi systemu limitów, to kod przyczyny to LIMIT_NIEDOSTEPNY, a komunikat prosi o ponowne złożenie dyspozycji później.
- Jeśli kod przyczyny to LIMIT_PRZEKROCZONY, KLIENT_NIEZNANY_W_SYSTEMIE_LIMITOW albo LIMIT_NIEDOSTEPNY, to dyspozycja jest zapisana ze statusem ODRZUCONA, kodem w rejectionReason i czasem w rejectedAt, i widać ją na liście dyspozycji klienta.
- Dyspozycja ze statusem ODRZUCONA nie wraca do obiegu: ponowna próba klienta tworzy nową dyspozycję z nowym identyfikatorem.
- Komunikat nie ujawnia nazw systemów ani technicznych kodów błędów.

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| Brak komunikatu dla kodu przyczyny w słowniku | Aktywność kończy się komunikatem ogólnym „Nie udało się przyjąć dyspozycji” i ostrzeżeniem w logu |
| Błąd zapisu odrzuconej dyspozycji | Odpowiedź dla klienta się nie zmienia; błąd trafia do logu z identyfikatorem żądania |

## Zależności

<!-- Bez ID dokumentów: wywołania INT, QUE i BPMS wskazuje przepływ w kolumnie „Wywołanie”. -->

Słownik komunikatów dla klienta (polski i angielski) oraz baza danych
dyspozycji.
