---
doc-id: ACT-010
title: "Ocena zgodności danych tożsamości"
description: "Porównanie danych wnioskodawcy z rejestrem PESEL i połączenie go z wynikiem listy sankcyjnej w jeden wynik weryfikacji."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations: []
---

# Ocena zgodności danych tożsamości

## Cel

Ustalić jeden wynik weryfikacji tożsamości: NO_MATCH, gdy numer PESEL jest
aktywny, dane zgadzają się z rejestrem PESEL i osoby nie ma na liście
sankcyjnej, POSSIBLE_MATCH, gdy wynik jest niejednoznaczny, albo MATCH przy
trafieniu na liście sankcyjnej.

## Opis akcji

1. Sprawdza status numeru PESEL z rejestru; status inny niż AKTYWNY zapisuje na liście rozbieżności jako rozbieżność PESEL.
2. Sprowadza imiona i nazwiska z wniosku i z rejestru do wielkich liter i usuwa spacje na początku i końcu.
3. Porównuje imię z wniosku z imieniem z rejestru; wymaga pełnej zgodności.
4. Liczy odległość Levenshteina między nazwiskiem z wniosku a nazwiskiem z rejestru.
5. Porównuje datę urodzenia z wniosku z datą z rejestru; wymaga pełnej zgodności.
6. Zapisuje każde niezgodne pole na liście rozbieżności.
7. Łączy listę rozbieżności z wynikiem listy sankcyjnej i ustala wynik weryfikacji.

## Wejście i wyjście

| Kierunek | Dane | Opis |
|---|---|---|
| Wejście | Dane wnioskodawcy | PESEL, imię, nazwisko i data urodzenia z wniosku |
| Wejście | Dane z rejestru PESEL | Status numeru PESEL (AKTYWNY, UNIEWAZNIONY albo ZGON), imię, nazwisko i data urodzenia osoby o podanym numerze albo informacja, że rejestr nie zna numeru |
| Wejście | Wynik listy sankcyjnej | NO_MATCH, POSSIBLE_MATCH albo MATCH |
| Wyjście | Wynik weryfikacji | NO_MATCH, POSSIBLE_MATCH albo MATCH |
| Wyjście | Lista rozbieżności | Nazwa pola, wartość z wniosku, wartość z rejestru; dla nazwiska także odległość, dla PESEL o statusie innym niż AKTYWNY ten status |

## Warunki i reguły

### Warunki uruchomienia

- Na wejściu są dane wnioskodawcy, dane z rejestru PESEL albo informacja, że rejestr nie zna numeru, oraz wynik listy sankcyjnej.

### Reguły i ograniczenia

- Jeśli status numeru PESEL jest inny niż AKTYWNY, to lista rozbieżności zawiera PESEL, a aktywność porównuje też pozostałe pola.
- Jeśli odległość Levenshteina między nazwiskami wynosi 0 albo 1, to nazwisko jest zgodne, np. „KOWALSKI” i „KOWALSKY”.
- Jeśli odległość między nazwiskami wynosi 2 lub więcej, to lista rozbieżności zawiera nazwisko.
- Jeśli imię albo data urodzenia różni się od danych z rejestru, to lista rozbieżności zawiera to pole.
- Jeśli rejestr nie zna numeru PESEL, to lista rozbieżności zawiera PESEL, a aktywność nie porównuje pozostałych pól.
- Jeśli lista sankcyjna zwróciła MATCH, to wynik weryfikacji to MATCH bez względu na listę rozbieżności.
- Jeśli lista sankcyjna zwróciła POSSIBLE_MATCH, to wynik weryfikacji to POSSIBLE_MATCH.
- Jeśli lista sankcyjna zwróciła NO_MATCH, a lista rozbieżności nie jest pusta, to wynik weryfikacji to POSSIBLE_MATCH.
- Jeśli lista sankcyjna zwróciła NO_MATCH, a lista rozbieżności jest pusta, to wynik weryfikacji to NO_MATCH.

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| Brak wyniku listy sankcyjnej, danych z rejestru albo statusu numeru znanego w rejestrze | Aktywność kończy się błędem niekompletnych danych, bez wyniku weryfikacji; nie zakłada wyniku NO_MATCH |
| Wartość listy sankcyjnej spoza trzech znanych wartości | Ten sam błąd niekompletnych danych |

## Zależności

<!-- Bez ID dokumentów: wywołania INT, QUE i BPMS wskazuje przepływ w kolumnie „Wywołanie”. -->

Implementacja odległości Levenshteina z biblioteki wspólnej. Dane z rejestru
PESEL i wynik listy sankcyjnej aktywność dostaje na wejściu.
