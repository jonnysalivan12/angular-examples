---
doc-id: ACT-001
title: "Walidacja wejścia dyspozycji"
description: "Sprawdzenie kompletności i spójności danych dyspozycji i zwrot pełnej listy naruszeń."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations: []
---

# Walidacja wejścia dyspozycji

## Cel

Wykryć w dyspozycji niekompletne albo sprzeczne dane i zwrócić pełną listę
naruszeń.

## Opis akcji

1. Sprawdza, czy żądanie ma rachunek obciążany, walutę i od 1 do 50 pozycji.
2. Dla każdej pozycji sprawdza numer rachunku odbiorcy (format IBAN i suma kontrolna), kwotę i tytuł.
3. Sumuje kwoty pozycji i porównuje sumę z kwotą łączną dyspozycji.
4. Zwraca listę naruszeń; pusta lista oznacza poprawne wejście.

## Wejście i wyjście

| Kierunek | Dane | Opis |
|---|---|---|
| Wejście | Dyspozycja z pozycjami | Dane z żądania złożenia dyspozycji |
| Wyjście | Lista naruszeń | Kod reguły, numer pozycji i komunikat dla każdego naruszenia |

## Warunki i reguły

### Warunki uruchomienia

- Przepływ przyjęcia dyspozycji przekazał żądanie złożenia dyspozycji z rachunkiem obciążanym, walutą, kwotą łączną i pozycjami.

### Reguły i ograniczenia

- Jeśli dyspozycja nie ma pozycji albo ma ich więcej niż 50, to wynik zawiera naruszenie liczby pozycji.
- Jeśli kwota pozycji jest mniejsza lub równa zero albo większa niż 1 000 000 PLN, to wynik zawiera naruszenie kwoty pozycji.
- Jeśli suma kwot pozycji różni się od kwoty łącznej choćby o 0,01, to wynik zawiera naruszenie sumy.
- Aktywność sprawdza wszystkie reguły i zwraca komplet naruszeń, nie tylko pierwsze.

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| Brak wymaganego pola | Aktywność kończy się listą naruszeń z kodem braku pola |
| Nierozpoznana waluta | Wynik zawiera naruszenie waluty |

## Zależności

<!-- Bez ID dokumentów: wywołania INT, QUE i BPMS wskazuje przepływ w kolumnie „Wywołanie”. -->

Słownik walut obsługiwanych przez bank oraz walidator numerów IBAN z biblioteki
wspólnej.
