---
doc-id: API-015
title: "POST /complaints/{id}/assignment"
description: "Przypisanie zadania rozpatrzenia reklamacji do pracownika zaplecza, który otwiera je z listy zadań."
status: draft                                  # draft | active
owner: "Piotr Zieliński"
relations:
  - type: realizes
    target: CAP-004
  - type: consumes
    target: SPEC-WF-005
  - type: applies
    target: CONV-001
  - type: applies
    target: CONV-002
---

# POST /complaints/{id}/assignment

| Pole | Wartość |
|---|---|
| Zdolność | CAP-004 |

## Cel

Punkt końcowy przypisuje zadanie „Rozpatrzenie reklamacji” z kolejki zespołu
reklamacji do pracownika, który otwiera je z listy zadań. Od przypisania
decyzję w tym zadaniu może zapisać tylko ten pracownik.

## Parametry wejściowe

| Parametr | Typ | Wymagany | Źródło | Opis |
|---|---|---|---|---|
| id | UUID (complaintId) | tak | path | Identyfikator reklamacji |

## Walidacja pól wejściowych

| Parametr | Reguła | Kod błędu HTTP | Komunikat zwracany przez system |
|---|---|---|---|
| id | Parametr id nie jest identyfikatorem UUID | 400 | „Niepoprawny identyfikator reklamacji.” |
| id | Reklamacja o podanym id nie istnieje albo nie ma otwartego zadania rozpatrzenia | 404 | „Nie znaleziono zadania rozpatrzenia reklamacji.” |
| id | Zadanie rozpatrzenia jest przypisane do innego pracownika | 409 | „Zadanie jest przypisane do innego pracownika.” |

## Autentykacja

Według CONV-002, token użytkownika. Wymagana rola: Pracownik zaplecza.
Zadanie rozpatrzenia musi czekać w kolejce grupy wywołującego pracownika albo
być już przypisane do niego.

## Zachowanie

### Przebieg podstawowy

1. Sprawdza token i rolę pracownika.
2. Znajduje w silniku procesów otwarte zadanie rozpatrzenia reklamacji o complaintId równym id.
3. Przypisuje zadanie do wywołującego pracownika. Zadanie przypisane już do tego pracownika zostaje bez zmian.
4. Zwraca 204.

- SPEC-WF-005: krok „Rozpatrzenie reklamacji” procesu „Obsługa reklamacji”, który punkt końcowy przypisuje w kroku 3.

### Przypadek brzegowy

- Zadanie przypisane do innego pracownika: punkt końcowy nie zmienia przypisania i zwraca 409.

## Struktura odpowiedzi błędnej

Według CONV-001. Komunikaty podaje tabela „Walidacja pól wejściowych”.
Kod własny: TASK_ASSIGNED_TO_OTHER (409), gdy zadanie jest przypisane do
innego pracownika.

## Encje

Punkt końcowy nie korzysta z encji: przypisanie zapisuje silnik procesów
w zadaniu.

## Zależności

Brak zależności od integracji.

## Ograniczenia NFR

Brak własnych progów; obowiązują progi zdolności CAP-004.
