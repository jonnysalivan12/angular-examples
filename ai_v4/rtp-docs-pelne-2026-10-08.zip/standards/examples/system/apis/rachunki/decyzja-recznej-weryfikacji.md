---
doc-id: API-014
title: "POST /account-applications/{id}/manual-verification/decision"
description: "Zapis decyzji pracownika zaplecza w ręcznej weryfikacji tożsamości i zakończenie zadania ręcznej weryfikacji w silniku procesów."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations:
  - type: realizes
    target: CAP-011
  - type: consumes
    target: SPEC-WF-012
  - type: applies
    target: CONV-001
  - type: applies
    target: CONV-002
---

# POST /account-applications/{id}/manual-verification/decision

| Pole | Wartość |
|---|---|
| Zdolność | CAP-011 |

## Cel

Punkt końcowy zapisuje decyzję pracownika zaplecza w ręcznej weryfikacji
tożsamości, ZATWIERDZONA albo ODRZUCONA z uzasadnieniem, a potem kończy zadanie
ręcznej weryfikacji w procesie otwarcia rachunku. Wniosek wskazuje jego
identyfikator, bo identyfikatora weryfikacji brak, gdy usługa weryfikacji nie
odpowiedziała.

## Parametry wejściowe

| Parametr | Typ | Wymagany | Źródło | Opis |
|---|---|---|---|---|
| id | UUID (applicationId) | tak | path | Identyfikator wniosku o rachunek |
| decision | String (ZATWIERDZONA, ODRZUCONA) | tak | body | Decyzja pracownika o tożsamości wnioskodawcy |
| rejectionReason | String (od 10 do 500 znaków) | nie | body | Uzasadnienie odrzucenia; wymagane przy decyzji ODRZUCONA |

## Walidacja pól wejściowych

| Parametr | Reguła | Kod błędu HTTP | Komunikat zwracany przez system |
|---|---|---|---|
| — | Brak tokenu albo token wygasł | 401 | Sesja wygasła. Zaloguj się ponownie. |
| — | Użytkownik nie ma roli Pracownik zaplecza | 403 | Brak uprawnień do weryfikacji tożsamości. |
| id | Parametr id nie jest identyfikatorem UUID | 400 | Niepoprawny identyfikator wniosku. |
| decision | Brak decision albo wartość inna niż ZATWIERDZONA i ODRZUCONA | 400 | Wybierz decyzję: zatwierdzona albo odrzucona. |
| rejectionReason | Decyzja ODRZUCONA bez rejectionReason albo z uzasadnieniem krótszym niż 10 lub dłuższym niż 500 znaków | 400 | Uzasadnienie odrzucenia musi mieć od 10 do 500 znaków. |
| id | Wniosek o podanym id nie istnieje albo nie ma otwartego zadania ręcznej weryfikacji | 404 | Nie znaleziono zadania weryfikacji dla wniosku. |
| id | Zadanie ręcznej weryfikacji jest przypisane do innego pracownika | 409 | Zadanie jest przypisane do innego pracownika. |

## Autentykacja

Według CONV-002, token użytkownika. Wymagana rola: Pracownik zaplecza
(aplikacja zaplecza). Zadanie ręcznej weryfikacji musi być przypisane do
wywołującego pracownika albo do jego grupy.

## Zachowanie

### Przebieg podstawowy

1. Sprawdza token i rolę pracownika.
2. Znajduje w silniku procesów otwarte zadanie ręcznej weryfikacji wniosku o applicationId równym id i sprawdza, że jest przypisane do wywołującego pracownika albo do jego grupy.
3. Kończy zadanie ze zmiennymi manualDecision równą decision i rejectionReason; przy decyzji ZATWIERDZONA rejectionReason jest pusty.
4. Zapisuje decyzję, uzasadnienie i identyfikator pracownika w śladzie audytowym wniosku.
5. Zwraca 204.

- SPEC-WF-012: krok „Ręczna weryfikacja tożsamości” procesu otwarcia rachunku, który punkt końcowy kończy w kroku 3.

### Przypadek brzegowy

- Silnik procesów nie kończy zadania: punkt końcowy nie zapisuje decyzji w śladzie audytowym i zwraca 503; zadanie pozostaje otwarte, a pracownik ponawia zapis.

## Struktura odpowiedzi błędnej

Według CONV-001. Komunikaty podaje tabela „Walidacja pól wejściowych”.
Kody własne: VERIFICATION_TASK_NOT_FOUND (404), gdy wniosek nie ma otwartego
zadania ręcznej weryfikacji, i TASK_ASSIGNED_TO_OTHER (409), gdy zadanie jest
przypisane do innego pracownika.

## Encje

Punkt końcowy nie korzysta z encji: decyzja trafia do zmiennych procesu i do
śladu audytowego wniosku.

## Zależności

Brak zależności od integracji.

## Ograniczenia NFR

Brak własnych progów; obowiązują progi zdolności CAP-011.
