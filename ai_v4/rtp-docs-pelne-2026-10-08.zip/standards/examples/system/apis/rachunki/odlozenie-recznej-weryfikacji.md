---
doc-id: API-017
title: "DELETE /account-applications/{id}/manual-verification/assignment"
description: "Odłożenie zadania ręcznej weryfikacji tożsamości: zadanie wraca do puli pracowników zaplecza bez decyzji."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations:
  - type: realizes
    target: CAP-011
  - type: consumes
    target: SPEC-WF-012
  - type: applies
    target: CONV-001
  - type: applies
    target: CONV-002
---

# DELETE /account-applications/{id}/manual-verification/assignment

| Pole | Wartość |
|---|---|
| Zdolność | CAP-011 |

## Cel

Punkt końcowy zwalnia przypisanie zadania ręcznej weryfikacji tożsamości, gdy
pracownik odkłada zadanie, np. przy niedostępnym rejestrze PESEL. Zadanie
wraca do puli pracowników zaplecza bez decyzji, a proces czeka dalej.

## Parametry wejściowe

| Parametr | Typ | Wymagany | Źródło | Opis |
|---|---|---|---|---|
| id | UUID (applicationId) | tak | path | Identyfikator wniosku o rachunek |

## Walidacja pól wejściowych

| Parametr | Reguła | Kod błędu HTTP | Komunikat zwracany przez system |
|---|---|---|---|
| — | Brak tokenu albo token wygasł | 401 | Sesja wygasła. Zaloguj się ponownie. |
| — | Użytkownik nie ma roli Pracownik zaplecza | 403 | Brak uprawnień do weryfikacji tożsamości. |
| id | Parametr id nie jest identyfikatorem UUID | 400 | Niepoprawny identyfikator wniosku. |
| id | Wniosek o podanym id nie istnieje albo nie ma otwartego zadania ręcznej weryfikacji | 404 | Nie znaleziono zadania weryfikacji dla wniosku. |
| id | Zadanie ręcznej weryfikacji jest przypisane do innego pracownika | 409 | Zadanie jest przypisane do innego pracownika. |

## Autentykacja

Według CONV-002, token użytkownika. Wymagana rola: Pracownik zaplecza
(aplikacja zaplecza).

## Zachowanie

### Przebieg podstawowy

1. Sprawdza token i rolę pracownika.
2. Znajduje w silniku procesów otwarte zadanie ręcznej weryfikacji wniosku o applicationId równym id.
3. Usuwa przypisanie zadania do wywołującego pracownika: zadanie wraca do puli pracowników zaplecza bez decyzji.
4. Zwraca 204.

- SPEC-WF-012: krok „Ręczna weryfikacja tożsamości” procesu otwarcia rachunku, który punkt końcowy odkłada w kroku 3.

### Przypadek brzegowy

- Zadanie bez przypisania, np. odłożone wcześniej: punkt końcowy nic nie zmienia i zwraca 204.
- Zadanie przypisane do innego pracownika: punkt końcowy nie zmienia przypisania i zwraca 409.

## Struktura odpowiedzi błędnej

Według CONV-001. Komunikaty podaje tabela „Walidacja pól wejściowych”.
Kody własne: VERIFICATION_TASK_NOT_FOUND (404), gdy wniosek nie ma otwartego
zadania ręcznej weryfikacji, i TASK_ASSIGNED_TO_OTHER (409), gdy zadanie jest
przypisane do innego pracownika.

## Encje

Punkt końcowy nie korzysta z encji: przypisanie zapisuje silnik procesów
w zadaniu.

## Zależności

Brak zależności od integracji.

## Ograniczenia NFR

Brak własnych progów; obowiązują progi zdolności CAP-011.
