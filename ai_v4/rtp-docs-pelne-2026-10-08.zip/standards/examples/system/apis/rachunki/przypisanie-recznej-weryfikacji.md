---
doc-id: API-016
title: "POST /account-applications/{id}/manual-verification/assignment"
description: "Przypisanie zadania ręcznej weryfikacji tożsamości do pracownika zaplecza, który otwiera je z listy zadań."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations:
  - type: realizes
    target: CAP-011
  - type: consumes
    target: SPEC-WF-012
  - type: applies
    target: CONV-001
  - type: applies
    target: CONV-002
---

# POST /account-applications/{id}/manual-verification/assignment

| Pole | Wartość |
|---|---|
| Zdolność | CAP-011 |

## Cel

Punkt końcowy przypisuje zadanie ręcznej weryfikacji tożsamości z puli
pracowników zaplecza do pracownika, który otwiera je z listy zadań. Od
przypisania decyzję w tym zadaniu może zapisać tylko ten pracownik.

## Parametry wejściowe

| Parametr | Typ | Wymagany | Źródło | Opis |
|---|---|---|---|---|
| id | UUID (applicationId) | tak | path | Identyfikator wniosku o rachunek |

## Walidacja pól wejściowych

| Parametr | Reguła | Kod błędu HTTP | Komunikat zwracany przez system |
|---|---|---|---|
| — | Brak tokenu albo token wygasł | 401 | Sesja wygasła. Zaloguj się ponownie. |
| — | Użytkownik nie ma roli Pracownik zaplecza | 403 | Brak uprawnień do weryfikacji tożsamości. |
| id | Parametr id nie jest identyfikatorem UUID | 400 | Niepoprawny identyfikator wniosku. |
| id | Wniosek o podanym id nie istnieje albo nie ma otwartego zadania ręcznej weryfikacji | 404 | Nie znaleziono zadania weryfikacji dla wniosku. |
| id | Zadanie ręcznej weryfikacji jest przypisane do innego pracownika | 409 | Zadanie jest przypisane do innego pracownika. |

## Autentykacja

Według CONV-002, token użytkownika. Wymagana rola: Pracownik zaplecza
(aplikacja zaplecza).

## Zachowanie

### Przebieg podstawowy

1. Sprawdza token i rolę pracownika.
2. Znajduje w silniku procesów otwarte zadanie ręcznej weryfikacji wniosku o applicationId równym id.
3. Przypisuje zadanie do wywołującego pracownika. Zadanie przypisane już do tego pracownika zostaje bez zmian.
4. Zwraca 204.

- SPEC-WF-012: krok „Ręczna weryfikacja tożsamości” procesu otwarcia rachunku, który punkt końcowy przypisuje w kroku 3.

### Przypadek brzegowy

- Zadanie przypisane do innego pracownika: punkt końcowy nie zmienia przypisania i zwraca 409.

## Struktura odpowiedzi błędnej

Według CONV-001. Komunikaty podaje tabela „Walidacja pól wejściowych”.
Kody własne: VERIFICATION_TASK_NOT_FOUND (404), gdy wniosek nie ma otwartego
zadania ręcznej weryfikacji, i TASK_ASSIGNED_TO_OTHER (409), gdy zadanie jest
przypisane do innego pracownika.

## Encje

Punkt końcowy nie korzysta z encji: przypisanie zapisuje silnik procesów
w zadaniu.

## Zależności

Brak zależności od integracji.

## Ograniczenia NFR

Brak własnych progów; obowiązują progi zdolności CAP-011.
