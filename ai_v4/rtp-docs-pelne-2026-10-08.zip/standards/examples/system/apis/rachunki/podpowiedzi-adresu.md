---
doc-id: API-009
title: "GET /addresses/suggestions"
description: "Podpowiedzi adresu korespondencyjnego ze słownika adresów TERYT dla formularza wniosku o rachunek."
status: draft                                  # draft | active
owner: "Piotr Zieliński"
relations:
  - type: realizes
    target: CAP-002
  - type: consumes
    target: INT-003
  - type: applies
    target: CONV-001
  - type: applies
    target: CONV-002
---

# GET /addresses/suggestions

| Pole | Wartość |
|---|---|
| Zdolność | CAP-002 |

## Cel

Zwrócić podpowiedzi adresu zgodne ze słownikiem TERYT dla tekstu wpisanego
w polu adresu korespondencyjnego, żeby ograniczyć błędy w nazwach ulic,
miejscowości i kodach pocztowych. Punkt końcowy niczego nie zapisuje.

## Parametry wejściowe

| Parametr | Typ | Wymagany | Źródło | Opis |
|---|---|---|---|---|
| query | String, co najmniej 3 znaki | tak | query | Fragment adresu wpisany przez klienta |

## Walidacja pól wejściowych

| Parametr | Reguła | Kod błędu HTTP | Komunikat zwracany przez system |
|---|---|---|---|
| query | query ma mniej niż 3 znaki | 400 | „Wpisz co najmniej 3 znaki adresu.” |

## Złożone parametry wejściowe

<!-- Opcjonalnie, np. zaszyfrowany token zawierający kilka informacji. -->

Punkt końcowy nie ma złożonych parametrów wejściowych.

## Autentykacja

Według CONV-002, token sesji wniosku. Punkt końcowy nie wymaga logowania
do bankowości.

## Zachowanie

### Przebieg podstawowy

1. Sprawdza token sesji wniosku i długość tekstu query.
2. Woła słownik adresów z tekstem query i limitem 10 podpowiedzi.
3. Zwraca 200 z listą podpowiedzi: ulica, numer budynku, kod pocztowy i miejscowość. Identyfikatora adresu w TERYT nie zwraca.

### Przypadek brzegowy

- Słownik adresów nie znajduje adresu, zwraca błąd albo nie odpowiada w czasie: punkt końcowy zwraca 200 z pustą listą, bez ponowień, a pole adresu działa wtedy jak zwykłe pole tekstowe.

## Model odpowiedzi

<!-- Opcjonalnie: classDiagram i tabela pól, bez kopiowania OpenAPI. -->

| Pole | Typ | Opis |
|---|---|---|
| suggestions | Lista | Podpowiedzi adresu, najwyżej 10; pusta, gdy słownik nie znalazł adresu albo nie odpowiedział |
| suggestions[].street | String | Nazwa ulicy z przedrostkiem, np. „ul. Marszałkowska” |
| suggestions[].buildingNumber | String | Numer budynku |
| suggestions[].postalCode | String | Kod pocztowy w formacie 00-000 |
| suggestions[].city | String | Miejscowość |

## Struktura odpowiedzi błędnej

Według CONV-001. Za krótki tekst query to naruszenie z kodem
QUERY_TOO_SHORT w `violations`.

## Encje

Punkt końcowy nie przenosi encji modelu logicznego.

## Zależności

- INT-003: wyszukanie adresów pasujących do wpisanego tekstu.

## Ograniczenia NFR

Brak własnych progów.
