---
doc-id: NFR-001
title: "Wymagania jakościowe systemu"
description: "Progi wydajności, dostępności, bezpieczeństwa i audytowalności obowiązujące cały system bankowości detalicznej."
status: active                                 # draft | active
scope: system                                  # system | component
owner: "Tomasz Lewandowski"
relations:
  - type: contains
    target: NFRT-AVAIL-01
  - type: contains
    target: NFRT-OBS-01
  - type: contains
    target: NFRT-PERF-01
  - type: contains
    target: NFRT-PERF-02
  - type: contains
    target: NFRT-SEC-01
---

# Wymagania jakościowe systemu

| Pole | Wartość |
|---|---|
| Zakres | system |
| Zespół odpowiedzialny | Zespół Architektury |
| Krytyczność | wysoka |

## Cel i kontekst

Dokument ustala progi jakościowe wspólne dla całego systemu bankowości
detalicznej: punktów końcowych API kanałów klienta i zaplecza, przetwarzania
wsadowego, integracji z systemami zewnętrznymi i dziennika audytowego.
Progi wynikają z PSD2 i standardów technicznych dotyczących silnego
uwierzytelniania klienta, z Rekomendacji D KNF oraz z polityki retencji danych
banku. Dokument procesu, scenariusza, zdolności albo kontraktu wskazuje wiersz
macierzy, który go ogranicza; progi pojedynczego komponentu leżą w osobnym
dokumencie NFR komponentu.

## Macierz wymagań

| ID | Atrybut jakości | Metryka | Próg docelowy | Metoda pomiaru | Środowisko | Priorytet |
|---|---|---|---|---|---|---|
| NFRT-PERF-01 | Wydajność: czas odpowiedzi API | 95. percentyl czasu odpowiedzi punktu końcowego mierzony na bramie API | p95 ≤ 500 ms | Test obciążeniowy z profilem ruchu szczytowego; pomiar APM w oknach 5-minutowych | PROD | Must |
| NFRT-PERF-02 | Wydajność: okno przetwarzania wsadowego | Godzina zakończenia nocnego przebiegu wsadowego | Zakończenie przed 05:00 | Znacznik zakończenia przebiegu w dzienniku harmonogramu | PROD | Must |
| NFRT-SEC-01 | Bezpieczeństwo: silne uwierzytelnienie klienta | Odsetek operacji finansowych klienta, np. złożeń dyspozycji, zatwierdzonych SCA | 100% operacji finansowych; korekta kwot pozycji bez zmiany kwoty łącznej nie wymaga ponownego SCA | Porównanie dziennika operacji finansowych z dziennikiem autoryzacji SCA | wszystkie | Must |
| NFRT-AVAIL-01 | Niezawodność: niedostępność systemu zewnętrznego | Limit czasu jednego wywołania i liczba ponowień | Limit czasu 3 s, najwyżej 3 ponowienia z rosnącym odstępem | Test ze wstrzykiwaniem opóźnień i błędów; metryki wywołań po stronie komponentu | PROD | Should |
| NFRT-OBS-01 | Audytowalność: ślad decyzji | Odsetek decyzji z wpisem w dzienniku audytowym; okres przechowywania wpisu | 100% decyzji, retencja 5 lat | Uzgodnienie liczby decyzji z liczbą wpisów audytowych; przegląd konfiguracji retencji | PROD | Must |

## Katalog według kategorii

### Performance

- NFRT-PERF-01: punkt końcowy API wołany z kanału klienta albo z aplikacji zaplecza odpowiada w 95% żądań w czasie do 500 ms, liczonym na bramie API bez czasu sieci po stronie klienta.
- NFRT-PERF-02: nocny przebieg wsadowy kończy się przed 05:00, żeby księga główna i raporty dzienne były gotowe przed otwarciem dnia operacyjnego.

### Availability i Reliability

- NFRT-AVAIL-01: każde wywołanie systemu zewnętrznego ma limit czasu 3 s i najwyżej 3 ponowienia z rosnącym odstępem. Po wyczerpaniu ponowień komponent kończy operację błędem biznesowym albo odkłada ją do ponowienia, zamiast czekać na odpowiedź bez limitu.

### Security i Compliance

- NFRT-SEC-01: operację finansową, np. złożenie dyspozycji, klient zatwierdza silnym uwierzytelnieniem, czyli dwoma niezależnymi elementami z różnych kategorii: wiedza, posiadanie, cecha klienta. Operacja bez potwierdzonego SCA nie trafia do przetwarzania. Korekta kwot pozycji przed rozliczeniem, która nie zmienia kwoty łącznej dyspozycji, nie wymaga ponownego SCA.

### Observability i Auditability

- NFRT-OBS-01: każda decyzja systemu i pracownika, np. przyjęcie albo odrzucenie dyspozycji, wynik rozliczenia, wynik weryfikacji, decyzja w sprawie reklamacji, zostawia wpis w dzienniku audytowym: autora decyzji (pracownik albo komponent), czas, dane wejściowe i wynik. Wpisy są przechowywane 5 lat.

### Operability i Maintainability

Macierz nie ma wierszy tej kategorii. Obowiązują ogólne zasady utrzymania
systemów banku: każdy komponent wystawia kontrolę stanu dla monitoringu, a progi
biznesowe, np. limity czasu, zmienia się konfiguracją bez ponownego wdrożenia.

### Continuity (RTO/RPO)

Macierz nie ma wierszy tej kategorii. Odtworzenie systemu po awarii ośrodka
przetwarzania opisuje plan ciągłości działania banku; dokument nie ustala
własnych progów RTO i RPO.

## Weryfikacja i monitorowanie

| ID | Przed wydaniem | Po wydaniu | Próg alertu |
|---|---|---|---|
| NFRT-PERF-01 | Test obciążeniowy w środowisku przedprodukcyjnym z profilem ruchu z godzin szczytu | Pomiar p95 w APM w oknach 5-minutowych dla każdego punktu końcowego | p95 > 450 ms przez 15 minut |
| NFRT-PERF-02 | Przebieg wsadowy na kopii danych z dnia o największym wolumenie w ostatnim kwartale | Godzina zakończenia przebiegu w dzienniku harmonogramu | Przebieg niezakończony o 04:30 |
| NFRT-SEC-01 | Testy penetracyjne i przegląd ścieżek autoryzacji operacji finansowych | Dzienny raport operacji finansowych bez potwierdzonego SCA | Co najmniej jedna operacja bez SCA |
| NFRT-AVAIL-01 | Test wstrzykiwania błędów: opóźnienie powyżej 3 s i odpowiedź 503 systemu zewnętrznego | Metryki przekroczeń czasu i ponowień dla każdej integracji | Ponad 5% wywołań integracji z ponowieniem w oknie 10 minut |
| NFRT-OBS-01 | Test kompletności: każda decyzja w testach end-to-end ma wpis audytowy | Miesięczne uzgodnienie liczby decyzji i wpisów oraz kontrola retencji | Każda rozbieżność między liczbą decyzji a liczbą wpisów |

## Wyjątki i odstępstwa

| ID | Powód | Akceptujący | Data wygaśnięcia |
|---|---|---|---|
| NFRT-PERF-02 | W ostatnim dniu roboczym miesiąca przebieg obejmuje też rozliczenia miesięczne i kończy się najpóźniej o 06:00; odstępstwo obowiązuje do wydzielenia przebiegu miesięcznego | Tomasz Lewandowski | 2027-03-31 |
