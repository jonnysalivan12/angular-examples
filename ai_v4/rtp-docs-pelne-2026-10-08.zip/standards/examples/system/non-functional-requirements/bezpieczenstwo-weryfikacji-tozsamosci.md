---
doc-id: NFR-002
title: "Bezpieczeństwo weryfikacji tożsamości"
description: "Progi ochrony danych dokumentu tożsamości i dostępności komponentu weryfikacji tożsamości."
status: draft                                  # draft | active
scope: component                               # system | component
owner: "Tomasz Lewandowski"
relations:
  - type: contains
    target: NFRT-AVAIL-01
  - type: contains
    target: NFRT-SEC-01
---

# Bezpieczeństwo weryfikacji tożsamości

| Pole | Wartość |
|---|---|
| Zakres | component |
| Zespół odpowiedzialny | Squad Weryfikacji Tożsamości |
| Krytyczność | wysoka |

## Cel i kontekst

Komponent weryfikacji tożsamości sprawdza wnioskodawcę automatycznie
(rejestr PESEL i lista sankcyjna) albo przekazuje wniosek pracownikowi
zaplecza do weryfikacji ręcznej. Przetwarza numer PESEL, dane i zdjęcie
dokumentu tożsamości, czyli dane osobowe w rozumieniu RODO. Dokument dodaje
progi tego komponentu do progów systemowych; w kategoriach bez własnych
wierszy obowiązują wyłącznie progi systemowe.

## Macierz wymagań

| ID | Atrybut jakości | Metryka | Próg docelowy | Metoda pomiaru | Środowisko | Priorytet |
|---|---|---|---|---|---|---|
| NFRT-SEC-01 | Poufność danych dokumentu tożsamości | Szyfrowanie danych w spoczynku i w transmisji; liczba niezamaskowanych wystąpień danych dokumentu w logach | AES-256 w spoczynku, TLS 1.2 lub wyższy w transmisji; 0 wystąpień pełnego numeru PESEL, numeru dokumentu i zdjęcia w logach | Przegląd konfiguracji szyfrowania; skan logów wzorcami numeru PESEL i numeru dokumentu | wszystkie | Must |
| NFRT-AVAIL-01 | Dostępność weryfikacji tożsamości | Odsetek minut dostępności usługi w godzinach 6:00–22:00 w miesiącu kalendarzowym | ≥ 99,9% | Monitoring syntetyczny: testowe wywołanie weryfikacji co 60 s | PROD | Must |

## Katalog według kategorii

### Performance

Komponent nie ma własnych progów wydajności. Czas odpowiedzi jego punktów
końcowych ograniczają progi systemowe.

### Availability i Reliability

- NFRT-AVAIL-01: weryfikacja tożsamości działa w 99,9% minut między 6:00 a 22:00 w miesiącu, czyli dopuszcza około 29 minut niedostępności w miesiącu 30-dniowym. Prace serwisowe planuje się między 22:00 a 6:00; wniosek złożony w tym czasie czeka na weryfikację do 6:00.

### Security i Compliance

- NFRT-SEC-01: numer PESEL, numer i zdjęcie dokumentu tożsamości są szyfrowane w bazie i w transmisji. W logach aplikacji numer PESEL i numer dokumentu występują tylko zamaskowane, z widocznymi 3 ostatnimi znakami, a zdjęcie dokumentu nie trafia do logów w żadnej postaci.

### Observability i Auditability

Komponent nie ma własnych wierszy tej kategorii. Wpis audytowy wyniku
weryfikacji zawiera identyfikator weryfikacji, wynik i autora decyzji, bez
niezamaskowanych danych dokumentu.

### Operability i Maintainability

Komponent nie ma własnych wierszy tej kategorii. Reguły maskowania i adresy
usług zewnętrznych zmienia się konfiguracją, bez ponownego wdrożenia
komponentu.

### Continuity (RTO/RPO)

Komponent nie ma własnych wierszy tej kategorii. Obowiązuje plan ciągłości
działania systemu.

## Weryfikacja i monitorowanie

| ID | Przed wydaniem | Po wydaniu | Próg alertu |
|---|---|---|---|
| NFRT-SEC-01 | Skan logów po testach end-to-end wzorcami numeru PESEL i numeru dokumentu; przegląd konfiguracji szyfrowania | Codzienny skan logów produkcyjnych; kwartalny przegląd dostępu do danych dokumentów | Jedno niezamaskowane wystąpienie numeru PESEL albo numeru dokumentu |
| NFRT-AVAIL-01 | Test przełączenia instancji bez przerwy w obsłudze wywołań | Monitoring syntetyczny co 60 s w godzinach 6:00–22:00 | 3 kolejne nieudane wywołania testowe albo dostępność w bieżącym miesiącu poniżej 99,95% |

## Wyjątki i odstępstwa

| ID | Powód | Akceptujący | Data wygaśnięcia |
|---|---|---|---|
| — | Brak zatwierdzonych odstępstw | — | — |
