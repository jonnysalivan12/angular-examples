---
doc-id: SCR-001
title: "Ekran Dyspozycja: Krok 1 z 2 — Dane i pozycje"
description: "Pierwszy krok składania dyspozycji: dane klienta i lista pozycji przelewu."
status: draft                                  # draft | active
step: "1"                                      # numer kroku
owner: "Anna Nowak"
relations:
  - type: contains
    target: SCRSEC-001
  - type: contains
    target: SCRSEC-002
---

# Ekran Dyspozycja: Krok 1 z 2 — Dane i pozycje

## Opis ekranu

Pierwszy z dwóch kroków składania dyspozycji przelewu wielopozycyjnego w aplikacji mobilnej i bankowości internetowej. Klient widzi tu swoje dane z profilu i wpisuje pozycje przelewu, zanim przejdzie do podsumowania.

- Cele ekranu: klient widzi swoje dane z profilu i wpisuje od 1 do 50 pozycji przelewu; ekran nie przepuszcza do podsumowania dyspozycji z błędnymi pozycjami.
- Figma: [Dyspozycja, krok 1](https://www.figma.com/design/Qm3dK7pLr2/Dyspozycja?node-id=120-4410)

## Mapa sekcji na ekranie

![Ekran Dyspozycja: Krok 1 z 2 — Dane i pozycje](assets/dyspozycja-dane-i-pozycje.png)

![Podział ekranu na sekcje](assets/dyspozycja-dane-i-pozycje-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-001 | Dane klienta tylko do odczytu: imię i nazwisko, PESEL, adres korespondencyjny | Zawsze |
| 2 | SCRSEC-002 | Pozycje dyspozycji z przyciskiem dodania pozycji | Zawsze |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | — | — |
| Bieżący | 1 Dane i pozycje | Aktywny |
| Następny | 2 Podsumowanie | Dostępny po poprawnym wypełnieniu kroku 1 |

## Nawigacja

- Przycisk wstecz: wraca do pulpitu aplikacji; gdy klient wpisał już pozycje, ekran pyta, czy porzucić dyspozycję.
- Przycisk „Dalej”: aktywny, gdy wszystkie pozycje są poprawne; przenosi do kroku 2 Podsumowanie z wpisanymi pozycjami.
- Odnośniki i akcje dodatkowe: „Anuluj” zamyka formularz bez zapisu; „Jak działa przelew wielopozycyjny” otwiera pomoc w warstwie nad ekranem.
