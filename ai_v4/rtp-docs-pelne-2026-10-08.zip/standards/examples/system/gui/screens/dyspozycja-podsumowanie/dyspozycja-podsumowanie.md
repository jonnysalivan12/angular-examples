---
doc-id: SCR-002
title: "Ekran Dyspozycja: Krok 2 z 2 — Podsumowanie"
description: "Drugi krok dyspozycji: podsumowanie pozycji i kwot przed zatwierdzeniem, wspólne dla złożenia i korekty."
status: draft                                  # draft | active
step: "2"                                      # numer kroku
owner: "Anna Nowak"
relations:
  - type: contains
    target: SCRSEC-002
  - type: contains
    target: SCRSEC-003
---

# Ekran Dyspozycja: Krok 2 z 2 — Podsumowanie

## Opis ekranu

Drugi i ostatni krok dyspozycji, wspólny dla złożenia i korekty. Klient sprawdza tu pozycje i kwoty, a potem zatwierdza złożenie albo potwierdza korektę.

- Cele ekranu: klient sprawdza pozycje i kwotę łączną, a potem zatwierdza złożenie dyspozycji silnym uwierzytelnieniem albo potwierdza korektę kwot pozycji bez ponownego uwierzytelnienia; ten sam ekran kończy obie ścieżki.
- Figma: [Dyspozycja, krok 2](https://www.figma.com/design/Qm3dK7pLr2/Dyspozycja?node-id=120-5120)

## Mapa sekcji na ekranie

![Ekran Dyspozycja: Krok 2 z 2 — Podsumowanie](assets/dyspozycja-podsumowanie.png)

![Podział ekranu na sekcje](assets/dyspozycja-podsumowanie-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-002 | Pozycje dyspozycji z kroku 1, tylko do odczytu | Zawsze |
| 2 | SCRSEC-003 | Podsumowanie kwot: kwota łączna, waluta, liczba pozycji | Zawsze |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | 1 Dane i pozycje (złożenie) albo 1 Edycja pozycji (korekta) | Ukończony |
| Bieżący | 2 Podsumowanie | Aktywny |
| Następny | — | — |

## Nawigacja

- Przycisk wstecz: wraca do kroku 1 z zachowaniem wpisanych pozycji.
- Przycisk „Dalej”: na ostatnim kroku ma etykietę „Zatwierdź”. Przy złożeniu uruchamia silne uwierzytelnienie i wysyła dyspozycję; gdy kwota przekracza dostępny limit, ekran zostaje otwarty i pokazuje komunikat nad podsumowaniem kwot. Przy korekcie zapisuje zmienione pozycje bez silnego uwierzytelnienia; gdy dyspozycja jest już rozliczana, ekran pokazuje komunikat, że korekta jest niemożliwa.
- Odnośniki i akcje dodatkowe: „Zapisz szkic” (tylko przy złożeniu) zamyka ekran, a aplikacja przechowuje wpisane pozycje do powrotu klienta; „Anuluj” wraca do listy dyspozycji.
