---
doc-id: SCR-012
title: "Ekran Weryfikacja zaplecze: Krok 1 z 1 — Weryfikacja tożsamości"
description: "Formularz zadania ręcznej weryfikacji tożsamości w procesie otwarcia rachunku, obsługiwany przez pracownika zaplecza."
status: draft                                  # draft | active
step: "1"                                      # numer kroku
owner: "Katarzyna Wójcik"
relations:
  - type: contains
    target: SCRSEC-013
---

# Ekran Weryfikacja zaplecze: Krok 1 z 1 — Weryfikacja tożsamości

## Opis ekranu

Formularz zadania ręcznej weryfikacji tożsamości w procesie otwarcia rachunku, otwierany przez pracownika zaplecza z listy zadań. Pracownik porównuje tu dokument tożsamości z danymi wnioskodawcy i zapisuje decyzję, która kończy zadanie.

- Cele ekranu: pozwolić pracownikowi zaplecza porównać zdjęcie dokumentu tożsamości z danymi wnioskodawcy i z wynikiem weryfikacji automatycznej, a następnie zapisać decyzję, która kończy zadanie użytkownika w procesie otwarcia rachunku.
- Figma: https://www.figma.com/design/Pm3Tz8/Zaplecze-weryfikacja-tozsamosci?node-id=44-10

## Mapa sekcji na ekranie

![Ekran Weryfikacja zaplecze: Krok 1 z 1 — Weryfikacja tożsamości](assets/weryfikacja-tozsamosci.png)

![Podział ekranu na sekcje](assets/weryfikacja-tozsamosci-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-013 | Zdjęcie i numer dokumentu, wynik porównania danych oraz decyzja pracownika | Zawsze, po otwarciu zadania z listy zadań |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | — | — |
| Bieżący | 1 Weryfikacja tożsamości | bieżący |
| Następny | — | — |

## Nawigacja

- Przycisk wstecz: wraca do listy zadań bez zapisu decyzji; zadanie zostaje przypisane do pracownika.
- Przycisk „Dalej”: na tym ekranie ma etykietę „Zatwierdź decyzję”; aktywny po wyborze decyzji, a przy odrzuceniu także po wpisaniu uzasadnienia. Zapis kończy zadanie w silniku procesów i wraca do listy zadań.
- Odnośniki i akcje dodatkowe: „Odłóż zadanie” zwalnia przypisanie i zwraca zadanie do puli, np. gdy rejestr PESEL jest niedostępny; „Historia wniosku” otwiera w panelu bocznym przebieg dotychczasowej weryfikacji.
