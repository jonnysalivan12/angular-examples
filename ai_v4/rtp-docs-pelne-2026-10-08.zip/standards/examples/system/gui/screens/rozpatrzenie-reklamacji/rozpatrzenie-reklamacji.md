---
doc-id: SCR-005
title: "Ekran Reklamacje zaplecze: Krok 1 z 1 — Rozpatrzenie reklamacji"
description: "Formularz zadania użytkownika w silniku procesów, na którym pracownik zaplecza przegląda reklamowaną dyspozycję i opis reklamacji oraz zapisuje decyzję."
status: draft                                  # draft | active
step: "1"                                      # numer kroku
owner: "Piotr Zieliński"
relations:
  - type: contains
    target: SCRSEC-005
  - type: contains
    target: SCRSEC-006
  - type: contains
    target: SCRSEC-007
---

# Ekran Reklamacje zaplecze: Krok 1 z 1 — Rozpatrzenie reklamacji

## Opis ekranu

Formularz zadania rozpatrzenia reklamacji w silniku procesów, otwierany przez pracownika zaplecza z listy zadań. Pracownik przegląda tu reklamowaną dyspozycję i opis reklamacji oraz zapisuje decyzję, która kończy zadanie.

- Cele ekranu: pracownik zaplecza otwiera z listy zadań zadanie rozpatrzenia reklamacji w procesie obsługi reklamacji, zapoznaje się z reklamowaną dyspozycją oraz powodem, opisem i załącznikiem klienta, a następnie zapisuje decyzję, kwotę rekompensaty i uzasadnienie. Ekran jest formularzem tego zadania w silniku procesów.
- Figma: https://www.figma.com/design/reklamacje-zaplecze?node-id=3-15

## Mapa sekcji na ekranie

![Ekran Reklamacje zaplecze: Krok 1 z 1 — Rozpatrzenie reklamacji](assets/rozpatrzenie-reklamacji.png)

![Podział ekranu na sekcje](assets/rozpatrzenie-reklamacji-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-005 | Reklamowana dyspozycja tylko do odczytu: rachunek obciążany, kwota łączna, waluta i data rozliczenia, bez listy wyboru | Zawsze |
| 2 | SCRSEC-006 | Powód, opis i załącznik reklamacji tylko do odczytu; załącznik jako odnośnik do pobrania | Zawsze |
| 3 | SCRSEC-007 | Decyzja UZNANA albo ODRZUCONA, kwota rekompensaty i uzasadnienie decyzji | Zawsze; pola edytowalne tylko w zadaniu przypisanym do zalogowanego pracownika, w pozostałych zadaniach tylko do odczytu |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | — | — |
| Bieżący | 1 Rozpatrzenie reklamacji | bieżący |
| Następny | — | — |

## Nawigacja

- Przycisk wstecz: wraca do listy zadań bez zapisu; zadanie zostaje przypisane do pracownika.
- Przycisk „Dalej”: formularz zadania ma w tym miejscu przycisk „Zapisz decyzję”; zapis kończy zadanie w silniku procesów i wraca do listy zadań z komunikatem potwierdzenia, a odrzucony zapis (kwota rekompensaty wyższa niż kwota dyspozycji) zostawia formularz otwarty z komunikatem przy kwocie.
- Odnośniki i akcje dodatkowe: „Zwolnij zadanie” oddaje zadanie do wspólnej kolejki zespołu reklamacji.
