---
doc-id: SCRSEC-004
title: "Historia statusów"
description: "Lista zmian statusu dyspozycji z etykietą statusu i datą zmiany, tylko do odczytu."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations:
  - type: consumes
    target: ENT-Disposition
  - type: consumes
    target: ENT-StatusDict
---

# Historia statusów

## Opis sekcji

Sekcja pokazuje zmiany statusu dyspozycji od najnowszej: etykietę statusu
i datę zmiany. Na ekranie edycji pozycji potwierdza klientowi, że dyspozycja
nie weszła jeszcze do rozliczenia.

## Pola sekcji

<!-- Blok powielany dla każdego pola albo elementu. -->

### Status

| Atrybut | Wartość |
|---|---|
| Typ pola | Znacznik statusu w wierszu listy |
| Etykieta | Status |
| Wartość domyślna | Etykieta bieżącego statusu dyspozycji |
| Wartość przykładowa | Zaakceptowana |
| Źródło danych | ENT-StatusDict (label dla kodu statusu dyspozycji) |
| Miejsce utrwalenia | — |
| Edytowalność | nie |
| Wymagalność | nie |
| Uprawnienia | Klient: odczyt historii własnej dyspozycji |
| Walidacja | — |
| Zachowanie | Bez wywołań; kod statusu z dyspozycji zamieniany na etykietę ze słownika statusów dyspozycji |
| Tooltip | Przy statusie końcowym, czyli dyspozycji odrzuconej albo skorygowanej: „Ta dyspozycja nie zmieni już statusu” |
| WCAG | aria-label łączy etykietę statusu i datę zmiany |
| Analityka zdarzeń (opcjonalnie) | — |
| Referencja komponentu UI (opcjonalnie) | ds-status-badge |

### Data zmiany

| Atrybut | Wartość |
|---|---|
| Typ pola | Data i godzina, tylko do odczytu |
| Etykieta | Data zmiany |
| Wartość domyślna | Data przyjęcia dyspozycji |
| Wartość przykładowa | 14.09.2026 10:32 |
| Źródło danych | ENT-Disposition (createdAt, settledAt) |
| Miejsce utrwalenia | — |
| Edytowalność | nie |
| Wymagalność | nie |
| Uprawnienia | Klient: odczyt historii własnej dyspozycji |
| Walidacja | — |
| Zachowanie | Bez wywołań; data przyjęcia pochodzi z createdAt, data rozliczenia z settledAt |
| Tooltip | — |
| WCAG | Element time z atrybutem datetime w formacie ISO 8601 |
| Analityka zdarzeń (opcjonalnie) | — |
| Referencja komponentu UI (opcjonalnie) | ds-date-time |

## Reguły biznesowe

1. **Kolejność wierszy**: Wiersze są uporządkowane od najnowszej zmiany.
2. **Wyróżnienie statusu końcowego**: Status oznaczony w słowniku jako końcowy jest wyróżniony i ma tooltip.
3. **ROZLICZONA nie jest końcowy**: Status ROZLICZONA nie jest końcowy: po uznanej reklamacji rozliczona dyspozycja może przejść do statusu SKORYGOWANA, więc przy statusie ROZLICZONA sekcja nie pokazuje tooltipu statusu końcowego.
4. **Wiersz rozliczenia**: Wiersz rozliczenia pojawia się dopiero wtedy, gdy dyspozycja ma datę rozliczenia.

## Zachowania specjalne

<!-- Opcjonalnie: podsekcja na każdy stan albo scenariusz, prozą albo pseudokodem. -->

### Budowa listy

Sekcja dodaje wiersz ze statusem ZAAKCEPTOWANA i datą createdAt, a gdy settledAt jest ustawione, wiersz z bieżącym statusem i datą settledAt. Wiersze są posortowane malejąco po dacie.

### Status końcowy

Wiersz ze statusem, który ma w słowniku isFinal = true, jest wyróżniony i ma tooltip.
