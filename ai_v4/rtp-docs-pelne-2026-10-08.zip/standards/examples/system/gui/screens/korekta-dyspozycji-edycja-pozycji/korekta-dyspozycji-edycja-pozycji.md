---
doc-id: SCR-003
title: "Ekran Korekta dyspozycji: Krok 1 z 2 — Edycja pozycji"
description: "Pierwszy krok korekty: edycja pozycji zaakceptowanej dyspozycji przed nocnym rozliczeniem."
status: draft                                  # draft | active
step: "1"                                      # numer kroku
owner: "Anna Nowak"
relations:
  - type: contains
    target: SCRSEC-001
  - type: contains
    target: SCRSEC-002
  - type: contains
    target: SCRSEC-004
---

# Ekran Korekta dyspozycji: Krok 1 z 2 — Edycja pozycji

## Opis ekranu

Pierwszy krok korekty dyspozycji w statusie ZAAKCEPTOWANA, otwierany z listy dyspozycji przyciskiem „Koryguj”. Klient zmienia tu kwoty pozycji, zanim dyspozycja trafi do nocnego rozliczenia.

- Cele ekranu: klient zmienia kwoty pozycji dyspozycji w statusie ZAAKCEPTOWANA, zanim dyspozycja trafi do nocnego rozliczenia; suma kwot pozycji musi pozostać równa kwocie dyspozycji, a rachunek odbiorcy i tytuł są tylko do odczytu.
- Figma: [Korekta dyspozycji, krok 1](https://www.figma.com/design/Qm3dK7pLr2/Dyspozycja?node-id=130-2210)

## Mapa sekcji na ekranie

![Ekran Korekta dyspozycji: Krok 1 z 2 — Edycja pozycji](assets/korekta-dyspozycji-edycja-pozycji.png)

![Podział ekranu na sekcje](assets/korekta-dyspozycji-edycja-pozycji-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-001 | Dane klienta tylko do odczytu: imię i nazwisko, PESEL, adres korespondencyjny | Zawsze |
| 2 | SCRSEC-002 | Pozycje dyspozycji z edytowalną kwotą; rachunek odbiorcy i tytuł tylko do odczytu | Dyspozycja ma status ZAAKCEPTOWANA; w innym statusie pozycje są tylko do odczytu |
| 3 | SCRSEC-004 | Historia statusów dyspozycji, domyślnie zwinięta | Zawsze |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | — | — |
| Bieżący | 1 Edycja pozycji | Aktywny |
| Następny | 2 Podsumowanie | Dostępny, gdy suma kwot pozycji jest równa kwocie dyspozycji |

## Nawigacja

- Przycisk wstecz: wraca do listy dyspozycji.
- Przycisk „Dalej”: aktywny, gdy suma kwot pozycji jest równa kwocie dyspozycji; przenosi do kroku 2 Podsumowanie. Przy niezgodnej sumie ekran pokazuje komunikat z różnicą kwot i blokuje przejście.
- Odnośniki i akcje dodatkowe: gdy dyspozycja nie ma już statusu ZAAKCEPTOWANA, ekran pokazuje komunikat, że korekta jest niemożliwa, z odnośnikiem „Wróć do listy dyspozycji”.
