---
doc-id: SCR-010
title: "Ekran Konto: Krok 1 z 2 — Dane i produkt"
description: "Pierwszy krok wniosku o rachunek online: dane osobowe wnioskodawcy i wybór rachunku osobistego albo lokaty."
status: draft                                  # draft | active
step: "1"                                      # numer kroku
owner: "Katarzyna Wójcik"
relations:
  - type: contains
    target: SCRSEC-010
  - type: contains
    target: SCRSEC-011
---

# Ekran Konto: Krok 1 z 2 — Dane i produkt

## Opis ekranu

Pierwszy z dwóch kroków wniosku o rachunek online, otwierany ze strony oferty. Wnioskodawca podaje tu dane osobowe i wybiera rachunek osobisty albo lokatę terminową.

- Cele ekranu: zebrać dane osobowe wnioskodawcy potrzebne do weryfikacji tożsamości oraz ustalić, czy klient zakłada rachunek osobisty, czy lokatę terminową z kwotą i okresem.
- Figma: https://www.figma.com/design/Kx7Rq2/Konto-wniosek-online?node-id=101-2

## Mapa sekcji na ekranie

![Ekran Konto: Krok 1 z 2 — Dane i produkt](assets/konto-dane-i-produkt.png)

![Podział ekranu na sekcje](assets/konto-dane-i-produkt-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-010 | Dane osobowe wnioskodawcy: PESEL, imię, nazwisko, data urodzenia i adres | Zawsze |
| 2 | SCRSEC-011 | Wybór produktu z oferty; dla lokaty także kwota i okres | Zawsze; pola lokaty po wyborze lokaty terminowej |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | — | — |
| Bieżący | 1 Dane i produkt | bieżący |
| Następny | 2 Zgody i wysłanie | do wykonania |

## Nawigacja

- Przycisk wstecz: wyświetla okno z pytaniem o przerwanie wniosku; po potwierdzeniu wraca na stronę oferty rachunków bez zapisu danych.
- Przycisk „Dalej”: aktywny, gdy wszystkie pola wymagane obu sekcji przeszły walidację; przenosi do kroku 2 Zgody i wysłanie z zachowaniem wpisanych danych.
- Odnośniki i akcje dodatkowe: „Tabela opłat i prowizji” oraz „Oprocentowanie lokat” otwierają dokumenty PDF w nowej karcie.
