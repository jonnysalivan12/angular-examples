---
doc-id: SCR-011
title: "Ekran Konto: Krok 2 z 2 — Zgody i wysłanie"
description: "Drugi krok wniosku o rachunek online: akceptacja zgód, wysłanie wniosku i potwierdzenie otwarcia rachunku."
status: draft                                  # draft | active
step: "2"                                      # numer kroku
owner: "Katarzyna Wójcik"
relations:
  - type: contains
    target: SCRSEC-012
---

# Ekran Konto: Krok 2 z 2 — Zgody i wysłanie

## Opis ekranu

Drugi i ostatni krok wniosku o rachunek online. Klient akceptuje tu zgody, wysyła wniosek i widzi wynik: potwierdzenie otwarcia rachunku albo informację o weryfikacji przez pracownika.

- Cele ekranu: uzyskać zgodę na regulamin produktu i opcjonalną zgodę marketingową, wysłać wniosek oraz pokazać klientowi wynik: potwierdzenie otwarcia rachunku albo informację o weryfikacji przez pracownika banku.
- Figma: https://www.figma.com/design/Kx7Rq2/Konto-wniosek-online?node-id=101-3

## Mapa sekcji na ekranie

![Ekran Konto: Krok 2 z 2 — Zgody i wysłanie](assets/konto-zgody-i-wyslanie.png)

![Podział ekranu na sekcje](assets/konto-zgody-i-wyslanie-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-012 | Zgoda na regulamin wybranego produktu (wymagana) i zgoda marketingowa (opcjonalna) | Zawsze |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | 1 Dane i produkt | ukończony |
| Bieżący | 2 Zgody i wysłanie | bieżący |
| Następny | — | — |

## Nawigacja

- Przycisk wstecz: wraca do kroku 1 Dane i produkt z zachowaniem danych i zaznaczonych zgód; po wysłaniu wniosku przycisk jest ukryty.
- Przycisk „Dalej”: na tym ekranie ma etykietę „Wyślij wniosek”; jest nieaktywny, dopóki zgoda na regulamin nie jest zaznaczona. Po wysłaniu ekran pokazuje komunikat oczekiwania, a po odebraniu informacji o otwarciu rachunku potwierdzenie z numerem rachunku. Gdy wniosek trafia do weryfikacji przez pracownika, ekran pokazuje informację, że klient dostanie powiadomienie po jej zakończeniu.
- Odnośniki i akcje dodatkowe: „Regulamin” i „Informacja o przetwarzaniu danych osobowych” otwierają aktualne wersje dokumentów PDF w nowej karcie.
