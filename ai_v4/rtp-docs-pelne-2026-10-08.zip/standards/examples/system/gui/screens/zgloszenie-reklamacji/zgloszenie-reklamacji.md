---
doc-id: SCR-004
title: "Ekran Reklamacja: Krok 1 z 1 — Zgłoszenie reklamacji"
description: "Jednokrokowy formularz zgłoszenia reklamacji rozliczonej dyspozycji, wspólny dla bankowości internetowej i oddziału."
status: draft                                  # draft | active
step: "1"                                      # numer kroku
owner: "Piotr Zieliński"
relations:
  - type: contains
    target: SCRSEC-005
  - type: contains
    target: SCRSEC-006
---

# Ekran Reklamacja: Krok 1 z 1 — Zgłoszenie reklamacji

## Opis ekranu

Jednokrokowy formularz zgłoszenia reklamacji rozliczonej dyspozycji, wspólny dla klienta w bankowości internetowej i doradcy w oddziale. Zgłoszenie wysłane z tego ekranu uruchamia proces obsługi reklamacji.

- Cele ekranu: klient w bankowości internetowej albo doradca w oddziale w imieniu klienta wybiera rozliczoną dyspozycję, opisuje powód reklamacji i wysyła zgłoszenie jednym przyciskiem.
- Figma: https://www.figma.com/design/reklamacje-dyspozycji?node-id=12-4

## Mapa sekcji na ekranie

![Ekran Reklamacja: Krok 1 z 1 — Zgłoszenie reklamacji](assets/zgloszenie-reklamacji.png)

![Podział ekranu na sekcje](assets/zgloszenie-reklamacji-sekcje.png)

## Struktura ekranu

| Kolejność | Sekcja | Opis | Warunek wyświetlenia |
|---|---|---|---|
| 1 | SCRSEC-005 | Lista rozliczonych dyspozycji klienta z ostatnich 30 dni; wybór jednej dyspozycji do reklamacji | Zawsze; przy braku dyspozycji z ostatnich 30 dni sekcja pokazuje komunikat zamiast listy |
| 2 | SCRSEC-006 | Powód, opis i opcjonalny załącznik reklamacji | Wybrana dyspozycja w sekcji „Wybór dyspozycji” |

## Kolejne ekrany

| Krok | Numer i nazwa | Status |
|---|---|---|
| Poprzedni | — | — |
| Bieżący | 1 Zgłoszenie reklamacji | bieżący |
| Następny | — | — |

## Nawigacja

- Przycisk wstecz: wraca do miejsca, z którego otwarto formularz (lista dyspozycji w bankowości internetowej albo karta klienta w aplikacji oddziału); przed wyjściem z wypełnionym opisem ekran pyta o porzucenie zmian.
- Przycisk „Dalej”: ekran jednokrokowy ma w tym miejscu przycisk „Wyślij zgłoszenie”, aktywny po wybraniu dyspozycji i powodu; po przyjęciu zgłoszenia ekran pokazuje komunikat z numerem reklamacji, a przy odrzuceniu (dyspozycja rozliczona ponad 30 dni temu) komunikat błędu nad sekcją wyboru dyspozycji.
- Odnośniki i akcje dodatkowe: „Regulamin reklamacji” otwiera dokument w nowej karcie.
