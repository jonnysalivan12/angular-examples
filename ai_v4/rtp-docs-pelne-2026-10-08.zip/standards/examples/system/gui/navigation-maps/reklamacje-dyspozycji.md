---
doc-id: NAV-002
title: "Reklamacje dyspozycji: mapa nawigacyjna"
description: "Przejścia między ekranami procesu reklamacji: ścieżka zgłoszenia i ścieżka rozpatrzenia przez zaplecze."
status: draft                                  # draft | active
owner: "Piotr Zieliński"
relations:
  - type: groups
    target: SCR-004
  - type: groups
    target: SCR-005
---

# Reklamacje dyspozycji: mapa nawigacyjna

## Warunki wstępne

Mapa obejmuje oba ekrany procesu reklamacji dyspozycji. Ścieżka zgłoszenia ma
jeden ekran, wspólny dla klienta w bankowości internetowej i doradcy w oddziale.
Ścieżka rozpatrzenia ma jeden ekran pracownika zaplecza. Ścieżek nie łączy
przejście między ekranami, tylko proces obsługi reklamacji w silniku procesów,
który po rejestracji tworzy zadanie rozpatrzenia. Mapa nie opisuje ekranów
spoza procesu: podglądu dyspozycji, identyfikacji klienta w aplikacji
oddziałowej i listy zadań zaplecza; pokazuje je tylko jako wejścia i wyjścia.

## Diagram nawigacji

<!-- Wszystkie ekrany procesu: startowy, pośrednie, końcowy, ekran błędu, wejścia i wyjścia poza przepływ. Krawędzie: akcja użytkownika to strzałka z etykietą (-->|Dalej|), błąd techniczny to linia przerywana (-. błąd techniczny .->). Duży diagram dzielisz na obszary subgraph. -->

```mermaid
flowchart TD
    Podglad([Podgląd dyspozycji w bankowości internetowej]) --> Zgloszenie[SCR-004 Zgłoszenie reklamacji]
    Oddzial([Identyfikacja klienta w aplikacji oddziałowej]) -->|tożsamość potwierdzona| Zgloszenie
    Zgloszenie -->|zgłoszenie po terminie 30 dni| Zgloszenie
    Zgloszenie -->|reklamacja zarejestrowana| Potwierdzenie([Komunikat z numerem reklamacji, wyjście z przepływu])
    Zadania([Lista zadań aplikacji zaplecza])
    Zadania --> Rozpatrzenie[SCR-005 Rozpatrzenie reklamacji]
    Rozpatrzenie -->|kwota ponad kwotę dyspozycji| Rozpatrzenie
    Rozpatrzenie -. błąd techniczny: silnik nie przyjął zapisu decyzji .-> Rozpatrzenie
    Rozpatrzenie -->|decyzja zapisana, zadanie zakończone| Zadania
```

## Kluczowe elementy nawigacji

- Główne przejścia: SCR-004 jest ekranem startowym i końcowym ścieżki zgłoszenia: klient wchodzi na niego z podglądu dyspozycji, doradca po potwierdzeniu tożsamości klienta w aplikacji oddziałowej. SCR-005 jest ekranem startowym i końcowym ścieżki rozpatrzenia: pracownik otwiera go z zadania na liście zadań i przegląda reklamowaną dyspozycję i opis reklamacji tylko do odczytu.
- Przejścia końcowe i ich warunki: po rejestracji reklamacji przepływ zgłoszenia kończy komunikat z numerem reklamacji na SCR-004. Przejście do ścieżki rozpatrzenia nie jest nawigacją użytkownika: zarejestrowana reklamacja uruchamia proces w silniku, a ten tworzy zadanie na liście zadań pracownika zaplecza. Zapis decyzji na SCR-005 kończy zadanie i wraca do listy zadań.

## Odniesienia do ekranów

| Ekran | Rola w mapie | Dokument |
|---|---|---|
| Zgłoszenie reklamacji | startowy i końcowy ścieżki klienta i doradcy | SCR-004 |
| Rozpatrzenie reklamacji | startowy i końcowy ścieżki pracownika zaplecza | SCR-005 |

## Scenariusze błędów

Proces nie ma osobnych ekranów błędów; każdy błąd pokazuje komunikat na ekranie, na którym wystąpił.

| Scenariusz | Zachowanie |
|---|---|
| Zgłoszenie dyspozycji rozliczonej ponad 30 dni temu | Komunikat na SCR-004 bez rejestracji reklamacji |
| Klient bez dyspozycji rozliczonych w ostatnich 30 dniach | SCR-004 pokazuje pustą listę i nie pozwala wysłać zgłoszenia |
| Kwota rekompensaty większa niż kwota dyspozycji | Komunikat na SCR-005; pracownik poprawia kwotę bez opuszczania ekranu |
| Silnik procesów nie przyjmuje zapisu decyzji | SCR-005 pokazuje komunikat i pozwala ponowić zapis |
