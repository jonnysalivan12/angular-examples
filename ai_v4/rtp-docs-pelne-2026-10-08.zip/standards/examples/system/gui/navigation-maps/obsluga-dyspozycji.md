---
doc-id: NAV-001
title: "Obsługa dyspozycji: mapa nawigacyjna"
description: "Przejścia między ekranami złożenia i korekty dyspozycji w aplikacji mobilnej i bankowości internetowej."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations:
  - type: groups
    target: SCR-001
  - type: groups
    target: SCR-002
  - type: groups
    target: SCR-003
---

# Obsługa dyspozycji: mapa nawigacyjna

## Warunki wstępne

Mapa obejmuje ekrany klienta w procesie obsługi dyspozycji: ścieżkę złożenia
i ścieżkę korekty, w aplikacji mobilnej i w bankowości internetowej. Klient jest
zalogowany. Lista dyspozycji nie ma osobnego dokumentu ekranu, więc na mapie
jest tylko punktem wejścia i wyjścia. Nocne rozliczenie i ponowienia działają
bez ekranów i nie należą do mapy.

## Diagram nawigacji

<!-- Wszystkie ekrany procesu: startowy, pośrednie, końcowy, ekran błędu, wejścia i wyjścia poza przepływ. Krawędzie: akcja użytkownika to strzałka z etykietą (-->|Dalej|), błąd techniczny to linia przerywana (-. błąd techniczny .->). Duży diagram dzielisz na obszary subgraph. -->

```mermaid
flowchart TD
    wz(["Wejście: klient wybiera „Nowa dyspozycja”"]) --> SCR001["SCR-001 Dane i pozycje"]
    wk(["Wejście: klient wybiera „Koryguj” na liście dyspozycji"]) --> SCR003["SCR-003 Edycja pozycji"]
    SCR001 -->|Dalej| SCR002["SCR-002 Podsumowanie"]
    SCR003 -->|Dalej| SCR002
    SCR002 -->|Wstecz, ścieżka złożenia| SCR001
    SCR002 -->|Wstecz, ścieżka korekty| SCR003
    SCR002 -->|złożenie odrzucone| blad["Komunikat o odrzuceniu na podsumowaniu"]
    blad -->|Popraw pozycje| SCR001
    SCR002 -->|korekta odrzucona| bladK["Komunikat: korekta niemożliwa"]
    bladK --> wyL(["Wyjście poza przepływ: lista dyspozycji"])
    SCR002 -->|zatwierdzenie udane| wyP(["Wyjście poza przepływ: lista dyspozycji z potwierdzeniem"])
    SCR002 -->|Dokończ później| wyS(["Wyjście poza przepływ: szkic dyspozycji"])
```

## Kluczowe elementy nawigacji

- Główne przejścia: złożenie zaczyna się na SCR-001, korekta na SCR-003. Obie ścieżki prowadzą przyciskiem „Dalej” do wspólnego ekranu końcowego SCR-002, a „Dalej” jest nieaktywny, dopóki sekcje ekranu startowego pokazują błędy walidacji. SCR-002 pamięta ścieżkę wejścia: „Wstecz” wraca do SCR-001 przy złożeniu i do SCR-003 przy korekcie.
- Przejścia końcowe i ich warunki: zatwierdzenie złożenia na SCR-002 wymaga silnego uwierzytelnienia, a potwierdzenie korekty kwot pozycji go nie wymaga; po sukcesie klient wychodzi z przepływu na listę dyspozycji z potwierdzeniem. „Dokończ później” na SCR-002 w ścieżce złożenia zamyka przepływ i zostawia szkic, a powrót do szkicu otwiera SCR-002. Odrzucona korekta kończy przepływ wyjściem na listę dyspozycji.

## Odniesienia do ekranów

| Ekran | Rola w mapie | Dokument |
|---|---|---|
| Ekran Dyspozycja: Krok 1 z 2 — Dane i pozycje | startowy | SCR-001 |
| Ekran Korekta dyspozycji: Krok 1 z 2 — Edycja pozycji | startowy | SCR-003 |
| Ekran Dyspozycja: Krok 2 z 2 — Podsumowanie | końcowy | SCR-002 |

## Scenariusze błędów

Mapa nie ma osobnego ekranu błędu; błędy są komunikatami na ekranach mapy.

| Scenariusz | Zachowanie |
|---|---|
| Odrzucenie złożenia przy zatwierdzeniu, np. przekroczony limit | SCR-002 pokazuje komunikat, a „Popraw pozycje” wraca do SCR-001 |
| Odrzucenie korekty, bo rozliczenie dyspozycji już się rozpoczęło | SCR-002 przy zapisie pokazuje komunikat, że korekta jest niemożliwa; klient wychodzi na listę dyspozycji |
| Suma kwot pozycji różna od kwoty łącznej | Komunikat przy sekcji pozycji na SCR-001 albo SCR-003; przejście do SCR-002 jest zablokowane |
