---
doc-id: NAV-010
title: "Otwarcie rachunku: mapa nawigacyjna"
description: "Przejścia między ekranami wniosku o rachunek na ścieżce klienta i ekranem ręcznej weryfikacji tożsamości na ścieżce pracownika zaplecza."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations:
  - type: groups
    target: SCR-010
  - type: groups
    target: SCR-011
  - type: groups
    target: SCR-012
---

# Otwarcie rachunku: mapa nawigacyjna

## Warunki wstępne

Mapa obejmuje dwie niezależne ścieżki procesu otwarcia rachunku: ścieżkę
klienta, który w bankowości internetowej albo aplikacji mobilnej wypełnia
dwukrokowy wniosek, oraz ścieżkę pracownika zaplecza, który rozstrzyga
zadanie ręcznej weryfikacji tożsamości. Mapa jest kompletna dla tych ścieżek.
Nie obejmuje strony oferty, listy zadań w aplikacji zaplecza ani powiadomień
e-mail i SMS. Proces nie ma osobnych ekranów błędu: błędy są komunikatami na
ekranach mapy.

## Diagram nawigacji

<!-- Wszystkie ekrany procesu: startowy, pośrednie, końcowy, ekran błędu, wejścia i wyjścia poza przepływ. Krawędzie: akcja użytkownika to strzałka z etykietą (-->|Dalej|), błąd techniczny to linia przerywana (-. błąd techniczny .->). Duży diagram dzielisz na obszary subgraph. -->

```mermaid
flowchart TD
    subgraph K["Ścieżka klienta"]
        OFERTA(["Wejście: przycisk Otwórz rachunek na stronie oferty"]) --> SCR010["SCR-010 Dane i produkt"]
        SCR010 -->|Wstecz i potwierdzenie przerwania wniosku| PRZERWANIE(["Wyjście poza przepływ: strona oferty rachunków"])
        SCR010 -->|Dalej| SCR011["SCR-011 Zgody i wysłanie"]
        SCR011 -->|Wstecz| SCR010
        SCR011 -. błąd techniczny: wygasła sesja wniosku .-> SCR010
        SCR011 -->|wniosek odrzucony: rachunek osobisty dla osoby niepełnoletniej| SCR010
        SCR011 -->|potwierdzenie otwarcia albo informacja o weryfikacji| WYJSCIE_K(["Wyjście poza przepływ: strona główna banku"])
    end
    subgraph P["Ścieżka pracownika zaplecza"]
        ZADANIA(["Wejście: lista zadań w aplikacji zaplecza"]) --> SCR012["SCR-012 Weryfikacja tożsamości"]
        SCR012 -->|Zatwierdź decyzję, Odłóż zadanie albo Wstecz| WYJSCIE_P(["Wyjście poza przepływ: lista zadań"])
    end
```

## Kluczowe elementy nawigacji

- Główne przejścia: przejście z kroku 1 do kroku 2 wymaga poprawnych danych osobowych i wybranego produktu, a dla lokaty także kwoty i okresu. Powrót z kroku 2 do kroku 1 zachowuje wpisane dane i zaznaczone zgody. Ścieżka pracownika nie łączy się z ekranami klienta: ekran weryfikacji otwiera zadanie z listy zadań.
- Przejścia końcowe i ich warunki: przycisk wstecz na kroku 1 pyta o przerwanie wniosku, a po potwierdzeniu klient wraca na stronę oferty rachunków bez zapisu danych. Wysłanie wniosku jest możliwe tylko po zaznaczeniu zgody na regulamin; po wysłaniu klient zostaje na kroku 2, który pokazuje potwierdzenie otwarcia z numerem IBAN albo informację o ręcznej weryfikacji, a wysłanego wniosku nie można już edytować. Na ścieżce pracownika zatwierdzenie decyzji kończy zadanie, odłożenie zwraca je do puli, a przycisk wstecz zostawia je przypisane do pracownika; w każdym przypadku pracownik wraca do listy zadań.

## Odniesienia do ekranów

| Ekran | Rola w mapie | Dokument |
|---|---|---|
| Dane i produkt | startowy | SCR-010 |
| Zgody i wysłanie | końcowy | SCR-011 |
| Weryfikacja tożsamości | startowy i końcowy ścieżki pracownika | SCR-012 |

## Scenariusze błędów

| Scenariusz | Zachowanie |
|---|---|
| Rachunek osobisty dla osoby niepełnoletniej | Po wysłaniu wniosku klient wraca z kroku 2 do kroku 1 z komunikatem przy dacie urodzenia |
| Brak zgody na regulamin | Klient zostaje na kroku 2, a przycisk wysłania jest nieaktywny |
| Wygasła sesja wniosku | Bieżący ekran pokazuje komunikat, a klient zaczyna wniosek od kroku 1 |
| Rejestr PESEL niedostępny | Pracownik zostaje na ekranie weryfikacji z komunikatem i może odłożyć zadanie, które wraca do puli, a pracownik do listy zadań |
