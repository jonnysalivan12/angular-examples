---
doc-id: UC-005
title: "Podgląd dyspozycji"
description: "Klient przegląda w kanale cyfrowym złożone dyspozycje, ich pozycje i status."
status: draft                                  # draft | active
owner: "Anna Nowak"
relations:
  - type: realizes
    target: BFS-001.REQ-03
  - type: realizes
    target: CAP-001
  - type: consumes
    target: API-005
  - type: involves
    target: ACTOR-001.ROLE-01
---

# Podgląd dyspozycji

| Pole | Wartość |
|---|---|
| Aktor główny | ACTOR-001.ROLE-01 |
| Kanały | Aplikacja mobilna, bankowość internetowa |
| BFS | BFS-001 |
| Powiązane REQ | BFS-001.REQ-03 |
| Powiązane RB | — |
| Zdolność | CAP-001 |
| Makiety | Figma, plik „Dyspozycja”, ramka „Lista dyspozycji” |

## Powiązanie z BFS

| Typ | ID z BFS | Jak UC to realizuje |
|---|---|---|
| REQ | BFS-001.REQ-03 | Klient otwiera listę swoich dyspozycji, zawęża ją do wybranego statusu i przegląda pozycje wybranej dyspozycji. |

## Cel

Klient chce sprawdzić, jakie dyspozycje złożył, co zawierają i czy bank już je
rozliczył.

## Aktorzy

- ACTOR-001.ROLE-01: Klient; przegląda listę swoich dyspozycji i ich pozycje.

## Kiedy można to zrobić

- [ ] Klient jest zalogowany w aplikacji mobilnej albo w bankowości internetowej.

## Kroki

| Nr | Krok | Ekran | Wywołanie |
|---|---|---|---|
| 1 | Klient otwiera listę dyspozycji i opcjonalnie wybiera status, na przykład „Rozliczona”. | — | — |
| 2 | System pobiera dyspozycje klienta w wybranym statusie, z pozycjami i etykietą statusu. | — | API-005 |
| 3 | Klient rozwija dyspozycję i przegląda jej pozycje: rachunek odbiorcy, kwotę i tytuł. | — | — |

## Reguły biznesowe

Scenariusz nie realizuje reguł biznesowych procesu, bo tylko odczytuje dane dyspozycji.

## Ograniczenia NFR

Brak własnych progów; obowiązują progi zdolności CAP-001.

## Kryteria akceptacji

- Kiedy klient otworzy listę dyspozycji, wtedy widzi tylko własne dyspozycje, każdą z etykietą statusu. (BFS-001.REQ-03)
- Kiedy klient wybierze status, wtedy lista zawiera tylko dyspozycje w tym statusie. (BFS-001.REQ-03)
- Kiedy klient rozwinie dyspozycję, wtedy widzi wszystkie jej pozycje z rachunkiem odbiorcy, kwotą i tytułem. (BFS-001.REQ-03)
