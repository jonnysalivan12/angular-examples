---
doc-id: BFS-002
title: "Reklamacje dyspozycji"
description: "Wymagania i reguły procesu reklamacji rozliczonej dyspozycji, od zgłoszenia do zamknięcia po wypłacie rekompensaty albo odrzucenia."
status: draft                                  # draft | active
owner: "Piotr Zieliński"
relations:
  - type: contains
    target: REQ-01
  - type: contains
    target: REQ-02
  - type: contains
    target: REQ-03
  - type: contains
    target: RB-01
  - type: contains
    target: RB-02
  - type: constrained_by
    target: NFR-001.NFRT-OBS-01
---

# Reklamacje dyspozycji

| Pole | Wartość |
|---|---|
| Proces | Reklamacje dyspozycji |
| Właściciel biznesowy | Piotr Zieliński |

## Kontekst biznesowy

Klient, który zauważy błąd w rozliczonej dyspozycji przelewu wielopozycyjnego,
na przykład podwójne obciążenie rachunku albo pozycję zaksięgowaną z inną
kwotą, zgłasza reklamację w bankowości internetowej albo u doradcy w oddziale.
Reklamacja startuje od własnego zgłoszenia klienta, a nie od złożenia
dyspozycji, dlatego jest osobnym procesem obok procesu „Obsługa dyspozycji”.
Proces czyta dane rozliczonych dyspozycji; zmienia je tylko korekta rozliczenia
po uznanej reklamacji.

## Cel

Rozpatrzyć każdą reklamację rozliczonej dyspozycji w 14 dni, a zasadną zakończyć
wypłatą rekompensaty i korektą rozliczenia. Każda decyzja ma ślad audytowy, więc
bank może ją odtworzyć na potrzeby kontroli wewnętrznej i nadzoru.

## Zakres

### W zakresie

Proces zaczyna się zgłoszeniem reklamacji, a kończy na jeden z dwóch sposobów:
reklamacja uznana zostaje zamknięta po wypłacie rekompensaty, a reklamacja
odrzucona kończy obsługę w chwili zapisu decyzji. Obejmuje:

- zgłoszenie reklamacji przez klienta w bankowości internetowej i przez doradcę w oddziale w imieniu klienta zidentyfikowanego na podstawie dowodu osobistego,
- rozpatrzenie reklamacji przez pracownika zaplecza i decyzję: uznana albo odrzucona,
- eskalację do kierownika reklamacji nierozpatrzonej w 14 dni,
- wypłatę rekompensaty i korektę rozliczenia uznanej reklamacji.

### Poza zakresem

- korekta pozycji dyspozycji przed rozliczeniem (należy do procesu „Obsługa dyspozycji”),
- reklamacje kart, kredytów i innych produktów niż dyspozycje przelewu,
- odwołanie klienta od decyzji reklamacyjnej.

## Wymagania funkcjonalne

| ID | Wymaganie | Priorytet (MoSCoW) |
|---|---|---|
| REQ-01 | Proces musi przyjąć zgłoszenie reklamacji rozliczonej dyspozycji od klienta w bankowości internetowej albo od doradcy w oddziale w imieniu klienta. | Must |
| REQ-02 | Proces musi doprowadzić do rozpatrzenia reklamacji przez pracownika zaplecza i zapisu decyzji w ciągu 14 dni od zgłoszenia. | Must |
| REQ-03 | Proces musi zakończyć uznaną reklamację wypłatą rekompensaty na rachunek klienta i korektą rozliczenia dyspozycji. | Must |

## Reguły biznesowe

| ID | Reguła | Źródło / uzasadnienie |
|---|---|---|
| RB-01 | Reklamacja dotyczy dyspozycji rozliczonej nie dawniej niż 30 dni przed dniem zgłoszenia. | Regulamin rachunku i dyspozycji, rozdział o reklamacjach |
| RB-02 | Kwota rekompensaty nie przekracza kwoty reklamowanej dyspozycji. | Polityka reklamacji: rekompensata pokrywa szkodę z jednej dyspozycji |

## Wymagania niefunkcjonalne

- NFR-001.NFRT-OBS-01: każda decyzja w reklamacji (uznanie, odrzucenie, eskalacja) zostawia ślad audytowy przechowywany 5 lat.

## Słownik pojęć

| Pojęcie | Definicja |
|---|---|
| Reklamacja | zgłoszenie klienta, że rozliczona dyspozycja została wykonana niezgodnie z jego zleceniem, z powodem, opisem i opcjonalnym załącznikiem. |
| Rekompensata | kwota wypłacana klientowi po uznaniu reklamacji, nie większa niż kwota reklamowanej dyspozycji. |
| Eskalacja | przekazanie kierownikowi zespołu reklamacji sprawy, której pracownik zaplecza nie rozpatrzył w 14 dni. |

## Założenia i otwarte pytania

### Założenia

> Założenie: termin 14 dni liczony jest w dniach kalendarzowych od dnia zarejestrowania reklamacji.

### Otwarte pytania

| # | Pytanie | Właściciel | Termin | Status |
|---|---|---|---|---|
| 1 | Czy klient może zgłosić drugą reklamację tej samej dyspozycji po odrzuceniu pierwszej? | Piotr Zieliński | 2026-10-15 | otwarte |
