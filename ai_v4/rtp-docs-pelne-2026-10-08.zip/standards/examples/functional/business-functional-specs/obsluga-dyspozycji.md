---
doc-id: BFS-001
title: "Obsługa dyspozycji"
description: "Wymagania i reguły procesu od złożenia dyspozycji przelewu wielopozycyjnego do jej rozliczenia w księdze głównej."
status: active                                 # draft | active
owner: "Anna Nowak"
relations:
  - type: contains
    target: REQ-01
  - type: contains
    target: REQ-02
  - type: contains
    target: REQ-03
  - type: contains
    target: REQ-04
  - type: contains
    target: REQ-05
  - type: contains
    target: RB-01
  - type: contains
    target: RB-02
  - type: constrained_by
    target: NFR-001.NFRT-PERF-01
  - type: constrained_by
    target: NFR-001.NFRT-SEC-01
---

# Obsługa dyspozycji

| Pole | Wartość |
|---|---|
| Proces | Obsługa dyspozycji |
| Właściciel biznesowy | Anna Nowak |

## Kontekst biznesowy

Klienci detaliczni co miesiąc opłacają kilka stałych należności: czynsz, media,
raty. W aplikacji mobilnej i w bankowości internetowej każdy przelew wymaga dziś
osobnego formularza i osobnego silnego uwierzytelnienia. Bank wprowadza
dyspozycję przelewu wielopozycyjnego: jedno zlecenie z kilkoma przelewami
z jednego rachunku, rozliczane w nocnym przetwarzaniu księgi głównej.

Proces jest nowy. Tabela wymagań to lista zaległości do rozbicia na przypadki
użycia.

## Cel

Klient zleca do 50 przelewów jedną dyspozycją i jednym silnym uwierzytelnieniem,
a bank rozlicza przyjęte dyspozycje w księdze głównej bez ręcznej obsługi.
Kwotę ponad limit klienta bank wykrywa przy złożeniu dyspozycji, a nie dopiero
przy księgowaniu.

## Zakres

### W zakresie

- Start: klient składa dyspozycję przelewu wielopozycyjnego w aplikacji mobilnej albo w bankowości internetowej.
- Korekta kwot pozycji złożonej dyspozycji przed nocnym rozliczeniem, bez zmiany kwoty łącznej.
- Podgląd złożonych dyspozycji, ich pozycji i statusu.
- Nocne rozliczenie zaakceptowanych dyspozycji i ponowienie rozliczeń, które się nie powiodły.
- Koniec: dyspozycja rozliczona w księdze głównej. Warianty końca: dyspozycja odrzucona przy złożeniu albo nierozliczona po ponowieniach.

### Poza zakresem

- Reklamacje rozliczonych dyspozycji: osobny proces „Reklamacje dyspozycji”, bo startuje od własnego zgłoszenia.
- Otwieranie rachunków i zmiana limitów klienta.
- Przelewy natychmiastowe, przelewy zagraniczne i zlecenia stałe.

## Wymagania funkcjonalne

| ID | Wymaganie | Priorytet (MoSCoW) |
|---|---|---|
| REQ-01 | Proces musi przyjąć od klienta dyspozycję przelewu wielopozycyjnego z 1–50 pozycjami. | Must |
| REQ-02 | Proces musi pozwolić klientowi skorygować pozycje złożonej dyspozycji przed jej rozliczeniem. | Must |
| REQ-03 | Proces powinien pokazywać klientowi złożone dyspozycje i ich status. | Should |
| REQ-04 | Proces musi rozliczyć zaakceptowane dyspozycje w nocnym przebiegu. | Must |
| REQ-05 | Proces powinien ponowić rozliczenie dyspozycji, których rozliczenie się nie powiodło. | Should |

## Reguły biznesowe

| ID | Reguła | Źródło / uzasadnienie |
|---|---|---|
| RB-01 | Kwota dyspozycji nie przekracza dostępnego limitu klienta. | Polityka limitów transakcyjnych klientów detalicznych |
| RB-02 | Korekta dyspozycji jest możliwa tylko w statusie ZAAKCEPTOWANA, przed nocnym rozliczeniem. | Regulamin bankowości elektronicznej: dyspozycji przekazanej do rozliczenia nie można zmienić |

## Wymagania niefunkcjonalne

- NFR-001.NFRT-PERF-01: czas odpowiedzi systemu przy składaniu, korekcie i podglądzie dyspozycji w kanałach cyfrowych.
- NFR-001.NFRT-SEC-01: silne uwierzytelnienie klienta przy złożeniu dyspozycji; korekta kwot pozycji bez zmiany kwoty łącznej go nie wymaga.

## Słownik pojęć

| Pojęcie | Definicja |
|---|---|
| Dyspozycja | zlecenie klienta obejmujące od 1 do 50 przelewów z jednego rachunku, zatwierdzane jednym silnym uwierzytelnieniem. |
| Pozycja | pojedynczy przelew w dyspozycji: rachunek odbiorcy, kwota i tytuł. |
| Rozliczenie | zaksięgowanie pozycji dyspozycji w księdze głównej w nocnym przebiegu albo w ponowieniu. |

## Założenia i otwarte pytania

### Założenia

> Założenie: nocne rozliczenie startuje o 01:00 i obejmuje dyspozycje przyjęte do końca poprzedniego dnia, więc klient może korygować taką dyspozycję do 01:00.

### Otwarte pytania

| # | Pytanie | Właściciel | Termin | Status |
|---|---|---|---|---|
| 1 | Czy klient dostaje powiadomienie, gdy dyspozycja pozostaje nierozliczona po ponowieniach? | Anna Nowak | 2026-10-30 | Otwarte |
