---
doc-id: BFS-003
title: "Otwarcie rachunku"
description: "Wymagania i reguły procesu otwarcia rachunku osobistego albo lokaty na podstawie wniosku online, odtworzone z działającego systemu wniosków."
status: draft                                  # draft | active
owner: "Katarzyna Wójcik"
relations:
  - type: contains
    target: REQ-01
  - type: contains
    target: REQ-02
  - type: contains
    target: REQ-03
  - type: contains
    target: REQ-04
  - type: contains
    target: RB-01
  - type: contains
    target: RB-02
  - type: constrained_by
    target: NFR-002.NFRT-SEC-01
---

# Otwarcie rachunku

| Pole | Wartość |
|---|---|
| Proces | Otwarcie rachunku |
| Właściciel biznesowy | Katarzyna Wójcik |

## Kontekst biznesowy

Bank od kilku lat otwiera rachunki osobiste i lokaty terminowe na podstawie
wniosku składanego online, ale proces nie miał dokumentacji wymagań. Dokument
opisuje proces istniejący (dokumentacja wsteczna): wymagania i reguły biznesowe
wydobyto z kodu systemu wniosków, a następnie potwierdzono z właścicielem
biznesowym. Reguła pełnoletności pochodzi z walidatora wniosku, a reguła zgody
na regulamin z formularza wniosku.

Proces zaczyna się, gdy klient wysyła wniosek online. Kończy się, gdy rachunek
jest aktywny i klient może z niego korzystać. Wariant końca: wniosek zostaje
odrzucony w weryfikacji tożsamości.

## Cel

Klient otwiera rachunek osobisty albo lokatę bez wizyty w oddziale, a bank
przed otwarciem potwierdza jego tożsamość, zgodnie z obowiązkiem identyfikacji
klienta wynikającym z przepisów o przeciwdziałaniu praniu pieniędzy.

## Zakres

### W zakresie

- Wniosek online o rachunek osobisty albo lokatę terminową: dane osobowe, wybór produktu, zgody.
- Automatyczna weryfikacja tożsamości w rejestrze PESEL i na liście sankcyjnej.
- Ręczna weryfikacja tożsamości przez pracownika zaplecza, gdy weryfikacja automatyczna nie daje jednoznacznego wyniku.
- Otwarcie rachunku z nadaniem numeru IBAN i aktywacja rachunku w systemie centralnym.
- Odrzucenie wniosku z powiadomieniem klienta, gdy weryfikacja tożsamości kończy się wynikiem negatywnym.

### Poza zakresem

- Wniosek składany w oddziale i przez infolinię.
- Rachunki firmowe, wspólne i rachunki dla osób niepełnoletnich prowadzone przez opiekuna.
- Wydanie karty płatniczej i dostęp do bankowości internetowej po otwarciu rachunku.
- Zerwanie lokaty i zamknięcie rachunku.

## Wymagania funkcjonalne

| ID | Wymaganie | Priorytet (MoSCoW) |
|---|---|---|
| REQ-01 | Proces musi przyjąć online wniosek klienta o rachunek osobisty albo lokatę terminową z danymi osobowymi, wybranym produktem i zgodami. | Must |
| REQ-02 | Proces musi automatycznie zweryfikować tożsamość wnioskodawcy w rejestrze PESEL i na liście sankcyjnej. | Must |
| REQ-03 | Proces musi przekazać wniosek do ręcznej weryfikacji tożsamości przez pracownika zaplecza, gdy weryfikacja automatyczna nie daje jednoznacznego wyniku. | Must |
| REQ-04 | Proces musi aktywować rachunek w systemie centralnym po jego otwarciu. | Must |

## Reguły biznesowe

| ID | Reguła | Źródło / uzasadnienie |
|---|---|---|
| RB-01 | Rachunek osobisty otwiera się tylko dla osoby pełnoletniej; wniosek osoby poniżej 18 lat o rachunek osobisty jest odrzucany. | Kod walidatora wniosku w systemie wniosków |
| RB-02 | Bez zgody na regulamin produktu wniosek nie przechodzi dalej; zgoda marketingowa jest dobrowolna. | Kod formularza wniosku w systemie wniosków |

## Wymagania niefunkcjonalne

- NFR-002.NFRT-SEC-01: numer PESEL i dane dokumentu tożsamości wnioskodawcy są szyfrowane w bazie wniosków i maskowane w logach weryfikacji.

## Słownik pojęć

| Pojęcie | Definicja |
|---|---|
| Rachunek | rachunek osobisty klienta w wybranym produkcie i w walucie tego produktu, identyfikowany numerem IBAN nadanym przy otwarciu. |
| Lokata | lokata terminowa, czyli rodzaj rachunku z kwotą i okresem od 1 do 24 miesięcy z wniosku, oprocentowana stałą stopą z oferty w dniu otwarcia do dnia zapadalności. |
| Weryfikacja tożsamości | potwierdzenie, że wnioskodawca jest osobą, za którą się podaje, i nie figuruje na liście sankcyjnej; automatyczne albo ręczne. |

## Założenia i otwarte pytania

### Założenia

> Założenie: reguły RB-01 i RB-02 opisują zachowanie produkcyjnej wersji systemu wniosków; zmiana kodu walidatora albo formularza wymaga aktualizacji tego dokumentu.

### Otwarte pytania

| # | Pytanie | Właściciel | Termin | Status |
|---|---|---|---|---|
| 1 | Walidator wniosku sprawdza pełnoletność na dzień złożenia wniosku, a reguła domeny rachunków na dzień otwarcia. Która data obowiązuje, gdy klient kończy 18 lat w trakcie ręcznej weryfikacji? | Katarzyna Wójcik | 2026-10-15 | Otwarte |
| 2 | Jak długo wniosek może czekać na ręczną weryfikację, zanim bank go anuluje? | Katarzyna Wójcik | 2026-10-30 | Otwarte |
