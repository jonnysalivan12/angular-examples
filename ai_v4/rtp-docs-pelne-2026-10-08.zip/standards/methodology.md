# Metodyka dokumentacji

Dokumentacja projektowa jest grafem, czyli siecią powiązanych elementów.
Element tej sieci to węzeł. Węzłem jest dokument albo pojedynczy wiersz
dokumentu, który ma własny identyfikator lokalny. Powiązanie między dwoma
węzłami to krawędź. Krawędzią jest wpis w polu `relations` dokumentu.

Ten plik opisuje zasady. Szczegóły są w plikach z tabeli.

| Plik | Zawartość |
|---|---|
| `config/relation-matrix.yaml` | Matryca relacji: lista rodzajów relacji, lista dozwolonych trójek (źródło, relacja, cel), reguła o wzmiankach identyfikatorów w treści i reguły walidatora dla poszczególnych trójek. |
| `config/query-patterns.yaml` | Wzorce dwóch zapytań do grafu: `change_scope` (zasięg zmiany) i `implementation` (co przeczytać, żeby zbudować element). |
| `config/folders.yaml` | W którym folderze dokumentacji leży dokument danego typu i czy wolno mu leżeć w podfolderze (sekcja 11). |
| `templates/` | Dla każdego typu dokumentu czysty szablon i opis, jak z niego korzystać. Spis wszystkich szablonów jest w pliku `templates/_00-meta.md`. |

## Pojęcia używane w tym pliku

- **Front matter** to blok YAML na początku pliku Markdown. Zawiera między innymi `doc-id`, `title`, `status` i `relations`.
- **doc-id** to identyfikator dokumentu, na przykład `UC-001`. Prefiks przed myślnikiem (tutaj `UC`) określa typ dokumentu.
- **Identyfikator lokalny** to identyfikator wiersza wewnątrz dokumentu, na przykład wymagania `REQ-01` w dokumencie `BFS-001`.
- **Trójka** to zapis jednego powiązania: typ dokumentu źródłowego, rodzaj relacji i typ celu. Na przykład trójka „UC realizes REQ” oznacza, że scenariusz użycia może wskazać wymaganie, które realizuje.
- **Źródło** to dokument, który ma wpis relacji. **Cel** to dokument albo wiersz, który ten wpis wskazuje.
- **Walidator** to program, który sprawdza strukturę grafu. Listę sprawdzeń podaje sekcja 8.
- **Zapytanie** idzie po relacjach od wybranego węzła do kolejnych węzłów i zbiera powiązane dokumenty. Wzorce zapytań są w pliku `config/query-patterns.yaml`.

## 1. Pole `relations`

Dokument zapisuje swoje relacje w polu `relations` w front matter. Pole to
lista wpisów. Każdy wpis ma dwa klucze: `type` (rodzaj relacji) i `target`
(cel).

Rodzaju relacji się nie wybiera. Wynika on z pary typów: typu dokumentu
źródłowego i typu celu. Dla każdej takiej pary plik `relation-matrix.yaml`
podaje dokładnie jeden rodzaj relacji.

Tak wygląda fragment front matter scenariusza `UC-001`:

```yaml
doc-id: UC-001
title: Złożenie dyspozycji
status: draft
relations:            # fragment
  - type: realizes
    target: BFS-001.REQ-01
  - type: realizes
    target: CAP-001
  - type: involves
    target: ACTOR-001.ROLE-01
  - type: consumes
    target: API-001
  - type: contains
    target: A1
```

Wpis zapisuje tylko samo powiązanie. Opis powiązania i liczebność, czyli ile
elementów jest po każdej stronie, zostają w treści dokumentu. Przykład: encja
`ENT-Disposition` ma wpis `contains ENT-DispositionItem`. To, że jedna
dyspozycja ma wiele pozycji, opisuje treść encji, a nie wpis.

## 2. Kto zapisuje relację

Relację zapisuje tylko dokument, który jest źródłem trójki. Cel nie dostaje
wpisu w drugą stronę, bo relację odwrotną wylicza graf. Przykład: `UC-001` ma
wpis `realizes BFS-001.REQ-01`, a `BFS-001` nie ma żadnego wpisu, który
wskazuje `UC-001`.

Dlatego nowy scenariusz w procesie `BFS-001` zapisuje relacje tylko we własnym
pliku. Dokumenty `BFS-001`, `CAP-001` i `ACTOR-001` nie dostają nowych wpisów.

Jeśli dokument wspomina w treści identyfikator innego dokumentu albo wiersza,
to sam musi zapisać tę relację. Pełny opis tej reguły jest w nagłówku pliku
`relation-matrix.yaml`, w części „Wzmianki o identyfikatorach w treści”.

## 3. Identyfikatory

`doc-id` musi być unikalny w całej dokumentacji, bez względu na typ dokumentu.
Tę regułę opisuje też nagłówek pliku `relation-matrix.yaml`.

Identyfikator lokalny oznacza wiersz dokumentu. Wiersz nie ma własnego pliku
ani front matter, więc sam nie może zapisać relacji. Dokument, w którym leży
wiersz, zapisuje go samym identyfikatorem lokalnym. Inne dokumenty wskazują
wiersz pełnym identyfikatorem, czyli doc-id dokumentu, kropką i identyfikatorem
lokalnym:

```text
BFS-001 ma wpis contains REQ-01
UC-001  ma wpis realizes BFS-001.REQ-01
```

Tabela pokazuje wszystkie rodzaje wierszy. Kolumna „Zawiera go” podaje typ
dokumentu, w którym wiersz leży.

| Prefiks | Wiersz | Zawiera go | Pełne ID |
|---|---|---|---|
| REQ | wymaganie funkcjonalne | BFS | `BFS-001.REQ-01` |
| RB | reguła biznesowa | BFS | `BFS-001.RB-01` |
| DOM | pojęcie domenowe | DDM | `DDM-001.DOM-Dyspozycja` |
| RD | reguła i niezmiennik domenowy | DDM | `DDM-001.RD-001` |
| RW | reguła walidacyjna | ENT | `ENT-Disposition.RW-001` |
| NFRT | wiersz macierzy wymagań jakościowych | NFR | `NFR-001.NFRT-PERF-01` |
| ROLE | rola aktora | ACTOR | `ACTOR-001.ROLE-01` |
| AC | kryterium akceptacji | SPEC-WF | `SPEC-WF-001.AC-01` |
| STEP | zadanie procesu | BPMS | `BPMS-001.STEP-01` |
| A | wariant przebiegu | UC, TUC | `UC-001.A1` |
| E | sytuacja błędna | UC, TUC | `UC-001.E1` |

Numerów wierszy REQ, RB, RD, NFRT, ROLE i STEP nie używa się ponownie, bo inne
dokumenty mają wpisy, które wskazują te wiersze. Nowy wiersz dostaje kolejny
wolny numer, także wtedy, gdy wcześniejszy wiersz usunięto. Przykład: jeśli
ostatnim wymaganiem w `BFS-001` było `REQ-05`, następne wymaganie to `REQ-06`.
Usunięty wiersz znika z dokumentu, a jego historię przechowuje repozytorium.

## 4. Spójność grafu

Każdy dokument i każdy wiersz musi mieć powiązanie z resztą grafu. Kierunek
powiązania nie ma znaczenia.

Dokument bez własnych wpisów jest poprawny, jeśli wskazuje go inny dokument.
Przykład: aktywność `ACT-002` „Zapis dyspozycji” nie ma wpisów, ale przepływ
`FLOW-001` ma wpis `contains ACT-002`.

Walidator zgłasza błąd w dwóch przypadkach:

1. Węzeł nie ma żadnego powiązania.
2. Grupa dokumentów jest powiązana tylko ze sobą i nie ma powiązania z resztą grafu. Taką grupę nazywamy wyspą.

Wyjątkiem jest zapis decyzji architektonicznej ADR. Nie ma on powiązań
z innymi typami, więc walidator nie sprawdza jego połączenia z grafem.

## 5. Zakres BFS

BFS (specyfikacja biznesowo-funkcjonalna) opisuje jeden proces. Proces ma
jeden początek i jeden koniec. Koniec może mieć kilka wariantów.

Przykład: `BFS-001` „Obsługa dyspozycji” obejmuje złożenie dyspozycji
(`UC-001`), jej korektę (`UC-002`), nocne rozliczenie (`TUC-001`) i ponowienie
nieudanych dyspozycji (`TUC-002`). Reklamacja zaczyna się od osobnego
zgłoszenia (`UC-003`), więc ma własny dokument `BFS-002` „Reklamacje
dyspozycji”.

Oba procesy korzystają z jednego domenowego modelu danych `DDM-001` „Domena
dyspozycji”. Encja `ENT-Disposition` realizuje pojęcie `DOM-Dyspozycja`,
a encja `ENT-Complaint` realizuje pojęcie `DOM-Reklamacja`.

BFS nie dzieli się według iteracji, ścieżek ani komponentów:

- Iterację, na przykład MVP (pierwszą, najmniejszą działającą wersję produktu), opisuje zakres BFS.
- Ścieżki przebiegu opisują warianty A i sytuacje błędne E w scenariuszu UC lub TUC.
- Komponenty nie dzielą BFS. Zdolność CAP opisuje konkretną, mierzalną umiejętność systemu, a nie komponent.

## 6. Zmiana dokumentu

Dokument zmieniaj w tej kolejności:

1. Uruchom zapytanie `change_scope` dla zmienianego węzła. Wzorce tego zapytania są w pliku `query-patterns.yaml`. Wynik zapytania wyznacza zakres zgłoszenia.
2. Popraw treść w plikach, które zwróciło zapytanie.
3. Usuń relacje i wiersze, które mają zniknąć.
4. Uruchom walidator.

Relacje usuwasz na końcu, bo zapytanie idzie po relacjach. Przykład:
zapytanie `change_scope` dla wiersza `BFS-001.REQ-01` zaczyna od `UC-001`, bo
tylko ten scenariusz ma wpis `realizes BFS-001.REQ-01`. Jeśli usuniesz ten
wpis wcześniej, zapytanie nie dojdzie do `UC-001`. Nie dojdzie też dalej,
do API, ekranów i zdolności tego scenariusza.

## 7. Dokumenty wskazujące

Dokument nie wymienia w swojej treści dokumentów, które go wskazują. Taką listę
wylicza graf z wpisów tych dokumentów. Przykład: listę dokumentów zdolności
`CAP-002` graf wylicza z wpisów `realizes CAP-002` w UC-006, API-003, API-009
i INT-003.

Zasada obowiązuje także wtedy, gdy wskazujący dokument zawiera dany dokument
albo go wywołuje. Przykłady:

- Sekcja ekranu SCRSEC-001 nie wymienia ekranu SCR-001.
- Krok SPEC-WF-001 nie wymienia procesu BPMS-001.
- Krok SPEC-WF-005 nie wymienia API-015 i API-008, które go przypisują i kończą, ani ekranu SCR-005, z którego człowiek wywołuje te API.
- Przepływ FLOW-001 nie wymienia API-001, które z niego korzysta.
- Aktywność ACT-001 nie wymienia przepływów FLOW-001 i FLOW-002, które ją zawierają.
- Zdarzenie QUE-001 nie wymienia scenariusza UC-001, który publikuje to zdarzenie.

Tabela pokazuje listy, których nie pisze się ręcznie, i wpisy, z których graf
je wylicza.

| Lista | Źródło w grafie | Przykład z `examples/` |
|---|---|---|
| udział ról w scenariuszach i procesach | wpisy `involves`, które wskazują rolę | `ACTOR-001.ROLE-02`: UC-004, UC-011, BPMS-002, BPMS-010 |
| zakres zdolności | wpisy `realizes`, które wskazują CAP | `CAP-002`: UC-006, API-003, API-009, INT-003 |
| lista „wskazywany przez” | wszystkie wpisy, które wskazują dokument albo jego wiersz | `NFR-001.NFRT-PERF-01`: BFS-001, CAP-010, API-001, API-002, API-005, API-011 |

## 8. Walidator

Walidator uruchamia się przy każdym scaleniu zmian w repozytorium. Ma dwa
tryby. Na początku działa w trybie ostrzegawczym: zgłasza problemy, ale nie
blokuje scalenia. Gdy dokumentacja się ustabilizuje, przechodzi w tryb
blokujący: nie pozwala scalić zmian z błędami.

Walidator sprawdza, czy:

1. Rodzaj relacji jest na liście `relation_types`.
2. Trójka (typ źródła, relacja, typ celu) jest w matrycy relacji.
3. Cel istnieje. Jeśli nie istnieje, walidator zgłasza błąd „cel nie istnieje”. Wiersz istnieje wtedy, gdy dokument o doc-id z pełnego identyfikatora ma wpis `contains` dla tego wiersza. Przykład: `BFS-001.REQ-01` istnieje, bo `BFS-001` ma wpis `contains REQ-01`.
4. Każda wzmianka o identyfikatorze w treści ma relację. Regułę opisuje nagłówek pliku `relation-matrix.yaml`.
5. `doc-id` jest unikalny.
6. Do każdego węzła prowadzi powiązanie z resztą grafu, zgodnie z sekcją 4. Walidator pomija w tym sprawdzeniu zapis decyzji ADR.
7. Numery wierszy REQ, RB, RD, NFRT, ROLE i STEP nie są użyte ponownie.

Reguły dla pojedynczych trójek są w komentarzach w pliku
`relation-matrix.yaml`.

## 9. Co ocenia analityk

Walidator sprawdza strukturę grafu, ale nie sprawdza, czy treść ma sens. Tę
ocenę wykonuje analityk. Analityk odpowiada na pytania:

- Gdzie kończy się proces? Czy to jeden BFS, czy kilka?
- Czy treść wymagań REQ, reguł biznesowych RB i reguł domenowych RD jest poprawna? Czy definicje pojęć DOM są poprawne?
- Czy odpowiedzialność jest dobrze podzielona między zdolności CAP?
- Czy kryteria akceptacji AC są poprawne?
- Czy zmiana wiersza to edycja istniejącego wiersza, czy nowy wiersz z nowym numerem?
- Czy scenariusz opisuje to, co system rzeczywiście robi?
- Czy dokument wspomina każdy identyfikator, od którego zależy? Rodzaj relacji wynika z pary typów, ale tylko analityk wie, że dane API korzysta z danej encji.

## 10. Typy dokumentów

Typ dokumentu wynika z prefiksu `doc-id`. Szablon typu leży w folderze, który
podaje kolumna „Typ” spisu `templates/_00-meta.md`, na przykład
`templates/functional/use-cases/use-case/`. W tym folderze są dwa pliki:
`template.md` (szablon) i `guide.md` (opis, jak z szablonu korzystać). Kolumna
„Szablon” w tabelach poniżej podaje nazwę typu, czyli ostatni segment tej
ścieżki.

### Wymagania

Te dokumenty opisują, co ma działać i jakie progi jakości system musi spełnić.

| Prefiks | Szablon | Dokument |
|---|---|---|
| BFS | business-functional-spec | wymagania i reguły jednego procesu |
| NFR | non-functional-requirements | wymagania jakościowe |

### Odpowiedzialność

Te dokumenty opisują, kto za co odpowiada: role aktorów i zdolności systemu.
Zdolność to konkretna, mierzalna umiejętność systemu do wykonania określonego
zadania albo osiągnięcia celu.

| Prefiks | Szablon | Dokument |
|---|---|---|
| ACTOR | actors | wspólna baza aktorów |
| CAP | capability | zdolność systemu |

### Scenariusze

Te dokumenty opisują cel aktora i kroki, które prowadzą do tego celu.

| Prefiks | Szablon | Dokument |
|---|---|---|
| UC | use-case | scenariusz działania użytkownika |
| TUC | technical-use-case | scenariusz uruchamiany automatycznie |

### Ekrany

Te dokumenty opisują to, co użytkownik widzi i wypełnia.

| Prefiks | Szablon | Dokument |
|---|---|---|
| SCR | screen | ekran |
| SCRSEC | screen-section | sekcja ekranu |

### Kontrakty

Te dokumenty opisują format i zasady komunikacji z elementem systemu.
Kontrakt wskazuje konwencję CONV, którą stosuje: `API-009 applies CONV-001`.

| Prefiks | Szablon | Dokument |
|---|---|---|
| API | api-endpoint | punkt końcowy |
| INT | integration | integracja z systemem zewnętrznym |
| QUE | asyncapi-event | kontrakt zdarzenia publikowanego przez brokera |
| CONV | convention | konwencja: zasady wspólne dla wielu kontraktów |

### Przepływy

Te dokumenty opisują kolejność kroków i wywołań. Przepływ FLOW zawiera
aktywności ACT. Proces BPMS w silniku Workflow wymienia zadania w wierszach
STEP, a złożone zadania opisują osobne pliki SPEC-WF.

| Prefiks | Szablon | Dokument |
|---|---|---|
| FLOW | flow | przepływ biznesowy lub techniczny |
| ACT | activity | aktywność przepływu |
| BPMS | bpms-process | proces w silniku Workflow |
| SPEC-WF | workflow-step | złożony krok procesu BPMS |

### Pojęcia i dane

Te dokumenty opisują, co znaczy pojęcie, jak wygląda w danych i jakie ma stany.

| Prefiks | Szablon | Dokument |
|---|---|---|
| DDM | ddm | domenowy model danych: znaczenie pojęć |
| LDM | ldm | logiczny model danych: indeks encji obszaru |
| ENT | ldm-entity | encja modelu logicznego |
| STM | state-machine | maszyna stanów: cykl życia obiektu |

### Mapy

Te dokumenty zestawiają inne dokumenty: powiązania między scenariuszami
i przejścia między ekranami.

| Prefiks | Szablon | Dokument |
|---|---|---|
| UCMAP | use-case-technical-map | mapa relacji między UC i TUC |
| NAV | navigation-map | mapa nawigacyjna ekranów |

### Architektura

Te dokumenty zapisują decyzje architektoniczne. Decyzja nie ma powiązań
z innymi typami. Jedyna jej relacja to `supersedes` do decyzji, którą
zastępuje. Status `deprecated` ma tylko ten typ.

| Prefiks | Szablon | Dokument |
|---|---|---|
| ADR | adr | zapis decyzji architektonicznej |

## 11. Układ katalogów

Dokumenty projektu leżą w folderze `project/` w głównym folderze repozytorium,
obok `standards/`. Folder dokumentu wynika z jego typu, a nie z procesu, który
go używa. Relacje i zapytania posługują się doc-id, więc miejsce pliku nie
zmienia ich wyniku. Plik `config/folders.yaml` mówi, w którym folderze leży
każdy typ dokumentu. Czytają go walidator formy (sprawdzenie FORM-06)
i warsztat dokumentacji.

Schemat folderów. Po prawej stronie są typy dokumentów, które leżą w danym
folderze:

```text
project/
  functional/                       co ma działać
    business-functional-specs/      BFS
    actors/                         ACTOR
    data-models/                    DDM
    use-cases/                      UC
    technical-use-cases/            TUC
    use-case-technical-map/         UCMAP
  system/                           jak system to robi
    capabilities/                   CAP
    apis/                           API
    integrations/                   INT
    asyncapi/                       QUE
    conventions/                    CONV
    non-functional-requirements/    NFR
    flows/                          FLOW, ACT
    state-machines/                 STM
    data-models/                    LDM, ENT
    gui/
      screens/
        {ekran}/                    SCR
          ui-specs/                 SCRSEC tego ekranu
        _shared/
          ui-specs/                 SCRSEC wspólne dla kilku ekranów
      navigation-maps/              NAV
    workflows/
      {proces}/                     BPMS
        steps/                      SPEC-WF
  architecture/                     decyzje
    decision-records/               ADR
```

### Podfoldery

Pod folderem typu wolno założyć jeden poziom podfolderów o dowolnej nazwie,
na przykład według procesu albo domeny: `system/apis/dyspozycje/`. Narzędzia
nie czytają z nazwy podfolderu żadnego znaczenia. Grupowanie liczą z relacji.
Wyjątki:

- Mapy nawigacji nie mają podfolderów.
- Ekran SCR leży w folderze nazwanym jak jego plik bez rozszerzenia:
  `system/gui/screens/zgloszenie-reklamacji/zgloszenie-reklamacji.md`.
- Sekcja SCRSEC leży w podfolderze `ui-specs/` folderu ekranu, który ma do
  niej wpis `contains`: `system/gui/screens/zgloszenie-reklamacji/ui-specs/`.
  Sekcja, którą zawiera więcej niż jeden ekran, leży w folderze wspólnym
  `system/gui/screens/_shared/ui-specs/`. Gdy liczba ekranów sekcji zmieni
  się z jednego na dwa albo z dwóch na jeden, plik trzeba przenieść. Relacje
  tego nie zauważają, bo wskazują doc-id.
- Proces BPMS leży w folderze nazwanym jak jego plik bez rozszerzenia:
  `system/workflows/rozliczenie-dyspozycji/rozliczenie-dyspozycji.md`.
- Kroki SPEC-WF leżą w podfolderze `steps/` folderu procesu, który ma do nich
  wpis `contains`: `system/workflows/rozliczenie-dyspozycji/steps/`.

### Nazwy plików

Nazwa pliku to skrót tytułu po polsku: małe litery bez polskich znaków, cyfry
i słowa połączone myślnikiem, bez prefiksu typu. Przykłady:
`walidacja-danych-klienta.md`, `zlozenie-dyspozycji.md`. Encja bierze nazwę
z doc-id: `ENT-Disposition` to `disposition.md`. Nazwa jest jedyna w całym
folderze typu, razem z jego podfolderami.

Doc-id zostaje we front matter pliku i jest kluczem relacji. Zmiana tytułu
zmienia nazwę pliku. Relacje tego nie zauważają, bo wskazują doc-id.

### Pliki pomocnicze

Makiety ekranów, pliki diagramów i eksporty leżą w podfolderze `assets/` obok
dokumentu i nazywają się tak jak plik dokumentu:
`assets/zgloszenie-reklamacji.png` obok `zgloszenie-reklamacji.md`,
`assets/rozliczenie-dyspozycji.bpmn` obok pliku procesu. Drugi obraz ekranu,
z zaznaczonymi sekcjami, ma dopisek `-sekcje`:
`assets/zgloszenie-reklamacji-sekcje.png`. Obraz sekcji leży w `assets/`
folderu `ui-specs/`, obok pliku sekcji: `ui-specs/assets/wybor-dyspozycji.png`.

### Przykłady w standardzie

Folder `standards/examples/` ma ten sam układ co `project/`, bez folderu
`project/` na początku: `standards/examples/functional/use-cases/…`.
