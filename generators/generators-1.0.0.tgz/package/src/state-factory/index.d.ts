import { Rule } from '@angular-devkit/schematics';
import { AddAsyncStateActionSchemaModel } from './models/add-async-state-action-schema-model';
import { AddStateActionSchemaModel } from './models/add-state-action-schema-model';
import { InitStateSchemaModel } from './models/init-state-schema-model';
export declare function initState(options: InitStateSchemaModel): Rule;
export declare function addStateAction(options: AddStateActionSchemaModel): Rule;
export declare function addAsyncStateAction(options: AddAsyncStateActionSchemaModel): Rule;
