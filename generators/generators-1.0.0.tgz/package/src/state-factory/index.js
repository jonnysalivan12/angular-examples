"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initState = initState;
exports.addStateAction = addStateAction;
exports.addAsyncStateAction = addAsyncStateAction;
const core_1 = require("@angular-devkit/core");
const strings_1 = require("@angular-devkit/core/src/utils/strings");
const schematics_1 = require("@angular-devkit/schematics");
const typescript_1 = require("typescript");
const ast_utils_1 = require("../utils/ast-utils");
const async_state_action_utils_1 = require("../utils/async-state-action-utils");
const schematics_utils_1 = require("../utils/schematics-utils");
const simple_state_action_utils_1 = require("../utils/simple-state-action-utils");
function initState(options) {
    return (_tree, _context) => {
        const templateSource = (0, schematics_1.apply)((0, schematics_1.url)('./files/init-state'), [
            (0, schematics_1.applyTemplates)({
                classify: schematics_1.strings.classify,
                dasherize: schematics_1.strings.dasherize,
                camelize: schematics_1.strings.camelize,
                name: options.name,
            }),
            (0, schematics_1.move)((0, core_1.normalize)(`${options.path}`)),
        ]);
        return (0, schematics_1.chain)([(0, schematics_1.mergeWith)(templateSource)]);
    };
}
function addStateAction(options) {
    return (tree, context) => __awaiter(this, void 0, void 0, function* () {
        const normalizedStateFolderPath = (0, core_1.normalize)(`${options.path}`);
        /* Add action */
        const actionTsFileName = schematics_utils_1.SchematicsUtils.findFileInDir(tree, normalizedStateFolderPath, '-actions.ts');
        if (!actionTsFileName) {
            throw new Error('*-actions.ts file not found!');
        }
        const actionTsFilePath = (0, core_1.normalize)(`${normalizedStateFolderPath}/${actionTsFileName}`);
        /* 'a.b.c -> ['a', 'b', 'c'] */
        const actionNestingNodesNames = options.name.split('.');
        /* 'a.b.c -> a */
        const topLevelActionNestingNodeName = actionNestingNodesNames.slice().shift();
        const actionPayloadModelName = schematics_utils_1.SchematicsUtils.createActionPayloadModelName(actionNestingNodesNames);
        const actionTsFileSourceFile = (0, typescript_1.createSourceFile)(actionTsFileName, tree.readText(actionTsFilePath), typescript_1.ScriptTarget.Latest);
        const [rootActionNestingNode] = (0, ast_utils_1.findNodes)(actionTsFileSourceFile, typescript_1.SyntaxKind.ModuleDeclaration, 1, false);
        const rootActionNestingNodeName = ((0, ast_utils_1.isNamedNode)(rootActionNestingNode) && rootActionNestingNode.name.escapedText) || '';
        const actionFullName = [rootActionNestingNodeName, ...actionNestingNodesNames].map(strings_1.classify).join('.');
        const nodeToUpdate = schematics_utils_1.SchematicsUtils.findActionNodeToUpdate(actionTsFileSourceFile, rootActionNestingNodeName, actionNestingNodesNames);
        const actionNodeNameToInsert = schematics_utils_1.SchematicsUtils.getActionNodeNameToInsert(nodeToUpdate, actionNestingNodesNames);
        const actionTsFileContentToUpdate = simple_state_action_utils_1.SimpleStateActionUtils.createActionNodes({
            actionNodeNameToInsert: actionNodeNameToInsert,
            context,
            withPayload: options.withPayload,
            rootActionNestingNodeName,
            topLevelActionNestingNodeName,
            typeDescription: schematics_utils_1.SchematicsUtils.toPlainText(actionNestingNodesNames.join('-')),
            payloadActonName: options.withPayload ? actionPayloadModelName : undefined,
        });
        const actionTsFileUpdateRecorder = tree.beginUpdate(actionTsFilePath);
        const actionTsFileInsertPosition = nodeToUpdate.end - 1;
        actionTsFileUpdateRecorder.insertLeft(actionTsFileInsertPosition, '\n' + actionTsFileContentToUpdate);
        /* Add payload */
        let actionPayloadModelSource = (0, schematics_1.empty)();
        if (options.withPayload) {
            actionPayloadModelSource = schematics_utils_1.SchematicsUtils.getPayloadModelSource(actionPayloadModelName, normalizedStateFolderPath, options.payloadContent, options.payloadImports);
            const importPosition = schematics_utils_1.SchematicsUtils.getImportPosition(actionTsFileSourceFile);
            const importContent = schematics_utils_1.SchematicsUtils.createImport(actionPayloadModelName, `./payloads/${(0, strings_1.dasherize)(actionPayloadModelName)}`);
            actionTsFileUpdateRecorder.insertLeft(importPosition, importContent + (importPosition ? '' : '\n'));
        }
        tree.commitUpdate(actionTsFileUpdateRecorder);
        yield schematics_utils_1.SchematicsUtils.formatFile(tree, actionTsFilePath);
        /* Add state method */
        yield simple_state_action_utils_1.SimpleStateActionUtils.updateState({
            tree,
            context,
            withPayload: options.withPayload,
            actionPayloadModelName,
            actionName: actionFullName,
            stateFolderPath: normalizedStateFolderPath,
            actionNestingNodesNames,
            actionContent: options.content,
        });
        /* Add action effect */
        if (options.withEffect) {
            yield simple_state_action_utils_1.SimpleStateActionUtils.updateEffect({
                tree,
                context,
                withPayload: options.withPayload,
                stateFolderPath: normalizedStateFolderPath,
                actionPayloadModelName,
                actionNestingNodesNames,
                actionName: actionFullName,
            });
        }
        return (0, schematics_1.chain)([(0, schematics_1.mergeWith)(actionPayloadModelSource)]);
    });
}
function addAsyncStateAction(options) {
    return (tree, context) => __awaiter(this, void 0, void 0, function* () {
        const normalizedStateFolderPath = (0, core_1.normalize)(`${options.path}`);
        /* Add action */
        const actionTsFileName = schematics_utils_1.SchematicsUtils.findFileInDir(tree, normalizedStateFolderPath, '-actions.ts');
        if (!actionTsFileName) {
            throw new Error('*-actions.ts file not found!');
        }
        const actionTsFilePath = (0, core_1.normalize)(`${normalizedStateFolderPath}/${actionTsFileName}`);
        /* 'a.b.c -> ['a', 'b', 'c'] */
        const actionNestingNodesNames = options.name.split('.');
        const actionPayloadModelName = schematics_utils_1.SchematicsUtils.createActionPayloadModelName(actionNestingNodesNames);
        const actionTsFileSourceFile = (0, typescript_1.createSourceFile)(actionTsFileName, tree.readText(actionTsFilePath), typescript_1.ScriptTarget.Latest);
        const [rootActionNestingNode] = (0, ast_utils_1.findNodes)(actionTsFileSourceFile, typescript_1.SyntaxKind.ModuleDeclaration, 1, false);
        const rootActionNestingNodeName = ((0, ast_utils_1.isNamedNode)(rootActionNestingNode) && rootActionNestingNode.name.escapedText) || '';
        const actionFullName = [rootActionNestingNodeName, ...actionNestingNodesNames].map(strings_1.classify).join('.');
        yield async_state_action_utils_1.AsyncStateActionUtils.updateEffect({
            tree,
            context,
            requestWithPayload: options.requestWithPayload,
            successWithPayload: options.successWithPayload,
            failureWithPayload: options.failureWithPayload,
            stateFolderPath: normalizedStateFolderPath,
            actionPayloadModelName,
            actionNestingNodesNames,
            actionName: actionFullName,
        });
        return (0, schematics_1.chain)([
            (0, schematics_1.externalSchematic)('generators', 'add-state-action', {
                name: `${options.name}.request`,
                path: options.path,
                withPayload: options.requestWithPayload,
                withEffect: false,
            }),
            (0, schematics_1.externalSchematic)('generators', 'add-state-action', {
                name: `${options.name}.success`,
                path: options.path,
                withPayload: options.successWithPayload,
                withEffect: false,
            }),
            (0, schematics_1.externalSchematic)('generators', 'add-state-action', {
                name: `${options.name}.failure`,
                path: options.path,
                withPayload: options.failureWithPayload,
                withEffect: false,
            }),
        ]);
    });
}
//# sourceMappingURL=index.js.map