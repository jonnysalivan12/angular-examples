import { EndpointOptions } from '../schema';
export interface ApiRequestConfig {
    requestEntityPrefix: string;
    requestName: string;
    requestHandlerName: string;
    requestPath: string;
    hasPathParam: boolean;
    hasRequestBody: boolean;
    pathParams: any[];
}
export declare namespace ProcessApiRequestUtils {
    function processApiRequest(options: EndpointOptions, projectNamePath: string): Promise<ApiRequestConfig>;
}
