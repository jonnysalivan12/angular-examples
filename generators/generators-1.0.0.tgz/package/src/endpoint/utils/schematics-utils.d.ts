import { Tree } from '@angular-devkit/schematics';
export declare namespace SchematicsUtils {
    function getProjectPath(tree: Tree, projectName: string): Promise<string | undefined>;
}
