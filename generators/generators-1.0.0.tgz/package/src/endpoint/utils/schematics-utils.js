"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchematicsUtils = void 0;
const workspace_1 = require("@schematics/angular/utility/workspace");
var SchematicsUtils;
(function (SchematicsUtils) {
    function getProjectPath(tree, projectName) {
        return __awaiter(this, void 0, void 0, function* () {
            const workspace = yield (0, workspace_1.getWorkspace)(tree);
            const project = workspace.projects.get(projectName);
            if (project) {
                return project.sourceRoot;
            }
            else {
                return undefined;
            }
        });
    }
    SchematicsUtils.getProjectPath = getProjectPath;
})(SchematicsUtils || (exports.SchematicsUtils = SchematicsUtils = {}));
//# sourceMappingURL=schematics-utils.js.map