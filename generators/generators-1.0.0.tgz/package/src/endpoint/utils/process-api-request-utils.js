"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessApiRequestUtils = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const strings_1 = require("@angular-devkit/core/src/utils/strings");
const schema_1 = require("../schema");
const requestRootFolder = 'app/api/request';
const pathSplitter = '/';
const leftBracket = '{';
const rightBracket = '}';
var ProcessApiRequestUtils;
(function (ProcessApiRequestUtils) {
    function processApiRequest(options, projectNamePath) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!options) {
                throw new schematics_1.SchematicsException('Options not defined but required.');
            }
            const basePath = `${projectNamePath}/${requestRootFolder}`;
            const pathParamParts = replacePathParam(options.url);
            const baseUrl = pathParamParts.url;
            const pathSegments = baseUrl.split(pathSplitter).map(strings_1.dasherize);
            const requestName = pathSegments.pop() || '';
            const requestUrl = pathSegments.join(pathSplitter);
            const requestNamePart = [options.method.toLowerCase(), ...pathSegments, requestName].join('_').replace('/', '');
            return {
                hasPathParam: !!pathParamParts.params.length,
                requestName,
                pathParams: pathParamParts.params,
                hasRequestBody: [schema_1.HttpMethod.POST, schema_1.HttpMethod.PUT].includes(options.method),
                requestEntityPrefix: (0, strings_1.classify)(requestNamePart),
                requestHandlerName: (0, strings_1.camelize)(requestNamePart),
                requestPath: [basePath, options.method.toLowerCase(), requestUrl, requestName]
                    .join(pathSplitter)
                    .replace('//', '/'),
            };
        });
    }
    ProcessApiRequestUtils.processApiRequest = processApiRequest;
})(ProcessApiRequestUtils || (exports.ProcessApiRequestUtils = ProcessApiRequestUtils = {}));
function replacePathParam(url, params = []) {
    let pathParamParts = { url, params };
    if (!url.includes(leftBracket)) {
        return pathParamParts;
    }
    const leftBracketIndex = url.indexOf(leftBracket);
    const rightBracketIndex = url.indexOf(rightBracket);
    const param = url.slice(leftBracketIndex + 1, rightBracketIndex);
    const replacedUrl = url.replace(leftBracket + param + rightBracket, param);
    pathParamParts = {
        url: replacedUrl,
        params: [...params, param],
    };
    return replacePathParam(pathParamParts.url, pathParamParts.params);
}
//# sourceMappingURL=process-api-request-utils.js.map