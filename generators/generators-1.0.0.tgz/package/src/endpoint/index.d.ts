import { Rule } from '@angular-devkit/schematics';
import { EndpointOptions } from './schema';
export declare function chooseType(hasType: boolean, type: string, defaultType?: string): string;
export declare function endpoint(endpointOptions: EndpointOptions): Rule;
