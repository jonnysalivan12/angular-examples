"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.chooseType = chooseType;
exports.endpoint = endpoint;
const schematics_1 = require("@angular-devkit/schematics");
const schematics_utils_1 = require("./utils/schematics-utils");
const process_api_request_utils_1 = require("./utils/process-api-request-utils");
function chooseType(hasType, type, defaultType = 'void') {
    return hasType ? type : defaultType;
}
function endpoint(endpointOptions) {
    return (tree, _context) => __awaiter(this, void 0, void 0, function* () {
        const projectNamePath = yield schematics_utils_1.SchematicsUtils.getProjectPath(tree, endpointOptions.projectName);
        if (!projectNamePath) {
            throw new schematics_1.SchematicsException('projectNamePath not defined but required.');
        }
        const apiRequestConfig = yield process_api_request_utils_1.ProcessApiRequestUtils.processApiRequest(endpointOptions, projectNamePath);
        const apiRequestSource = (0, schematics_1.apply)((0, schematics_1.url)('./files/api'), [
            (0, schematics_1.applyTemplates)(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, schematics_1.strings), { name: apiRequestConfig.requestName }), endpointOptions), apiRequestConfig), { chooseType })),
            (0, schematics_1.forEach)((fileEntry) => {
                const prettyFile = fileEntry.content.toString()
                    .split(new RegExp('[\r\n]{2,}'))
                    .filter(Boolean)
                    .join('\r\n')
                    .split('export')
                    .join('\r\nexport')
                    .concat('\r\n');
                return {
                    path: fileEntry.path,
                    content: new Buffer(prettyFile),
                };
            }),
            (0, schematics_1.move)(apiRequestConfig.requestPath),
        ]);
        const apiRequestRule = (0, schematics_1.mergeWith)(apiRequestSource);
        return (0, schematics_1.chain)([apiRequestRule]);
    });
}
//# sourceMappingURL=index.js.map