import { SchematicContext, Tree } from '@angular-devkit/schematics';
interface CreateEffectNodeOptions {
    context: SchematicContext;
    requestWithPayload: boolean;
    successWithPayload: boolean;
    failureWithPayload: boolean;
    effectName: string;
    actionName: string;
}
interface UpdateEffectOptions {
    tree: Tree;
    context: SchematicContext;
    stateFolderPath: string;
    requestWithPayload: boolean;
    successWithPayload: boolean;
    failureWithPayload: boolean;
    actionPayloadModelName: string;
    actionName: string;
    actionNestingNodesNames: string[];
}
export declare namespace AsyncStateActionUtils {
    function updateEffect(options: UpdateEffectOptions): Promise<void>;
    function createEffectNode(options: CreateEffectNodeOptions): string;
}
export {};
