import { PathFragment } from '@angular-devkit/core';
import { SchematicContext, Source, Tree } from '@angular-devkit/schematics';
import { BuiltInParserName, LiteralUnion } from 'prettier';
import { Node, SourceFile } from 'typescript';
export declare namespace SchematicsUtils {
    function getImportPosition(sourceFile: SourceFile): number;
    function createImport(modelName: string, path: string): string;
    function formatFile(tree: Tree, filepath: string, parser?: LiteralUnion<BuiltInParserName>): Promise<void>;
    function toPlainText(str: string): string;
    function getPayloadModelSource(name: string, path: string, content: string | undefined, imports: string | undefined): Source;
    function findFileInDir(tree: Tree, folderPath: string, pattern: string): PathFragment | undefined;
    function findActionNodeToUpdate(sourceFile: SourceFile, rootActionNodeName: string, actionNodesNames: string[]): Node;
    function getActionNodeNameToInsert(node: Node, actionNodesNames: string[]): string[];
    function createActionPayloadModelName(actionNestingNodesNames: string[]): string;
    function resolveTemplateContent<T = unknown>(templatePath: string, context: SchematicContext, options: T): string;
    function findActionNodeToUpdatingFromSource(node: Node, _actionsNestingNames: string[]): Node;
}
