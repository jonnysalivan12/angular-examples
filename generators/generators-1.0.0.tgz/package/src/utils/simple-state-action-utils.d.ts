import { SchematicContext, Tree } from '@angular-devkit/schematics';
interface ResolveActionStructureModel {
    context: SchematicContext;
    withPayload: boolean;
    rootActionNestingNodeName: string;
    topLevelActionNestingNodeName?: string;
    typeDescription: string;
    payloadActonName?: string | undefined;
    actionNodeNameToInsert: string[];
}
interface CreateEffectNodeOptions {
    context: SchematicContext;
    withPayload: boolean;
    effectName: string;
    actionName: string;
    actionPayloadModelName: string;
}
interface CreateStateActionMethodNodeOption {
    context: SchematicContext;
    withPayload: boolean;
    actionName: string;
    methodName: string;
    stateModeName: string;
    actionPayloadName: string;
    actionContent: string | undefined;
}
interface UpdateEffectOptions {
    tree: Tree;
    context: SchematicContext;
    stateFolderPath: string;
    withPayload: boolean;
    actionPayloadModelName: string;
    actionName: string;
    actionNestingNodesNames: string[];
}
interface UpdateStateOption {
    tree: Tree;
    context: SchematicContext;
    stateFolderPath: string;
    withPayload: boolean;
    actionPayloadModelName: string;
    actionName: string;
    actionNestingNodesNames: string[];
    actionContent: string | undefined;
}
export declare namespace SimpleStateActionUtils {
    function updateEffect(options: UpdateEffectOptions): Promise<void>;
    function updateState(options: UpdateStateOption): Promise<void>;
    function createActionNodes(options: ResolveActionStructureModel): string;
    function createEffectNode(options: CreateEffectNodeOptions): string;
    function createStateActionMethodNode(options: CreateStateActionMethodNodeOption): string;
}
export {};
