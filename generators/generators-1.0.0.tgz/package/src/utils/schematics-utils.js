"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchematicsUtils = void 0;
const core_1 = require("@angular-devkit/core");
const strings_1 = require("@angular-devkit/core/src/utils/strings");
const schematics_1 = require("@angular-devkit/schematics");
const prettier = require("prettier");
const typescript_1 = require("typescript");
const url_1 = require("url");
const ast_utils_1 = require("./ast-utils");
var SchematicsUtils;
(function (SchematicsUtils) {
    function getImportPosition(sourceFile) {
        const importNodes = (0, ast_utils_1.findNodes)(sourceFile, typescript_1.SyntaxKind.ImportDeclaration, 9999, false);
        const lastImport = importNodes.slice().pop();
        return lastImport ? lastImport.end : 0;
    }
    SchematicsUtils.getImportPosition = getImportPosition;
    function createImport(modelName, path) {
        return `import { ${(0, strings_1.classify)(modelName)} } from '${path}';\n`;
    }
    SchematicsUtils.createImport = createImport;
    function formatFile(tree_1, filepath_1) {
        return __awaiter(this, arguments, void 0, function* (tree, filepath, parser = 'typescript') {
            const content = yield prettier.format(tree.readText(filepath), {
                filepath,
                singleQuote: true,
                tabWidth: 2,
                printWidth: 140,
                semi: true,
                useTabs: false,
                arrowParens: 'always',
                trailingComma: 'all',
                bracketSpacing: true,
                bracketSameLine: false,
                singleAttributePerLine: true,
                parser,
            });
            tree.overwrite(filepath, content);
        });
    }
    SchematicsUtils.formatFile = formatFile;
    function toPlainText(str) {
        return (0, strings_1.dasherize)(str).replaceAll(/-/g, ' ');
    }
    SchematicsUtils.toPlainText = toPlainText;
    function getPayloadModelSource(name, path, content, imports) {
        return (0, schematics_1.apply)((0, schematics_1.url)('./files/common/models'), [
            (0, schematics_1.applyTemplates)({
                classify: schematics_1.strings.classify,
                dasherize: schematics_1.strings.dasherize,
                name,
                content,
                imports,
            }),
            (0, schematics_1.move)((0, core_1.normalize)(`${path}/payloads`)),
        ]);
    }
    SchematicsUtils.getPayloadModelSource = getPayloadModelSource;
    function findFileInDir(tree, folderPath, pattern) {
        const dir = tree.getDir(folderPath);
        return dir.subfiles.find((fragment) => fragment.endsWith(pattern));
    }
    SchematicsUtils.findFileInDir = findFileInDir;
    function findActionNodeToUpdate(sourceFile, rootActionNodeName, actionNodesNames) {
        const fullActionNestingItems = [rootActionNodeName, ...actionNodesNames].slice().reverse().splice(1).reverse().map(strings_1.classify);
        return findActionNodeToUpdatingFromSource(sourceFile, fullActionNestingItems);
    }
    SchematicsUtils.findActionNodeToUpdate = findActionNodeToUpdate;
    function getActionNodeNameToInsert(node, actionNodesNames) {
        if (!(0, ast_utils_1.isNamedNode)(node)) {
            throw new Error('Node has not name, but required!');
        }
        const actionNodeName = node.name.escapedText;
        const index = actionNodesNames.map(strings_1.classify).indexOf(actionNodeName) + 1;
        return actionNodesNames.slice().map(strings_1.classify).splice(index);
    }
    SchematicsUtils.getActionNodeNameToInsert = getActionNodeNameToInsert;
    function createActionPayloadModelName(actionNestingNodesNames) {
        return (0, strings_1.classify)([...actionNestingNodesNames, 'payload'].join('-'));
    }
    SchematicsUtils.createActionPayloadModelName = createActionPayloadModelName;
    function resolveTemplateContent(templatePath, context, options) {
        const schematicsTree = context.engine.createSourceFromUrl((0, url_1.parse)('./'), context)(context);
        const decoder = new TextDecoder('utf-8', { fatal: true });
        const entry = schematicsTree.get(templatePath);
        if (!entry) {
            throw new Error('entry is NULL');
        }
        return (0, core_1.template)(decoder.decode(entry.content).replace(/\n/, ''))(options);
    }
    SchematicsUtils.resolveTemplateContent = resolveTemplateContent;
    function findActionNodeToUpdatingFromSource(node, _actionsNestingNames) {
        const action = _actionsNestingNames && _actionsNestingNames[0];
        if (!action) {
            return node;
        }
        const findResult = (0, ast_utils_1.findNodeByName)(node, typescript_1.SyntaxKind.ModuleDeclaration, action);
        if (findResult) {
            return findActionNodeToUpdatingFromSource(findResult, _actionsNestingNames.slice().splice(1));
        }
        return node;
    }
    SchematicsUtils.findActionNodeToUpdatingFromSource = findActionNodeToUpdatingFromSource;
})(SchematicsUtils || (exports.SchematicsUtils = SchematicsUtils = {}));
//# sourceMappingURL=schematics-utils.js.map