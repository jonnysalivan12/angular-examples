"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AsyncStateActionUtils = void 0;
const core_1 = require("@angular-devkit/core");
const strings_1 = require("@angular-devkit/core/src/utils/strings");
const schematics_1 = require("@angular-devkit/schematics");
const typescript_1 = require("typescript");
const ast_utils_1 = require("./ast-utils");
const schematics_utils_1 = require("./schematics-utils");
var AsyncStateActionUtils;
(function (AsyncStateActionUtils) {
    function updateEffect(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const effectTsFileName = schematics_utils_1.SchematicsUtils.findFileInDir(options.tree, options.stateFolderPath, '-effects.service.ts');
            if (!effectTsFileName) {
                throw new Error('*-effects.service.ts file not found!');
            }
            const effectTsFilePath = (0, core_1.normalize)(`${options.stateFolderPath}/${effectTsFileName}`);
            const effectName = `init${(0, strings_1.classify)(options.actionNestingNodesNames.join('-'))}RequestEffect`;
            const effectTsFileContentToUpdate = createEffectNode({
                context: options.context,
                requestWithPayload: options.requestWithPayload,
                successWithPayload: options.successWithPayload,
                failureWithPayload: options.failureWithPayload,
                actionName: options.actionName,
                effectName,
            });
            const effectTsFileSourceFile = (0, typescript_1.createSourceFile)(effectTsFileName, options.tree.readText(effectTsFilePath), typescript_1.ScriptTarget.Latest);
            const [rootEffectNode] = (0, ast_utils_1.findNodes)(effectTsFileSourceFile, typescript_1.SyntaxKind.ClassDeclaration, 1, false);
            const effectTsFileUpdateRecorder = options.tree.beginUpdate(effectTsFilePath);
            const effectTsFileInsertPosition = rootEffectNode.end - 1;
            effectTsFileUpdateRecorder.insertLeft(effectTsFileInsertPosition, '\n' + effectTsFileContentToUpdate);
            options.tree.commitUpdate(effectTsFileUpdateRecorder);
            yield schematics_utils_1.SchematicsUtils.formatFile(options.tree, effectTsFilePath);
        });
    }
    AsyncStateActionUtils.updateEffect = updateEffect;
    function createEffectNode(options) {
        return schematics_utils_1.SchematicsUtils.resolveTemplateContent('files/add-async-state-action/async-action-effect.template', options.context, {
            camelize: schematics_1.strings.camelize,
            requestWithPayload: options.requestWithPayload,
            successWithPayload: options.successWithPayload,
            failureWithPayload: options.failureWithPayload,
            effectName: options.effectName,
            actionName: options.actionName,
        });
    }
    AsyncStateActionUtils.createEffectNode = createEffectNode;
})(AsyncStateActionUtils || (exports.AsyncStateActionUtils = AsyncStateActionUtils = {}));
//# sourceMappingURL=async-state-action-utils.js.map