"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimpleStateActionUtils = void 0;
const core_1 = require("@angular-devkit/core");
const strings_1 = require("@angular-devkit/core/src/utils/strings");
const schematics_1 = require("@angular-devkit/schematics");
const typescript_1 = require("typescript");
const ast_utils_1 = require("./ast-utils");
const schematics_utils_1 = require("./schematics-utils");
var SimpleStateActionUtils;
(function (SimpleStateActionUtils) {
    function updateEffect(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const effectTsFileName = schematics_utils_1.SchematicsUtils.findFileInDir(options.tree, options.stateFolderPath, '-effects.service.ts');
            if (!effectTsFileName) {
                throw new Error('*-effects.service.ts file not found!');
            }
            const effectTsFilePath = (0, core_1.normalize)(`${options.stateFolderPath}/${effectTsFileName}`);
            const effectName = `init${(0, strings_1.classify)(options.actionNestingNodesNames.join('-'))}Effect`;
            const effectTsFileContentToUpdate = SimpleStateActionUtils.createEffectNode({
                context: options.context,
                withPayload: options.withPayload,
                actionName: options.actionName,
                actionPayloadModelName: options.actionPayloadModelName,
                effectName,
            });
            const effectTsFileSourceFile = (0, typescript_1.createSourceFile)(effectTsFileName, options.tree.readText(effectTsFilePath), typescript_1.ScriptTarget.Latest);
            const [rootEffectNode] = (0, ast_utils_1.findNodes)(effectTsFileSourceFile, typescript_1.SyntaxKind.ClassDeclaration, 1, false);
            const effectTsFileUpdateRecorder = options.tree.beginUpdate(effectTsFilePath);
            const effectTsFileInsertPosition = rootEffectNode.end - 1;
            effectTsFileUpdateRecorder.insertLeft(effectTsFileInsertPosition, '\n' + effectTsFileContentToUpdate);
            if (options.withPayload) {
                const importPosition = schematics_utils_1.SchematicsUtils.getImportPosition(effectTsFileSourceFile);
                const importContent = schematics_utils_1.SchematicsUtils.createImport(options.actionPayloadModelName, `./payloads/${(0, strings_1.dasherize)(options.actionPayloadModelName)}`);
                effectTsFileUpdateRecorder.insertLeft(importPosition, importContent + (importPosition ? '' : '\n'));
            }
            options.tree.commitUpdate(effectTsFileUpdateRecorder);
            yield schematics_utils_1.SchematicsUtils.formatFile(options.tree, effectTsFilePath);
        });
    }
    SimpleStateActionUtils.updateEffect = updateEffect;
    function updateState(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const stateTsFileName = schematics_utils_1.SchematicsUtils.findFileInDir(options.tree, options.stateFolderPath, '-state.ts');
            if (!stateTsFileName) {
                throw new Error('*-state.ts file not found!');
            }
            const stateTsFilePath = (0, core_1.normalize)(`${options.stateFolderPath}/${stateTsFileName}`);
            const stateTsFileSourceFile = (0, typescript_1.createSourceFile)(stateTsFileName, options.tree.readText(stateTsFilePath), typescript_1.ScriptTarget.Latest);
            const [rootStateNode] = (0, ast_utils_1.findNodes)(stateTsFileSourceFile, typescript_1.SyntaxKind.ClassDeclaration, 1, false);
            if (!(0, ast_utils_1.isNamedNode)(rootStateNode)) {
                throw new Error('Node has not name, but required!');
            }
            const stateName = rootStateNode.name.escapedText;
            const methodName = (0, strings_1.camelize)(options.actionNestingNodesNames.join('-'));
            const stateTsFileContentToUpdate = SimpleStateActionUtils.createStateActionMethodNode({
                context: options.context,
                withPayload: options.withPayload,
                actionName: options.actionName,
                stateModeName: `${stateName}Model`,
                methodName,
                actionPayloadName: options.actionPayloadModelName,
                actionContent: options.actionContent,
            });
            const stateTsFileUpdateRecorder = options.tree.beginUpdate(stateTsFilePath);
            const stateTsFileInsertPosition = rootStateNode.end - 1;
            stateTsFileUpdateRecorder.insertLeft(stateTsFileInsertPosition, '\n' + stateTsFileContentToUpdate);
            options.tree.commitUpdate(stateTsFileUpdateRecorder);
            yield schematics_utils_1.SchematicsUtils.formatFile(options.tree, stateTsFilePath);
        });
    }
    SimpleStateActionUtils.updateState = updateState;
    function createActionNodes(options) {
        const currentFragmentName = options.actionNodeNameToInsert[0];
        const nextFragmentName = options.actionNodeNameToInsert[1];
        if (nextFragmentName) {
            const content = createActionNodes({
                context: options.context,
                withPayload: options.withPayload,
                rootActionNestingNodeName: options.rootActionNestingNodeName,
                topLevelActionNestingNodeName: options.topLevelActionNestingNodeName,
                typeDescription: options.typeDescription,
                payloadActonName: options.payloadActonName,
                actionNodeNameToInsert: options.actionNodeNameToInsert.slice().splice(1),
            });
            return schematics_utils_1.SchematicsUtils.resolveTemplateContent('files/common/namespace.template', options.context, {
                classify: schematics_1.strings.classify,
                name: currentFragmentName,
                content,
            });
        }
        return schematics_utils_1.SchematicsUtils.resolveTemplateContent('files/add-state-action/simple-action.template', options.context, {
            classify: schematics_1.strings.classify,
            dasherize: schematics_1.strings.dasherize,
            withPayload: options.withPayload,
            name: currentFragmentName,
            rootActionNestingNodeName: options.rootActionNestingNodeName,
            topLevelActionNestingNodeName: options.topLevelActionNestingNodeName,
            typeDescription: options.typeDescription,
            payloadActonName: options.payloadActonName,
        });
    }
    SimpleStateActionUtils.createActionNodes = createActionNodes;
    function createEffectNode(options) {
        return schematics_utils_1.SchematicsUtils.resolveTemplateContent('files/add-state-action/simple-action-effect.template', options.context, {
            camelize: schematics_1.strings.camelize,
            withPayload: options.withPayload,
            effectName: options.effectName,
            actionName: options.actionName,
            actionPayloadName: options.actionPayloadModelName,
        });
    }
    SimpleStateActionUtils.createEffectNode = createEffectNode;
    function createStateActionMethodNode(options) {
        return schematics_utils_1.SchematicsUtils.resolveTemplateContent('files/add-state-action/simple-action-patch-state-method.template', options.context, {
            camelize: schematics_1.strings.camelize,
            withPayload: options.withPayload,
            actionName: options.actionName,
            methodName: options.methodName,
            stateModeName: options.stateModeName,
            actionPayloadName: options.actionPayloadName,
            actionContent: options.actionContent,
        });
    }
    SimpleStateActionUtils.createStateActionMethodNode = createStateActionMethodNode;
})(SimpleStateActionUtils || (exports.SimpleStateActionUtils = SimpleStateActionUtils = {}));
//# sourceMappingURL=simple-state-action-utils.js.map